<?
include "libs.php";
include "head2.php";

if(!$id) {
	echo("
		<script>
			window.alert('잘못된 접근입니다.')
			history.go(-1)
		</script>
	");
	exit;
}
if(!$no) {
	echo("
		<script>
			window.alert('잘못된 접근입니다.')
			history.go(-1)
		</script>
	");
	exit;
}
?>
<div class="boards_header">
	<p style="float:left;">댓글삭제</p>
	<p style="float:right;text-align:right;">
<? if(!$dlog[no]) {?>
		<a href="login.php">로그인</a>
		&nbsp;
		<a href="join.php">회원가입</a>
<? }else{?>
		<span style="font-weight:bold;"><?=$dlog[name]?></span>님 환영합니다.
<? }?>
	</p>
</div>
<form action="board_comment_del_post.php" method="post">
<input type="hidden" name="id" value="<?=$id?>" />
<input type="hidden" name="no" value="<?=$no?>" />
<input type="hidden" name="ano" value="<?=$ano?>" />
<table cellpadding="7" cellspacing="0" class="boards" style="margin:0 auto;width:300px;">
  <tr class="boards_t">
    <th colspan="2">비밀번호를 입력해주세요</th>
  </tr>
  <tr>
    <td><input type="password" name="passz" /></td>
    <td><input type="submit" value="입력" /></td>
  </tr>
</table>
</form>
<?
include "foot2.php";
?>
