<?
include "libs.php";
if($_GET[id] == "notice1")
  include "head5.php";
else
  include "head2.php";

if(!$id) {
	echo("
		<script>
			window.alert('잘못된 접근입니다.')
			history.go(-1)
		</script>
	");
	exit;
}

if(!$dlog[no]) {
	$oldl = "1";
}else{
	$oldl = $dlog[level];
}
if($oldl < $dadmin[level_write]) {
	echo("
		<script>
			window.alert('권한이 없습니다.')
			history.go(-1)
		</script>
	");
	exit;
}

$qedit = "select * from ho_board_data where no='$no' and id='$id'";
$redit = mysql_query($qedit, $connect);
$dedit = mysql_fetch_array($redit);
?>
<div class="boards_header">
	<p style="float:left;">수정하기</p>
	<p style="float:right;text-align:right;">
<? if(!$dlog[no]) {?>
		<a href="login.php">로그인</a>
		&nbsp;
		<a href="join.php">회원가입</a>
<? }else{?>
		<span style="font-weight:bold;"><?=$dlog[name]?></span>님 환영합니다.
<? }?>
	</p>
</div>

<?
if($dedit[secret] == 1) {
	$tem = 1;
}

if($dlog[no]) {
  $passz = $dlog[password];
  }

$passzs = md5($passz);

if($dlog[level] != 3) {
if($dedit[secret] == 1) {
if($passz) {
if($passzs == $dedit[password]) {
  $dedit[secret] = 0;
  }else{
    echo("
      <script>
        window.alert('비밀번호가 다릅니다.')
        history.go(-1)
      </script>
    ");
    exit;
    }
}}
}else{
	$dedit[secret] = 0;
}
if($dedit[secret] != 1) {
?>


<form name="ed_b" action="board_edit_post.php" method="post">
<input type="hidden" name="id" value="<?=$dedit[id]?>" />
<input type="hidden" name="no" value="<?=$dedit[no]?>" />
<table cellpadding="7" cellspacing="0" class="boards">
<col width="80" />
<col width="420" />
	<tr class="boards_t">
		<th style="background:#d5e9ff;">제목</th>
		<th><input type="text" name="subject" value="<?=$dedit[subject]?>" style="width:412px;height:25px;line-height:25px;" /></th>
	</tr>
	<tr>
		<th style="background:#d5e9ff;border:none;border-bottom:1px solid #A0A0A0;">비밀글</th>
		<td style="padding:0 0 0 3px;"><input type="checkbox" name="secret" value="1" style="width:15px;height:15px;border:0px;" <? if($tem == 1) {?>checked<? }?> /> 본인과 관리자만 볼 수 있습니다.</td>
	</tr>
	<tr <? if($dlog[no]) {?>style="display:none;"<? }?>>
		<th style="background:#d5e9ff;border:none;border-bottom:1px solid #A0A0A0;">이름</th>
		<td style="padding:0 0 0 3px;"><input type="text" name="name" value="<?=$dedit[name]?>" /></td>
	</tr>
	<tr <? if($dlog[no]) {?>style="display:none;"<? }?>>
		<th style="background:#d5e9ff;border:none;border-bottom:1px solid #A0A0A0;">비밀번호</th>
		<td style="padding:0 0 0 3px;"><input type="password" name="passworde" value="<?=$dlog[password]?>" /></td>
	</tr>
	</table>
<table cellpadding="7" cellspacing="0" style="width:100%;">
	<tr>
		<td align="center"><textarea name="memo" rows="100" cols="100" id="b_memo"><?=$dedit[memo]?></textarea></textarea></td>
	</tr>
</table>
<div class="boards_b">
	<div class="boards_bl">
		<a href="board.php?id=<?=$id?>" style="background:url(./images/home_boardbutton1.jpg) no-repeat left top;"></a>
	</div>
	<div class="boards_br">
		<input type="button" onclick="submits2();" value="&nbsp;" style="background:url(./images/home_editb.jpg) no-repeat left top;" />
	</div>
</div>
</form>
<?
}else{
?>
<form action="<?=$PHP_SELF?>" method="post">
<input type="hidden" name="id" value="<?=$id?>" />
<input type="hidden" name="no" value="<?=$no?>" />
<input type="hidden" name="page" value="<?=$page?>" />
<table cellpadding="7" cellspacing="0" class="boards" style="margin:0 auto;width:300px;">
  <tr class="boards_t">
    <th colspan="2">비밀글입니다 비밀번호를 입력해주세요</th>
  </tr>
  <tr>
    <td><input type="password" name="passz" /></td>
    <td><input type="submit" value="입력" /></td>
  </tr>
</table>
</form>
<?
}
?>
<?
include "foot2.php";
?>
