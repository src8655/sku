<?
include "lib.php";

if($Search_mode) {
  if($Search_mode == 1) $tmp = "company";
  if($Search_mode == 2) $tmp = "addr";
  
  $where = "where $tmp like '%$Search_text%'";
  }else{
    $where = "";
    }

if(!$page) $page = 1;


$qinfo = "select count(*) from min_board_info $where";
$rinfo = mysql_query($qinfo, $connect);
$dinfo = mysql_fetch_array($rinfo);
$infocount = $dinfo[0];

$lim1 = "10";
$lim2 = $lim1*$page-$lim1;

$pageing = ceil($infocount/$lim1);

$pa1 = $page-2;
$pa2 = $page+2;

$query = "select * from min_board_info $where order by company asc limit $lim2, $lim1";
$result = mysql_query($query, $connect);
?>
<?
while($data = mysql_fetch_array($result)) {
?>
  <info>
      <company><?=$data[company]?></company>
<? if($data[addr]) {?>
      <data>[지번]주소 : <?=$data[addr]?></data>
<? }?>
<? if($data[addr2]) {?>
      <data>[도로명]주소 : <?=$data[addr2]?></data>
<? }?>
<? if($data[tel1]||$data[tel2]||$data[tel3]) {?>
      <data>전화번호 : <?=$data[tel1]?> - <?=$data[tel2]?> - <?=$data[tel3]?></data>
<? }?>
<? if($data[fax1]||$data[fax2]||$data[fax3]) {?>
      <data>FAX번호 : <?=$data[fax1]?> - <?=$data[fax2]?> - <?=$data[fax3]?></data>
<? }?>
<? if($data[email]) {?>
      <data>이메일 : <?=$data[email]?></data>
<? }?>
<? if($data[name]||$data[phone1]||$data[phone2]||$data[phone3]) {?>
      <data>담당자 : <?=$data[name]?> 담당자번호 : <?=$data[phone1]?> - <?=$data[phone2]?> - <?=$data[phone3]?></data>
<? }?>
<?
if($plus == $data[no]) {
}
$quer = "select * from min_board_info_plus where id='$data[no]' order by no desc";
$reer = mysql_query($quer, $connect);
while($daer = mysql_fetch_array($reer)) {
?>
			<data>담당자 : <?=$daer[name]?> 담당자번호 : <?=$daer[phone1]?> - <?=$daer[phone2]?> - <?=$daer[phone3]?></data>
<?
}
?>
<? if($data[memo]) {?>
      <data>메모 : <?=$data[memo]?></data>
<? }?>
    </info>
<?
}
?>