<?
include "libs.php";
include "head2.php";
?>
<div id="home_comw">
	<div id="home_com2" style="background:none;width:483px;padding:12px 5px 20px 10px;">
		<p><img src="./images/home_comh2.jpg" alt="로타리종합물류" /></p>
	</div>
</div>
<?
include "foot2.php";
?>
