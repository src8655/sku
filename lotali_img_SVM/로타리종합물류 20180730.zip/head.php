<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>로타리종합물류</title>
<link rel="stylesheet" type="text/css" href="mmsm.css" />
<link rel="shortcut icon" href="./images/ic_launcher.png" />
</head>
<body>
<div id="header">
	<ul id="tmenu">
		<li><a href="map.php?id=map"><img src="./images/tmenu3.jpg" alt="오시는길" /></a></li>
		<? if($dlog[no]) {?>
		<li><a href="logout.php"><img src="./images/tmenu4.jpg" alt="로그아웃" /></a></li>
		<? }else{?>
		<li><a href="join.php"><img src="./images/tmenu2.jpg" alt="회원가입" /></a></li>
		<li><a href="login.php"><img src="./images/tmenu1.jpg" alt="로그인" /></a></li>
		<? }?>
	</ul>
	<h1><a href="index.php">로타리종합물류</a></h1>
	<ul id="mainmenu">
		<li class="mainm1"><a href="companyh.php?id=companyh">회사소개</a></li>
		<li class="mainm2"><a href="board.php?id=notice">공지사항</a></li>
		<li class="mainm3"><a href="map.php?id=map">오시는길</a></li>
		<li class="mainm4"><a href="carinfo.php?id=carinfo">차량정보</a></li>
		<li class="mainm5"><a href="board.php?id=q">고객센터</a></li>
		<li style="float:right;" class="mainm6"><a href="sitemap.php" style="width:190px;">사이트맵</a></li>
	</ul>
</div>
<div id="main">
  5톤 윙바디 카고 화물 운송주선 업체 1톤 1.4톤 2.5톤 3.5톤 5톤 11톤 25톤 윙바디
  오토바이 다마스 라보 행사 선거 전자제품 수송
  5톤, 윙바디, 카고, 화물 운송주선, 차량 정보 제공.
</div>
<div id="contents">