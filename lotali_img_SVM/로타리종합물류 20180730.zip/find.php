<?
include "libs.php";
include "head2.php";
?>
<div id="site_map">
HOME > <span style="font-weight:bold;">아이디/비밀번호찾기</span>
</div>
<h1 id="home_com1" style="background:url(./images/home_t_find.jpg) no-repeat left top;"></h1>
<div id="home_coml1"><div id="home_coml2"></div></div>
<form action="find_id.php">
<table cellpadding="7" cellspacing="0" class="finds" style="float:left;">
<col width="200px" />
<col width="45px" />
	<tr>
		<th colspan="2">아이디찾기</th>
	</tr>
	<tr>
		<th style="background:none;">이름</th>
		<td><input type="text" name="name" /></td>
	</tr>
	<tr>
		<th style="background:none;">이메일</th>
		<td><input type="text" name="email" /></td>
	</tr>
	<tr>
		<th colspan="2">생년월일</th>
	</tr>
	<tr>
		<td colspan="2" align="center">
			<select name="birthy">
				<? for($i=date("Y");$i>1949;$i--) {?>
				<option value="<?=$i?>"><?=$i?></option>
				<? }?>
			</select>
			년
			<select name="birthm">
				<? for($i=1;$i<13;$i++) {?>
				<option value="<?=$i?>"><?=$i?></option>
				<? }?>
			</select>
			월
			<select name="birthd">
				<? for($i=1;$i<33;$i++) {?>
				<option value="<?=$i?>"><?=$i?></option>
				<? }?>
			</select>
			일
		</td>
	</tr>
	<tr>
		<td colspan="2" align="center"><input type="submit" value="아이디찾기" style="background:url(./images/boardbu4.jpg) no-repeat left top;border:0px;font-size:0px;line-height:200px;width:78px;height:26px;" /></td>
	</tr>
</table>
</form>
<form action="find_pw.php">
<table cellpadding="7" cellspacing="0" class="finds" style="float:right;">
<col width="200px" />
<col width="45px" />
	<tr>
		<th colspan="2">비밀번호찾기</th>
	</tr>
	<tr>
		<th style="background:none;">아이디</th>
		<td><input type="text" name="user_id" /></td>
	</tr>
	<tr>
		<th style="background:none;">이름</th>
		<td><input type="text" name="name" /></td>
	</tr>
	<tr>
		<th style="background:none;">이메일</th>
		<td><input type="text" name="email" /></td>
	</tr>
	<tr>
		<th colspan="2">생년월일</th>
	</tr>
	<tr>
		<td colspan="2" align="center">
			<select name="birthy">
				<? for($i=date("Y");$i>1949;$i--) {?>
				<option value="<?=$i?>"><?=$i?></option>
				<? }?>
			</select>
			년
			<select name="birthm">
				<? for($i=1;$i<13;$i++) {?>
				<option value="<?=$i?>"><?=$i?></option>
				<? }?>
			</select>
			월
			<select name="birthd">
				<? for($i=1;$i<33;$i++) {?>
				<option value="<?=$i?>"><?=$i?></option>
				<? }?>
			</select>
			일
		</td>
	</tr>
	<tr>
		<td colspan="2" align="center"><input type="submit" value="비밀번호찾기" style="background:url(./images/boardbu5.jpg) no-repeat left top;border:0px;font-size:0px;line-height:200px;width:78px;height:26px;" /></td>
	</tr>
</table>
</form>
<?
include "foot2.php";
?>
