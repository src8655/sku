<?
include "libs.php";
include "head2.php";

if(!$name) {
	echo("
		<script>
			window.alert('이름을 입력해주세요')
			history.go(-1)
		</script>
	");
	exit;
}
if(!$email) {
	echo("
		<script>
			window.alert('이메일을 입력해주세요')
			history.go(-1)
		</script>
	");
	exit;
}

$bir = $birthy."-".$birthm."-".$birthd;

$qfinds = "select * from ho_board_member where name='$name' and email='$email' and birth='$bir'";
$rfinds = mysql_query($qfinds, $connect);
$dfinds = mysql_fetch_array($rfinds);
?>
<div id="site_map">
HOME > <span style="font-weight:bold;">아이디/비밀번호찾기</span>
</div>
<h1 id="home_com1" style="background:url(./images/home_t_find.jpg) no-repeat left top;"></h1>
<div id="home_coml1"><div id="home_coml2"></div></div>
<div class="finds" style="margin:0 auto;margin-top:10px;padding:10px;">
<? if(!$dfinds[no]) {?>정보가 존재하지 않습니다.<? }else{?>아이디 : <?=$dfinds[user_id]?><? }?>
</div>
<?
include "foot2.php";
?>
