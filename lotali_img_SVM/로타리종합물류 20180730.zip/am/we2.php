<?
include "lib.php";
include "../home/head2.php";


echo $_POST[sid1];
?>

