<?
include "../home/head2.php";

?>

<style>
a {
text-decoration:none;
color:#000000;
}
.aabc_t {
  margin:0 auto;
  width:750px;
  background:#888888;
}
.aabc_t tr th {
  background:#fbfbfb;
  font-size:12px;
  padding:1px;
}
.aabc_t tr td {
  background:#ffffff;
  font-size:12px;
  padding:1px;
}

.table_col {
  background:#888888;
  border:1px solid #888888;
}
.table_col tr th {
  background:#fbfbfb;
  font-size:12px;
  padding:1px;
}
.table_col tr td {
  background:#ffffff;
  font-size:12px;
  padding:1px;
}
</style>

<script>
function sdfsdf1(assa) {
   	if(assa.style.display == "none") {
   		assa.style.display = "";
   	}else{
   		assa.style.display = "none";
   	}
}
document.paramInvcNo.value="sdf";
</script>
<table border="0" cellpadding="0" cellspacing="1" class="aabc_t">
<col width="30" />
<col width="50" />
<col width="150" />
<col width="100" />
<col width="150" />
<col width="60" />
  <tr>
    <th>번호</th>
    <th>제품</th>
    <th>제품명</th>
    <th>택배회사</th>
    <th>운송장번호</th>
    <th>배송추적</th>
  </tr>
  <tr>
    <td align="center">1</td>
    <td align="center"><img src="./images/aabc_1.jpg" alt="램" /></td>
    <td>삼성전자 DDR4 8G PC4 19200 데스크탑 메모리</td>
    <td align="center">우체국택배</td>
    <td align="center">6864010624324</td>
    <td align="center"><a href="#10" onclick="sdfsdf1(tds1)">배송추적</a></td>
  </tr>
  <tr id="tds1" style="display:none;">
    <td colspan="6">
<?
//xml 받아오기
$ch = curl_init();

$url = "http://service.epost.go.kr/trace.RetrieveDomRigiTraceList.comm"; /*URL*/

//displayHeader 6864010624324

curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "sid1=6864010624324");
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
$response = curl_exec($ch);
curl_close($ch);

//원하는 부분
$response = explode("<", $response);  //문자열 자르고
$sizes = count($response);            //배열 크기
$flag = 0;
for($i = 0;$i < $sizes; $i++) {
  if(strpos($response[$i], 'class="table_col"'))       //시작과
    $flag = 1;
  
  if(strpos($response[$i], 'class="h4_wrap ma_t_10"'))  //끝
    $flag = 0;
    
  if($flag == 1)
    $tmp = "<".$response[$i];
    else $tmp = "";
?>
<?=$tmp?>
<?
}
$tmp = "";
$flag = 0;
for($i = 0;$i < $sizes; $i++) {
  if(strpos($response[$i], 'class="table_col detail_off"'))       //시작과
    $flag = 1;
  
  if(strpos($response[$i], 'class="dpno no-print"'))  //끝
    $flag = 0;
    
  if($flag == 1)
    $tmp = "<".$response[$i];
    else $tmp = "";
?>
<?=$tmp?>
<?
}
?>
    </td>
  </tr>
  
  
  
  
  
  
  
  
  
  
  
  <tr>
    <td align="center">2</td>
    <td align="center"><img src="./images/aabc_2.jpg" alt="파워" /></td>
    <td>잘만 ZM600-LEII 정격 파워 600W.</td>
    <td align="center">로젠택배</td>
    <td align="center">91183263850</td>
    <td align="center"><a href="#10" onclick="sdfsdf1(tds2)">배송추적</a></td>
  </tr>
  <tr id="tds2" style="display:none;">
    <td colspan="6">
<?

//xml 받아오기
$ch = curl_init();

$url = "http://www.ilogen.com/iLOGEN.Web.New/TRACE/TraceDetail.aspx?gubun=link&slipno=91183263850"; /*URL*/

//displayHeader 6864010624324

curl_setopt($ch, CURLOPT_POST, 1);
//curl_setopt($ch, CURLOPT_POSTFIELDS, "tbSlipNo=91183263850&__EVENTVALIDATION=/wEWDwL2nYw3AvScq8sPAoTbn5MPAraHk9MLAo7dqsYBAo7d7rQHAo7dghAC45C9/QgC3Yjr6gYChYiksQQCtv2+mQEC7NH22QwCkpThhA8CiqPZ4AsC7NGy6waBtEVKW9Lyv2QtJWembQzMgvekSg==&__EVENTARGUMENT=__EVENTARGUMENT&__EVENTTARGET=__EVENTTARGET&__VIEWSTATEGENERATOR=CD46B424&__VIEWSTATE=/wEPDwUKMjAyMDAzMzg3Mw9kFgICAw9kFgICAQ9kFgYCDw88KwALAGQCEw88KwALAGQCGQ88KwALAGQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgQFD2J0blNsaXBub1NlYXJjaAURYnRuQ3VzdGluZm9TZWFyY2gFD2J0blRha2Vub1NlYXJjaAUWYnRuUmVzZXJ2ZVRha2VOb1NlYXJjaA1FcSWmQXy2DOdJZAT1bjJwIU5U");
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
$response = curl_exec($ch);
curl_close($ch);
$response = iconv("EUC-KR", "UTF-8", $response);
?>
  <?=$response?>
    </td>
  </tr>
  
  
  
  
  
  
  
  
  
  <tr>
    <td align="center">3</td>
    <td align="center"><img src="./images/aabc_3.jpg" alt="시피유" /></td>
    <td>인텔 코어i5-8세대 8600 (커피레이크) 정품</td>
    <td align="center">로젠택배</td>
    <td align="center">96199576664</td>
    <td align="center"><a href="#10" onclick="sdfsdf1(tds3)">배송추적</a></td>
  </tr>
  <tr id="tds3" style="display:none;">
    <td colspan="6">
<?

//xml 받아오기
$ch = curl_init();

$url = "http://www.ilogen.com/iLOGEN.Web.New/TRACE/TraceDetail.aspx?gubun=link&slipno=96199576664"; /*URL*/

//displayHeader 6864010624324

curl_setopt($ch, CURLOPT_POST, 1);
//curl_setopt($ch, CURLOPT_POSTFIELDS, "tbSlipNo=91183263850&__EVENTVALIDATION=/wEWDwL2nYw3AvScq8sPAoTbn5MPAraHk9MLAo7dqsYBAo7d7rQHAo7dghAC45C9/QgC3Yjr6gYChYiksQQCtv2+mQEC7NH22QwCkpThhA8CiqPZ4AsC7NGy6waBtEVKW9Lyv2QtJWembQzMgvekSg==&__EVENTARGUMENT=__EVENTARGUMENT&__EVENTTARGET=__EVENTTARGET&__VIEWSTATEGENERATOR=CD46B424&__VIEWSTATE=/wEPDwUKMjAyMDAzMzg3Mw9kFgICAw9kFgICAQ9kFgYCDw88KwALAGQCEw88KwALAGQCGQ88KwALAGQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgQFD2J0blNsaXBub1NlYXJjaAURYnRuQ3VzdGluZm9TZWFyY2gFD2J0blRha2Vub1NlYXJjaAUWYnRuUmVzZXJ2ZVRha2VOb1NlYXJjaA1FcSWmQXy2DOdJZAT1bjJwIU5U");
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
$response = curl_exec($ch);
curl_close($ch);
$response = iconv("EUC-KR", "UTF-8", $response);
?>
  <?=$response?>
    </td>
  </tr>
  
  
  
  
  
  
  
  
  
  
    
  <tr>
    <td align="center">4</td>
    <td align="center"><img src="./images/aabc_4.jpg" alt="메인보드" /></td>
    <td>))즉시출고((ASRock B360M PRO4 디앤디컴</td>
    <td align="center">CJ대한통운</td>
    <td align="center">344045222322</td>
    <td align="center"><a href="https://www.cjlogistics.com/ko/tool/parcel/tracking" target="_BLANK">배송추적</a></td>
  </tr>
  <tr id="tds4" style="display:none;">
    <td colspan="6">
    </td>
  </tr>
</table>
<?
include "../home/foot2.php";
?>
