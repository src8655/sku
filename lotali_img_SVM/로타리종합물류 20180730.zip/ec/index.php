<?
include "lib.php";

$q = "select * from ec where no='0'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

?>
<?=$d[flag]?>