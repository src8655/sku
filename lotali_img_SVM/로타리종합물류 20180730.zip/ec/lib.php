<?
$connect = mysql_connect("localhost","lsm8655","snrnsi11"); 
mysql_select_db("lsm8655", $connect);

mysql_query("set names utf8"); 
?>