<?
include "lib.php";
include "head.php";

$query = "select * from min_board_admin where company='$company'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<table cellpadding="7" cellspacing="1" width="500px" id="write1_table" border="0" style="margin-bottom:10px;">
  <tr>
    <td><a href="index_edit.php?olddate=<?=$olddate?>" class="view1_button">뒤로가기</a></td>
  </tr>
</table>
<form action="index_edit_post.php">
<input type="hidden" name="olddate" value="<?=$olddate?>" />
<input type="hidden" name="company" value="<?=$company?>" />
<table cellpadding="7" cellspacing="1" width="500px" id="write1_table" border="0" style="margin-bottom:10px;">
<col width="200" />
<col width="200" />
<col width="100" />
  <tr>
    <th colspan="3"><span style="color:green;font-size:12px;">!경고! 회사명을 수정하시면 월별 모든 장부의 회사명도 같이 변경됩니다</span></th>
  </tr>
  <tr>
    <th>회사명</th>
    <th>상태</th>
    <th>수정</th>
  </tr>
  <tr>
    <td align="center">
    	<input type="text" name="name" value="<?=$data[name]?>" />
    </td>
    <td align="center">
    	<select name="orders" style="margin-top:3px;">
	      <option value="1" <? if($data[orders] == 1) {?>selected<? }?>>한달결제</option>
	      <option value="2" <? if($data[orders] == 2) {?>selected<? }?>>그때그때결제</option>
	      <option value="3" <? if($data[orders] == 3) {?>selected<? }?>>기사에게입금</option>
	      <option value="0" <? if($data[orders] == 0) {?>selected<? }?>>정렬 지정하지 않음</option>
      </select>
    </td>
    <td align="center"><input type="submit" value="수정하기" class="view1_button" /></td>
  </tr>
</table>
</form>
<?
include "foot.php";
?>
