<?
include "lib.php";
include "head.php";
?>
<table cellpadding="10" cellspacing="1" id="write1_table" border="0" style="margin-bottom:10px;font-size:15px;">
	<tr>
		<th colspan="2"><span style="color:red;">체크</span> 하시겠습니까?</th>
	</tr>
	<tr>
		<td><a href="jang_check.php?date=<?=$date?>" class="view1_button">취소</a></td>
		<td><a href="jang_check_post.php?date=<?=$date?>&members=<?=$members?>&is=<?=$is?>&memo=<?=$memo?>" class="view1_button">확인</a></td>
	</tr>
</table>
<?
include "foot.php";
?>
