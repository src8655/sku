<?
include "lib.php";
include "head.php";

$qeel = "select * from min_board_admin_check where no='$no'";
$reel = mysql_query($qeel, $connect);
$deel = mysql_fetch_array($reel);

$query = "select * from min_board_admin where company='$deel[company]'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<table cellpadding="7" cellspacing="1" id="write1_table" border="0" style="font-size:15px;">
<col width="100" />
<col width="100" />
	<tr>
		<th colspan="2"><span style="color:blue;"><?=$data[name]?><? if(!$data[name]) {?>담터<? }?></span> 의 <br />입금확인 취소 하시겠습니까?</th>
	</tr>
	<tr>
		<td><a href="index.php?olddate=<?=$olddate?>&erqs=<?=$erqs?>&ipgm=<?=$_GET[ipgm]?>" class="view1_button">아니오</a></td>
		<td><a href="index_erq_edit_post2.php?no=<?=$no?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>&ipgm=<?=$_GET[ipgm]?>" class="view1_button">예</a></td>
	</tr>
</table>
<?
include "foot.php";
?>
