  function bodysb1() {
    bodys.style.background="FFFFFF";
    window.open("bodybg1s.php?idbb=FFFFFF","new","width=1, height=1");
    }
  function bodysb2() {
    bodys.style.background="#ECECEC";
    window.open("bodybg1s.php?idbb=ECECEC","new","width=1, height=1");
    }
  function bodysb3() {
    bodys.style.background="#ECFCD2";
    window.open("bodybg1s.php?idbb=ECFCD2","new","width=1, height=1");
    }
  function bodysb4() {
    bodys.style.background="#FFFECB";
    window.open("bodybg1s.php?idbb=FFFECB","new","width=1, height=1");
    }
  function bodysb5() {
    bodys.style.background="#EBD4F7";
    window.open("bodybg1s.php?idbb=EBD4F7","new","width=1, height=1");
    }
  function bodysb6() {
    bodys.style.background="#B4BFCC";
    window.open("bodybg1s.php?idbb=B4BFCC","new","width=1, height=1");
    }
  function bodysb7() {
    bodys.style.background="#FF943D";
    window.open("bodybg1s.php?idbb=FF943D","new","width=1, height=1");
    }
  function bodysb8() {
    bodys.style.background="#0099FF";
    window.open("bodybg1s.php?idbb=0099FF","new","width=1, height=1");
    }
  function bodysb9() {
    bodys.style.background="#8EDC0C";
    window.open("bodybg1s.php?idbb=8EDC0C","new","width=1, height=1");
    }
  function bodysb10() {
    bodys.style.background="#000099";
    window.open("bodybg1s.php?idbb=000099","new","width=1, height=1");
    }
  function bodysb11() {
    bodys.style.background="#000000";
    window.open("bodybg1s.php?idbb=000000","new","width=1, height=1");
    }
  function bodysb12() {
    bodys.style.background="#C7141A";
    window.open("bodybg1s.php?idbb=C7141A","new","width=1, height=1");
    }
  function allc() {
    if(col1.style.display == "none") {
      col1.style.display = "";
      col2.style.display = "";
      col3.style.display = "";
      }else{
        col1.style.display = "none";
        col2.style.display = "none";
        col3.style.display = "none";
        }
    }
   function sdfsdf1(assa) {
   	if(assa.style.display == "none") {
   		assa.style.display = "";
   	}else{
   		assa.style.display = "none";
   	}
   }
   function sdfsdf2(assa) {
   	if(assa.style.display == "none") {
   		assa.style.display = "";
   	}else{
   		assa.style.display = "none";
   	}
   }
   function sdfsdf3(assa) {
   	if(assa.style.display == "none") {
   		assa.style.display = "";
   	}else{
   		assa.style.display = "none";
   	}
   }
   function sdfsdf5(assa) {
   	if(assa.style.display == "none") {
   		assa.style.display = "";
   	}else{
   		assa.style.display = "none";
   	}
   }
   function sdfsdf6(assa) {
   	if(assa.style.display == "none") {
   		assa.style.display = "";
   	}else{
   		assa.style.display = "none";
   	}
   }
	function mmmacc(asssss) {
		if(asssss.style.display == "none") {
		asssss.style.display = "";
		}else{
		asssss.style.display = "none";
		}
	}
	function emmeviiv() {
		if(viiv.style.display == "none") {
		viiv.style.display = "";
		}else{
		viiv.style.display = "none";
		}
	}
function uols(assas) {
	if(assas.style.display == "none") {
		assas.style.display = "";
	}else{
		assas.style.display = "none";
	}
}
function uolsm(assas) {
	if(assas.style.display == "") {
		assas.style.display = "none";
	}else{
		assas.style.display = "";
		assas.form.memo.focus();
	}
}
function chaing() {
	if(cha.style.display == "none") {
		cha.style.display = "";
	}else{
		cha.style.display = "none";
	}
}
function chaings(aab) {
	if(aab.style.display == "none") {
		aab.style.display = "";
	}else{
		aab.style.display = "none";
	}
}
function ebsofm(assa) {
	if(assa.style.background != "orange") {
		assa.style.background = "orange";
	}else{
		assa.style.background = "";
	}
}
function ememaee(assa) {
	if(assa.style.display == "none") {
		assa.style.display = "";
	}else{
		assa.style.display = "none";
	}
}
function golem(okl) {
	if(okl.style.display == "none") {
		okl.style.display = "";
	}else{
		okl.style.display = "none";
	}
}
function confirms(mass,urs) {
	var amms = confirm(mass);
	if(amms == false) {
		
	}else{
		location.href=urs;
	}
}
function locas(sdds) {
	location.href=sdds;
}



function listclick() {
  var rse1 = document.getElementById(listname.value);
  rse.style.color="red";
}




	function print_link(str){
		document.execCommand('SelectAll');
	 clipboardData.setData("Text", str); 
	 alert("주소가 복사되었습니다.");
	}
	
////////////////jquery


$(function(){
	// 달력
	$('.suv a').hover(function(){
		var mm = $(this).next();
		$(mm).slideToggle(200);
	});
	// 달력
	
	
	// 메일 회사검색
	$('#mailgom').hover(function(){
		$('#mail_aa').show(100);
	}, function(){
		$('#mail_aa').hide(100);
	});
	// 메일 회사검색
	
	
	// 날짜선택 더보기
	$('.olddatemore').click(function(){
		$('.olddatemo').slideToggle();
	}, function(){
		$('.olddatemo').slideToggle();
	});
	// 날짜선택 더보기
	
	
	// 메모창
	$('.memobuttons').click(function(){
		var ase = $('#memoz').val();
		var as = escape(ase);
		$('#querysz').load('memo_post.php?memo='+as);
		$('#zx1').load('index.php #zx1');
		$('#zx1').load('index.php #zx1');
		$('#zx3').load('index.php #zx3');
		$('#ze2').load('index.php #ze2');
	});
	$('.acv a').click(function(){
		var am = $(this).attr('class');
		var ams = am.split("a");
		var tm = "c"+am;
		$('#'+tm).addClass('hiddens');
		$('#querysz').load("memo_check2.php?no="+ams[1]);
		$('#zx3').load('index.php #zx3');
		$('#ze2').load('index.php #ze2');
	});
	// 메모창


	//배경색
	$('.colorp').click(function(){
		$('#topsaxx').slideToggle();
	});
	//배경식
	
	
	
	//회사찾기
	$("#fdkey").focus();
	$("#fdkey").bind('keyup',function(e){
	var key = $("#fdkey").val();
	var lens = key.length;
	var exh,ext,exta,exhtml;
	$("#cda").slideDown(100);
	$(".fd1").each(function(){
	  var fdtext = $(this).text();
	  $(this).html(fdtext);
	  var index = fdtext.search(key);
	  if(index >= 0) {
	    exh = fdtext.substr(0,index);
	    ext = fdtext.substr(index,lens);
	    exta = fdtext.substr(index+lens);
	    exhtml = exh+"<span style='background:yellow;font-weight:bold;'>"+ext+"</span>"+exta;
	    $(this).html(exhtml);
	  }else{ //대소문자모두찾기
	    index = fdtext.search(key.toUpperCase());
	    if(index >= 0) {
  	    exh = fdtext.substr(0,index);
  	    ext = fdtext.substr(index,lens);
  	    exta = fdtext.substr(index+lens);
  	    exhtml = exh+"<span style='background:yellow;font-weight:bold;'>"+ext+"</span>"+exta;
  	    $(this).html(exhtml);
	    }
	    index = fdtext.search(key.toLowerCase());
	    if(index >= 0) {
  	    exh = fdtext.substr(0,index);
  	    ext = fdtext.substr(index,lens);
  	    exta = fdtext.substr(index+lens);
  	    exhtml = exh+"<span style='background:yellow;font-weight:bold;'>"+ext+"</span>"+exta;
  	    $(this).html(exhtml);
	    }
	  }
	});
	
	});
	
	
	//회사찾기
	
	//입금자 회사찾기
	$("#fdkey2").bind('keyup',function(e){
	var key = $("#fdkey2").val();
	var lens = key.length;
	var exh,ext,exta,exhtml;
	$("#ipgm_list_hd").slideDown(100);
	$(".fd2").each(function(){
	  var fdtext = $(this).text();
	  var index = fdtext.search(key);
	  if(index >= 0) {
	    $(this).css("display","block");
	  }else{ //대소문자모두찾기
	    
	    index = fdtext.search(key.toUpperCase());
	    if(index >= 0) 
  	    $(this).css("display","block");
	    else{
  	    index = fdtext.search(key.toLowerCase());
  	    if(index >= 0) 
    	    $(this).css("display","block");
  	    else{
  	      $(this).css("display","none");
  	    }
	    }
	  }
	});
	
	});
	
	
	//입금자 회사찾기
	
	
	
	
	
	
	
	
	
	
	});






////////////////jquery