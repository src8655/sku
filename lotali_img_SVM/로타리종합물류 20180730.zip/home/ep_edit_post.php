<?
include "lib.php";
include "head.php";

$_REQUEST[moneymm] = $money;
$_REQUEST[moneys] = $_REQUEST[moneymm]/10;
$_REQUEST[ses] = $_REQUEST[moneymm]+$_REQUEST[moneys];

if($checks == 2) {
$_REQUEST[emem] = "2";
}else{
$_REQUEST[emem] = "1";
}
if($checks2 == 2) {
$_REQUEST[emem2] = "2";
}else{
$_REQUEST[emem2] = "1";
}

$query = "update min_board_ep set
					se1='$_REQUEST[ses]',
					checks='$_REQUEST[emem]',
					checks2='$_REQUEST[emem2]',
					money='$_REQUEST[moneymm]',
					moneys='$_REQUEST[moneys]',
					date='$_REQUEST[date1]',
					date2='$_REQUEST[date2]',
					memo='$_REQUEST[memo]' where olddate='$olddate' and no='$no'";
mysql_query($query, $connect);
?>
<script>
	location.href='ep.php?olddate=<?=$olddate?>&empq=<?=$no?>';
</script>
