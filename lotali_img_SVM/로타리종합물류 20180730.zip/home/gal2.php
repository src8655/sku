<?
include "lib.php";
include "head.php";

if(!$years) {
$years = date("Y");
}
if(!$mons) {
$mons = date("n");
}
if(!$days) {
$days = date("j");
}

$allmons = date("t",strtotime("$years-$mons-1"));
$firstmons = date("w",strtotime("$years-$mons-1"));

if($mons == 1) {
	$spsptmp1 = $years-1;
	$spsptmp2 = 12;
}else{
	$spsptmp1 = $years;
	$spsptmp2 = $mons-1;
}
if($mons == 12) {
	$smsmtmp1 = $years+1;
	$smsmtmp2 = 1;
}else{
	$smsmtmp1 = $years;
	$smsmtmp2 = $mons+1;
}



$yearsem1 = substr($years,0,1);
$yearsem2 = substr($years,1,1);
$yearsem3 = substr($years,2,1);
$yearsem4 = substr($years,3,1);

$mons_long = strlen($mons);
if($mons_long != 1) {
$monsem1 = substr($mons,0,1);
$monsem2 = substr($mons,1,1);
}





?>
<div style="width:1000px;overflow:hidden;font-family:'Arial';height:200px;background:url(./images/gal2top.jpg) no-repeat left top;">
	<div style="font-size:15px;font-weight:bold;margin:160px 0 0 15px;width:185px;float:left;overflow:hidden;">
		<a href="gal2.php"><img src="gal2/today.png" style="border:0px;" /></a>
	</div>
	<div style="margin:110px 0 0 0;width:600px;float:left;color:#ffffff;text-align:center;font-size:35px;font-weight:bold;overflow:hidden;">
		<a href="gal2.php?years=<?=$spsptmp1?>&mons=<?=$spsptmp2?>"><img src="images/dhls.png" style="border:0px;" /></a>&nbsp;
		<img src="gal2/<?=$yearsem1?>.png" style="border:0px;" /><img src="gal2/<?=$yearsem2?>.png" style="border:0px;" /><img src="gal2/<?=$yearsem3?>.png" style="border:0px;" /><img src="gal2/<?=$yearsem4?>.png" style="border:0px;" />
		<img src="gal2/00.png" style="border:0px;" /> <? if($mons_long != 1) {?><img src="gal2/<?=$monsem1?>.png" style="border:0px;" /><img src="gal2/<?=$monsem2?>.png" style="border:0px;" /><? }else{?><img src="gal2/<?=$mons?>.png" style="border:0px;" /><? }?>
		&nbsp;<a href="gal2.php?years=<?=$smsmtmp1?>&mons=<?=$smsmtmp2?>"><img src="images/dh.png" style="border:0px;" /></a>
	</div>
	<div style="margin:150px 10px 0 0;color:#ffffff;width:190px;float:right;text-align:right;font-size:18px;padding:20px 0 0 0;font-weight:bold;overflow:hidden;">
		<form action="<?=$PHP_SELF?>">
			<div style="float:right;"><input type="submit" value="GO" style="border:0px;width:50px;height:25px;color:#ffffff;margin:0px;padding:0px;background:#525252;font-size:13px;font-weight:bold;" /></div>
			<div style="float:right;"><input type="text" name="years" style="border:0px;width:60px;height:23px;font-size:18px;font-family:'Arial';background:#525252;" /> -&nbsp;
			<input type="text" name="mons" style="border:0px;width:30px;font-size:18px;font-family:'Arial';height:23px;background:#525252;" />&nbsp;</div>
		</form>
	</div>
</div>
<table cellspacing="0" cellpadding="5" id="cals" style="font-family:'Arial';font-size:28px;" width="1000px">
<col width="142" />
<col width="142" />
<col width="142" />
<col width="142" />
<col width="142" />
<col width="142" />
<col width="142" />
	<tr>
		<th><img src="gal2/sun.png" style="border:0px;" /></th>
		<th><img src="gal2/mon.png" style="border:0px;" /></th>
		<th><img src="gal2/thu.png" style="border:0px;" /></th>
		<th><img src="gal2/wed.png" style="border:0px;" /></th>
		<th><img src="gal2/thu.png" style="border:0px;" /></th>
		<th><img src="gal2/fri.png" style="border:0px;" /></th>
		<th><img src="gal2/sat.png" style="border:0px;" /></th>
	</tr>
</table>
<table cellspacing="0" cellpadding="5" id="cals" style="font-family:'Arial';font-size:28px;border:1px solid #E2E2E2;border-top:0px;" width="1000px">
<col width="142" />
<col width="142" />
<col width="142" />
<col width="142" />
<col width="142" />
<col width="142" />
<col width="142" />
	<tr>
<?
for($i=0;$i<$firstmons;$i++) {
?>
		<td>&nbsp;</td>
<?
}
?>
<?
for($i=1;$i<=$allmons;$i++) {
$temp = date("w",strtotime("$years-$mons-$i"));
if($temp == 0) {
?>
	</tr>
	<tr>
<?
}

$tmpsoo = $years."-".$mons."-".$i;
$tmpsoo2 = $years.$mons.$i;
$qcal = "select * from min_board_cal where date='$tmpsoo'";
$rcal = mysql_query($qcal, $connect);
$dcal = mysql_fetch_array($rcal);
?>
		<td align="center" <? if($years == date("Y")) {if($mons == date("n")) {if($i == date("j")) {?>style="font-weight:bold;<? if($temp == 0) {?>color:red;<? }if($temp == 6) {?>color:blue;<? }?>"<? }}}?>>
			<div style="text-align:left;overflow:hidden;">
			<span <? if($temp == 0) {?>style="color:red;"<? }if($temp == 6) {?>style="color:blue;"<? }?>>
				<?=$i?>
			</span>
			<? if($years == date("Y")) {if($mons == date("n")) {if($i == date("j")) {?>
				<span style="font-size:18px;">Today</span>
			<? }}}?>
			<? if(!$dcal[date]) {?>
				<a onclick="uols(a<?=$tmpsoo2?>);uolsm(ab<?=$tmpsoo2?>);" style="font-size:13px;font-weight:normal;">작성</a>
			<? }else{?>
				<a href="gal2_del.php?date=<?=$tmpsoo?>&years=<?=$years?>&mons=<?=$mons?>" style="font-size:13px;font-weight:normal;color:red;">삭제</a>
			<? }?>
			</div>
			<div style="overflow:scroll;overflow-x:hidden;font-weight:normal;text-align:left;width:122px;border:1px solid #dddddd;height:80px;font-size:15px;padding:2px;" id="a<?=$tmpsoo2?>">
				<?=nl2br($dcal[memo])?>
			</div>
			<div style="width:126px;border:1px solid #dddddd;height:84px;display:none;overflow:hidden;" id="ab<?=$tmpsoo2?>">
				<form action="gal2_post.php">
					<input type="hidden" name="years" value="<?=$years?>" />
					<input type="hidden" name="mons" value="<?=$mons?>" />
					<input type="hidden" name="date" value="<?=$tmpsoo?>" />
					<div><textarea name="memo" style="width:123px;height:55px;border:0px;"></textarea></div>
					<div><input type="submit" value="등록" style="margin:2px 0 0 0;padding:0px;width:70px;height:20px;background:#ffffff;border:1px solid #dddddd;" /></div>
				</form>
			</div>
		</td>
<?
}
?>
<?
$tmps1 = date("w",strtotime("$years-$mons-$allmons"));
$tmps2 = 6-$tmps1;
for($i=0;$i<$tmps2;$i++) {
?>
		<td>&nbsp;</td>
<?
}
?>
	</tr>
</table>
<?
include "foot.php";
?>
