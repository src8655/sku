<?
include "lib.php";
include "head.php";

if($cop == "1") {

if($cacp == "a1") {
if(!$memo) {
$mmm = "(완)";
}else{
$mmm = "(완)<br />$_REQUEST[memo]";
}
$query = "update min_board_jang_check set
					a1='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a2") {
if(!$memo) {
$mmm = "(완)";
}else{
$mmm = "(완)<br />$_REQUEST[memo]";
}
$query = "update min_board_jang_check set
					a2='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a3") {
if(!$memo) {
$mmm = "(완)";
}else{
$mmm = "(완)<br />$_REQUEST[memo]";
}
$query = "update min_board_jang_check set
					a3='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a4") {
if(!$memo) {
$mmm = "(완)";
}else{
$mmm = "(완)<br />$_REQUEST[memo]";
}
$query = "update min_board_jang_check set
					a4='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a5") {
if(!$memo) {
$mmm = "(완)";
}else{
$mmm = "(완)<br />$_REQUEST[memo]";
}
$query = "update min_board_jang_check set
					a5='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a6") {
if(!$memo) {
$mmm = "(완)";
}else{
$mmm = "(완)<br />$_REQUEST[memo]";
}
$query = "update min_board_jang_check set
					a6='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a7") {
if(!$memo) {
$mmm = "(완)";
}else{
$mmm = "(완)<br />$_REQUEST[memo]";
}
$query = "update min_board_jang_check set
					a7='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a8") {
if(!$memo) {
$mmm = "(완)";
}else{
$mmm = "(완)<br />$_REQUEST[memo]";
}
$query = "update min_board_jang_check set
					a8='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a9") {
if(!$memo) {
$mmm = "(완)";
}else{
$mmm = "(완)<br />$_REQUEST[memo]";
}
$query = "update min_board_jang_check set
					a9='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a10") {
if(!$memo) {
$mmm = "(완)";
}else{
$mmm = "(완)<br />$_REQUEST[memo]";
}
$query = "update min_board_jang_check set
					a10='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a11") {
if(!$memo) {
$mmm = "(완)";
}else{
$mmm = "(완)<br />$_REQUEST[memo]";
}
$query = "update min_board_jang_check set
					a11='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a12") {
if(!$memo) {
$mmm = "(완)";
}else{
$mmm = "(완)<br />$_REQUEST[memo]";
}
$query = "update min_board_jang_check set
					a12='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}


}


if($cop == "2") {

if($cacp == "a1") {
$mmm = "";
$query = "update min_board_jang_check set
					a1='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a2") {
$mmm = "";
$query = "update min_board_jang_check set
					a2='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a3") {
$mmm = "";
$query = "update min_board_jang_check set
					a3='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a4") {
$mmm = "";
$query = "update min_board_jang_check set
					a4='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a5") {
$mmm = "";
$query = "update min_board_jang_check set
					a5='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a6") {
$mmm = "";
$query = "update min_board_jang_check set
					a6='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a7") {
$mmm = "";
$query = "update min_board_jang_check set
					a7='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a8") {
$mmm = "";
$query = "update min_board_jang_check set
					a8='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a9") {
$mmm = "";
$query = "update min_board_jang_check set
					a9='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a10") {
$mmm = "";
$query = "update min_board_jang_check set
					a10='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a11") {
$mmm = "";
$query = "update min_board_jang_check set
					a11='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}
if($cacp == "a12") {
$mmm = "";
$query = "update min_board_jang_check set
					a12='$mmm' where date='$date' and member='$members'";
mysql_query($query, $connect);
}

}
?>

<script>
	location.href='jang_check.php?date=<?=$date?>&oldu=1';
</script>
