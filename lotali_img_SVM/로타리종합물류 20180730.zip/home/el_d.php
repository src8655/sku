<?
include "lib.php";
include "head3.php";

$qm = "select * from min_board_el where no='$el'";
$rm = mysql_query($qm, $connect);
$dm = mysql_fetch_array($rm);

$allcount = selectc("min_board_el_d","where el='$el'");

$query = "select * from min_board_el_d where el='$el' order by no desc";
$result = mysql_query($query, $connect);
?>
<table cellpadding="5" cellspacing="1" width="1200px" id="write1_table" border="0" style="margin-bottom:10px;font-family:'Arial';">
<col width="200" />
<col width="600" />
<col width="200" />
  <tr>
    <td><a href="el.php" class="view1_button">뒤로가기</a></td>
    <td align="center" style="font-size:25px;font-weight:bold;"><?=$dm[date]?> <?=$dm[yos]?> - <span style="color:red;"><?=$allcount?></span></td>
    <td>
      <a href="#bottomtxx" class="view1_button">맨 아래로</a>
    </td>
  </tr>
</table>
<form action="el_d_post.php" method="post" id="writep" name="writepp">
<input type="hidden" name="el" value="<?=$el?>" />
<table cellpadding="5" cellspacing="1" id="write1_table" border="0" width="1200px" style="font-size:15px;font-family:'Arial';">
<col width="70" />
<col width="130" />
<col width="130" />
<col width="110" />
<col width="100" />
<col width="150" />
<col width="100" />
<col width="140" />
<col width="150" />
<col width="60" />
<col width="60" />
	<tr>
		<th>번호</th>
		<th>출발지</th>
		<th>도착지</th>
		<th>차량</th>
		<th>차량번호</th>
		<th>핸드폰번호</th>
		<th>성명</th>
		<th>금액</th>
		<th>비고</th>
		<th colspan="2">관리</th>
	</tr>
	<tr>
		<th>작성</th>
		<td align="center"><input type="text" name="date2" style="font-size:15px;padding:2px 0 2px 0;width:110px;border:1px solid #7F9DB9;" /></td>
		<td align="center"><input type="text" name="ddo" style="font-size:15px;padding:2px 0 2px 0;width:110px;border:1px solid #7F9DB9;" /></td>
		<td align="center"><input type="text" name="car" style="font-size:15px;padding:2px 0 2px 0;width:90px;border:1px solid #7F9DB9;" /></td>
		<td align="center"><input type="text" name="number" style="font-size:15px;padding:2px 0 2px 0;width:80px;border:1px solid #7F9DB9;" /></td>
		<td align="center"><input type="text" name="phone" style="font-size:15px;padding:2px 0 2px 0;width:130px;border:1px solid #7F9DB9;" /></td>
		<td align="center"><input type="text" name="name" style="font-size:15px;padding:2px 0 2px 0;width:80px;border:1px solid #7F9DB9;" /></td>
		<td align="right"><input type="text" name="money" style="font-size:15px;padding:2px 0 2px 0;width:50px;border:1px solid #7F9DB9;" /> ,000</td>
		<td align="center"><input type="text" name="memo" style="font-size:15px;padding:2px 0 2px 0;width:130px;border:1px solid #7F9DB9;" /></td>
		<td align="center" colspan="2"><input type="submit" value="작성하기" class="view1_button" style="width:90%;" /></td>
	</tr>
<?
$cnt = $allcount;
while($data = mysql_fetch_array($result)) {
$datas = $data[money]*1000;
?>
	<tr>
		<td align="center"><?=$cnt?></td>
		<td align="center"><?=$data[chu]?></td>
		<td align="center"><?=$data[ddo]?></td>
		<td align="center"><?=$data[car]?></td>
		<td align="center"><?=$data[number]?></td>
		<td align="center"><?=$data[phone]?></td>
		<td align="center"><?=$data[name]?></td>
		<td align="right"><?=number_format($datas)?></td>
		<td align="center"><?=$data[memo]?></td>
		<td align="center"><a href="el_d_edit.php?el=<?=$el?>&no=<?=$data[no]?>" class="view1_button">수정</a></td>
		<td align="center"><a href="el_d_del.php?el=<?=$el?>&no=<?=$data[no]?>" class="view1_button">삭제</a></td>
	</tr>
<?
$cnt -= 1;
}
?>
	<tr>
		<td colspan="11">
    	<div style="float:left;width:10%;padding:0 6px 0 0;overflow:hidden;">
				<a href="el_print.php?el=<?=$el?>" target="_blank" class="view1_button">인쇄하기1</a>
			</div>
    	<div style="float:left;width:10%;padding:0 6px 0 0;overflow:hidden;">
				<a href="el_print_pdf.php?el=<?=$el?>" target="_blank" class="view1_button">인쇄하기2</a>
			</div>
    	<div style="float:right;width:20%;padding:0 6px 0 0;overflow:hidden;">
				<a href="#toptxx" class="view1_button">맨 위로</a>
			</div>
		</td>
	</tr>
</table>
</form>
<?
include "foot3.php";
?>