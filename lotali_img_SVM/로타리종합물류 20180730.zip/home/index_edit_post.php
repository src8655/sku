<?
include "lib.php";
include "head.php";

if(!$name) {
  echo("
    <script>
      window.alert('회사명을 입력해주세요.')
      history.go(-1)
    </script>
  ");
  exit;
}

$query = "update min_board_admin set
          name='$_REQUEST[name]',
          orders='$_REQUEST[orders]' where company='$company'";
mysql_query($query, $connect);
?>
<script>
  location.href='index.php?olddate=<?=$olddate?>';
</script>
