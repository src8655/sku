<?
include "lib.php";
include "head3.php";

$query = "delete from min_board_el_d where el='$el' and no='$no'";
mysql_query($query, $connect);
?>
<script>
	location.href="el_d.php?el=<?=$el?>";
</script>
<?
include "foot3.php";
?>