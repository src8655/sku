<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>로타리종합물류</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<link rel="stylesheet" type="text/css" href="./minhogood.css" />
<script src="../jquery/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="./minsd.js"></script>
<?
if($bodybg) {
?>
<style type="text/css">
#bodys {
  background:#<?=$bodybg?>;
  }
</style>
<?
  }
?>

<script type="text/javascript">
$(function(){
  $(".focus_on").focus();
});
</script>
</head>
<body id="bodys">
<a name="toptxx"></a>
<div style="background:#ffffff; width:1200px; margin:0 auto; padding:10px;">
<div id="header2">
  <h1><a href="index.php"><img src="./images/logos.jpg" alt="로타리종합물류" width="189" height="40" /></a></h1>
  
	<div id="calsmm" class="suv">
		<a href="./logout.php"><img src="./images/logs.png" width="75" height="76" /></a>
  	<div style="display:none;background:#ffffff;border:1px solid #676767;padding:5px;position:absolute;overflow:hidden;">
  		클릭시 로그아웃 됩니다.
  	</div>
  </div>
	<div id="calsmm" class="suv">
	<a href="wether.php"><img src="./images/nal.jpg" width="75" height="76" /></a>
		<div style="display:none;background:#ffffff;border:1px solid #676767;padding:5px;position:absolute;overflow:hidden;">
  		날씨 페이지로 이동됩니다.
  	</div>
	</div>
  <div id="calsmm" class="suv">
  	<a href="tong.php"><img src="./images/tong.jpg" width="75" height="76" /></a>
  	<div style="display:none;background:#ffffff;border:1px solid #676767;padding:5px;position:absolute;overflow:hidden;">
  		월별 통계 페이지로 이동됩니다.
  	</div>
  </div>
	<div id="calsmm" class="suv">
  <div class="colorp"><a href="https://www.hometax.go.kr/websquare/websquare.html?w2xPath=/ui/pp/index.xml" target="_BLANK">
  <img src="./images/hometex.png" width="75" height="76" /></a>
  	<div style="display:none;background:#ffffff;border:1px solid #676767;padding:5px;position:absolute;overflow:hidden;">
  		전자세금계산서 국세청 홈택스로 이동합니다.
  	</div>
  </div>
	</div>
	<div id="calsmm" class="suv">
  	<a href="mail.php"><img src="./images/mail.png" width="75" height="76" /></a>
  	<div style="display:none;background:#ffffff;border:1px solid #676767;padding:5px;position:absolute;overflow:hidden;">
  		이메일 페이지로 이동됩니다.
  	</div>
	</div>
	<div id="calsmm" class="suv">
  	<a href="#" onclick="window.open('goom.php','s','toolbar=no,location=no,status=no,scrollbars=no,resizable=no,width=306px,height=450px')"><img src="./images/cll.png" width="75" height="76" /></a>
  	<div style="display:none;background:#ffffff;border:1px solid #676767;padding:5px;position:absolute;overflow:hidden;">
  		클릭시 계산기가 열립니다.
  	</div>
  </div>
  <div id="calsmm" class="suv"><a href="gal2.php"><img src="./cal/<?=date("m")?><?=date("d")?>.jpg" width="75" height="76" /></a>
		<div style="margin:0 0 0 -110px;float:left;position:absolute;display:none;background:#ffffff;padding:0 5px 5px 5px;border:1px solid #bbbbbb;">
			<? include "cal.php";?>
		</div>
	</div>
</div>
<?
if($olddate) {
$ef = "select * from min_board_olddate where olddate='$olddate'";
$df = mysql_query($ef, $connect);
$cf = mysql_fetch_array($df);
}else{}
?>
  <h1 id="headdate">
    <div style="width:436px;padding:10px 0 0px 10px;float:left;overflow:hidden;"><? if($olddate) {?><?=$cf[date]?> 장부<? }else{?>공통<? }?></div>
      <div style="background:url(./images/submenubg.gif) repeat-x left bottom;padding:0 10px 0 10px;width:280px;border:1px solid #B4BFCC;border-top:0px;border-bottom:0px;height:45px;line-height:45px;text-align:center;float:left;overflow:hidden;">
      <? if($dyyocount == 0) {?>
        <span style="font-size:15px;">새로운 메모가 없습니다.</span>
      <? }else{?>
        <span style="font-size:15px;color:red;"><?=$dyyocount?> 개의 새로운 메모가 있습니다.</span>
      <? }?>
    	</div>
    <div style="float:right;padding:10px 10px 0px 0;width:436px;overflow:hidden;text-align:right;"><span style="font-size:11px;"><?=$_SERVER['REMOTE_ADDR']?></span> <?=date("m")?>월<?=date("d")?>일 <?=date("A")?><?=date("h")?>시<?=date("i")?>분</div>
  </h1>
