<?
include "lib.php";
include "head.php";

if(!$page) {
$page = 1;
}

$limitnum = 15;
$limits = $limitnum*$page-$limitnum;

$q = "select count(*) from min_board_memo";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

$countnum = $d[0];

$countnum1 = ceil($countnum/($limitnum+1));

$query = "select * from min_board_memo order by no desc limit $limits, $limitnum";
$result = mysql_query($query, $connect);


?>
<div id="ind">
<table cellpadding="7" cellspacing="0" id="elelmemo" border="0" width="1000px">
<col width="90">
<col>
<col width="110">
<col width="60">
<col width="60">
  <tr>
    <th>확인</th>
    <th>내용</th>
    <th>올린날짜</th>
    <th colspan="2">관리</th>
  </tr>
<?
$cntt = 0;
while($data = mysql_fetch_array($result)) {
$cntm = $cntt%2;
?>
  <tr>
    <td align="center"><? if($data[checks] == 1) {?><a href="memo_check.php?no=<?=$data[no]?>&olddate=<?=$olddate?>" class="chred">확인안함</a><? }else{?><a onclick="uols(aaui<?=$data[no]?>);" class="hoack">확인함</a><span style="font-size:13px;color:blue;display:none;" id="aaui<?=$data[no]?>"><?=$data[checksdate]?></span><? }?></td>
    <td>
    	<span id="dmze<?=$data[no]?>"><?=mb_substr($data[memo],0,40,'UTF-8')?></span>
    	<span id="dmzes<?=$data[no]?>">
    	<? if(mb_strlen($data[memo],'UTF-8') > 40) {?>
    	...
    	<a onclick="uols(dmze<?=$data[no]?>);uols(dmzes<?=$data[no]?>);uols(dmzess<?=$data[no]?>);" style="font-weight:bold;color:red;">[더보기]</a>
    	<? }?>
    	</span>
    	<span style="display:none;" id="dmzess<?=$data[no]?>">
    		<?=nl2br($data[memo])?> <a onclick="uols(dmze<?=$data[no]?>);uols(dmzes<?=$data[no]?>);uols(dmzess<?=$data[no]?>);" style="font-weight:bold;color:red;">[닫기]</a>
    	</span>
    </td>
    <td align="center"><span style="font-size:15px;"><?=$data[date]?></span></td>
    <td align="center"><a href="memo_edit.php?olddate=<?=$olddate?>&no=<?=$data[no]?>" class="view1_button">수정</a></td>
    <td align="center"><a onclick="confirms('삭제를 하시겠습니까?','memo_del.php?olddate=<?=$olddate?>&no=<?=$data[no]?>');" class="view1_button">삭제</a></td>
  </tr>
<?
$cntt ++;
}
?>
  <tr>
    <td colspan="5" align="center" style="font-size:15px;">
<a href="memo_list.php?olddate=<?=$olddate?>&page=1" style="font-weight:bold;"><< </a>
<?
$i1 = $page-5;
$i2 = $page+6;

for($i=$i1;$i<$i2;$i++) {

if($i<1) {

}else{
if($i>$countnum1) {

}else{
?>
 &nbsp;<a href="memo_list.php?olddate=<?=$olddate?>&page=<?=$i?>" <? if($i == $page) {?>style="font-weight:bold;color:red;"<? }?>>[<?=$i?>]</a>
<?
}}}
?>
&nbsp;<a href="memo_list.php?olddate=<?=$olddate?>&page=<?=$countnum1?>" style="font-weight:bold;"> >></a>
    </td>
  </tr>
</table>
</div>
<?
include "foot.php";
?>
