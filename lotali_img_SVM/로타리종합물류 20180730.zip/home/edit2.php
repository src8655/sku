<?
include "lib.php";
include "head3.php";

$query = "select * from min_board_data2 where no='$no' and olddate='$olddate'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);

$ddmso = $data[money]/1000;


?>
<form action="edit2_post.php">
<input type="hidden" value="<?=$no?>" name="no" />
<input type="hidden" value="<?=$olddate?>" name="olddate" />
<input type="hidden" value="<?=$page?>" name="page" />
<input type="hidden" value="<?=$view2_password?>" name="view2_password" />
<input type="hidden" name="mmmq" value="<?=$mmmq?>" />
<input type="hidden" name="mon" value="<?=$mon?>" />
<input type="hidden" name="id" value="<?=$id?>" />
<table cellpadding="7" cellspacing="1" id="write1_table" border="0" width="1200px">
<col width="70" />
<col width="50" />
<col width="100" />
<col width="90" />
<col width="100" />
<col width="60" />
<col width="70" />
<col width="90" />
<col width="100" />

<col width="100" />
<col width="100" />
<? if($mon){?><col width="60" /><? }?>
<col width="30" />
<col width="30" />
<col width="100" />
<col width="65" />
  <tr>
    <th colspan="<? if($mon){?>16<? }else{?>15<? }?>" align="center">담터 <span style="color:red;">수정하기</span></th>
  </tr>
  <tr>
    <th rowspan="2">날짜</th>
    <th rowspan="2">요일</th>
    <th colspan="3">납품처</th>
    <th rowspan="2">차량번호</th>
    <th rowspan="2">이름</th>
    <th rowspan="2">톤수</th>
    <th rowspan="2">
    	<? if($mon){?>
    		<a onclick="location.href='edit2.php?olddate=<?=$olddate?>&no=<?=$no?>&page=<?=$page?>&view2_password=<?=$view2_password?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&mmmq=<?=$mmmq?>'">수량<br />(박스)</a>
    	<? }else{?>
    		<a onclick="location.href='edit2.php?olddate=<?=$olddate?>&no=<?=$no?>&page=<?=$page?>&view2_password=<?=$view2_password?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&mmmq=<?=$mmmq?>&mon=1'">수량<br />(박스)</a>
    	<? }?>
    </th>
    <th rowspan="2">메모</th>
    <? if($mon){?><th rowspan="2">금액</th><? }?>
    <th rowspan="2">숫자</th>
    <th colspan="2">납품구분</th>
    <th rowspan="2">전화번호</th>
    <th rowspan="2">완</th>
  </tr>
  <tr>
    <th>출발지</th>
    <th>경유지</th>
    <th>도착지</th>
    <th>수송</th>
    <th>납품</th>
  </tr>
  <tr>
    <td align="center">
      <input type="text" name="date2" value="<?=$data[date2]?>" style="margin:0 0 2px 0;font-size:15px;padding:2px 0 2px 0;width:30px;border:1px solid #7F9DB9;" />
      월
      <input type="text" name="date3" value="<?=$data[date3]?>" style="font-size:15px;padding:2px 0 2px 0;width:30px;border:1px solid #7F9DB9;" />
      일
    </td>
    <td align="center"><input type="text" name="yo" class="write1_input" value="<?=$data[yo]?>" style="font-size:15px;padding:2px 0 2px 0;" /></td>
    <td align="center"><input type="text" name="chu" class="write1_input" value="<?=$data[chu]?>" style="width:75px;font-size:15px;padding:2px 0 2px 0;" /></td>
    <td align="center"><input type="text" name="gu" class="write1_input" value="<?=$data[gu]?>" style="width:70px;font-size:15px;padding:2px 0 2px 0;" /></td>
    <td align="center"><input type="text" name="ddo" class="write1_input" value="<?=$data[ddo]?>" style="width:75px;font-size:15px;padding:2px 0 2px 0;" /></td>
    <td align="center"><input type="text" name="number" class="write1_input" value="<?=$data[number]?>" style="font-size:15px;padding:2px 0 2px 0;" /></td>
    <td align="center"><input type="text" name="name" class="write1_input" value="<?=$data[name]?>" style="font-size:15px;padding:2px 0 2px 0;" /></td>
    <td align="center"><input type="text" name="ton" class="write1_input" value="<?=$data[ton]?>" style="font-size:15px;padding:2px 0 2px 0;" /></td>
    <td align="center"><input type="text" name="su" class="write1_input" value="<?=$data[su]?>" style="font-size:15px;padding:2px 0 2px 0;" /></td>
  	<td align="center"><input type="text" name="memos" class="write1_input" value="<?=$data[memos]?>" style="font-size:15px;padding:2px 0 2px 0;" /></td>
  	<td align="right" <? if(!$mon){?>style="display:none;"<? }?>><input type="text" name="money" value="<?=$ddmso?>" style="width:45px;font-size:15px;padding:2px 0 2px 0;" />,000</td>
    <td align="center"><input type="text" name="secrets" class="write1_input" value="<?=$data[secrets]?>" style="font-size:15px;padding:2px 0 2px 0;" /></td>
    
    <td align="center"><input type="radio" value="1" name="ox"
    <?
      if($data[ox] == 1) {
    ?>
     checked 
     <?
     }else{}
     ?>
     /></td>
    <td align="center"><input type="radio" value="2" name="ox"
    <?
      if($data[ox] == 2) {
    ?>
    checked 
    <?
    }else{}
    ?>
     /></td>
     
     <td align="center"><input type="text" name="phone" class="write1_input" value="<?=$data[phone]?>" style="width:75px;font-size:15px;padding:2px 0 2px 0;" /></td>
     <td align="center"><input type="checkbox" name="wan" <? if($data[wan] == "(완)") {?>checked<? }?> /><br /><input type="text" name="wandate" value="<?=$data[wandate]?>" style="width:35px;font-size:15px;padding:2px 0 2px 0;" /></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><a href="view2.php?olddate=<?=$olddate?>&view2_password=<?=$view2_password?>&page=<?=$page?>&mmmq=<?=$mmmq?>&mon=<?=$mon?>&id=<?=$id?>" class="view1_button">취소</a></td>
    <td colspan="<? if($mon){?>14<? }else{?>13<? }?>" align="center"><input type="submit" value="수정하기" class="view1_button" /></td>
  </tr>
</table>
</form>
<?
include "foot3.php";
?>
