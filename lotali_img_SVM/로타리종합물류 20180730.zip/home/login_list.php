<?
include "lib.php";
include "head.php";

if(!$page) {
$page = 1;
}

$qco = "select * from min_board_login_list";
$rco = mysql_query($qco, $connect);
$dco = mysql_num_rows($rco);

$pagenum1 = "20";
$pagenum2 = ($page*$pagenum1)-$pagenum1;

$paging = ceil($dco/$pagenum1);
$ai1 = $page-5;
$ai2 = $page+6;

$query = "select * from min_board_login_list order by no desc limit $pagenum2, $pagenum1";
$result = mysql_query($query, $connect);
?>
<table cellpadding="7" cellspacing="0" id="elelmemo" border="0" width="1000px" style="font-size:15px;font-family:'Arial';border:1px solid #cccccc;">
<col width="100" />
<col width="200" />
<col width="320" />
<col width="200" />
<col width="100" />
	<tr>
		<th>상태</th>
		<th>아이피</th>
		<th>세션ID</th>
		<th>시간</th>
		<th>PC/모바일</th>
	</tr>
<?
$cnt = 0;
while($data = mysql_fetch_array($result)) {
if ($data[status] == 0) {
$eeem = "<span style='color:red;'>로그인실패</span>";
}else{
$eeem = "로그인성공";
}
if ($data[computer] == 0) {
$eeem2 = "PC";
}else{
$eeem2 = "모바일";
}
$cntm = $cnt%2;
?>
	<tr>
		<td align="center" <? if($cntm == 1) {?>style="background:#f5f5f5;"<? }?>><?=$eeem?></td>
		<td align="center" <? if($cntm == 1) {?>style="background:#f5f5f5;"<? }?>><?=$data[ip]?></td>
		<td align="left" <? if($cntm == 1) {?>style="background:#f5f5f5;"<? }?>><?=$data[session]?></td>
		<td align="center" <? if($cntm == 1) {?>style="background:#f5f5f5;"<? }?>><?=$data[date]?></td>
		<td align="center" <? if($cntm == 1) {?>style="background:#f5f5f5;"<? }?>><?=$eeem2?></td>
	</tr>
<?
$cnt ++;
}
?>
	<tr>
		<td align="center" colspan="5">
			<a href="login_list.php?page=1" <? if($page == $i) {?>style="font-weight:bold;color:red;"<? }?>><<</a>
<?
for($i=$ai1;$i<$ai2;$i++) {
if($i<1) {
}else{
if($i>$paging) {
}else{
?>
			&nbsp;<a href="login_list.php?page=<?=$i?>" <? if($page == $i) {?>style="font-weight:bold;color:red;"<? }?>>[<?=$i?>]</a>
<?
}}}
?>
			&nbsp;<a href="login_list.php?page=<?=$paging?>" <? if($page == $i) {?>style="font-weight:bold;color:red;"<? }?>>>></a>
		</td>
	</tr>
</table>
<?
include "foot.php";
?>
