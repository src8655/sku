<?
include "lib.php";
include "head.php";
?>
<form action="company_info_write_post.php">
<div class="box" id="companyboxr">
  <h1>작성하기</h1>
 	<p>
 		<span style="font-weight:bold;">회사명</span> : <input type="text" name="company" style="width:200px;font-size:15px;padding:2px 0 2px 0;" />
 	</p>
 	<p>
    <span style="font-weight:bold;">[지번] 주소</span> : <input type="text" name="addr" style="width:450px;font-size:15px;padding:2px 0 2px 0;" />
 	</p>
 	<p>
    <span style="font-weight:bold;">[도로명] 주소</span> : <input type="text" name="addr2" style="width:450px;font-size:15px;padding:2px 0 2px 0;" />
 	</p>
 	<p>
    <span style="font-weight:bold;">우편번호</span> : <input type="text" name="addrnum" style="width:100px;font-size:15px;padding:2px 0 2px 0;" />
 	</p>
 	<p>
    <span style="font-weight:bold;">전화번호</span> : <input type="text" name="tel1" style="width:45px;font-size:15px;padding:2px 0 2px 0;" />-<input type="text" name="tel2" style="width:45px;font-size:15px;padding:2px 0 2px 0;" />-<input type="text" name="tel3" style="width:45px;font-size:15px;padding:2px 0 2px 0;" /> 　　　<span style="font-weight:bold;">FAX번호</span> : <input type="text" name="fax1" style="width:45px;font-size:15px;padding:2px 0 2px 0;" />-<input type="text" name="fax2" style="width:45px;font-size:15px;padding:2px 0 2px 0;" />-<input type="text" name="fax3" style="width:45px;font-size:15px;padding:2px 0 2px 0;" />
 	</p>
 	<p>
    <span style="font-weight:bold;">이메일</span> : <input type="text" name="email" size="50" />
 	</p>
 	<p>
    <span style="font-weight:bold;">담당자</span> : <input type="text" name="name" size="10" /> 　　　<span style="font-weight:bold;">담당자번호</span> : <input type="text" name="phone1" size="5">-<input type="text" name="phone2" size="5">-<input type="text" name="phone3" size="5">
 	</p>
 	<p>
    <span style="font-weight:bold;">메모</span> : <input type="text" name="memo" size="50" />
 	</p>
 	<p style="padding:10px 0 0 0;margin:10px 0 0 0;border-top:1px solid #777777">
   	<div style="float:left;width:80px;text-align:right;"><a href="company_info.php" class="view1_button">취소</a></div><div style="float:right;width:120px;margin:0 200px 0 0;"><input type="submit" value="등록하기" class="view1_button" style="padding:5px 7px 5px 7px;border:1px solid #777777;" /></div>
 	</p>
</div>
</form>
<?
include "foot.php";
?>
