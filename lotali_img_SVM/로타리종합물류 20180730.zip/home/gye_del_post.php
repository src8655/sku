<?
include "lib.php";
include "head.php";

$query = "delete from min_board_gye where no='$no' and company='$company'";
mysql_query($query, $connect);
?>
<script>
	location.href='gye.php?company=<?=$company?>';
</script>
