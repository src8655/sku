<?
define('FPDF_FONTPATH','./mpdf/font/');  
require_once './mpdf/mpdf.php';
 
// 함수의 원형 : function mPDF($mode='',$format='A4',$default_font_size=0,$default_font='',$mgl=15,$mgr=15,$mgt=16,$mgb=16,$mgh=9,$mgf=9, $orientation='P')
$pdf = new mPDF('ko');


ob_start(); 
?>
<?
include "lib.php";
include "head2.php";

$wheree = "where olddate='$olddate'";

if($Search_text){
  if($Search_mode==1) $tmp = "date";
  if($Search_mode==2) $tmp = "ne";
  if($Search_mode==3) $tmp = "ep";
  if($Search_mode==4) $tmp = "je";
  if($Search_mode==5) $tmp = "be";
  
  if(!$company) {
    $where = "$wheree and $tmp like '%$Search_text%'";
  }else{
    $where = "$wheree and $tmp like '%$Search_text%'";
  }
}else{
$where = "$wheree";
}

$mlistall = selectc("min_board_mlist","$where");

$qmlist = "select * from min_board_mlist $where order by date asc, no asc";
$rmlist = mysql_query($qmlist, $connect);

$ef = "select * from min_board_olddate where olddate='$olddate'";
$df = mysql_query($ef, $connect);
$cf = mysql_fetch_array($df);
?>
<table cellpadding="5" cellspacing="0" id="print_a">
<col width="130" />
<col width="170" />
<col width="130" />
<col width="130" />
<col width="130" />
<col width="170" />
	<tr>
		<th colspan="6"><?=$cf[date]?> 경비내역 - </span><span style="font-size:13px; color:red;"><?=$mlistall?></span></th>
	</tr>
	<tr>
		<th width="100">날짜</th>
		<th width="140">내역</th>
		<th width="100">입금</th>
		<th width="100">지출</th>
		<th width="100">잔액</th>
		<th width="140">비고</th>
	</tr>
<?
while($dmlist = mysql_fetch_array($rmlist)) {
$epmje += $dmlist[ep];
$epmje -= $dmlist[je];
?>
	<tr>
		<td align="center"><?=$dmlist[date]?></td>
		<td align="center"><?=$dmlist[ne]?></td>
		<td align="right"><?=number_format($dmlist[ep])?></td>
		<td align="right"><?=number_format($dmlist[je])?></td>
		<td align="right"><? if($Search_text) {?>검색은 자동계산이 제한됩니다.<? }else{?><?=number_format($epmje)?><? }?></td>
		<td align="center"><?=$dmlist[be]?></td>
	</tr>
<?
$eps += $dmlist[ep];
$jes += $dmlist[je];
}
?>
	<tr>
		<td>　</td>
		<td>　</td>
		<td>　</td>
		<td>　</td>
		<td align="center">총잔액</td>
		<td>　</td>
	</tr>
	<tr>
		<td>　</td>
		<td>　</td>
		<td align="right"><?=number_format($eps)?></td>
		<td align="right"><?=number_format($jes)?></td>
		<td align="right"><? if($Search_text) {?>검색은 자동계산이 제한됩니다.<? }else{?><?=number_format($epmje)?><? }?></td>
		<td>　</td>
	</tr>
</table>
<?
include "foot2.php";
?>

<?
$html=ob_get_contents(); 
ob_end_clean(); 
$html = iconv("UTF-8","UTF-8",$html);

$pdf->SetTopMargin(25);
$pdf->SetFont('Arial');
$pdf->Bookmark("로타리장부",0);
// $pdf->SetDisplayMode('fullpage');   // pdf가 열릴때 창크기에 맞게 보여지도록 함. 이부분이 주석처리되거나 삭제되면 창크기에 맞춰지지 않고 pdf Viewer의 설정을 따르게됨
 
$pdf->WriteHTML($html);
$pdf->Output();     // 웹상에서 열림
?>
