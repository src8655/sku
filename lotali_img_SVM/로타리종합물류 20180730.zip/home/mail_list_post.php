<?
include "lib.php";
include "head.php";

if(!$company) {
	echo("
		<script>
			window.alert('회사이름을 입력해주세요.')
			history.go(-1)
		</script>
	");
	exit;
}
if(!$email) {
	echo("
		<script>
			window.alert('이메일을 입력해주세요.')
			history.go(-1)
		</script>
	");
	exit;
}

$query = "insert into min_board_mail_list(company,email)
					values('$_REQUEST[company]','$_REQUEST[email]')";
mysql_query($query, $connect);
?>
<script>
	location.href="mail_list.php";
</script>
<?
include "foot.php";
?>
