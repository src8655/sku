<?
include "lib.php";
include "head.php";

if(!$page) $page = 1;

$elcount = selectc("min_board_el","");

$pagenum1 = "10";
$pagenum2 = ($pagenum1*$page)-10;

$paging = ceil($elcount/$pagenum1);

$query = "select * from min_board_el order by date2 desc limit $pagenum2,$pagenum1";
$result = mysql_query($query, $connect);
?>
<form action="el_post.php" method="post" id="writep" name="writepp">
<table cellpadding="6" cellspacing="1" width="1000px" id="write1_table" style="margin-bottom:10px;font-size:17px;font-family:'Arial';">
<col width="200" />
<col width="" />
<col width="150" />
<col width="150" />
	<tr>
		<th colspan="4">일일 일지 - <span style="color:red;"><?=$elcount?></span></th>
	</tr>
	<tr>
		<th>번호</th>
		<th>날짜</th>
		<th>수정</th>
		<th>삭제</th>
	</tr>
	<tr>
		<th>추가</th>
		<td align="center">
			<select name="date1w" style="font-size:17px;">
				<? for($i=(date("Y")-1);$i<(date("Y")+10);$i++) {?>
				<option value="<?=$i?>" <? if($i==date("Y")){?>selected<? }?>><?=$i?></option>
				<? }?>
			</select>
			년&nbsp;
			<select name="date2w" style="font-size:17px;">
				<? for($i=1;$i<13;$i++) { if($i<10) $ax = "0".$i; else $ax = $i;?>
				<option value="<?=$ax?>" <? if($ax==date("m")){?>selected<? }?>><?=$ax?></option>
				<? }?>
			</select>
			월&nbsp;
			<select name="date3w" style="font-size:17px;">
				<? for($i=1;$i<32;$i++) { if($i<10) $ax = "0".$i; else $ax = $i;?>
				<option value="<?=$ax?>" <? if($ax==date("d")){?>selected<? }?>><?=$ax?></option>
				<? }?>
			</select>
			일&nbsp;
			<select name="date5w" style="font-size:17px;">
				<?
				for($i=0;$i<7;$i++) {
				if($i==0) $yos="일요일";
				if($i==1) $yos="월요일";
				if($i==2) $yos="화요일";
				if($i==3) $yos="수요일";
				if($i==4) $yos="목요일";
				if($i==5) $yos="금요일";
				if($i==6) $yos="토요일";
				?>
				<option value="<?=$yos?>" <? if($i==date("w")){?>selected<? }?>><?=$yos?></option>
				<? }?>
			</select>
		</td>
		<td align="center" colspan="2"><input type="submit" value="날짜 추가하기" class="view1_button" style="width:90%;" /></td>
	</tr>
<?
$cnt = 0;
while($data = mysql_fetch_array($result)) {
?>
	<tr>
		<td align="center"><?=$elcount-$pagenum2-$cnt?></td>
		<td align="center"><a href="el_d.php?el=<?=$data[no]?>" class="el_a">&nbsp;<span style="font-weight:bold;"><?=$data[date]?> <?=$data[yos]?> 일지</span> [클릭]</a></td>
		<td align="center"><a href="el_edit.php?no=<?=$data[no]?>&page=<?=$page?>" class="view1_button">수정</a></td>
		<td align="center"><a href="el_del.php?no=<?=$data[no]?>&page=<?=$page?>" class="view1_button">삭제</a></td>
	</tr>
<?
$cnt += 1;
}
?>
	<tr>
		<td align="center" colspan="4">
			<? for($i=$page-5;$i<$page+5;$i++){ if($i<1) continue;if($i>$paging) break;?>
			<a href="el.php?page=<?=$i?>" <? if($i == $page){?>style="font-weight:bold;color:red;"<? }?>>&nbsp;[<?=$i?>]</a>
			<? }?>
		</td>
	</tr>
</table>
</form>
<?
include "foot.php";
?>