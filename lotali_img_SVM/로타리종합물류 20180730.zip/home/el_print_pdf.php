<?
define('FPDF_FONTPATH','./mpdf/font/');  
require_once './mpdf/mpdf.php';
 
// 함수의 원형 : function mPDF($mode='',$format='A4',$default_font_size=0,$default_font='',$mgl=15,$mgr=15,$mgt=16,$mgb=16,$mgh=9,$mgf=9, $orientation='P')
$pdf = new mPDF('ko','A4-L'); 


ob_start(); 
?>
<?
include "lib.php";
include "head2.php";

$qm = "select * from min_board_el where no='$el'";
$rm = mysql_query($qm, $connect);
$dm = mysql_fetch_array($rm);

$allcount = selectc("min_board_el_d","where el='$el'");

$query = "select * from min_board_el_d where el='$el' order by no asc";
$result = mysql_query($query, $connect);
?>
<table cellpadding="8" cellspacing="0" border="0" style="width:100%;">
	<tr>
		<th style="font-size:35px;font-weight:bold;">일 일 일 지</th>
	</tr>
</table>
<table cellpadding="8" cellspacing="0" border="0" style="width:100%;">
	<tr>
		<td align="right" style="font-size:20px;font-weight:bold;">
			<?=$dm[date]?> <?=$dm[yos]?>
			<span style="color:red;"><?=$allcount?></span>건
		</td>
	</tr>
</table>
<table cellpadding="8" cellspacing="0" id="print_a" style="font-size:17px;">
<col width="70" />
<col width="130" />
<col width="130" />
<col width="110" />
<col width="100" />
<col width="160" />
<col width="100" />
<col width="130" />
<col width="150" />
	<tr>
		<th width="70">번호</th>
		<th width="130">출발지</th>
		<th width="130">도착지</th>
		<th width="110">차량</th>
		<th width="100">차량번호</th>
		<th width="160">핸드폰번호</th>
		<th width="100">성명</th>
		<th width="130">금액</th>
		<th width="150">비고</th>
	</tr>
<?
$cnt = 1;
while($data = mysql_fetch_array($result)) {
$datas = $data[money]*1000;
?>
	<tr>
		<td align="center"><?=$cnt?></td>
		<td align="center"><?=$data[chu]?></td>
		<td align="center"><?=$data[ddo]?></td>
		<td align="center"><?=$data[car]?></td>
		<td align="center"><?=$data[number]?></td>
		<td align="center"><?=$data[phone]?></td>
		<td align="center"><?=$data[name]?></td>
		<td align="right"><?=number_format($datas)?></td>
		<td align="center"><?=$data[memo]?></td>
	</tr>
<?
$cnt += 1;
}
?>
</table>
<?
include "foot2.php";
?>

<?
$html=ob_get_contents(); 
ob_end_clean(); 
$html = iconv("UTF-8","UTF-8",$html);

$pdf->SetTopMargin(12);
$pdf->Bookmark("로타리장부",0);
// $pdf->SetDisplayMode('fullpage');   // pdf가 열릴때 창크기에 맞게 보여지도록 함. 이부분이 주석처리되거나 삭제되면 창크기에 맞춰지지 않고 pdf Viewer의 설정을 따르게됨
 
$pdf->WriteHTML($html);
$pdf->Output();     // 웹상에서 열림
?>
