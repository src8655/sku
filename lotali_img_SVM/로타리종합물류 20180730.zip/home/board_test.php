<?
include "lib.php";
include "head2.php";

if(!$page) {
  $page = "1";
}

/* *****************페이징**************** */

$pagenum = 15;
$pages = $page*$pagenum-$pagenum+1;

/* ********************************* */

/* *****************페이지 갯수**************** */

$q = "select count(*) from min_board_data1";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

$board_count = $d[0];
$board_nanugi1 = round($board_count/$pagenum)+1;

/* ********************************* */

$query = "select * from min_board_data1 order by no desc limit $pages , $pagenum";
$result = mysql_query($query, $connect);
?>
<table border="1" cellpadding="7" cellspacing="1" style="margin:0 auto;" width="700">
<col width="50">
<col width="100">
<col width="100">
<col width="100">
<col width="100">
<col width="100">
  <tr>
    <th>번호</th>
    <th>차량번호</th>
    <th>이름</th>
    <th>금액</th>
    <th>메모</th>
    <th>기타</th>
  </tr>
<?
while($data = mysql_fetch_array($result)) {

$ise += 1;
?>
  <tr>
    <td align="center"><?=$ise?></td>
    <td align="center"><?=$data[number]?></td>
    <td align="center"><?=$data[name]?></td>
    <td align="right"><?=number_format($data[money])?></td>
    <td align="center"><?=$data[memo1]?></td>
    <td align="center"><?=$data[memo2]?></td>
  </tr>
<?
}
?>
  <tr>
    <td colspan="6" align="center">
    <a href="board_test.php?page=1" style="font-weight:bold;"><<</a>
    <?
    $i1 = $page-5;
    $i2 = $page+6;
    
    for($i=$i1;$i<$i2;$i++) {
    
    if($i<1) {
    
    }else{
    if($i>$board_nanugi1){
    
    }else{
    ?>
    <a href="board_test.php?page=<?=$i?>" <? if($i==$page){?> style="font-weight:bold;"<? }?>><?=$i?></a>
    <?
    }}}
    ?>
    <a href="board_test.php?page=<?=$board_nanugi1?>" style="font-weight:bold;">>></a>
    </td>
  </tr>
</table>

<?
include "foot2.php";
?>
