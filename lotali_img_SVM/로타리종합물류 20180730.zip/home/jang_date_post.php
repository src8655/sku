<?
include "lib.php";
include "head.php";

$qch = "select count(*) from min_board_jang_date where date='$jang_date'";
$rch = mysql_query($qch, $connect);
$dch = mysql_fetch_array($rch);

if($dch[0] != 0) {
	echo("
		<script>
			window.alert('이미 존재하는 날짜입니다.')
			history.go(-1)
		</script>
	");
	exit;
}

$query = "insert into min_board_jang_date(date)
					values('$_REQUEST[jang_date]')";
mysql_query($query, $connect);
?>
<script>
	location.href='index.php';
</script>
