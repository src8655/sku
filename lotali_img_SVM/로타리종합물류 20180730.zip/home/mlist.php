<?
include "lib.php";
include "head.php";

$wheree = "where olddate='$olddate'";

if($Search_text){
  if($Search_mode==1) $tmp = "date";
  if($Search_mode==2) $tmp = "ne";
  if($Search_mode==3) $tmp = "ep";
  if($Search_mode==4) $tmp = "je";
  if($Search_mode==5) $tmp = "be";
  
  if(!$company) {
    $where = "$wheree and $tmp like '%$Search_text%'";
  }else{
    $where = "$wheree and $tmp like '%$Search_text%'";
  }
}else{
$where = "$wheree";
}

$mlistall = selectc("min_board_mlist","$where");

$qmlist = "select * from min_board_mlist $where order by date asc, no asc";
$rmlist = mysql_query($qmlist, $connect);
?>
<form action="<?=$PHP_SELF?>" id="writep">
<table cellpadding="5" cellspacing="1" width="1000px" id="write1_table" border="0" style="margin-bottom:10px;">
<col width="200" />
<col width="600" />
<col width="200" />
<input type="hidden" name="olddate" value="<?=$olddate?>" />
  <tr>
    <td><a href="index.php?olddate=<?=$olddate?>" class="view1_button">뒤로가기</a></td>
    <td align="center">
      <select name="Search_mode" id="searchmode">
        <option value="1" <? if($Search_mode == 1){?>selected<? }?>>날짜</option>
        <option value="2" <? if($Search_mode == 2){?>selected<? }?>>내역</option>
        <option value="3" <? if($Search_mode == 3){?>selected<? }?>>입금</option>
        <option value="4" <? if($Search_mode == 4){?>selected<? }?>>지출</option>
        <option value="5" <? if($Search_mode == 5){?>selected<? }?>>비고</option>
      </select>
      <input type="text" name="Search_text" value="<?=$Search_text?>" id="searchtext" size="30" />
      <input type="submit" value="검색" id="searchbutton" />
    </td>
    <td>
      <a href="#bottomtxx" class="view1_button">맨 아래로</a>
    </td>
  </tr>
</table>
</form>
<table cellpadding="5" cellspacing="1" id="write1_table" border="0" width="1000px" style="font-size:15px;font-family:'Arial';">
<col width="130" />
<col width="170" />
<col width="130" />
<col width="130" />
<col width="130" />
<col width="170" />
<col width="70" />
<col width="70" />
	<tr>
		<th colspan="8">경비내역 - </span><span style="font-size:13px; color:red;"><?=$mlistall?></span></th>
	</tr>
	<tr>
		<th>날짜</th>
		<th>내역</th>
		<th>입금</th>
		<th>지출</th>
		<th>잔액</th>
		<th>비고</th>
		<th colspan="2">관리</th>
	</tr>
<form action="mlist_post.php" method="post" id="writep" name="writepp">
<input type="hidden" name="olddate" value="<?=$olddate?>" />
	<tr>
		<td align="center">
			<input type="text" name="date2" style="font-size:15px;padding:2px 0 2px 0;width:35px;border:1px solid #7F9DB9;margin-bottom:2px;" /> 월
			<input type="text" name="date3" style="font-size:15px;padding:2px 0 2px 0;width:35px;border:1px solid #7F9DB9;" /> 일
		</td>
		<td align="center"><input type="text" name="ne" style="font-size:15px;padding:2px 0 2px 0;width:140px;border:1px solid #7F9DB9;" /></td>
		<td align="center"><input type="text" name="ep" style="font-size:15px;padding:2px 0 2px 0;width:110px;border:1px solid #7F9DB9;" /></td>
		<td align="center"><input type="text" name="je" style="font-size:15px;padding:2px 0 2px 0;width:110px;border:1px solid #7F9DB9;" /></td>
		<td align="center">자동계산</td>
		<td align="center"><input type="text" name="be" style="font-size:15px;padding:2px 0 2px 0;width:140px;border:1px solid #7F9DB9;" /></td>
		<td colspan="2" align="center"><input type="submit" value="작성하기" class="view1_button" style="width:90%;" /></td>
	</tr>
</form>
<?
while($dmlist = mysql_fetch_array($rmlist)) {
$epmje += $dmlist[ep];
$epmje -= $dmlist[je];
?>
	<tr id="qq">
		<td align="center"><?=$dmlist[date]?></td>
		<td align="center"><?=$dmlist[ne]?></td>
		<td align="right"><?=number_format($dmlist[ep])?></td>
		<td align="right"><?=number_format($dmlist[je])?></td>
		<td align="right"><? if($Search_text) {?>검색은 자동계산이 제한됩니다.<? }else{?><?=number_format($epmje)?><? }?></td>
		<td align="center"><?=$dmlist[be]?></td>
		<td align="center"><a href="mlist_edit.php?no=<?=$dmlist[no]?>&olddate=<?=$olddate?>" class="view1_button">수정</a></td>
		<td align="center"><a href="mlist_del.php?no=<?=$dmlist[no]?>&olddate=<?=$olddate?>" class="view1_button">삭제</a></td>
	</tr>
<?
$eps += $dmlist[ep];
$jes += $dmlist[je];
}
?>
	<tr>
		<td>　</td>
		<td>　</td>
		<td>　</td>
		<td>　</td>
		<td align="center">총잔액</td>
		<td>　</td>
		<td>　</td>
		<td>　</td>
	</tr>
	<tr>
		<td>　</td>
		<td>　</td>
		<td align="right"><?=number_format($eps)?></td>
		<td align="right"><?=number_format($jes)?></td>
		<td align="right"><? if($Search_text) {?>검색은 자동계산이 제한됩니다.<? }else{?><?=number_format($epmje)?><? }?></td>
		<td>　</td>
		<td>　</td>
		<td>　</td>
	</tr>
	<tr>
    <td colspan="8">
    	<div style="float:left;width:10%;padding:0 6px 0 0;overflow:hidden;">
			<form action="mlist_print.php" target="_blank">
				<input type="hidden" name="olddate" value="<?=$olddate?>" />
				<input type="hidden" name="Search_text" value="<?=$Search_text?>" />
				<input type="hidden" name="Search_mode" value="<?=$Search_mode?>" />
				<input type="submit" value="인쇄1" class="view1_button" style="width:100%;" />
			</form>
			</div>
    	<div style="float:left;width:10%;padding:0 6px 0 0;overflow:hidden;">
				<form action="mlist_print_pdf.php" target="_blank">
					<input type="hidden" name="olddate" value="<?=$olddate?>" />
					<input type="hidden" name="Search_text" value="<?=$Search_text?>" />
					<input type="hidden" name="Search_mode" value="<?=$Search_mode?>" />
					<input type="submit" value="인쇄2" class="view1_button" style="width:100%;" />
				</form>
			</div>
    	<div style="float:right;width:20%;overflow:hidden;">
				<a href="#toptxx" class="view1_button">맨 위로</a>
			</div>
		</td>
	</tr>
</table>
<?
include "foot.php";
?>
