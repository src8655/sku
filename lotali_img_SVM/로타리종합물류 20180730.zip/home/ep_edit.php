<?
include "lib.php";
include "head.php";

$query = "select * from min_board_ep where olddate='$olddate' and no='$no'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<form action="ep_edit_post.php">
<input type="hidden" name="olddate" value="<?=$olddate?>" />
<input type="hidden" name="no" value="<?=$data[no]?>" />
<table cellpadding="7" cellspacing="1" width="1000px" id="write1_table" border="0" style="margin-bottom:10px;font-family:'Arial';font-size:13px;">
<col width="130">
<col width="100">
<col width="200">
<col width="100">
<col width="100">
<col width="110">
<col width="110">
	<tr>
		<th>상호</th>
		<th>발행 총금액</th>
		<th>전자세금&일세금발행</th>
		<th>공급가액</th>
		<th>세액</th>
		<th>입금확인</th>
		<th>메모</th>
	</tr>
	<tr>
		<th><?=$data[name]?></th>
		<td align="center">자동계산</td>
		<td align="center">
			전자세금 : <input type="checkbox" value="2" name="checks" <? if($data[checks] == 2) {?>checked<? }?> /> / 
			일반세금 : <input type="checkbox" value="2" name="checks2" <? if($data[checks2] == 2) {?>checked<? }?> />
		</td>
		<td align="center"><input type="text" name="money" value="<?=$data[money]?>" style="width:80px;" /></td>
		<td align="center">자동계산</td>
		<td align="center"><input type="text" name="date1" value="<?=$data[date]?>" style="width:20px;" />월 <input type="text" name="date2" value="<?=$data[date2]?>" style="width:20px;" />일</td>
		<td align="center"><input type="text" name="memo" value="<?=$data[memo]?>" style="width:100px;" /></td>
	</tr>
	<tr>
		<td align="center"><a href="ep.php?olddate=<?=$olddate?>" class="view1_button">취소</a></td>
		<td align="center" colspan="6"><input type="submit" value="수정하기" class="view1_button"></td>
	</tr>
</table>
</form>
<?
include "foot.php";
?>
