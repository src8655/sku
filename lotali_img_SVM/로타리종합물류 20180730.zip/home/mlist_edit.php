<?
include "lib.php";
include "head.php";

$qmlist = "select * from min_board_mlist where no='$no' and olddate='$olddate'";
$rmlist = mysql_query($qmlist, $connect);
$dmlist = mysql_fetch_array($rmlist);
?>
<form action="mlist_edit_post.php" method="post" id="writep" name="writepp">
<input type="hidden" name="olddate" value="<?=$olddate?>" />
<input type="hidden" name="no" value="<?=$dmlist[no]?>" />
<table cellpadding="5" cellspacing="1" id="write1_table" border="0" width="1000px" style="font-size:15px;font-family:'Arial';">
<col width="130" />
<col width="170" />
<col width="130" />
<col width="130" />
<col width="130" />
<col width="170" />
<col width="70" />
<col width="70" />
	<tr>
		<th colspan="6">수정하기</th>
	</tr>
	<tr>
		<th>날짜</th>
		<th>내역</th>
		<th>입금</th>
		<th>지출</th>
		<th>잔액</th>
		<th>비고</th>
	</tr>
	<tr>
		<td align="center">
			<input type="text" name="date2" style="width:25px;border:1px solid #7F9DB9;height:18px;line-height:18px;margin-bottom:2px;" value="<?=$dmlist[date2]?>" /> 월
			<input type="text" name="date3" style="width:25px;border:1px solid #7F9DB9;height:18px;line-height:18px;" value="<?=$dmlist[date3]?>" /> 일
		</td>
		<td align="center"><input type="text" name="ne" style="width:140px;border:1px solid #7F9DB9;height:18px;line-height:18px;" value="<?=$dmlist[ne]?>" /></td>
		<td align="center"><input type="text" name="ep" style="width:110px;border:1px solid #7F9DB9;height:18px;line-height:18px;" value="<?=$dmlist[ep]?>" /></td>
		<td align="center"><input type="text" name="je" style="width:110px;border:1px solid #7F9DB9;height:18px;line-height:18px;" value="<?=$dmlist[je]?>" /></td>
		<td align="center">자동계산</td>
		<td align="center"><input type="text" name="be" style="width:140px;border:1px solid #7F9DB9;height:18px;line-height:18px;" value="<?=$dmlist[be]?>" /></td>
	</tr>
  <tr>
    <td align="center"><a href="mlist.php?olddate=<?=$olddate?>" class="view1_button">취소</a></td>
    <td colspan="5" align="center"><input type="submit" value="수정하기" class="view1_button" /></td>
  </tr>
</table>
</form>
<?
include "foot.php";
?>
