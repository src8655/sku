<?
include "lib.php";
include "head.php";

if(!$name) {
  echo("
    <script>
      window.alert('회사 이름을 입력해주세요.')
      history.go(-1);
    </script>
  ");
  exit;
}

$qn = "select * from min_board_admin where name='$name'";
$rn = mysql_query($qn, $connect);
$dn = mysql_fetch_array($rn);

if($dn[name]) {
	echo("
		<script>
			window.alert('이미 존재하는 회사명입니다.')
			history.go(-1)
		</script>
	");
	exit;
}

$query = "insert into min_board_admin(name, orders)
          values('$_REQUEST[name]','$_REQUEST[orders]')";
mysql_query($query, $connect);
?>
<script>
  location.href='index.php?olddate=<?=$olddate?>';
</script>
