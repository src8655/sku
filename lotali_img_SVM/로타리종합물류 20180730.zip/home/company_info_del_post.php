<?
include "lib.php";
include "head.php";

$query = "delete from min_board_info where no='$no'";
mysql_query($query, $connect);
?>
<script>
  location.href='company_info.php';
</script>
