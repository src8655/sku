<?
include "lib.php";
include "head.php";

$query = "select * from min_board_ep where no='$no' and olddate='$olddate'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<table cellpadding="7" cellspacing="1" id="write1_table" border="0" style="margin-bottom:10px;font-family:'Arial';font-size:15px;">
	<tr>
		<th colspan="2"><?=$data[name]?> 을 정말로 삭제하시겠습니까?</th>
	</tr>
	<tr>
		<td><a href="ep.php?olddate=<?=$olddate?>" class="view1_button">취소</a></td>
		<td><a href="ep_del_post.php?olddate=<?=$olddate?>&no=<?=$no?>" class="view1_button">삭제</a></td>
	</tr>
</table>
<?
include "foot.php";
?>
