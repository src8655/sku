<?
include "lib.php";
include "head.php";

$query = "update min_board_el_d set
					chu='$_REQUEST[date2]',
					ddo='$_REQUEST[ddo]',
					car='$_REQUEST[car]',
					number='$_REQUEST[number]',
					phone='$_REQUEST[phone]',
					name='$_REQUEST[name]',
					money='$_REQUEST[money]',
					memo='$_REQUEST[memo]' where no='$no'"
mysql_query($query, $connect);
?>
<script>
	location.href="el_d.php?el=<?=$el?>";
</script>
<?
include "foot.php";
?>