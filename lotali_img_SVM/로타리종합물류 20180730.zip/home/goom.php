<?
include "lib.php";
include "head2.php";
?>
<style>
body {
margin:0px;
padding:0px;
}
</style>
<form name="empabm">
<table cellpadding="0" cellspacing="0" id="mmgemp">
	<tr>
		<th colspan="4"><textarea type="text" id="oplsm"></textarea></th>
	</tr>
	<tr>
		<td><input type="button" value="◀" style="font-size:50px;" onclick="backs()" /></td>
		<td><input type="button" value="." onclick="epepl1('.')" /></td>
		<td><input type="button" value="C" onclick="epepl3()" /></td>
		<td><input type="button" value="÷" onclick="epepl1('/')" /></td>
	</tr>
	<tr>
		<td><input type="button" value="7" onclick="epepl1(7)" /></td>
		<td><input type="button" value="8" onclick="epepl1(8)" /></td>
		<td><input type="button" value="9" onclick="epepl1(9)" /></td>
		<td><input type="button" value="*" onclick="epepl1('*')" /></td>
	</tr>
	<tr>
		<td><input type="button" value="4" onclick="epepl1(4)" /></td>
		<td><input type="button" value="5" onclick="epepl1(5)" /></td>
		<td><input type="button" value="6" onclick="epepl1(6)" /></td>
		<td><input type="button" value="-" onclick="epepl1('-')" /></td>
	</tr>
	<tr>
		<td><input type="button" value="1" onclick="epepl1(1)" /></td>
		<td><input type="button" value="2" onclick="epepl1(2)" /></td>
		<td><input type="button" value="3" onclick="epepl1(3)" /></td>
		<td rowspan="2"><input type="button" value="+" onclick="epepl1('+')" style="height:140px;" /></td>
	</tr>
	<tr>
		<td><input type="button" value="0" onclick="epepl1(0)" /></td>
		<td colspan="2"><input type="button" value="=" onclick="epepl2()" style="width:142px;" /></td>
	</tr>
</table>
</form>
<script>
var oplsm = document.getElementById("oplsm");
var oplsmdata = "";
function epepl2() {
var a=eval(document.empabm.oplsm.value);
oplsm.innerText = a;
}
function epepl1(datases) {
oplsmdata = document.empabm.oplsm.value+datases;
oplsm.innerText = oplsmdata;
}
function epepl3() {
oplsm.innerText = "";
}
function backs() {
var bc = document.empabm.oplsm.value.length;
var bcs = eval(bc-1);
oplsm.innerText = document.empabm.oplsm.value.substr(0,bcs);
}
</script>
<?
include "foot2.php";
?>
