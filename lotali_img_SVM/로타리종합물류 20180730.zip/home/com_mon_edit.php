<?
include "lib.php";
include "head.php";


$q = "update min_board_com_mon set
      memos='$_POST[memos]' where no='1'";
mysql_query($q, $connect);
?>
<script>
  location.href="com_mon.php";
</script>
<?
include "foot.php";
?>
