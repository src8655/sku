<?
include "lib.php";
include "head.php";

$query = "insert into min_board_info(company, addr, tel1, tel2, tel3, fax1, fax2, fax3, email, name, phone1, phone2, phone3, memo, addr2, addrnum)
          values('$_REQUEST[company]','$_REQUEST[addr]','$_REQUEST[tel1]','$_REQUEST[tel2]','$_REQUEST[tel3]','$_REQUEST[fax1]','$_REQUEST[fax2]','$_REQUEST[fax3]','$_REQUEST[email]','$_REQUEST[name]','$_REQUEST[phone1]','$_REQUEST[phone2]','$_REQUEST[phone3]','$_REQUEST[memo]','$_REQUEST[addr2]','$_REQUEST[addrnum]')";
mysql_query($query, $connect);
?>
<script>
  location.href='company_info.php';
</script>
<?
include "foot.php";
?>
