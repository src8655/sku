<?
include "lib.php";
include "head.php";

$query = "select * from min_board_memo where no='$no'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<table cellpadding="7" cellspacing="1" id="write1_table" border="0" width="1000px">
  <tr>
    <td><a href="memo_list.php?olddate=<?=$olddate?>" class="view1_button">뒤로가기</a></td>
  </tr>
</table>
<br />
<form action="memo_edit_post.php">
<input type="hidden" name="olddate" value="<?=$olddate?>" />
<input type="hidden" name="no" value="<?=$no?>" />
<table cellpadding="7" cellspacing="0" id="elelmemo" border="0" width="1000px" style="border:1px solid #cccccc;">
  <tr>
    <th>내용</th>
  </tr>
  <tr>
    <td align="center"><textarea name="memo" style="width:98%; height:100px;"><?=$data[memo]?></textarea></td>
  </tr>
  <tr>
    <td align="center"><input type="submit" value="수정하기" class="view1_button" /></td>
  </tr>
</table>
</form>
<?
include "foot.php";
?>
