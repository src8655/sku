<?
define('FPDF_FONTPATH','./mpdf/font/');  
require_once './mpdf/mpdf.php';
 
// 함수의 원형 : function mPDF($mode='',$format='A4',$default_font_size=0,$default_font='',$mgl=15,$mgr=15,$mgt=16,$mgb=16,$mgh=9,$mgf=9, $orientation='P')
$pdf = new mPDF('ko');

ob_start(); 
?>





<?
include "lib.php";
include "head2.php";


$query = "select * from min_board_info $where order by company asc";
$result = mysql_query($query, $connect);
?>


<table cellpadding="8" cellspacing="0" id="print_te" style="width:100%;">
	<tr>
<?
$tem = 0;
while($data = mysql_fetch_array($result)) {
$tem = $tem+1;
?>
		<td style="font-size:12px;">
			<p><span style="font-weight:bold;font-size:15px;"><?=$data[company]?></span></p>
			<p <? if(!$data[addr]) {?>style="display:none;"<? }?>>
				<span style="font-weight:bold;">[지번] 주소</span> : <span style="color:red;font-weight:bold;"><?=$data[addr]?></span>
			</p>
			<p <? if(!$data[addr2]) {?>style="display:none;"<? }?>>
				<span style="font-weight:bold;">[도로명] 주소</span> : <span style="color:blue;font-weight:bold;"><?=$data[addr2]?></span>
			</p>
			<p <? $okl = $data[tel1].$data[tel2].$data[tel3].$data[fax1].$data[fax2].$data[fax3]; if(!$okl) {?>style="display:none;"<? }?>>
				<span <? $okl2 = $data[tel1].$data[tel2].$data[tel3]; if(!$okl2) {?>style="display:none;"<? }?>><span style="font-weight:bold;">전화번호</span> : <?=$data[tel1]?>-<?=$data[tel2]?>-<?=$data[tel3]?> 　　　</span><span <? $okl1 = $data[fax1].$data[fax2].$data[fax3]; if(!$okl1) {?>style="display:none;"<? }?>><span style="font-weight:bold;">FAX번호</span> : <?=$data[fax1]?>-<?=$data[fax2]?>-<?=$data[fax3]?></span>
			</p>
			<p <? if(!$data[email]) {?>style="display:none;"<? }?>>
				<span style="font-weight:bold;">이메일</span> : <?=$data[email]?>
			</p>
			<p <? $okl3 = $data[name].$data[phone1].$data[phone2].$data[phone3]; if(!$okl3) {?>style="display:none;"<? }?>>
				<span style="font-weight:bold;">담당자</span> : <?=$data[name]?> 　　　<span style="font-weight:bold;">담당자번호</span> : <?=$data[phone1]?>-<?=$data[phone2]?>-<?=$data[phone3]?>
			</p>
	<?
	$quer = "select * from min_board_info_plus where id='$data[no]' order by no desc";
	$reer = mysql_query($quer, $connect);
	while($daer = mysql_fetch_array($reer)) {
	?>
	      <p>
	      	<span style="font-weight:bold;">담당자</span> : <?=$daer[name]?> 　　　<span style="font-weight:bold;">담당자번호</span> : <?=$daer[phone1]?>-<?=$daer[phone2]?>-<?=$daer[phone3]?> 　　<a href="company_info_plus_del2.php?no=<?=$daer[no]?>&onon=<?=$data[no]?>&page=<?=$page?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>"><span style="font-weight:normal; font-size:11px; color:red;">(삭제)</span></a>
	      </p>
	<?
	}
	?>
	      <p <? if(!$data[memo]) {?>style="display:none;"<? }?>>
	      	<span style="font-weight:bold;">메모</span> : <?=$data[memo]?>
	      </p>
    </td>
    <?
    if($tem == 2) {
    	$tem = 0;
    ?>
  </tr>
  <tr>
  <?
		}
  ?>
<?
}
?>
	</table>
<?
include "foot2.php";
?>









<?
$html=ob_get_contents(); 
ob_end_clean(); 
$html = iconv("UTF-8","UTF-8",$html);
$pdf->SetTopMargin(25);
$pdf->bookmark("로타리종합물류",0);
// $pdf->SetDisplayMode('fullwidth');   // pdf가 열릴때 창크기에 맞게 보여지도록 함. 이부분이 주석처리되거나 삭제되면 창크기에 맞춰지지 않고 pdf Viewer의 설정을 따르게됨
$pdf->WriteHTML($html);
$pdf->Output();     // 웹상에서 열림
?>
