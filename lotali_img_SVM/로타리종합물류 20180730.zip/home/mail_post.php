<?
include "lib.php";
include "head.php";
include "Sendmail.php";
















if(!$ba) {
	echo("
		<script>
			window.alert('받는사람 이메일을 입력해주세요')
			history.go(-1)
		</script>
	");
	exit;
}
if(!$bo) {
	echo("
		<script>
			window.alert('보내는사람 이메일을 입력해주세요')
			history.go(-1)
		</script>
	");
	exit;
}
if(!$subject) {
	echo("
		<script>
			window.alert('제목을 입력해주세요')
			history.go(-1)
		</script>
	");
	exit;
}
$ddm1 = date("y");
$ddm2 = date("m");
$ddm3 = date("d");
$ddm4 = date("h");
$ddm5 = date("i");
$ddm6 = date("s");

if($files1) {
$filesname1 = $files1_name;
$ffd1 = explode(".",$filesname1);


$_REQUEST[filesname11] = time().$ddm6."1."."xls";

if(!ereg("xls",$filesname1)) {
	echo("
		<script>
			window.alert('xls 파일만 업로드 가능합니다')
			history.go(-1)
		</script>
	");
	exit;
}}

if($files2) {
$filesname2 = $files2_name;
$ffd2 = explode(".",$filesname2);


$_REQUEST[filesname22] = time().$ddm6."2."."xls";

if(!ereg("xls",$filesname2)) {
	echo("
		<script>
			window.alert('xls 파일만 업로드 가능합니다')
			history.go(-1)
		</script>
	");
	exit;
}}

$_REQUEST[date] = $ddm1."-".$ddm2."-".$ddm3." ".$ddm4.":".$ddm5;

$query = "insert into min_board_mail(ba, bo, subject, memo, files, date, files2)
					values('$_REQUEST[ba]','$_REQUEST[bo]','$_REQUEST[subject]','$_REQUEST[memo]','$_REQUEST[filesname11]','$_REQUEST[date]','$_REQUEST[filesname22]')";
mysql_query($query, $connect);

move_uploaded_file($files1,"../data/".$_REQUEST[filesname11]);
move_uploaded_file($files2,"../data/".$_REQUEST[filesname22]);

$q = "select * from min_board_mail where subject='$subject' and memo='$memo' and ba='$ba' and bo='$bo'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

$headers = 'From: '.$bo."\r\n";

if($files1) {
$filesmm1 = "<br />첨부파일 1 : http://로타리종합물류.com/data/$_REQUEST[filesname11]";
}else{
	$filesmm1 = "";
}
if($files2) {
$filesmm2 = "<br />첨부파일 2 : http://로타리종합물류.com/data/$_REQUEST[filesname22]";
}else{
	$filesmm2 = "";
}
/*
$memos = $memo." ".$filesmm1.$filesmm2;
$subject    = "=?utf-8?B?".base64_encode($subject)."?=\n";
mail($ba,$subject,$memos,$headers);
*/


$config=array( 'host'=>'ssl://smtp.naver.com', 
                'smtp_id'=>'qwq6735@naver.com', 
                'smtp_pw'=>'dbswornjs2', 
                'debug'=>1, 
                'charset'=>'utf-8', 
                'ctype'=>'text/plain' 
                );
$sendmail = new Sendmail($config);

$to=$ba;
$from="로타리종합물류";
$body=$memo;
$cc_mail="";
$bcc_mail="";

/* 메일 보내기 */ 
$sendmail->send_mail($to, $from, $subject, $body,$cc_mail,$bcc_mail);

?>
<script>
	location.href='mail.php?sendmail=1';
</script>
