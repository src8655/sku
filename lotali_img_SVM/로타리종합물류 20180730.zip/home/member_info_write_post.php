<?
include "lib.php";
include "head.php";

//코드가 존재하고 중복되면 되돌아감
if($_REQUEST[codes]) {
  $q = "select * from min_board_member where codes='$_REQUEST[codes]'";
  $r = mysql_query($q, $connect);
  $d = mysql_fetch_array($r);
  
  if($d[no]) {
    echo("
  		<script>
  			window.alert('이미 존재하는 코드입니다.')
  			history.go(-1)
  		</script>
  	");
  	exit;
  }
}

$query = "insert into min_board_member(name, phone1, phone2, phone3, memo, email, car_num, ton_no, codes)
          values('$_REQUEST[name]','$_REQUEST[phone1]','$_REQUEST[phone2]','$_REQUEST[phone3]','$_REQUEST[memo]','$_REQUEST[email]','$_REQUEST[car_num]','$_REQUEST[ton_no]','$_REQUEST[codes]')";
mysql_query($query, $connect);
?>
<script>
  location.href='member_info.php';
</script>
