<?
include "lib.php";
include "head.php";

$query = "update min_board_gye set
					memo='$_REQUEST[memo]',
					name='$_REQUEST[name]',
					number='$_REQUEST[number]',
					bank='$_REQUEST[bank]',
					gye='$_REQUEST[gye]' where no='$no'";
mysql_query($query, $connect);
?>
<script>
	location.href='gye.php?company=<?=$company?>&ppl=<?=$no?>';
</script>
