<?
include "lib.php";
include "head.php";
?>
<table cellpadding="10" cellspacing="1" id="write1_table" border="0" style="margin-bottom:10px;font-size:15px;">
	<tr>
		<th colspan="2">
			<? if(!$cpp) {?>
				<span style="color:red;">체크</span> 하시겠습니까?
			<? }else{?>
				<span style="color:red;">체크</span>를 제거하시겠습니까?
			<? }?>
		</th>
	</tr>
	<tr>
		<td><a href="jang_check.php?date=<?=$date?>" class="view1_button">취소</a></td>
		<td>
			<a href="jang_check_post2.php?date=<?=$date?>&members=<?=$members?>&cacp=<?=$cacp?>&memo=<?=$memo?>&cop=<?=$cop?>" class="view1_button">확인</a>
		</td>
	</tr>
</table>
<?
include "foot.php";
?>
