<?
include "lib.php";
include "head.php";


$qs = "select count(*) from min_board_data1 where company='$_GET[company]'";
      $rs = mysql_query($qs, $connect);
      $ads = mysql_fetch_array($rs);
      $adscount = $ads[0];
if($adscount != 0) {
  echo("
    <script>
      window.alert('해당 회사의 데이터가 '+$adscount+'만큼 존재합니다. 데이터를 모두 삭제하신 후 재시도 해주세요.')
      history.go(-1)
    </script>
  ");
  exit;
}



//카운터 삭제
$counr = mysql_query("select * from min_board_admin_count where company='$company'",$connect);
$cound = mysql_fetch_array($counr);
if(!$cound[no]) {

}else{
$cq = "update min_board_admin_count set
        counts='0' where company='$company'";
mysql_query($cq, $connect);
}

// 삭제시 del값은 1에서2로
$_REQUEST[del] = "2";

$query = "delete from min_board_admin where company='$company'";
mysql_query($query, $connect);

$q = "update min_board_data1 set
      del='$_REQUEST[del]' where company='$company'";
mysql_query($q, $connect);
?>
<script>
  location.href='index.php?olddate=<?=$olddate?>';
</script>
