<?
include "lib.php";
include "head.php";

$adscountese = selectc("min_board_money","");

$q0 = "select * from min_board_admin where orders='0' order by name asc";
$r0 = mysql_query($q0, $connect);

// $qqqord[0] = selectc("min_board_admin","where orders='1'");
$qhc = "select * from min_board_admin where orders='1'";
$rhc = mysql_query($qhc, $connect);
$hidecnt = 0;
while($dhc = mysql_fetch_array($rhc)) {
	$qhi = "select count(*) from min_board_admin_hide where olddate='$olddate' and company='$dhc[company]'";
	$rhi = mysql_query($qhi, $connect);
	$dhi = mysql_fetch_array($rhi);
	if($dhi[0] == 0) $hidecnt += 1;
}

$qqqorban1 = ceil($hidecnt/2);

$q1 = "select * from min_board_admin where orders='1' order by name asc";
$r1 = mysql_query($q1, $connect);

$q2 = "select * from min_board_admin where orders='2' order by name asc";
$r2 = mysql_query($q2, $connect);

$q3 = "select * from min_board_admin where orders='3' order by name asc";
$r3 = mysql_query($q3, $connect);


?>
<?
$olst = "1";
$olsxxt = "1";

$r = mysql_query("select sum(counts) from min_board_admin_count where olddate='$olddate'");
$d = mysql_fetch_array($r);
$adscountt = $d[0];
//$adscountt = selectc("min_board_data1","where olddate='$olddate' and del='$olsxxt'");
$adscountts = selectc("min_board_data2","where olddate='$olddate'");
$adscountts2 = selectc("min_board_data3","where olddate='$olddate'");

$adstotal = $adscountt+$adscountts+$adscountts2;
?>
<?
if(!$olddate) {

?>
<div style="width:1000px; margin:0 auto; overflow:hidden;">
<?
$nosi = "1";
$qi = "select * from min_board_memo where checks='$nosi' order by no asc";
$ri = mysql_query($qi, $connect);
?>
 <div style="float:right;width:544px;">
	 <div style="display:none;width:544px;margin:0 0 10px 0;text-align:center;overflow:hidden;">
	 	<a href="el.php" id="calopl">- 일일 일지 바로가기 -</a>
	 </div>
 	<a href="gal2.php" id="calopl" style="display:none;"><div style="float:left;width:200px;">달력메모 바로가기</div><div style="float:right;width:290px;text-align:right;padding:0 10px 0 0;font-family:'Arial';"><?=date("Y")?> 년 <?=date("n")?> 월 <?=date("j")?> 일 <?=date("l")?></div></a>
 	<div id="galsm" style="display:none;">
<?
$years = date("Y");
$mons = date("n");
$days = date("j");
$tmmps = $years."-".$mons."-".$days;

$qcals = "select * from min_board_cal where date='$tmmps'";
$rcals = mysql_query($qcals, $connect);
$dcals = mysql_fetch_array($rcals);
?>
		<div style="float:left;width:90px;overflow:hidden;"><span style="font-weight:bold;font-size:15px;">오늘의 일정</span></div>
		<marquee behavior="scroll" direction="left" scrollDelay="65" scrollAmount="3" style="font-size:15px;width:402px;float:right;font-family:'Arial';"><? if($dcals[memo]) {?><span style="font-weight:bold;color:blue;"><?=$dcals[memo]?></span><? }else{?>오늘의 일정이 없습니다.<? }?></marquee>
 	</div>
 	
 	
  <div id="goodminho3" style="width:540px; float:right; margin:0 0 10px 0;overflow:hidden;">
    <h1>
      <div style="width:100px;float:left;">
        메모
      </div>
      <div style="float:right;width:350px;text-align:right;margin:0 20px 0 0;">
        <a href="#10" onclick="ememaee(memo_w);" style="width:100px;float:right;font-weight:bold;text-align:center;display:block;border-left:1px solid #ABABAB;border-right:1px solid #ABABAB;font-size:15px;height:100%;">메모추가</a>
        <a href="memo_list.php?olddate=<?=$olddate?>" style="width:100px;float:right;font-weight:bold;text-align:center;display:block;border-left:1px solid #ABABAB;font-size:15px;height:100%;"><span style="color:red; font-size:15px;">보관함</span></a>
      </div>
    </h1>
		<? if($dyyocount == 0) {?>
		<div style="overflow:hidden; margin:10px; padding:7px; font-size:17px; border:1px solid #ABABAB;">
      새로쓴 메모가 없습니다.
    </div>
		<? }?>
<?
while($di = mysql_fetch_array($ri)) {
?>
    <div style="overflow:hidden; margin:10px; padding:7px; font-size:17px; border:1px solid #ABABAB;">
      <div style="float:left;width:75px;margin:0 5px 0 0;overflow:hidden; font-size:15px;text-align:center;">
      	<a onclick="confirms('체크를 하시겠습니까?','memo_check2.php?no=<?=$di[no]?>&olddate=<?=$olddate?>');" class="chred">확인안함</a>
      	<span style="font-family:'Arial';"><?=$di[date]?></span>
      </div>
      <div style="float:left;width:415px;overflow:hidden;">
      	<?=nl2br($di[memo])?>
      </div>
    </div>
<?
}
?>
    <div id="memo_w" style="display:none;text-align:left; overflow:hidden; padding:0px 5px 5px 5px;">
      <form action="memo_post.php">
        <input type="hidden" name="olddate" value="<?=$olddate?>" />
        <textarea name="memo" style="border:1px solid #bbbbbb;width:525px;height:50px;margin:0 0 5px 0;font-size:15px;"></textarea>
        <input type="submit" value="등록하기" id="ind_button" /> &nbsp;<span style="font-size:15px; color:black;">확인한 메모는 보관함으로 이동됩니다.</span>
      </form>
    </div>
  </div>
  
  <div id="goodminho3" style="width:540px; float:right; margin:0 0 10px 0;overflow:hidden;">
    <h1>
      <div style="width:200px;float:left;">간편메모 <a href="memo_list.php?olddate=<?=$olddate?>"></div>
      <div style="float:right;width:250px;text-align:right;margin:0 20px 0 0;">
        <a href="#10" onclick="ememaee(memo_w2);" style="width:100px;float:right;font-weight:bold;text-align:center;display:block;border-left:1px solid #ABABAB;border-right:1px solid #ABABAB;font-size:15px;height:100%;">메모추가</a>
      </div>
    </h1>
		<div id="memo_w2" style="border-bottom:1px solid #ABABAB;display:none;width:100%;padding:5px;overflow:hidden;">
		  <form action="memo2_post.php">
  		  <div style="width:83%;float:left;">
  		    <input type="text" style="border:1px solid #ABABAB;font-size:15px;padding:5px 0 5px 0;width:98%;" name="memo" /> 
  		  </div>
  		  <div style="width:17%;float:right;">
  		    <input type="submit"style="border:1px solid #ABABAB;font-size:15px;padding:5px 0 5px 0;width:88%;font-weight:bold;background:#eeeeee;" value="추가하기" /> 
  		  </div>
		  </form>
		</div>
		<ul class="memo2_list">
<?
$memo2_cnt = selectc("min_board_memo2","");
?>
		<? if($memo2_cnt == 0) {?>
		<li style="border:0px;">
      작성한 메모가 없습니다.
    </li>
		<? }?>
<?
$memo2_cnt2 = 0;
$memo2_result = mysql_query("select * from min_board_memo2 order by no desc",$connect);
while($memo2_data = mysql_fetch_array($memo2_result)) {
  $memo2_cnt2 = $memo2_cnt2+1;
  
  if($memo2_cnt2 == 7) {
?>
      <li style="border:0px;">
        <a href="#10" onclick="ememaee(memo_li2);" style="font-weight:bold;text-align:center;display:block;border:1px solid #ABABAB;font-size:15px;font-family:'Arial';padding:5px;">- 더보기 -</a>
      </li>
      </ul>
      <ul class="memo2_list" id="memo_li2" style="display:none;">
<?
}
?>
      <li <? if($memo2_cnt2 == $memo2_cnt){?>style="border:0px;"<? }?>>
  		  <div style="width:85%;float:left;color:blue;">
  		    <?=$memo2_data[memo]?>
  		  </div>
  		  <div style="width:3%;float:right;text-align:center;">
  		    <a href="#10" title="삭제" onclick="confirms('삭제하시겠습니까?','memo2_del.php?no=<?=$memo2_data[no]?>')" style="color:red;font-family:'Arial';">X</a>
  		  </div>
  		  <div style="width:12%;float:right;text-align:center;">
  		    <?=$memo2_data[date]?>
  		  </div>
      </li>
<?
}
?>
		</ul>
  </div>
  <div id="goodminho3" style="width:540px; float:left; margin:0 0 10px 0;overflow:hidden;">
      <h1>
      <a href="#10" onclick="ememaee(ipgm_list_hd);" style="color:blue;">거래처 입금자 확인</a>
      <input type="text" name="name" value="" id="fdkey2" style="float:right;border:1px solid #999999;height:20px;line-height:20px;margin:2px 5px 0 0;width:120px;font-size:17px;" />
      <p style="float:right;padding:0px;margin:0 5px 0 5px;overflow:hidden;">검색하기</p>
      <a href="ipgm_pdf.php" target="_BLANK" style="width:60px;float:right;font-weight:bold;text-align:center;display:block;border-right:1px solid #ABABAB;font-size:15px;height:100%;">인쇄2</a>
      <a href="ipgm_print.php" target="_BLANK" style="width:60px;float:right;font-weight:bold;text-align:center;display:block;border-left:1px solid #ABABAB;border-right:1px solid #ABABAB;font-size:15px;height:100%;">인쇄1</a>
      </h1>
		<ul class="ipgm_list" id="ipgm_list_hd" style="overflow-y:scroll;height:203px;display:none;font-weight:bold;">
<?
$cnt = 1;

$ipgm_result = mysql_query("select * from min_board_admin_damt where ipgm!='' order by no asc",$connect);
while($ipgm_data = mysql_fetch_array($ipgm_result)) {
?>
  <li class="fd2">
  <div style="float:left;width:47%;overflow:hidden;"><?=$cnt?>. <?=$ipgm_data[company]?></div>
  <div style="float:right;width:48%;padding:0 0 0 5px;border-left:1px solid #ABABAB;overflow:hidden;"><span style="background:yellow;">입금자:[<?=$ipgm_data[ipgm]?>]</span></div>
  </li>
<?
$cnt++;
}
$ipgm_result = mysql_query("select * from min_board_admin where ipgm!='' order by name asc",$connect);
while($ipgm_data = mysql_fetch_array($ipgm_result)) {
?>
  <li class="fd2">
  <div style="float:left;width:47%;overflow:hidden;"><?=$cnt?>. <?=$ipgm_data[name]?></div>
  <div style="float:right;width:48%;padding:0 0 0 5px;border-left:1px solid #ABABAB;overflow:hidden;"><span style="background:yellow;">입금자:[<?=$ipgm_data[ipgm]?>]</span></div>
  </li>
<?
$cnt++;
}
?>
		</ul>
  </div>
	 <div style="display:none;width:544px;margin:0px;text-align:center;overflow:hidden;">
	 	<a href="login_list.php" id="calopl">로그인 기록 바로가기</a>
	 </div>
	 <div style="display:none;width:544px;margin:10px 0 0 0;text-align:center;overflow:hidden;">
	 	<a href="http://로타리종합물류.com/home/install_flash.apk" id="calopl">플래시 플레이어 다운로드</a>
	 </div>
	 <div style="width:544px;margin:10px 0 0 0;text-align:center;overflow:hidden;">
	 	<a href="http://로타리종합물류.com/home/im/2017_2.hwp" id="calopl">운임표 2017-2 다운로드</a>
	 </div>
	 <div style="width:544px;margin:10px 0 0 0;text-align:center;overflow:hidden;">
	 	<a href="http://로타리종합물류.com/home/scan.php" id="calopl">입금통장사본/사업자등록증/운송주선사업허가증</a>
	 </div>
 </div>
 
 <div style="float:left; width:218px; overflow:hidden;">
  <div class="goodminho2" style="float:left;margin:0 0 10px 0;display:none;">
  	<h1>장부</h1>
  	<ul>
  		<li style="border-bottom:1px solid #eeeeee;padding:2px 5px 2px 5px;font-size:17px;">
  			<form action="jang_date_post.php">
  				<select name="jang_date" class="ind_select">
          <?
          $sedateq = date("Y");
          $cndate1q = $sedateq-1;
          $cndate2q = $sedateq+10;
          for($i=$cndate1q;$i<$cndate2q;$i++) {
          ?>
            <option value="<?=$i?>" <? if($sedateq==$i) {?>selected<? }?>><?=$i?></option>
          <?
          }
          ?>
  				</select>년
  				<input type="submit" value="등록" style="font-size:17px;background:#ffffff;border:1px solid #676767;font-weight:bold;" />
  			</form>
  		</li>
<?
$jangcnt = "1";
$jangmax = "2";

$djangc[0] = selectc("min_board_jang_date","");

$qjang = "select * from min_board_jang_date order by date desc";
$rjang = mysql_query($qjang, $connect);

while($djang = mysql_fetch_array($rjang)) {
?>
  		<li <? if($jangcnt > $jangmax) {?>style="display:none;" id="ak<?=$jangcnt?>"<? }?>><a href="jang_check.php?date=<?=$djang[no]?>" style="font-size:17px;font-family:'Arial';"><?=$djang[date]?> 년</a></li>
  		<? if($jangcnt == $jangmax) {?><li><a href="#nones" onclick="<? for($c=$jangmax+1;$c<$djangc[0]+1;$c++) {?>golem(ak<?=$c?>);<? }?>" style="text-align:center;font-size:15px;background:none;padding-left:0px;">-&nbsp;&nbsp;&nbsp;더보기&nbsp;&nbsp;&nbsp;-</a></li><? }?>
<?
$jangcnt += 1;
}
?>  		
  	</ul>
  </div>
  <div class="goodminho2" style="float:left;margin:0 10px 0 0;">
    <h1>날짜선택</h1>
    <ul>
      <li style="border-bottom:1px solid #eeeeee;height:33px;line-height:33px;text-align:center;font-size:15px;">
        <form action="olddate.php">
          <select name="datey" class="ind_select">
          <?
          $sedate = date("Y");
          $datemmme = date("m");
          $cndate1 = $sedate-1;
          $cndate2 = $sedate+10;
          for($i=$cndate1;$i<$cndate2;$i++) {
          ?>
            <option value="<?=$i?>" <? if($sedate==$i) {?>selected<? }?>><?=$i?></option>
          <?
          }
          ?>
          </select>년
          <select name="datem" class="ind_select">
            <option value="01" <? if($datemmme == "01") {?>selected<? }?>>01</option>
            <option value="02" <? if($datemmme == "02") {?>selected<? }?>>02</option>
            <option value="03" <? if($datemmme == "03") {?>selected<? }?>>03</option>
            <option value="04" <? if($datemmme == "04") {?>selected<? }?>>04</option>
            <option value="05" <? if($datemmme == "05") {?>selected<? }?>>05</option>
            <option value="06" <? if($datemmme == "06") {?>selected<? }?>>06</option>
            <option value="07" <? if($datemmme == "07") {?>selected<? }?>>07</option>
            <option value="08" <? if($datemmme == "08") {?>selected<? }?>>08</option>
            <option value="09" <? if($datemmme == "09") {?>selected<? }?>>09</option>
            <option value="10" <? if($datemmme == "10") {?>selected<? }?>>10</option>
            <option value="11" <? if($datemmme == "11") {?>selected<? }?>>11</option>
            <option value="12" <? if($datemmme == "12") {?>selected<? }?>>12</option>
          </select>월
          <input type="submit" value="등록" style="font-size:15px;background:#ffffff;border:1px solid #676767;font-weight:bold;" />
        </form>
      </li>
<?
$gatt = 9; //보이는 갯수
$gatt_cnt = 0;
?>
<?
$u = "select * from min_board_olddate order by date desc";
$j = mysql_query($u, $connect);
while($m = mysql_fetch_array($j)) {
if($gatt_cnt == $gatt) {
?>

			<li><a href="#nones" class="olddatemore" style="height:34px;line-height:34px;background:none;text-align:center;width:220px;padding-left:0px;font-size:15px;">-&nbsp;&nbsp;&nbsp;더보기&nbsp;&nbsp;&nbsp;-</a></li>

	</ul>
	<ul class="olddatemo" style="display:none;">
<?
}
$r = mysql_query("select sum(counts) from min_board_admin_count where olddate='$m[olddate]'");
$d = mysql_fetch_array($r);
$adscountt = $d[0];
//$adscountt = selectc("min_board_data1","where olddate='$m[olddate]' and del='1'");
$adscountts = selectc("min_board_data2","where olddate='$m[olddate]'");
$adscountts2 = selectc("min_board_data3","where olddate='$m[olddate]'");

$adstotal = $adscountt+$adscountts+$adscountts2;

//미입금현황
$ep = selectc("min_board_ep","where olddate='$m[olddate]' and date='' and date2=''");
$ep2 = selectc("min_board_ep","where olddate='$m[olddate]'");
?>
      <li><a href="index.php?olddate=<?=$m[olddate]?>" style="height:34px;line-height:34px;font-size:15px;font-family:'Arial';"><?=$m[date]?> - <span style="font-size:15px; color:red;"><?=$adstotal?></span>
      &nbsp;<span style="font-size:15px; color:orange;"><? if($m[date]!=date("Y")."년".date("m")."월") {if(($ep2!=0)&&($ep==0)) {?>(완결)<? }else{?>(<?=$ep?>건)<? }}else{?>(진행중)<? }?></span></a></li>
<?
$gatt_cnt = $gatt_cnt+1;
}
?>

<?
$infocount = selectc("min_board_info","");
$infocounts = selectc("min_board_member","");

$gyes1 = "1";
$gyes2 = "2";
$gyes3 = "3";

$qgye1 = "select * from min_board_gye where company='$gyes1'";
$rgye1 = mysql_query($qgye1, $connect);
$dgye1 = mysql_num_rows($rgye1);

$qgye2 = "select * from min_board_gye where company='$gyes2'";
$rgye2 = mysql_query($qgye2, $connect);
$dgye2 = mysql_num_rows($rgye2);

$qgye3 = "select * from min_board_gye where company='$gyes3'";
$rgye3 = mysql_query($qgye3, $connect);
$dgye3 = mysql_num_rows($rgye3);

$qgye5 = "select * from min_board_gye";
$rgye5 = mysql_query($qgye5, $connect);
$dgye5 = mysql_num_rows($rgye5);

$qgye6 = "select * from min_board_gye where company='6'";
$rgye6 = mysql_query($qgye6, $connect);
$dgye6 = mysql_num_rows($rgye6);
?>
    </ul>
  </div>
 </div>
 <div style="float:right; width:228px; overflow:hidden;">
  <div class="goodminho2" class="goodlit" style="float:left;margin:0 0 0 0;">
    <h1>정보</h1>
    <ul>
      <li><a href="company_info.php" style="font-size:15px;">회사정보 - <span style="font-size:15px; color:red;font-family:'Arial';"><?=$infocount?></span></a></li>
      <li><a href="member_info.php" style="font-size:15px;">기사정보 - <span style="font-size:15px; color:red;font-family:'Arial';"><?=$infocounts?></span></a></li>
      <li><a href="view1_money_list.php" style="font-size:15px;">세금계산서 목록 - <span style="font-size:15px; color:red;font-family:'Arial';"><?=$adscountese?></span></a></li>
      <li><a href="view1_money.php" style="font-size:15px;">세금계산서 발행</a></li>
      <li><a href="gyeon.php" style="font-size:15px;">견적서</a></li>
    </ul>
  </div>
  <div class="goodminho2" style="float:left;margin:10px 0 0 0;">
    <h1>계좌번호</h1>
   	<ul>
			<li><a href="gye_total.php" style="font-size:15px;">계좌번호 전체보기 - <span style="color:red;font-family:'Arial';"><?=$dgye5?></span></a></li>
			<li><a href="gye.php?company=1" style="font-size:15px;">계좌번호 5t 기준 - <span style="color:red;font-family:'Arial';"><?=$dgye1?></span></a></li>
			<li><a href="gye.php?company=2" style="font-size:15px;">계좌번호 1t~3.5t - <span style="color:red;font-family:'Arial';"><?=$dgye2?></span></a></li>
			<li><a href="gye.php?company=3" style="font-size:15px;">계좌번호 외주차 - <span style="color:red;font-family:'Arial';"><?=$dgye3?></span></a></li>
			<li><a href="gye.php?company=6" style="font-size:15px;">계좌번호 거래처 - <span style="color:red;font-family:'Arial';"><?=$dgye6?></span></a></li>
    </ul>
  </div>
  <div class="goodminho2" style="margin:10px 0 0 0;font-size:13px;font-family:'Arial';display:none;">
		<h1>동시접속자(1분)</h1>
		<div style="overflow:scroll;overflow-x:hidden;width:204px;padding:5px;height:39px;">
<?
while($dcustom5 = mysql_fetch_array($rcustom5)) {
?>
			<?=$dcustom5[name]?> - <?=$dcustom5[ip]?><br />
<?
}
?>
		</div>
	</div>
 </div>
</div>
<?
}else{
?>
<div id="ind">
<div style="float:left;width:817px;overflow:hidden;">
  <div class="goodminho" style="margin-bottom:10px;width:813px;">
  	<h1 style="font-family:'Arial';">
  		<div style="float:left;overflow:hidden;">
  			로타리종합물류
  			<a href="index_del.php?olddate=<?=$olddate?>" style="font-size:13px; color:red;">삭제모드</a>&nbsp;
  			<a href="index_edit.php?olddate=<?=$olddate?>" style="font-size:13px; color:green;">수정모드</a>&nbsp;
  			<a href="index.php?olddate=<?=$olddate?><? if($erq){}else{?>&erq=1<? }?>&erqs=<?=$erqs?>&erqs2=<?=$erqs2?>&ipgm=<?=$_GET[ipgm]?>" style="font-size:13px; color:#AC6100;">입금체크</a>&nbsp;
  			<a href="index.php?olddate=<?=$olddate?>&erq=<?=$erq?>&erqs=<?=$erqs?><? if($erqs2) {}else{?>&erqs2=1<? }?>&ipgm=<?=$_GET[ipgm]?>" style="font-size:13px; color:#0088c8;">업체숨기기</a>&nbsp;
  			<a href="index.php?olddate=<?=$olddate?>&erq=<?=$erq?>&erqs=<?=$erqs?>&erqs2=<?=$erqs2?><? if($_GET[ipgm]) {}else{?>&ipgm=1<? }?>" style="font-size:13px; color:blue;">입금자보기</a>
  		</div>
  		<div style="float:right;overflow:hidden;">
  			<? if(!$erqs) {?>
  				<a href="index.php?olddate=<?=$olddate?>&erq=<?=$erq?>&erqs=1" style="font-size:13px; color:blue;">장부 있는 것만 보기</a>
  			<? }else{?>
  				<a href="index.php?olddate=<?=$olddate?>&erq=<?=$erq?>" style="font-size:13px; color:blue;">장부 전체 보기</a>
  			<? }?>
  			&nbsp;
  		</div>
  	</h1>
  </div>
  <div class="goodminho" style="width:394px;float:left;">
    <h1>한달결제</h1>
    <ul style="width:394px;">
    	<li style="width:394px;"><a href="view1_total.php?olddate=<?=$olddate?>" style="font-size:15px;">전체자료 - <span style="font-size:15px; color:red;font-family:'Arial';"><?=$adstotal?></span></a></li>
    </ul>
    <ul style="float:left;width:197px;">
      <?
      $adcnt = 0;
      while($admin1 = mysql_fetch_array($r1)) {
        //미청구한 회사찾기
        $ep2 = selectc("min_board_ep","where olddate='$_GET[olddate]' and company='$admin1[company]'");
        
        
        
        
      	$dhide = selectc("min_board_admin_hide","where olddate='$olddate' and company='$admin1[company]'");
      	if($dhide != 0) continue;
      
      $counr = mysql_query("select * from min_board_admin_count where company='$admin1[company]' and olddate='$olddate'",$connect);
      $cound = mysql_fetch_array($counr);
      if($cound[counts] == 0)
      $adscount = 0;
      else $adscount = $cound[counts];
      //$adscount = selectc("min_board_data1","where company='$admin1[company]' and olddate='$olddate' and del='1'");
      ?>
      <li <? if($erqs){if($adscount == 0){?>style="display:none;"<? }}?>>
      	<a href="view1.php?company=<?=$admin1[company]?>&olddate=<?=$olddate?>" class="fd1" style="font-size:15px;width:180px;"><?=$admin1[name]?>
      	</a>
      	<span style="font-size:15px; color:red;font-family:'Arial';"><?=$adscount?></span>
<?
$erqeerq = "select * from min_board_admin_check where company='$admin1[company]' and olddate='$olddate'";
$erqeerr = mysql_query($erqeerq, $connect);
$erqeerd = mysql_fetch_array($erqeerr);
?>
      	<? if($erq) {if(!$erqeerd[no]) {?><a href="index_erq_post.php?company=<?=$admin1[company]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:blue;">[체크]</a><? }else{?><a href="index_erq_edit_post.php?no=<?=$erqeerd[no]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:#AC6100;font-weight:bold;">[입금]</a><? }}else{?>
      	<? if($erqeerd[no]) {?><span style="color:#AC6100;font-weight:bold;">[입금]</span><? }}?>
      	<? if($erqs2) {?><a href="index_erqs2.php?company=<?=$admin1[company]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:#d20000;">[숨김]</a><? }?>
      	<? if(($_GET[ipgm] == 1)&&($admin1[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:13px;">입금자:[<?=$admin1[ipgm]?>]</span>
      	<? }?>
      	<? if(($cound[counts] != 0)&&($ep2==0)&&($_GET[olddate]>72)&&($cf[date]!=date("Y")."년".date("m")."월")) {//미청구한회사찾기?><span style="font-weight:bold;color:blue;">(미청구)</span><? }?>
      </li>
      <?
      		$adcnt += 1;
      		if($adcnt == $qqqorban1) {
      			?>
      			
			    </ul>
			    <ul style="float:right;width:197px;">
      			<?
      		}
      }
      ?>
    </ul>
  </div>
  <div class="goodminho" style="width:197px;float:left;margin-left:8px;">
    <h1>그때그때결제</h1>
    <ul>
      <?
      while($admin2 = mysql_fetch_array($r2)) {
      	$dhide = selectc("min_board_admin_hide","where olddate='$olddate' and company='$admin2[company]'");
      	if($dhide == 0) {
      
      $counr = mysql_query("select * from min_board_admin_count where company='$admin2[company]' and olddate='$olddate'",$connect);
      $cound = mysql_fetch_array($counr);
      if($cound[counts] == 0)
      $adscount = 0;
      else $adscount = $cound[counts];
      //$adscount = selectc("min_board_data1","where company='$admin2[company]' and olddate='$olddate' and del='1'");
      
      
      
      //$q2 = "select * from min_board_admin where orders='2' order by name asc";
      //입금확인 여부 찾기
      //$ipgum = selectc("min_board_data1","where company='$admin2[company]' and olddate='$olddate' and memocc='0' and virtualmoney='0' and del='1'");
      ?>
      <li <? if($erqs){if($adscount == 0){?>style="display:none;"<? }}?>>
      	<a href="view1.php?company=<?=$admin2[company]?>&olddate=<?=$olddate?>" class="fd1" style="font-size:15px;width:200px;"><?=$admin2[name]?></a>
      	<span style="font-size:15px; color:red;font-family:'Arial';"><?=$adscount?></span>
<?
$erqeerq2 = "select * from min_board_admin_check where company='$admin2[company]' and olddate='$olddate'";
$erqeerr2 = mysql_query($erqeerq2, $connect);
$erqeerd2 = mysql_fetch_array($erqeerr2);
?>
      	<? if($erq) {if(!$erqeerd2[no]) {?><a href="index_erq_post.php?company=<?=$admin2[company]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:blue;">[체크]</a><? }else{?><a href="index_erq_edit_post.php?no=<?=$erqeerd2[no]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:#AC6100;font-weight:bold;">[입금]</a><? }}else{?>
      	<? if($erqeerd2[no]) {?><span style="color:#AC6100;font-weight:bold;">[입금]</span><? }}?>
      	<? if($erqs2) {?><a href="index_erqs2.php?company=<?=$admin2[company]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:#d20000;">[숨김]</a><? }?>
      	<? if(($_GET[ipgm] == 1)&&($admin2[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:13px;">입금자:[<?=$admin2[ipgm]?>]</span>
      	<? }?>
      </li>
      <?
    		}
      }
      ?>
    </ul>
  </div>
  <div style="width:201px;float:right;overflow:hidden;">
  <div class="goodminho" style="width:197px;">
    <h1>기사에게입금</h1>
    <ul>
      <?
      while($admin3 = mysql_fetch_array($r3)) {
      	$dhide = selectc("min_board_admin_hide","where olddate='$olddate' and company='$admin3[company]'");
      	if($dhide == 0) {
      
      $counr = mysql_query("select * from min_board_admin_count where company='$admin3[company]' and olddate='$olddate'",$connect);
      $cound = mysql_fetch_array($counr);
      if($cound[counts] == 0)
      $adscount = 0;
      else $adscount = $cound[counts];
      //$adscount = selectc("min_board_data1","where company='$admin3[company]' and olddate='$olddate' and del='1'");
      ?>
      <li <? if($erqs){if($adscount == 0){?>style="display:none;"<? }}?>>
      	<a href="view1.php?company=<?=$admin3[company]?>&olddate=<?=$olddate?>" class="fd1" style="font-size:15px;width:200px;"><?=$admin3[name]?></a>
      	<span style="font-size:15px; color:red;font-family:'Arial';"><?=$adscount?></span>
<?
$erqeerq3 = "select * from min_board_admin_check where company='$admin3[company]' and olddate='$olddate'";
$erqeerr3 = mysql_query($erqeerq3, $connect);
$erqeerd3 = mysql_fetch_array($erqeerr3);
?>
      	<? if($erq) {if(!$erqeerd3[no]) {?><a href="index_erq_post.php?company=<?=$admin3[company]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:blue;">[체크]</a><? }else{?><a href="index_erq_edit_post.php?no=<?=$erqeerd3[no]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:#AC6100;font-weight:bold;">[입금]</a><? }}else{?>
      	<? if($erqeerd3[no]) {?><span style="color:#AC6100;font-weight:bold;">[입금]</span><? }}?>
      	<? if($erqs2) {?><a href="index_erqs2.php?company=<?=$admin3[company]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:#d20000;">[숨김]</a><? }?>
      	<? if(($_GET[ipgm] == 1)&&($admin3[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:13px;">입금자:[<?=$admin3[ipgm]?>]</span>
      	<? }?>
      </li>
      <?
      	}
      }
      ?>
    </ul>
  </div>
  <div class="goodminho" style="width:197px;margin-top:10px;">
    <h1>정렬 지정하지 않음</h1>
    <ul>
      <?
      while($admin0 = mysql_fetch_array($r0)) {
      	$dhide = selectc("min_board_admin_hide","where olddate='$olddate' and company='$admin0[company]'");
      	if($dhide == 0) {
      
      $counr = mysql_query("select * from min_board_admin_count where company='$admin0[company]' and olddate='$olddate'",$connect);
      $cound = mysql_fetch_array($counr);
      if($cound[counts] == 0)
      $adscount = 0;
      else $adscount = $cound[counts];
      //$adscount = selectc("min_board_data1","where company='$admin0[company]' and olddate='$olddate' and del='1'");
      ?>
      <li <? if($erqs){if($adscount == 0){?>style="display:none;"<? }}?>>
      	<a href="view1.php?company=<?=$admin0[company]?>&olddate=<?=$olddate?>" class="fd1" style="font-size:15px;width:200px;"><?=$admin0[name]?></a>
      	<span style="font-size:15px; color:red;font-family:'Arial';"><?=$adscount?></span>
<?
$erqeerq0 = "select * from min_board_admin_check where company='$admin0[company]' and olddate='$olddate'";
$erqeerr0 = mysql_query($erqeerq0, $connect);
$erqeerd0 = mysql_fetch_array($erqeerr0);
?>
      	<? if($erq) {if(!$erqeerd0[no]) {?><a href="index_erq_post.php?company=<?=$admin0[company]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:blue;">[체크]</a><? }else{?><a href="index_erq_edit_post.php?no=<?=$erqeerd0[no]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:#AC6100;font-weight:bold;">[입금]</a><? }}else{?>
      	<? if($erqeerd0[no]) {?><span style="color:#AC6100;font-weight:bold;">[입금]</span><? }}?>
      	<? if($erqs2) {?><a href="index_erqs2.php?company=<?=$admin0[company]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:#d20000;">[숨김]</a><? }?>
      	<? if(($_GET[ipgm] == 1)&&($admin0[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:13px;">입금자:[<?=$admin0[ipgm]?>]</span>
      	<? }?>
      </li>
      <?
      	}
      }
      ?>
    </ul>
  </div>
  <div class="goodminho" style="width:197px;margin-top:10px;">
    <h1>등록하기</h1>
      <div style="text-align:center;">
        <form action="index_post.php">
          <input type="hidden" name="olddate" value="<?=$olddate?>" />
          <select name="orders" style="border:1px solid #7F9DB9;height:26px;line-height:26px;margin-top:10px;width:180px;font-size:17px;">
          	<option value="1">한달결제</option>
          	<option value="2">그때그때결제</option>
          	<option value="3">기사에게입금</option>
          	<option value="0">정렬 지정하지 않음</option>
        	</select>
          <br />
          <input type="text" name="name" style="height:24px;line-height:24px;border:1px solid #7F9DB9;margin-top:3px;width:176px;font-size:17px;" /><br />
          <input type="submit" value="등록하기" style="border:1px solid #7F9DB9;" id="index_button" />
        </form>
      </div>
  </div>
  
  
  
  
	</div>
</div>
<div style="float:right;width:174px;overflow:hidden;">
<?
$olse = "1";

$adscounte1 = selectc("min_board_data2","where id='0' and olddate='$olddate'");
$adscounte2 = selectc("min_board_data2","where id='1' and olddate='$olddate'");
$adscounte3 = selectc("min_board_data2","where olddate='$olddate'");
?>

  <div class="goodminho" style="padding:10px;width:150px;margin-bottom:10px;">
      <div style="float:left;">
          <input type="text" name="name" value="" id="fdkey" style="border:1px solid #999999;height:26px;line-height:26px;margin:0px;width:146px;font-size:17px;" />
      </div>
  </div>
  <div class="goodminho" style="width:170px;margin:0 0 10px 0;">
    <h1>담터</h1>
    <ul>
      <li>
      	<a href="view2_total.php?olddate=<?=$olddate?>" class="fd1" style="font-size:15px;">담터 전체보기</a>
      	<span style="font-size:15px; color:red;font-family:'Arial';"><?=$adscounte3?></span>
      </li>
      <li>
      	<a href="view2.php?olddate=<?=$olddate?>&id=0" class="fd1" style="font-size:15px;">담터</a>
      	<span style="font-size:15px; color:red;font-family:'Arial';"><?=$adscounte1?></span>
<?
$erqeerq11 = "select * from min_board_admin_check where company='dam' and olddate='$olddate'";
$erqeerr11 = mysql_query($erqeerq11, $connect);
$erqeerd11 = mysql_fetch_array($erqeerr11);

$q_damt1 = "select * from min_board_admin_damt where no='0'";
$r_damt1 = mysql_query($q_damt1, $connect);
$d_damt1 = mysql_fetch_array($r_damt1);
?>
      	<? if($erq) {if(!$erqeerd11[no]) {?><a href="index_erq_post.php?company=dam&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:blue;">[체크]</a><? }else{?><a href="index_erq_edit_post.php?no=<?=$erqeerd11[no]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:#AC6100;font-weight:bold;">[입금]</a><? }}else{?>
      	<? if($erqeerd11[no]) {?><span style="color:#AC6100;font-weight:bold;">[입금]</span><? }}?>
      	<? if(($_GET[ipgm] == 1)&&($d_damt1[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:13px;">입금자:[<?=$d_damt1[ipgm]?>]</span>
      	<? }?>
      </li>
      <li>
      	<a href="view2.php?olddate=<?=$olddate?>&id=1" class="fd1" style="font-size:15px;">담터 FNB(승주)</a>
      	<span style="font-size:15px; color:red;font-family:'Arial';"><?=$adscounte2?></span>
<?
$erqeerq11 = "select * from min_board_admin_check where company='dam2' and olddate='$olddate'";
$erqeerr11 = mysql_query($erqeerq11, $connect);
$erqeerd11 = mysql_fetch_array($erqeerr11);

$q_damt2 = "select * from min_board_admin_damt where no='1'";
$r_damt2 = mysql_query($q_damt2, $connect);
$d_damt2 = mysql_fetch_array($r_damt2);
?>
      	<? if($erq) {if(!$erqeerd11[no]) {?><a href="index_erq_post.php?company=dam2&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:blue;">[체크]</a><? }else{?><a href="index_erq_edit_post.php?no=<?=$erqeerd11[no]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:#AC6100;font-weight:bold;">[입금]</a><? }}else{?>
      	<? if($erqeerd11[no]) {?><span style="color:#AC6100;font-weight:bold;">[입금]</span><? }}?>
      	<? if(($_GET[ipgm] == 1)&&($d_damt2[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:13px;">입금자:[<?=$d_damt2[ipgm]?>]</span>
      	<? }?>
      </li>
    </ul>
  </div>
<?
$adscountes1 = selectc("min_board_data3","where olddate='$olddate' and company='1'");
$adscountes2 = selectc("min_board_data3","where olddate='$olddate' and company='2'");
$adscountes3 = selectc("min_board_data3","where olddate='$olddate'");

$qeps = "select * from min_board_ep where olddate='$olddate'";
$reps = mysql_query($qeps, $connect);
$deps = mysql_num_rows($reps);
?>
  <div class="goodminho" style="width:170px;float:right;">
    <h1>로타리장부</h1>
    <ul>
      <li><a href="view3_total.php?olddate=<?=$olddate?>" style="font-size:15px;">전체보기 - <span style="font-size:15px; color:red;font-family:'Arial';"><?=$adscountes3?></span></a></li>
      <li><a href="view3.php?olddate=<?=$olddate?>&company=1" class="fd1" style="font-size:15px;">로타리장부1</a> - <span style="font-size:15px; color:red;font-family:'Arial';"><?=$adscountes1?></span></li>
      <li><a href="view3.php?olddate=<?=$olddate?>&company=2" class="fd1" style="font-size:15px;">로타리장부2</a> - <span style="font-size:15px; color:red;font-family:'Arial';"><?=$adscountes2?></span></li>
    </ul>
  </div>
	<div class="goodminho" style="width:170px;margin-top:10px;">
    <h1>관리</h1>
    <ul>
    	<li><a href="ep.php?olddate=<?=$olddate?>" style="font-size:15px;">입금확인 - <span style="font-size:15px; color:red;font-family:'Arial';"><?=$deps?></span></a></li>
    	<li><a href="mlist.php?olddate=<?=$olddate?>" style="font-size:15px;">경비내역 - <span style="font-size:15px; color:red;font-family:'Arial';"><?=selectc("min_board_mlist","where olddate='$olddate'")?></span></a></li>
    </ul>
	</div>
	
	<div class="goodminho" style="width:170px;margin-top:10px;">
    <h1>숨김 업체</h1>
    <ul>
      <?
      $qh = "select * from min_board_admin order by name asc";
			$rh = mysql_query($qh, $connect);
			$hamcnt = 0;
      while($adminh = mysql_fetch_array($rh)) {
      	$dhide = selectc("min_board_admin_hide","where olddate='$olddate' and company='$adminh[company]'");
      	if($dhide != 0) {
      $counr = mysql_query("select * from min_board_admin_count where company='$adminh[company]' and olddate='$olddate'",$connect);
      $cound = mysql_fetch_array($counr);
      if($cound[counts] == 0)
      $adscount = 0;
      else $adscount = $cound[counts];
      //$adscount = selectc("min_board_data1","where company='$adminh[company]' and olddate='$olddate' and del='1'");
      ?>
      <li style="<? if($erqs){if($adscount == 0){?>display:none;<? }}?>width:165px;">
      	<a href="view1.php?company=<?=$adminh[company]?>&olddate=<?=$olddate?>" class="fd1" style="font-size:15px;"><?=$adminh[name]?></a>
      	<span style="font-size:15px; color:red;font-family:'Arial';"><?=$adscount?></span>
<?
$erqeerq0 = "select * from min_board_admin_check where company='$adminh[company]' and olddate='$olddate'";
$erqeerr0 = mysql_query($erqeerq0, $connect);
$erqeerd0 = mysql_fetch_array($erqeerr0);
?>
      	<? if($erq) {if(!$erqeerd0[no]) {?><a href="index_erq_post.php?company=<?=$adminh[company]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:blue;">[체크]</a><? }else{?><a href="index_erq_edit_post.php?no=<?=$erqeerd0[no]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:#AC6100;font-weight:bold;">[입금]</a><? }}else{?>
      	<? if($erqeerd0[no]) {?><span style="color:#AC6100;font-weight:bold;">[입금]</span><? }}?>
      	<? if($erqs2) {?><a href="index_erqs2_e.php?company=<?=$adminh[company]?>&olddate=<?=$olddate?>&erqs=<?=$erqs?>" style="color:#186700;">[복구]</a><? }?>
      	<? if(($_GET[ipgm] == 1)&&($adminh[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:13px;">입금자:[<?=$adminh[ipgm]?>]</span>
      	<? }?>
      </li>
      <?
      		$hamcnt += 1;
      		if($hamcnt == 5) {
      			?>
      				<li><a href="#223" onclick="sdfsdf1(cda);" style="font-size:15px;margin:0px;padding:5px 0 5px 0;width:155px;text-align:center;display:block;">더보기</a></li>
      			</ul>
      			<ul id="cda" style="display:none;">
      			<?
      		}
      	}
      }
      ?>
    </ul>
	</div>
<?
$nosi = "1";
$qi = "select * from min_board_memo where checks='$nosi' order by no asc";
$ri = mysql_query($qi, $connect);
?>
</div>
</div>
<?
}
?>
<?
include "foot.php";
?>
