<?
include "lib.php";
include "head2.php";
?>
<?
$qiiim = "select * from min_board_jang_date where no='$date'";
$riiim = mysql_query($qiiim, $connect);
$diiim = mysql_fetch_array($riiim);
?>
<script defer>
function prints() {
factory.printing.leftMargin = "15.0";
factory.printing.topMargin = "25.0";
factory.printing.rightMargin = "15.0";
factory.printing.bottomMargin = "15.0";
factory.printing.header="";
factory.printing.footer="";
factory.printing.portrait=true;
factory.printing.Print(true);
}
function printshide() {
	pppl.style.display = "none";
}
</script>
<a href="#" onclick="printshide();prints();" id="pppl" style="display:block;width:100px;border:1px solid #676767;text-align:center;font-size:15px;margin:0 auto;margin-bottom:10px;padding:10px;"><img src="./images/print_io.jpg" style="border:0px;" /><br />인쇄하기<br /><span style="font-size:12px;color:red;">(페이지 자동조절)</span></a>
<object id="factory" viewastext style="display:none" classid="clsid:1663ed61-23eb-11d2-b92f-008048fdd814" codebase="./adr/smsx.cab#Version=6,3,436,14"></object>
<table cellpadding="3" cellspacing="0" id="print_te" style="margin-bottom:10px;font-size:12px;">
<col width="70" />
<col width="70" />
<col width="50px" />
<col width="50px" />
<col width="50px" />
<col width="50px" />
<col width="50px" />
<col width="50px" />
<col width="50px" />
<col width="50px" />
<col width="50px" />
<col width="50px" />
<col width="50px" />
<col width="50px" />
	<tr>
		<th colspan="14" style="font-size:25px;"><?=$diiim[date]?></th>
	</tr>
	<tr>
		<th height="30">이름</th>
		<th>차량번호</th>
		<th>1월</th>
		<th>2월</th>
		<th>3월</th>
		<th>4월</th>
		<th>5월</th>
		<th>6월</th>
		<th>7월</th>
		<th>8월</th>
		<th>9월</th>
		<th>10월</th>
		<th>11월</th>
		<th>12월</th>
	</tr>
<?
$querym = "select * from min_board_jang_member order by name asc";
$resultm = mysql_query($querym, $connect);
while($datam = mysql_fetch_array($resultm)) {
$qjjm = "select * from min_board_jang_check where date='$date' and member='$datam[no]'";
$rjjm = mysql_query($qjjm, $connect);
$djjm = mysql_fetch_array($rjjm);
?>
	<tr>
		<td align="center"><?=$datam[name]?></td>
		<td align="center"><?=$datam[number]?></td>
<?
$qjjjm = "select * from min_board_jang_check where date='$date' and member='$datam[no]'";
$rjjjm = mysql_query($qjjjm, $connect);
if($djjm[member]) {
while($djjjm = mysql_fetch_array($rjjjm)) {
?>
		<td align="center" height="35"><?=$djjjm[a1]?></td>
		<td align="center"><?=$djjjm[a2]?></td>
		<td align="center"><?=$djjjm[a3]?></td>
		<td align="center"><?=$djjjm[a4]?></td>
		<td align="center"><?=$djjjm[a5]?></td>
		<td align="center"><?=$djjjm[a6]?></td>
		<td align="center"><?=$djjjm[a7]?></td>
		<td align="center"><?=$djjjm[a8]?></td>
		<td align="center"><?=$djjjm[a9]?></td>
		<td align="center"><?=$djjjm[a10]?></td>
		<td align="center"><?=$djjjm[a11]?></td>
		<td align="center"><?=$djjjm[a12]?></td>
<?
}
}else{
for($i=1;$i<13;$i++) {
?>
		<td align="center" height="35"></td>
<?
}
}
?>
	</tr>
<?
}
?>
</table>
<?
include "foot2.php";
?>
