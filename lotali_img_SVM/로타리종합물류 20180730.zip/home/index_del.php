<?
include "lib.php";
include "head.php";

$query = "select * from min_board_admin order by name asc";
$result = mysql_query($query, $connect);
?>
<table width="0" cellpadding="7" cellspacing="1" width="500" id="index_del" style="font-size:15px;">
<col width="200" />
<col width="200" />
<col width="100" />
  <tr>
    <th colspan="3"><a href="index.php?olddate=<?=$olddate?>" class="view1_button">뒤로가기<a></th>
  </tr>
  <tr>
    <th colspan="3"><span style="color:red; font-size:12px;">!경고! 삭제하고자 하는 회사의 데이터가 하나라도 있으면 삭제가 안됩니다. 존재한다면 해당 데이터를 모두 삭제한 후 시도해야 합니다.</span></th>
  </tr>
<?
while($data = mysql_fetch_array($result)) {

      $ols = "1";
      $olsxx = "1";
      
      $qs = "select count(*) from min_board_data1 where company='$data[company]' and olddate='$olddate' and del='$olsxx'";
      $rs = mysql_query($qs, $connect);
      $ads = mysql_fetch_array($rs);
      $adscount = $ads[0];
?>
  <tr>
    <td align="center"><?=$data[name]?>-<span style="font-size:13px; color:red;"><?=$adscount?></span></td>
    <td align="center">[<? if($data[orders] == 0) {?>정렬 지정하지 않음<? }?><? if($data[orders] == 1) {?>한달결제<? }?><? if($data[orders] == 2) {?>그때그때결제<? }?><? if($data[orders] == 3) {?>기사에게입금<? }?>]</td>
    <td><a href="index_del_post2.php?company=<?=$data[company]?>&olddate=<?=$olddate?>" class="view1_button" id="delred">삭제</a></td>
  </tr>
<?
}
?>
</table>
<?
include "foot.php";
?>
