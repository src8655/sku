<?php
$name='Norasi-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 1216,
  'Descent' => -488,
  'CapHeight' => 1216,
  'Flags' => 262148,
  'FontBBox' => '[-621 -482 1579 1182]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 366,
);
$up=-125;
$ut=50;
$ttffile='/home/hosting_users/lsm8655/www/home/mpdf/ttfonts/Norasi-Bold.ttf';
$TTCfontID='0';
$originalsize=77420;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='norasiB';
$panose=' 0 0 2 7 8 6 6 0 0 2 0 4';
$haskerninfo=false;
$unAGlyphs=false;
?>