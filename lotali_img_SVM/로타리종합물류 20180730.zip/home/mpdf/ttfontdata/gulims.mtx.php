<?php
$name='Baekmuk-Gulim';
$type='TTF';
$desc=array (
  'Ascent' => 800,
  'Descent' => -200,
  'CapHeight' => 800,
  'Flags' => 4,
  'FontBBox' => '[-4 -265 1011 810]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 1000,
);
$up=-60;
$ut=30;
$ttffile='/home/hosting_users/lsm8655/www/home/mpdf/ttfonts/gulim.ttf';
$TTCfontID='0';
$originalsize=10385096;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='gulims';
$panose=' 0 0 2 0 5 0 3 0 0 2 0 4';
$haskerninfo=false;
$unAGlyphs=false;
?>