<?
extract($_GET);
extract($_POST);
extract($_SERVER);
extract($_COOKIE);

$connect = mysql_connect("localhost","lsm8655","snrnsi11"); 
mysql_select_db("lsm8655", $connect);

mysql_query("set names utf8"); 

//함수

function selectc($sq1,$sq2) {
	global $connect;
	$result1 = "select count(*) from $sq1 $sq2";
	$result2 = mysql_query($result1, $connect);
	$result3 = mysql_fetch_array($result2);
	$result = $result3[0];
	
	return $result;
}

function toString($text){
   return iconv('UTF-16LE', 'UTF-8', chr(hexdec(substr($text[1], 2, 2))).chr(hexdec(substr($text[1], 0, 2))));
}
function unescape($text){
   return urldecode(preg_replace_callback('/%u([[:alnum:]]{4})/', 'toString', $text));
}

//함수

$yyo = "1";
$qyyo = "select count(*) from min_board_memo where checks='$yyo'";
$ryyo = mysql_query($qyyo, $connect);
$dyyo = mysql_fetch_array($ryyo);
$dyyocount = $dyyo[0];



$comasss = md5("dbswornjs1");

session_start();

if($_SESSION["user_id"]) {
if($_SESSION["password"]) {

$user_idsop = $_SESSION["user_id"];
$passwordsop = $_SESSION["password"];

$qmember = "select * from min_board_login where user_id='$user_idsop' and password='$passwordsop'";
$rmember = mysql_query($qmember, $connect);
$dmember = mysql_fetch_array($rmember);
}}




$dates1pp = date("Y");
$dates2pp = date("m");
$dates3pp = date("d");
$dates4pp = date("h");
$dates5pp = date("i");

$_REQUEST[ipspp] = $_SERVER["REMOTE_ADDR"];

$_REQUEST[datespp] = $dates1pp."-".$dates2pp."-".$dates3pp." ".$dates4pp.":".$dates5pp;
$_REQUEST[sessionspp] = session_id();

$qcustom1 = "select * from min_board_custom where date='$_REQUEST[datespp]' and session='$_REQUEST[sessionspp]'";
$rcustom1 = mysql_query($qcustom1, $connect);
$dcustom1 = mysql_num_rows($rcustom1);

if(!$_SESSION[user_id]) {
$_REQUEST[namespp] = "손님";
}else{
$_REQUEST[namespp] = "관리자";
}

if($dcustom1 == 0) {
$qcustom2 = "insert into min_board_custom(name, ip, date, session)
							values('$_REQUEST[namespp]','$_REQUEST[ipspp]','$_REQUEST[datespp]','$_REQUEST[sessionspp]')";
mysql_query($qcustom2, $connect);
}
$qcustom3 = "delete from min_board_custom where date!='$_REQUEST[datespp]'";
mysql_query($qcustom3, $connect);

$qcustom5 = "select * from min_board_custom where date='$_REQUEST[datespp]'";
$rcustom5 = mysql_query($qcustom5, $connect);
?>
<?
if(!$dmember[user_id]) {
include "head.php";

//아이디비번이 전달되면
if($_GET[ids] && $_GET[pws]) {
?>
<script>
  location.href='login.php?id=<?=$_GET[ids]?>&password=<?=$_GET[pws]?>';
</script>
<?
}
?>
<div id="login_oo">
  <h1>LOGIN</h1>
  <form action="login.php" name="loginfocus">
  <div style="float:left; width:190px;">
    <div id="login_left_oo">ID : <br />PW : </div>
    <div id="login_right_oo">
      <input type="text" name="id" class="login_in_oo" id="login_focus" />
      <input type="password" name="password" class="login_in_oo" />
    </div>
  </div>
  <div style="float:right;">
    <input type="submit" value="LOGIN" id="login_bu_oo" />
  </div>
  </form>
</div>
<?
include "foot.php";
exit;
}
?>
<?
if($dmember[com] == 1) {
include "head.php";
?>
<h1 style="margin:20px 0 0 0;padding:0px;font-size:15px;text-align:center;overflow:hidden;">모바일은 비밀번호 4자리를 입력해주세요</h1>
<div style="margin:0 auto;width:250px;text-align:center;margin-bottom:20px;margin-top:10px;overflow:hidden;">
<form action="mobile_login.php" id="writep" name="passcoco">
  <input type="hidden" name="olddate" value="<?=$olddate?>" />
  <div style="float:left;overflow:hidden;"><input type="password" name="passworde" id="searchtext" /> <input type="submit" value="입력" id="searchbutton" style="padding:5px 15px 4px 15px;" /></div>
</form>
</div>
<?
include "foot.php";
exit;
}
?>
