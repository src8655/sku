<?
include "lib.php";
include "head.php";

if($Search_mode) {
  if($Search_mode == 1) $tmp = "company";
  if($Search_mode == 2) $tmp = "addr";
  
  $where = "where $tmp like '%$Search_text%'";
  }else{
    $where = "";
    }
if($Search_mode != 3) {
  $qinfo = "select count(*) from min_board_info $where";
  $rinfo = mysql_query($qinfo, $connect);
  $dinfo = mysql_fetch_array($rinfo);
  $infocount = $dinfo[0];
}else{
  $where = "";
  $qinfo = "select * from min_board_info";
  $rinfo = mysql_query($qinfo, $connect);
  $infocount = 0;
  while($data = mysql_fetch_array($rinfo)) {
    $searchphone1 = $data[tel1].$data[tel2].$data[tel3].$data[fax1].$data[fax2].$data[fax3].$data[phone1].$data[phone2].$data[phone3];
    $searchphone2 = $data[tel1]."-".$data[tel2]."-".$data[tel3].$data[fax1]."-".$data[fax2]."-".$data[fax3].$data[phone1]."-".$data[phone2]."-".$data[phone3];
    $queri = "select * from min_board_info_plus where id='$data[no]' order by no desc";
    $reeri = mysql_query($queri, $connect);
    while($daeri = mysql_fetch_array($reeri)) {
      $searchphone1 = $searchphone1.$daeri[phone1].$daeri[phone2].$daeri[phone3];
      $searchphone2 = $searchphone2.$daeri[phone1]."-".$daeri[phone2]."-".$daeri[phone3];
    }
    $searchphone = $searchphone1.$searchphone2;
    if(eregi($Search_text,$searchphone)) {
      $infocount = $infocount+1;
    }
  }
}


if(!$page) {
$page = "1";
}

$pagenum1 = "10";
$pagenum2 = ($page*$pagenum1)-$pagenum1;
$limits = "limit $pagenum2, $pagenum1";

$paging = ceil($infocount/$pagenum1);

$ai1 = $page-5;
$ai2 = $page+5;


if($Search_mode == 3) $limits = "";

$query = "select * from min_board_info $where order by company asc $limits";
$result = mysql_query($query, $connect);
?>
<div style="width:730px;float:left;">
<form action="company_info_search.php" id="writep" name="searchtotal">
<table cellpadding="7" cellspacing="1" id="write1_table" border="0" width="730px" style="margin:0 0 10px 0;">
<col width="170" />
<col width="390" />
<col width="170" />
  <tr>
    <td><a href="index.php" class="view1_button">뒤로가기</a></td>
    <td align="center">
      <select name="Search_mode" id="searchmode">
        <option value="1" <? if($Search_mode == 1) {?>selected<? }?>>회사이름</option>
        <option value="3" <? if($Search_mode == 3) {?>selected<? }?>>전화번호</option>
        <option value="2" <? if($Search_mode == 2) {?>selected<? }?>>주소</option>
      </select>
      <input type="text" name="Search_text" id="searchtext" class="focus_on" size="20" <? if($Search_mode) {?>value="<?=$Search_text?>"<? }?> />
      <input type="submit" value="검색" id="searchbutton" />
    </td>
    <td><a href="#bottomtxx" class="view1_button">맨아래로</a></td>
  </tr>
</table>
</form>
<div class="box">
    <h1><div style="float:left;width:120px;">&nbsp;</div><div style="float:left;width:445px;text-align:center;">회사정보 - <span style="color:red;"><?=$infocount?></span></div><div style="float:right;width:120px;"><a href="company_info_write.php" class="view1_button">작성하기</a></div></h1>
		<? if($Search_mode != 3){?><p style="text-align:center;">
			<a href="company_info.php?page=1&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>"><<</a>&nbsp;
<?
for($i=$ai1;$i<$ai2;$i++) {
if($i<1) {
}else{
if($i>$paging) {
}else{
?>
			<a href="company_info.php?page=<?=$i?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>" <? if($i == $page) {?>style="font-weight:bold;color:red;"<? }?>>[<?=$i?>]</a>&nbsp;
<?
}}}
?>
			<a href="company_info.php?page=<?=$paging?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>">>></a>
		</p><? }?>
</div>
<?
while($data = mysql_fetch_array($result)) {
  if($Search_mode == 3) {
    $searchphone1 = $data[tel1].$data[tel2].$data[tel3].$data[fax1].$data[fax2].$data[fax3].$data[phone1].$data[phone2].$data[phone3];
    $searchphone2 = $data[tel1]."-".$data[tel2]."-".$data[tel3].$data[fax1]."-".$data[fax2]."-".$data[fax3].$data[phone1]."-".$data[phone2]."-".$data[phone3];
    $queri = "select * from min_board_info_plus where id='$data[no]' order by no desc";
    $reeri = mysql_query($queri, $connect);
    while($daeri = mysql_fetch_array($reeri)) {
      $searchphone1 = $searchphone1.$daeri[phone1].$daeri[phone2].$daeri[phone3];
      $searchphone2 = $searchphone2.$daeri[phone1]."-".$daeri[phone2]."-".$daeri[phone3];
    }
    $searchphone = $searchphone1.$searchphone2;
    if(!eregi($Search_text,$searchphone)) {
      continue;
    }
  }
?>
<div class="box">
<form action="./sms/sms_form.php" target="_BLANK">
		<h1>
		  <div style="float:left;width:300px;">
		  <input type="checkbox" name="callinfo[]" value="회사명 : <?=$data[company]?>" id="ach<?=$data[no]?>a" checked style="display:none;" /><label for="ach<?=$data[no]?>a"></label>
		  <?=$data[company]?></div>
		  <div style="float:right;width:380px;">
		    <a href="company_info_del.php?no=<?=$data[no]?>" class="view1_button" style="float:right;width:60px;">삭제</a>
		    <a href="company_info_edit.php?no=<?=$data[no]?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&page=<?=$page?>" class="view1_button" style="float:right;width:60px;margin:0 5px 0 5px;">수정</a>
		    <a href="#nones" onclick="ememaee(aee<?=$data[no]?>);" class="view1_button" style="float:right;width:100px;">담당자 추가</a>
		    <input type="submit" value="문자전송" class="view1_button" style="background:#eeeeee;float:right;width:80px;margin-right:5px;" />
		  </div>
		</h1>
		<p <? if(!$data[addr]) {?>style="display:none;"<? }?>>
		  <input type="checkbox" name="callinfo[]" value="[지번] 주소 : <?=$data[addr]?>" id="ach<?=$data[no]?>b" />
		  <label for="ach<?=$data[no]?>b">
			<span style="font-weight:bold;">[지번] 주소</span> : <span style="color:red;font-weight:bold;"><?=$data[addr]?></span>
			</label>
		</p>
		<p <? if(!$data[addr2]) {?>style="display:none;"<? }?>>
		  <input type="checkbox" name="callinfo[]" value="[도로명] 주소 : <?=$data[addr2]?>" id="ach<?=$data[no]?>be" /><label for="ach<?=$data[no]?>be">
			<span style="font-weight:bold;">[도로명] 주소</span> : <span style="color:blue;font-weight:bold;"><?=$data[addr2]?></span>
			</label>
		</p>
		<p <? if(!$data[addrnum]) {?>style="display:none;"<? }?>>
		  <input type="checkbox" name="callinfo[]" value="우편번호 : <?=$data[addrnum]?>" id="ach<?=$data[no]?>addrnum" /><label for="ach<?=$data[no]?>addrnum">
			<span style="font-weight:bold;">우편번호</span> : <span style="color:green;font-weight:bold;"><?=$data[addrnum]?></span>
			</label>
		</p>
		<p <? $okl = $data[tel1].$data[tel2].$data[tel3].$data[fax1].$data[fax2].$data[fax3]; if(!$okl) {?>style="display:none;"<? }?>>
		  <input type="checkbox" name="callinfo[]" value="전화번호 : <?=$data[tel1]?>-<?=$data[tel2]?>-<?=$data[tel3]?>" id="ach<?=$data[no]?>c" /><label for="ach<?=$data[no]?>c">
			<span <? $okl2 = $data[tel1].$data[tel2].$data[tel3]; if(!$okl2) {?>style="display:none;"<? }?>><span style="font-weight:bold;">전화번호</span> : <?=$data[tel1]?>-<?=$data[tel2]?>-<?=$data[tel3]?> 　　　</span>
			</label>
			<span <? $okl1 = $data[fax1].$data[fax2].$data[fax3]; if(!$okl1) {?>style="display:none;"<? }?>>
			<input type="checkbox" name="callinfo[]" value="FAX번호 : <?=$data[fax1]?>-<?=$data[fax2]?>-<?=$data[fax3]?>" id="ach<?=$data[no]?>d" /><label for="ach<?=$data[no]?>d">
			<span style="font-weight:bold;">FAX번호</span> : <?=$data[fax1]?>-<?=$data[fax2]?>-<?=$data[fax3]?>
		  </label></span>
		</p>
		<p <? if(!$data[email]) {?>style="display:none;"<? }?>>
		  <input type="checkbox" name="callinfo[]" value="이메일 : <?=$data[email]?>" id="ach<?=$data[no]?>e" /><label for="ach<?=$data[no]?>e">
			<span style="font-weight:bold;">이메일</span> : <?=$data[email]?>
			</label>
		</p>
		<p <? $okl3 = $data[name].$data[phone1].$data[phone2].$data[phone3]; if(!$okl3) {?>style="display:none;"<? }?>>
		  <input type="checkbox" name="callinfo[]" value="담당자 : <?=$data[name]?> 담당자번호 : <?=$data[phone1]?>-<?=$data[phone2]?>-<?=$data[phone3]?>" id="ach<?=$data[no]?>f" /><label for="ach<?=$data[no]?>f">
			<span style="font-weight:bold;">담당자</span> : <?=$data[name]?> 　　　<span style="font-weight:bold;">담당자번호</span> : <?=$data[phone1]?>-<?=$data[phone2]?>-<?=$data[phone3]?>
			</label>
		</p>
<?
$quer = "select * from min_board_info_plus where id='$data[no]' order by no desc";
$reer = mysql_query($quer, $connect);
while($daer = mysql_fetch_array($reer)) {
?>
      <p>
        <input type="checkbox" name="callinfo[]" value="담당자 : <?=$daer[name]?> 담당자번호 : <?=$daer[phone1]?>-<?=$daer[phone2]?>-<?=$daer[phone3]?>"id="ach<?=$daer[no]?>g" /><label for="ach<?=$daer[no]?>g">
      	<span style="font-weight:bold;">담당자</span> : <?=$daer[name]?> 　　　<span style="font-weight:bold;">담당자번호</span> : <?=$daer[phone1]?>-<?=$daer[phone2]?>-<?=$daer[phone3]?> 　　<a href="company_info_plus_del2.php?no=<?=$daer[no]?>&onon=<?=$data[no]?>&page=<?=$page?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>"><span style="font-weight:normal; font-size:11px; color:red;">(삭제)</span></a>
        </label>
      </p>
<?
}
?>
      <p <? if(!$data[memo]) {?>style="display:none;"<? }?>>
        <input type="checkbox" name="callinfo[]" value="메모 : <?=$data[memo]?>" id="ach<?=$data[no]?>h" /><label for="ach<?=$data[no]?>h">
      	<span style="font-weight:bold;">메모</span> : <?=$data[memo]?>
      	</label>
      </p>
      <div style="font-size:15px;font-weight:bold;padding-top:5px;padding-bottom:7px;color:blue;">
      
          <input type="checkbox" name="callinfo[]" value=" " checked style="display:none;" />
        	<input type="checkbox" name="callinfo[]" value="ㅡ세금계산서ㅡ등록번호:127-24-44779 상호:로타리종합물류 성명:윤재권 주소:경기도 양주시 은현면 화합로 959(1층) 업태:서비스업 종목:화물운송대행 우편:11430" id="ach<?=$data[no]?>segum" /><label for="ach<?=$data[no]?>segum"> 세금계산서</label>&nbsp;&nbsp;&nbsp;

        	<input type="checkbox" name="callinfo[]" value="ㅡ계좌번호ㅡ로타리종합물류 계좌 농협 351-0737-4897-53 윤재권" id="ach<?=$data[no]?>gj" /><label for="ach<?=$data[no]?>gj"> 계좌번호</label>
      </div>
</form>
		<div style="display:none;" id="aee<?=$data[no]?>">
			<form action="company_info_plus.php" id="company_in">
				<input type="hidden" name="id" value="<?=$data[no]?>" />
				<input type="hidden" name="page" value="<?=$page?>" />
				<input type="hidden" name="Search_text" value="<?=$Search_text?>" />
				<input type="hidden" name="Search_mode" value="<?=$Search_mode?>" />
	      <span style="font-weight:bold;font-size:14px;">담당자</span> : <input type="text" name="name" size="10" /> 　<span style="font-weight:bold;font-size:14px;">담당자번호</span> : <input type="text" name="phone1" size="5"> - <input type="text" name="phone2" size="5"> - <input type="text" name="phone3" size="5"> <input type="submit" value="등록하기" style="padding-left:10px;padding-right:10px;font-weight:bold;" />
			</form>
		</div>
	</div>
<?
}
?>
<? if($Search_mode != 3){?>
<div class="box">
		<p style="text-align:center;">
			<a href="company_info.php?page=1&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>"><<</a>&nbsp;
<?
for($i=$ai1;$i<$ai2;$i++) {
if($i<1) {
}else{
if($i>$paging) {
}else{
?>
			<a href="company_info.php?page=<?=$i?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>" <? if($i == $page) {?>style="font-weight:bold;color:red;"<? }?>>[<?=$i?>]</a>&nbsp;
<?
}}}
?>
			<a href="company_info.php?page=<?=$paging?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>">>></a>
		</p>
</div><? }?>
</div>
<div style="float:right;width:260px;overflow:hidden;">
	<div class="box">
		<h1>최근 검색목록</h1>
	<?
	$quia = "select * from min_board_company_searchc order by no desc limit 0,10";
	$ruia = mysql_query($quia, $connect);
	$ccn = 1;
	while($duia = mysql_fetch_array($ruia)) {
	?>
			<form action="company_info_search.php" name="aa<?=$duia[no]?>z">
				<input type="hidden" name="Search_mode" value="<?=$duia[mode]?>" />
				<input type="hidden" name="Search_text" value="<?=$duia[gom]?>" />
			</form>
		<p class="aasee">
			<?=$ccn?>. <a href="#" onclick="haaz(aa<?=$duia[no]?>z);"><?=$duia[gom]?></a>
		</p>
	<?
	$ccn++;
	}
	?>
	</div>
	<div class="box">
		<h1>자주쓰는 검색목록</h1>
	<?
	$ttty = date("Y").date("m");
	
	$quia2 = "select * from min_board_company_searchi where date='$ttty' order by hit desc limit 0,10";
	$ruia2 = mysql_query($quia2, $connect);
	$ccn2 = 1;
	while($duia2 = mysql_fetch_array($ruia2)) {
	?>
			<form action="company_info_search.php" name="aaz<?=$duia2[no]?>z">
				<input type="hidden" name="Search_mode" value="<?=$duia2[mode]?>" />
				<input type="hidden" name="Search_text" value="<?=$duia2[gom]?>" />
			</form>
		<p class="aasee">
			<?=$ccn2?>. <a href="#" onclick="haaz(aaz<?=$duia2[no]?>z);"><?=$duia2[gom]?></a> <span style="font-size:11px;">-</span> <?=$duia2[hit]?>
		</p>
	<?
	$ccn2++;
	}
	?>
	</div>
</div>
<script type="text/javascript">
	function haaz(aazz) {
		var asdf = aazz;
		asdf.submit();
	}
</script>
<?
include "foot.php";
?>
