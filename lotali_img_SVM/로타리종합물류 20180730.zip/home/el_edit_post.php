<?
include "lib.php";
include "head.php";

$query = "update min_board_el set
					yos='$_REQUEST[date5w]' where no='$no'";
mysql_query($query, $connect);
?>
<script>
	location.href="el.php?page=<?=$page?>";
</script>
<?
include "foot.php";
?>