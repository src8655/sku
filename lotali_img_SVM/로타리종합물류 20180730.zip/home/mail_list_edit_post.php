<?
include "lib.php";
include "head.php";

$query = "update min_board_mail_list set
					email='$_REQUEST[email]',
					company='$_REQUEST[company]' where no='$no'";
mysql_query($query, $connect);
?>
<script>
	location.href="mail_list.php";
</script>
<?
include "foot.php";
?>
