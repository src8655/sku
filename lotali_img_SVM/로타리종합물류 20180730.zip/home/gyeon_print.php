<?
include "lib.php";
include "head2.php";
?>
<script defer>
function prints() {
factory.printing.leftMargin = "15.0";
factory.printing.topMargin = "25.0";
factory.printing.rightMargin = "15.0";
factory.printing.bottomMargin = "15.0";
factory.printing.header="";
factory.printing.footer="";
factory.printing.portrait=true;
factory.printing.Print(true);
}
function printshide() {
	pppl.style.display = "none";
}
</script>
<a href="#" onclick="printshide();prints();" id="pppl" style="display:block;width:100px;border:1px solid #676767;text-align:center;font-size:15px;margin:0 auto;margin-bottom:10px;padding:10px;"><img src="./images/print_io.jpg" style="border:0px;" /><br />인쇄하기<br /><span style="font-size:12px;color:red;">(페이지 자동조절)</span></a>
<object id="factory" viewastext style="display:none" classid="clsid:1663ed61-23eb-11d2-b92f-008048fdd814" codebase="./adr/smsx.cab#Version=6,3,436,14"></object>






<h1 style="width:100%;text-align:center;margin:50px 0 50px 0;padding:0px;font-size:45px;overflow:hidden;">견&nbsp;&nbsp;적&nbsp;&nbsp;서</h1>

<div style="width:800px;margin:0 auto;overflow:hidden;">
  <table cellpadding="5" cellspacing="0"id="print_te" border="0" style="font-size:15px;width:280px;float:left;border:3px solid #000000;">
  <col width="80px" />
  <col width="130px" />
    <tr>
      <th height="25px">견적 일자</th>
      <td><?=$_GET[dates]?></td>
    </tr>
    <tr>
      <th height="25px">업체명</th>
      <td><?=$_GET[companys]?></td>
    </tr>
    <tr>
      <th height="25px">담당자</th>
      <td><?=$_GET[names]?></td>
    </tr>
    <tr>
      <th height="25px">연락처</th>
      <td><?=$_GET[phones]?></td>
    </tr>
    <tr>
      <th height="25px">팩스번호</th>
      <td><?=$_GET[faxs]?></td>
    </tr>
    <tr>
      <th height="25px">납기</th>
      <td><?=$_GET[nabgi]?></td>
    </tr>
    <tr>
      <th height="25px">지불조건</th>
      <td><?=$_GET[jijo]?></td>
    </tr>
  </table>
  
  
  <table cellpadding="5" cellspacing="0" id="print_te" border="0" style="font-size:15px;width:350px;float:right;border:3px solid #000000;">
  <col width="80px" />
  <col width="130px" />
    <tr>
      <th height="25px">상호</th>
      <td>로타리종합물류</td>
    </tr>
    <tr>
      <th height="25px">등록번호</th>
      <td>127-24-44779</td>
    </tr>
    <tr>
      <th height="25px">주소</th>
      <td>경기도 양주시 은현면 화합로 959</td>
    </tr>
    <tr>
      <th height="25px">전화번호</th>
      <td>031-836-6677~6688</td>
    </tr>
    <tr>
      <th height="25px">팩스번호</th>
      <td>031-836-8558</td>
    </tr>
    <tr>
      <th height="25px">소장님</th>
      <td>010-3349-5262</td>
    </tr>
  </table>
  <p style="font-size:20px;font-weight:bold;margin:0px;padding:50px 0 50px 0;width:100%;overflow:hidden;">
    *아래와 같이 견적합니다.
  </p>
  <table cellpadding="5" cellspacing="0" id="print_te" border="0" style="font-size:15px;width:100%;float:right;border:3px solid #000000;">
  <col width="300px" />
  <col width="125px" />
  <col width="125px" />
  <col width="125px" />
  <col width="125px" />
    <tr>
      <th height="25px">내용</th>
      <th>단가</th>
      <th>금액</th>
      <th>세액</th>
      <th>비고</th>
    </tr>
    <tr>
      <td align="center" height="25px"><?=$_GET[memos1]?></td>
      <td align="right"><?=number_format($_GET[dans1])?></td>
      <td align="right"><?=number_format($_GET[moneys1])?></td>
      <td align="right"><?=number_format($_GET[se1])?></td>
      <td align="center"><?=$_GET[bigo1]?></td>
    </tr>
    <tr>
      <td align="center" height="25px"><?=$_GET[memos2]?></td>
      <td align="right"><?=number_format($_GET[dans2])?></td>
      <td align="right"><?=number_format($_GET[moneys2])?></td>
      <td align="right"><?=number_format($_GET[se2])?></td>
      <td align="center"><?=$_GET[bigo2]?></td>
    </tr>
    <tr>
      <td align="center" height="25px"><?=$_GET[memos3]?></td>
      <td align="right"><?=number_format($_GET[dans3])?></td>
      <td align="right"><?=number_format($_GET[moneys3])?></td>
      <td align="right"><?=number_format($_GET[se3])?></td>
      <td align="center"><?=$_GET[bigo3]?></td>
    </tr>
    <tr>
      <td align="center" height="25px"><?=$_GET[memos4]?></td>
      <td align="right"><?=number_format($_GET[dans4])?></td>
      <td align="right"><?=number_format($_GET[moneys4])?></td>
      <td align="right"><?=number_format($_GET[se4])?></td>
      <td align="center"><?=$_GET[bigo4]?></td>
    </tr>
    <tr>
      <td align="center" height="25px"><?=$_GET[memos5]?></td>
      <td align="right"><?=number_format($_GET[dans5])?></td>
      <td align="right"><?=number_format($_GET[moneys5])?></td>
      <td align="right"><?=number_format($_GET[se5])?></td>
      <td align="center"><?=$_GET[bigo5]?></td>
    </tr>
    <tr>
      <td align="center" height="25px"><?=$_GET[memos6]?></td>
      <td align="right"><?=number_format($_GET[dans6])?></td>
      <td align="right"><?=number_format($_GET[moneys6])?></td>
      <td align="right"><?=number_format($_GET[se6])?></td>
      <td align="center"><?=$_GET[bigo6]?></td>
    </tr>
    <tr>
      <th height="25px">합계</th>
      <td align="right"><?=number_format($_GET[dans1]+$_GET[dans2]+$_GET[dans3]+$_GET[dans4]+$_GET[dans5]+$_GET[dans6])?></td>
      <td align="right"><?=number_format($_GET[moneys1]+$_GET[moneys2]+$_GET[moneys3]+$_GET[moneys4]+$_GET[moneys5]+$_GET[moneys6])?></td>
      <td align="right"><?=number_format($_GET[se1]+$_GET[se2]+$_GET[se3]+$_GET[se4]+$_GET[se5]+$_GET[se6])?></td>
      <td align="center">&nbsp;</td>
    </tr>
  </table>
  <div style="margin:0px;padding:40px 0 0 0;width:100%;overflow:hidden;">
    <h1 style="margin:0px;padding:10px;width:50px;text-align:center;font-size:20px;border:3px solid #000000;border-bottom:0px;overflow:hidden;">기타</h1>
    <p style="font-size15px;margin:0px;padding:45px 10px 45px 10px;border:3px solid #000000;overflow:hidden;">
      <?=$_GET[gitars]?>
    </p>
  </div>
</div>

<?
include "foot2.php";
?>
