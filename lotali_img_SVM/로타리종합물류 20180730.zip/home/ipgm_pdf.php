<?
define('FPDF_FONTPATH','./mpdf/font/');  
require_once './mpdf/mpdf.php';
 
// 함수의 원형 : function mPDF($mode='',$format='A4',$default_font_size=0,$default_font='',$mgl=15,$mgr=15,$mgt=16,$mgb=16,$mgh=9,$mgf=9, $orientation='P')
$pdf = new mPDF('ko');

ob_start(); 
?>
<?
include "lib.php";
include "head2.php";

?>
<table cellpadding="8" cellspacing="0" id="print_a">
<col width="200" />
<col width="200" />
  <tr>
    <th colspan="2">거래처 입금자 목록</th>
  </tr>
<?
$cnt = 1;

$ipgm_result = mysql_query("select * from min_board_admin_damt where ipgm!='' order by no asc",$connect);
while($ipgm_data = mysql_fetch_array($ipgm_result)) {
?>
  <tr>
    <td><?=$cnt?>. <?=$ipgm_data[company]?></td>
    <td>입금자:[<?=$ipgm_data[ipgm]?>]</td>
  </tr>
<?
$cnt++;
}
$ipgm_result = mysql_query("select * from min_board_admin where ipgm!='' order by name asc",$connect);
while($ipgm_data = mysql_fetch_array($ipgm_result)) {
?>
  <tr>
    <td><?=$cnt?>. <?=$ipgm_data[name]?></td>
    <td>입금자:[<?=$ipgm_data[ipgm]?>]</td>
  </tr>
<?
$cnt++;
}
?>
</table>
<?
include "foot2.php";
?>

<?
$html=ob_get_contents(); 
ob_end_clean(); 
$html = iconv("UTF-8","UTF-8",$html);
$pdf->SetTopMargin(25);
$pdf->bookmark("로타리종합물류",0);
// $pdf->SetDisplayMode('fullwidth');   // pdf가 열릴때 창크기에 맞게 보여지도록 함. 이부분이 주석처리되거나 삭제되면 창크기에 맞춰지지 않고 pdf Viewer의 설정을 따르게됨
$pdf->WriteHTML($html);
$pdf->Output();     // 웹상에서 열림
?>
