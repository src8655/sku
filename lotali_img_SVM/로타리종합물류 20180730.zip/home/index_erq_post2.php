<?
include "lib.php";
include "head.php";

$query = "insert into min_board_admin_check(company, olddate)
					values('$_REQUEST[company]','$_REQUEST[olddate]')";
mysql_query($query, $connect);
?>
<script>
location.href="index.php?olddate=<?=$olddate?>&erqs=<?=$erqs?>&ipgm=<?=$_GET[ipgm]?>&erq=1";	
</script>
