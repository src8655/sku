<?
include "lib.php";
include "head.php";
?>
<?
$qiii = "select * from min_board_jang_date where no='$date'";
$riii = mysql_query($qiii, $connect);
$diii = mysql_fetch_array($riii);
?>
<table cellpadding="5" cellspacing="1" width="1000px" id="write1_table" border="0" style="margin-bottom:10px;font-size:12px;">
<col width="150" />
<col width="350" />
<col width="350" />
<col width="150" />
	<tr>
		<td><a href="index.php" class="view1_button">뒤로가기</a></td>
		<td align="center"><a href="jang_edit.php?date=<?=$date?>" id="ablue" class="view1_button">회원 수정으로 이동</a></td>
		<td align="center"><a href="jang_del.php?date=<?=$date?>" id="ared" class="view1_button">회원 삭제로 이동</a></td>
		<td><a href="#bottomtxx" class="view1_button">맨아래로</a></td>
	</tr>
</table>
<?
if($oldu) {
?>
<table cellpadding="5" cellspacing="1" width="1000px" id="write1_table" border="0" style="margin-bottom:10px;font-size:15px;font-family:'Arial';">
<col width="100" />
<col width="100" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<form action="jang_member_post.php">
<input type="hidden" name="date" value="<?=$date?>" />
	<tr>
		<td align="center"><input type="text" name="name" style="width:110px;" /></td>
		<td align="center"><input type="text" name="numbers" style="width:110px;" /></td>
		<td align="center" colspan="2"><input type="submit" value="추가하기" class="view1_button" style="width:90%;" /></td>
		<th align="center" colspan="7" style="font-size:25px;"><?=$diii[date]?> 년</th>
		<th align="center" colspan="3"><a href="jang_check.php?date=<?=$date?>" class="view1_button" style="color:green;">보기모드로 이동</a></th>
	</tr>
</form>
	<tr>
		<th height="30">이름</th>
		<th>차량번호</th>
		<th>1월</th>
		<th>2월</th>
		<th>3월</th>
		<th>4월</th>
		<th>5월</th>
		<th>6월</th>
		<th>7월</th>
		<th>8월</th>
		<th>9월</th>
		<th>10월</th>
		<th>11월</th>
		<th>12월</th>
	</tr>
<?
$query = "select * from min_board_jang_member order by name asc";
$result = mysql_query($query, $connect);
while($data = mysql_fetch_array($result)) {
$qjj = "select * from min_board_jang_check where date='$date' and member='$data[no]'";
$rjj = mysql_query($qjj, $connect);
$djj = mysql_fetch_array($rjj);
?>
	<tr id="qq">
		<td align="center"><?=$data[name]?></td>
		<td align="center"><?=$data[number]?></td>
<?
$qjjj = "select * from min_board_jang_check where date='$date' and member='$data[no]'";
$rjjj = mysql_query($qjjj, $connect);
if($djj[member]) {
while($djjj = mysql_fetch_array($rjjj)) {
?>
		<td align="center" height="45"><? if($djjj[a1]) {?><a href="jang_check_post2_ch.php?date=<?=$date?>&members=<?=$data[no]?>&a1=<?=$djjj[a1]?>&cpp=<?=$djjj[a1]?>&cop=2&cacp=a1" style="font-size:13px;"><?=$djjj[a1]?></a><? }else{?><form action="jang_check_post2_ch.php"><input type="hidden" name="cacp" value="a1" /><input type="hidden" name="cop" value="1" /><input type="hidden" name="date" value="<?=$date?>" /><input type="hidden" name="members" value="<?=$data[no]?>" /><input type="submit" value="체크" /><input type="text" name="memo" style="width:38px;" /></form><? }?></td>
		<td align="center"><? if($djjj[a2]) {?><a href="jang_check_post2_ch.php?date=<?=$date?>&members=<?=$data[no]?>&a2=<?=$djjj[a2]?>&cpp=<?=$djjj[a2]?>&cop=2&cacp=a2" style="font-size:13px;"><?=$djjj[a2]?></a><? }else{?><form action="jang_check_post2_ch.php"><input type="hidden" name="cacp" value="a2" /><input type="hidden" name="cop" value="1" /><input type="hidden" name="date" value="<?=$date?>" /><input type="hidden" name="members" value="<?=$data[no]?>" /><input type="submit" value="체크" /><input type="text" name="memo" style="width:38px;" /></form><? }?></td>
		<td align="center"><? if($djjj[a3]) {?><a href="jang_check_post2_ch.php?date=<?=$date?>&members=<?=$data[no]?>&a3=<?=$djjj[a3]?>&cpp=<?=$djjj[a3]?>&cop=2&cacp=a3" style="font-size:13px;"><?=$djjj[a3]?></a><? }else{?><form action="jang_check_post2_ch.php"><input type="hidden" name="cacp" value="a3" /><input type="hidden" name="cop" value="1" /><input type="hidden" name="date" value="<?=$date?>" /><input type="hidden" name="members" value="<?=$data[no]?>" /><input type="submit" value="체크" /><input type="text" name="memo" style="width:38px;" /></form><? }?></td>
		<td align="center"><? if($djjj[a4]) {?><a href="jang_check_post2_ch.php?date=<?=$date?>&members=<?=$data[no]?>&a4=<?=$djjj[a4]?>&cpp=<?=$djjj[a4]?>&cop=2&cacp=a4" style="font-size:13px;"><?=$djjj[a4]?></a><? }else{?><form action="jang_check_post2_ch.php"><input type="hidden" name="cacp" value="a4" /><input type="hidden" name="cop" value="1" /><input type="hidden" name="date" value="<?=$date?>" /><input type="hidden" name="members" value="<?=$data[no]?>" /><input type="submit" value="체크" /><input type="text" name="memo" style="width:38px;" /></form><? }?></td>
		<td align="center"><? if($djjj[a5]) {?><a href="jang_check_post2_ch.php?date=<?=$date?>&members=<?=$data[no]?>&a5=<?=$djjj[a5]?>&cpp=<?=$djjj[a5]?>&cop=2&cacp=a5" style="font-size:13px;"><?=$djjj[a5]?></a><? }else{?><form action="jang_check_post2_ch.php"><input type="hidden" name="cacp" value="a5" /><input type="hidden" name="cop" value="1" /><input type="hidden" name="date" value="<?=$date?>" /><input type="hidden" name="members" value="<?=$data[no]?>" /><input type="submit" value="체크" /><input type="text" name="memo" style="width:38px;" /></form><? }?></td>
		<td align="center"><? if($djjj[a6]) {?><a href="jang_check_post2_ch.php?date=<?=$date?>&members=<?=$data[no]?>&a6=<?=$djjj[a6]?>&cpp=<?=$djjj[a6]?>&cop=2&cacp=a6" style="font-size:13px;"><?=$djjj[a6]?></a><? }else{?><form action="jang_check_post2_ch.php"><input type="hidden" name="cacp" value="a6" /><input type="hidden" name="cop" value="1" /><input type="hidden" name="date" value="<?=$date?>" /><input type="hidden" name="members" value="<?=$data[no]?>" /><input type="submit" value="체크" /><input type="text" name="memo" style="width:38px;" /></form><? }?></td>
		<td align="center"><? if($djjj[a7]) {?><a href="jang_check_post2_ch.php?date=<?=$date?>&members=<?=$data[no]?>&a7=<?=$djjj[a7]?>&cpp=<?=$djjj[a7]?>&cop=2&cacp=a7" style="font-size:13px;"><?=$djjj[a7]?></a><? }else{?><form action="jang_check_post2_ch.php"><input type="hidden" name="cacp" value="a7" /><input type="hidden" name="cop" value="1" /><input type="hidden" name="date" value="<?=$date?>" /><input type="hidden" name="members" value="<?=$data[no]?>" /><input type="submit" value="체크" /><input type="text" name="memo" style="width:38px;" /></form><? }?></td>
		<td align="center"><? if($djjj[a8]) {?><a href="jang_check_post2_ch.php?date=<?=$date?>&members=<?=$data[no]?>&a8=<?=$djjj[a8]?>&cpp=<?=$djjj[a8]?>&cop=2&cacp=a8" style="font-size:13px;"><?=$djjj[a8]?></a><? }else{?><form action="jang_check_post2_ch.php"><input type="hidden" name="cacp" value="a8" /><input type="hidden" name="cop" value="1" /><input type="hidden" name="date" value="<?=$date?>" /><input type="hidden" name="members" value="<?=$data[no]?>" /><input type="submit" value="체크" /><input type="text" name="memo" style="width:38px;" /></form><? }?></td>
		<td align="center"><? if($djjj[a9]) {?><a href="jang_check_post2_ch.php?date=<?=$date?>&members=<?=$data[no]?>&a9=<?=$djjj[a9]?>&cpp=<?=$djjj[a9]?>&cop=2&cacp=a9" style="font-size:13px;"><?=$djjj[a9]?></a><? }else{?><form action="jang_check_post2_ch.php"><input type="hidden" name="cacp" value="a9" /><input type="hidden" name="cop" value="1" /><input type="hidden" name="date" value="<?=$date?>" /><input type="hidden" name="members" value="<?=$data[no]?>" /><input type="submit" value="체크" /><input type="text" name="memo" style="width:38px;" /></form><? }?></td>
		<td align="center"><? if($djjj[a10]) {?><a href="jang_check_post2_ch.php?date=<?=$date?>&members=<?=$data[no]?>&a10=<?=$djjj[a10]?>&cpp=<?=$djjj[a10]?>&cop=2&cacp=a10" style="font-size:13px;"><?=$djjj[a10]?></a><? }else{?><form action="jang_check_post2_ch.php"><input type="hidden" name="cacp" value="a10" /><input type="hidden" name="cop" value="1" /><input type="hidden" name="date" value="<?=$date?>" /><input type="hidden" name="members" value="<?=$data[no]?>" /><input type="submit" value="체크" /><input type="text" name="memo" style="width:38px;" /></form><? }?></td>
		<td align="center"><? if($djjj[a11]) {?><a href="jang_check_post2_ch.php?date=<?=$date?>&members=<?=$data[no]?>&a11=<?=$djjj[a11]?>&cpp=<?=$djjj[a11]?>&cop=2&cacp=a11" style="font-size:13px;"><?=$djjj[a11]?></a><? }else{?><form action="jang_check_post2_ch.php"><input type="hidden" name="cacp" value="a11" /><input type="hidden" name="cop" value="1" /><input type="hidden" name="date" value="<?=$date?>" /><input type="hidden" name="members" value="<?=$data[no]?>" /><input type="submit" value="체크" /><input type="text" name="memo" style="width:38px;" /></form><? }?></td>
		<td align="center"><? if($djjj[a12]) {?><a href="jang_check_post2_ch.php?date=<?=$date?>&members=<?=$data[no]?>&a12=<?=$djjj[a12]?>&cpp=<?=$djjj[a12]?>&cop=2&cacp=a12" style="font-size:13px;"><?=$djjj[a12]?></a><? }else{?><form action="jang_check_post2_ch.php"><input type="hidden" name="cacp" value="a12" /><input type="hidden" name="cop" value="1" /><input type="hidden" name="date" value="<?=$date?>" /><input type="hidden" name="members" value="<?=$data[no]?>" /><input type="submit" value="체크" /><input type="text" name="memo" style="width:38px;" /></form><? }?></td>
<?
}
}else{
for($i=1;$i<13;$i++) {
?>
		<td align="center">
			<form action="jang_check_post_ch.php">
				<input type="hidden" name="is" value="a<?=$i?>" />
				<input type="hidden" name="date" value="<?=$date?>" />
				<input type="hidden" name="members" value="<?=$data[no]?>" />
				<input type="submit" value="체크" />
				<input type="text" name="memo" style="width:38px;" />
			</form>
		</td>
<?
}
}
?>
	</tr>
<?
}
?>
	<tr>
		<td align="center"><a href="jang_print.php?date=<?=$date?>" target="_BLANK" class="view1_button">인쇄</a></td>
		<td colspan="11"></td>
		<td align="center" colspan="2"><a href="#toptxx" class="view1_button">맨 위로</a></td>
	</tr>
</table>
<?
}else{
?>
<?
$qiiim = "select * from min_board_jang_date where no='$date'";
$riiim = mysql_query($qiiim, $connect);
$diiim = mysql_fetch_array($riiim);
?>
<table cellpadding="5" cellspacing="1" width="1000px" id="write1_table" border="0" style="margin-bottom:10px;font-size:15px;font-family:'Arial';">
<col width="100" />
<col width="100" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<col width="66" />
<form action="jang_member_post.php">
<input type="hidden" name="date" value="<?=$date?>" />
	<tr>
		<td align="center"><input type="text" name="name" style="width:110px;" /></td>
		<td align="center"><input type="text" name="numbers" style="width:110px;" /></td>
		<td align="center" colspan="2"><input type="submit" value="추가하기" class="view1_button" style="width:90%;" /></td>
		<th align="center" colspan="7" style="font-size:25px;"><?=$diii[date]?> 년</th>
		<th align="center" colspan="3"><a href="jang_check.php?date=<?=$date?>&oldu=1" class="view1_button" style="color:blue;">편집모드로 이동</a></th>
	</tr>
</form>
	<tr>
		<th height="30">이름</th>
		<th>차량번호</th>
		<th>1월</th>
		<th>2월</th>
		<th>3월</th>
		<th>4월</th>
		<th>5월</th>
		<th>6월</th>
		<th>7월</th>
		<th>8월</th>
		<th>9월</th>
		<th>10월</th>
		<th>11월</th>
		<th>12월</th>
	</tr>
<?
$querym = "select * from min_board_jang_member order by name asc";
$resultm = mysql_query($querym, $connect);
while($datam = mysql_fetch_array($resultm)) {
$qjjm = "select * from min_board_jang_check where date='$date' and member='$datam[no]'";
$rjjm = mysql_query($qjjm, $connect);
$djjm = mysql_fetch_array($rjjm);
?>
	<tr id="qq">
		<td align="center"><?=$datam[name]?></td>
		<td align="center"><?=$datam[number]?></td>
<?
$qjjjm = "select * from min_board_jang_check where date='$date' and member='$datam[no]'";
$rjjjm = mysql_query($qjjjm, $connect);
if($djjm[member]) {
while($djjjm = mysql_fetch_array($rjjjm)) {
?>
		<td align="center" height="45"><?=$djjjm[a1]?></td>
		<td align="center"><?=$djjjm[a2]?></td>
		<td align="center"><?=$djjjm[a3]?></td>
		<td align="center"><?=$djjjm[a4]?></td>
		<td align="center"><?=$djjjm[a5]?></td>
		<td align="center"><?=$djjjm[a6]?></td>
		<td align="center"><?=$djjjm[a7]?></td>
		<td align="center"><?=$djjjm[a8]?></td>
		<td align="center"><?=$djjjm[a9]?></td>
		<td align="center"><?=$djjjm[a10]?></td>
		<td align="center"><?=$djjjm[a11]?></td>
		<td align="center"><?=$djjjm[a12]?></td>
<?
}
}else{
for($i=1;$i<13;$i++) {
?>
		<td align="center" height="35"></td>
<?
}
}
?>
	</tr>
<?
}
?>
	<tr>
		<td align="center"><a href="jang_print.php?date=<?=$date?>" target="_BLANK" class="view1_button">인쇄</a></td>
		<td colspan="11"></td>
		<td align="center" colspan="2"><a href="#toptxx" class="view1_button">맨 위로</a></td>
	</tr>
</table>
<?
}
?>
<?
include "foot.php";
?>
