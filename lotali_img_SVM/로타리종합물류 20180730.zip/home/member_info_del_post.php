<?
include "lib.php";
include "head.php";

$query = "delete from min_board_member where no='$no'";
mysql_query($query, $connect);
?>
<script>
  location.href='member_info.php';
</script>
