<?
include "lib.php";
include "head.php";

$query = "delete from min_board_info_plus where no='$no'";
mysql_query($query, $connect);
?>
<script>
  location.href='company_info.php?onon=<?=$onon?>&page=<?=$page?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>#<?=$onon?>';
</script>
