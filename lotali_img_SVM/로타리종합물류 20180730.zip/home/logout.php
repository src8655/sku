<?
session_start();

unset($_SESSION["user_id"]);
unset($_SESSION["password"]);
?>
<script> 
  location.href='index.php'; 
</script>
