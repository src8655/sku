<?
include "lib.php";
include "head.php";

$q = "select * from min_board_com_mon where no='1'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);
?>
<script language="JavaScript" type="text/javascript" src="/alditor/alditor.js"></script>

	 <div style="width:100%;margin:0px;text-align:center;overflow:hidden;">
	 	<a href="http://로타리종합물류.com/home/com_mon_print.php" target="_BLANK" id="calopl">운임표 인쇄</a>
	 </div>
	 
	 <form action="com_mon_edit.php" method="post">
    <div style="width:100%;overflow:hidden;">
      <input type="submit" value="저장하기" style="float:right;font-weight:bold;width:100%;color:#000000;line-height:33px;border:1px solid #c6c6c6;background:none;padding:0px;margin:0px;font-size:15px;" />
    </div>
    <div id="jk_ed" style="text-align:center;overflow:hidden;">
      <textarea name="memos" style="width:99%;height:800px;"><?=$d[memos]?></textarea>
    </div>
  </form>


<?
include "foot.php";
?>
