<?
include "lib.php";
include "head2.php";

$qm = "select * from min_board_el where no='$el'";
$rm = mysql_query($qm, $connect);
$dm = mysql_fetch_array($rm);

$allcount = selectc("min_board_el_d","where el='$el'");

$query = "select * from min_board_el_d where el='$el' order by no asc";
$result = mysql_query($query, $connect);
?>
<script defer>
function prints() {
factory.printing.leftMargin = "13.0";
factory.printing.topMargin = "13.0";
factory.printing.rightMargin = "13.0";
factory.printing.bottomMargin = "13.0";
factory.printing.header="";
factory.printing.footer="";
factory.printing.portrait=false;
factory.printing.Print(true);
}
function printshide() {
	pppl.style.display = "none";
}
</script>
<a href="#" onclick="printshide();prints();" id="pppl" style="display:block;width:100px;border:1px solid #676767;text-align:center;font-size:15px;margin:0 auto;margin-bottom:10px;padding:10px;"><img src="./images/print_io.jpg" style="border:0px;" /><br />인쇄하기<br /><span style="font-size:12px;color:red;">(페이지 자동조절)</span></a>
<object id="factory" viewastext style="display:none" classid="clsid:1663ed61-23eb-11d2-b92f-008048fdd814" codebase="./adr/smsx.cab#Version=6,3,436,14"></object>
<table cellpadding="8" cellspacing="0" border="0" style="margin:0 auto;" width="1050px">
	<tr>
		<th style="font-size:35px;font-weight:bold;">일&nbsp;&nbsp;일&nbsp;&nbsp;일&nbsp;&nbsp;지</th>
	</tr>
	<tr>
		<td align="right" style="font-size:20px;font-weight:bold;">
			<?=$dm[date]?> <?=$dm[yos]?>
			<span style="color:red;"><?=$allcount?></span>건
		</td>
	</tr>
</table>
<table cellpadding="8" cellspacing="0" id="print_te" style="font-size:17px;">
<col width="70" />
<col width="130" />
<col width="130" />
<col width="110" />
<col width="100" />
<col width="160" />
<col width="100" />
<col width="130" />
<col width="150" />
	<tr>
		<th>번호</th>
		<th>출발지</th>
		<th>도착지</th>
		<th>차량</th>
		<th>차량번호</th>
		<th>핸드폰번호</th>
		<th>성명</th>
		<th>금액</th>
		<th>비고</th>
	</tr>
<?
$cnt = 1;
while($data = mysql_fetch_array($result)) {
$datas = $data[money]*1000;
?>
	<tr>
		<td align="center"><?=$cnt?></td>
		<td align="center"><?=$data[chu]?></td>
		<td align="center"><?=$data[ddo]?></td>
		<td align="center"><?=$data[car]?></td>
		<td align="center"><?=$data[number]?></td>
		<td align="center"><?=$data[phone]?></td>
		<td align="center"><?=$data[name]?></td>
		<td align="right"><?=number_format($datas)?></td>
		<td align="center"><?=$data[memo]?></td>
	</tr>
<?
$cnt += 1;
}
?>
</table>
<?
include "foot2.php";
?>
