<?
define('FPDF_FONTPATH','./mpdf/font/');  
require_once './mpdf/mpdf.php';
 
// 함수의 원형 : function mPDF($mode='',$format='A4',$default_font_size=0,$default_font='',$mgl=15,$mgr=15,$mgt=16,$mgb=16,$mgh=9,$mgf=9, $orientation='P')
$pdf = new mPDF('ko');

ob_start(); 
?>
<?
include "lib.php";
include "head2.php";

if($Search_mode) {
	if($Search_mode == "1") $temp = "name";
	if($Search_mode == "2") $temp = "number";
	if($Search_mode == "3") $temp = "memo";
	
	$where = "where $temp like '%$Search_text%'";
}else{
$where = "";
}

$eheight = "25px";

$qgye = "select * from min_board_gye $where";
$rgye = mysql_query($qgye, $connect);
$dgye = mysql_num_rows($rgye);

$query = "select * from min_board_gye $where order by name asc";
$result = mysql_query($query, $connect);
?>
<table cellpadding="3" cellspacing="0" id="print_a" style="margin-bottom:10px; font-size:15px;font-weight:bold;">
<col width="100" />
<col width="100" />
<col width="100" />
<col width="100" />
<col width="200" />
<col width="100" />
	<tr>
		<th colspan="6" height="<?=$eheight?>">계좌번호 전체보기 - <span style="color:red"><?=$dgye?></span>
		</th>
	</tr>
	<tr>
		<th height="<?=$eheight?>" width="80">위치</th>
		<th width="70">이름</th>
		<th width="70">차량번호</th>
		<th width="80">은행</th>
		<th width="200">계좌번호</th>
		<th width="80">메모</th>
	</tr>
<?
while($data = mysql_fetch_array($result)) {
?>
	<tr>
		<td align="center" height="<?=$eheight?>">
			<? if($data[company] == 1) {?>
				5t 기준
			<? }?>
			<? if($data[company] == 2) {?>
				1t~3.5t
			<? }?>
			<? if($data[company] == 3) {?>
				외주차
			<? }?>
			<? if($data[company] == 6) {?>
				거래처
			<? }?>
		</td>
		<td align="center"><?=$data[name]?></td>
		<td align="center"><?=$data[number]?></td>
		<td align="center"><span style="font-weight:bold;"><?=$data[bank]?></span></td>
		<td align="left"><span style="font-weight:bold;"><?=$data[gye]?></span></td>
		<td align="center"><?=$data[memo]?></td>
	</tr>
<?
}
?>
</table>
<?
include "foot2.php";
?>

<?
$html=ob_get_contents(); 
ob_end_clean(); 
$html = iconv("UTF-8","UTF-8",$html);
$pdf->SetTopMargin(25);
$pdf->Bookmark("로타리장부",0);
// $pdf->SetDisplayMode('fullpage');   // pdf가 열릴때 창크기에 맞게 보여지도록 함. 이부분이 주석처리되거나 삭제되면 창크기에 맞춰지지 않고 pdf Viewer의 설정을 따르게됨
$pdf->WriteHTML($html);
$pdf->Output();     // 웹상에서 열림
?>
