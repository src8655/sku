<?
include "lib.php";
include "head.php";

$qeps = "select * from min_board_ep where olddate='$olddate'";
$reps = mysql_query($qeps, $connect);
$deps = mysql_num_rows($reps);
?>
<table cellpadding="5" cellspacing="1" width="1000px" id="write1_table" border="0" style="margin-bottom:10px;font-family:'Arial';">
<col width="200" />
<col width="600" />
<col width="200" />
  <tr>
    <td><a href="index.php?olddate=<?=$olddate?>" class="view1_button">뒤로가기</a></td>
    <th style="font-size:25px;">
			<?=$cf[date]?> 입금현황  - <span style="color:red;font-family:'Arial';"><?=$deps?></span>
    </th>
    <td>
      <a href="#bottomtxx" class="view1_button">맨 아래로</a>
    </td>
  </tr>
</table>
<table cellpadding="3" cellspacing="1" width="1000px" id="write1_table" border="0" style="margin-bottom:10px;font-family:'Arial';font-size:15px;">
<col width="130">
<col width="100">
<col width="200">
<col width="100">
<col width="100">
<col width="110">
<col width="110">
<col width="60">
<col width="60">
	<tr>
		<th>상호</th>
		<th>발행 총금액</th>
		<th>전자세금&일세금발행</th>
		<th>공급가액</th>
		<th>세액</th>
		<th>입금확인</th>
		<th>메모</th>
		<th colspan="2">관리</th>
	</tr>
<?
$tal1 = 0;
$tal2 = 0;


$qmmeq211 = "select count(*) from min_board_ep where olddate='$olddate' and orders='11'";
$qmmer211 = mysql_query($qmmeq211, $connect);
$qmmed211 = mysql_fetch_array($qmmer211);
if($qmmed211[0] == 0) {
}else{
?>
	<tr>
		<th colspan="9">담터</th>
	</tr>
<?
$qep211 = "select * from min_board_ep where olddate='$olddate' and orders='11' order by name asc";
$rep211 = mysql_query($qep211, $connect);
while($dep211 = mysql_fetch_array($rep211)) {
if($dep211[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep211[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
	<tr id="qq">
		<th <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?> id="sdf"><?=$dep211[name]?></th>
		<td <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><?=number_format($dep211[money])?><? }else{?><?=number_format($dep211[money]+$dep211[moneys])?><? }?></td>
		<td <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?> align="center"><?=$depmom?> <?=$depmom2?></th>
		<td <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?> align="right"><?=number_format($dep211[money])?></td>
		<td <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><? }else{?><?=number_format($dep211[moneys])?><? }?></td>
		<td align="center" <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?>><? if($dep211[date]) {if($dep211[date2]) {?><?=$dep211[date]?>월<?=$dep211[date2]?>일 입금<? }}?></td>
		<td align="center" <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?>><?=$dep211[memo]?></td>
		<td align="center" <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?>><a href="ep_edit.php?no=<?=$dep211[no]?>&olddate=<?=$olddate?>" class="view1_button">수정</a></td>
		<td align="center" <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?>><a href="ep_del.php?no=<?=$dep211[no]?>&olddate=<?=$olddate?>" class="view1_button">삭제</a></td>
	</tr>
<?
$tal1 += $dep211[money];
if($depmom||$depmom2)
$tal2 += $dep211[moneys];


}}
?>
<?
$qmmeq2 = "select count(*) from min_board_ep where olddate='$olddate' and orders='1'";
$qmmer2 = mysql_query($qmmeq2, $connect);
$qmmed2 = mysql_fetch_array($qmmer2);
if($qmmed2[0] == 0) {
}else{
?>
	<tr>
		<th colspan="9">한달결제</th>
	</tr>
<?
$qep2 = "select * from min_board_ep where olddate='$olddate' and orders='1' order by name asc";
$rep2 = mysql_query($qep2, $connect);
while($dep2 = mysql_fetch_array($rep2)) {
if($dep2[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep2[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
	<tr id="qq">
		<th <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?> id="sdf"><?=$dep2[name]?></th>
		<td <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><?=number_format($dep2[money])?><? }else{?><?=number_format($dep2[money]+$dep2[moneys])?><? }?></td>
		<td <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?> align="center"><?=$depmom?> <?=$depmom2?></th>
		<td <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?> align="right"><?=number_format($dep2[money])?></td>
		<td <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><? }else{?><?=number_format($dep2[moneys])?><? }?></td>
		<td align="center" <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?>><? if($dep2[date]) {if($dep2[date2]) {?><?=$dep2[date]?>월<?=$dep2[date2]?>일 입금<? }}?></td>
		<td align="center" <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?>><?=$dep2[memo]?></td>
		<td align="center" <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?>><a href="ep_edit.php?no=<?=$dep2[no]?>&olddate=<?=$olddate?>" class="view1_button">수정</a></td>
		<td align="center" <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?>><a href="ep_del.php?no=<?=$dep2[no]?>&olddate=<?=$olddate?>" class="view1_button">삭제</a></td>
	</tr>
<?
$tal1 += $dep2[money];
if($depmom||$depmom2)
$tal2 += $dep2[moneys];
}}
?>
<?
$qmmeq22 = "select count(*) from min_board_ep where olddate='$olddate' and orders='2'";
$qmmer22 = mysql_query($qmmeq22, $connect);
$qmmed22 = mysql_fetch_array($qmmer22);
if($qmmed22[0] == 0) {
}else{
?>
	<tr>
		<th colspan="9">그때그때결제</th>
	</tr>
<?
$qep22 = "select * from min_board_ep where olddate='$olddate' and orders='2' order by name asc";
$rep22 = mysql_query($qep22, $connect);
while($dep22 = mysql_fetch_array($rep22)) {
if($dep22[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep22[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
	<tr id="qq">
		<th <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?> id="sdf"><?=$dep22[name]?></th>
		<td <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><?=number_format($dep22[money])?><? }else{?><?=number_format($dep22[money]+$dep22[moneys])?><? }?></td>
		<td <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?> align="center"><?=$depmom?> <?=$depmom2?></th>
		<td <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?> align="right"><?=number_format($dep22[money])?></td>
		<td <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><? }else{?><?=number_format($dep22[moneys])?><? }?></td>
		<td align="center" <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?>><? if($dep22[date]) {if($dep22[date2]) {?><?=$dep22[date]?>월<?=$dep22[date2]?>일 입금<? }}?></td>
		<td align="center" <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?>><?=$dep22[memo]?></td>
		<td align="center" <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?>><a href="ep_edit.php?no=<?=$dep22[no]?>&olddate=<?=$olddate?>" class="view1_button">수정</a></td>
		<td align="center" <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?>><a href="ep_del.php?no=<?=$dep22[no]?>&olddate=<?=$olddate?>" class="view1_button">삭제</a></td>
	</tr>
<?
$tal1 += $dep22[money];
if($depmom||$depmom2)
$tal2 += $dep22[moneys];
}}
?>
<?
$qmmeq23 = "select count(*) from min_board_ep where olddate='$olddate' and orders='3'";
$qmmer23 = mysql_query($qmmeq23, $connect);
$qmmed23 = mysql_fetch_array($qmmer23);
if($qmmed23[0] == 0) {
}else{
?>
	<tr>
		<th colspan="9">기사에게입금</th>
	</tr>
<?
$qep23 = "select * from min_board_ep where olddate='$olddate' and orders='3' order by name asc";
$rep23 = mysql_query($qep23, $connect);
while($dep23 = mysql_fetch_array($rep23)) {
if($dep23[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep23[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
	<tr id="qq">
		<th <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?> id="sdf"><?=$dep23[name]?></th>
		<td <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><?=number_format($dep23[money])?><? }else{?><?=number_format($dep23[money]+$dep23[moneys])?><? }?></td>
		<td <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?> align="center"><?=$depmom?> <?=$depmom2?></th>
		<td <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?> align="right"><?=number_format($dep23[money])?></td>
		<td <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><? }else{?><?=number_format($dep23[moneys])?><? }?></td>
		<td align="center" <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?>><? if($dep23[date]) {if($dep23[date2]) {?><?=$dep23[date]?>월<?=$dep23[date2]?>일 입금<? }}?></td>
		<td align="center" <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?>><?=$dep23[memo]?></td>
		<td align="center" <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?>><a href="ep_edit.php?no=<?=$dep23[no]?>&olddate=<?=$olddate?>" class="view1_button">수정</a></td>
		<td align="center" <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?>><a href="ep_del.php?no=<?=$dep23[no]?>&olddate=<?=$olddate?>" class="view1_button">삭제</a></td>
	</tr>
<?
$tal1 += $dep23[money];
if($depmom||$depmom2)
$tal2 += $dep23[moneys];
}}
?>
<?
$qmmeq20 = "select count(*) from min_board_ep where olddate='$olddate' and orders='0'";
$qmmer20 = mysql_query($qmmeq20, $connect);
$qmmed20 = mysql_fetch_array($qmmer20);
if($qmmed20[0] == 0) {
}else{
?>
	<tr>
		<th colspan="9">정렬 지정하지 않음</th>
	</tr>
<?
$qep20 = "select * from min_board_ep where olddate='$olddate' and orders='0' order by name asc";
$rep20 = mysql_query($qep20, $connect);
while($dep20 = mysql_fetch_array($rep20)) {
if($dep20[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep20[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
	<tr id="qq">
		<th <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?> id="sdf"><?=$dep20[name]?></th>
		<td <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><?=number_format($dep20[money])?><? }else{?><?=number_format($dep20[money]+$dep20[moneys])?><? }?></td>
		<td <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?> align="center"><?=$depmom?> <?=$depmom2?></th>
		<td <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?> align="right"><?=number_format($dep20[money])?></td>
		<td <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><? }else{?><?=number_format($dep20[moneys])?><? }?></td>
		<td align="center" <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?>><? if($dep20[date]) {if($dep20[date2]) {?><?=$dep20[date]?>월<?=$dep20[date2]?>일 입금<? }}?></td>
		<td align="center" <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?>><?=$dep20[memo]?></td>
		<td align="center" <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?>><a href="ep_edit.php?no=<?=$dep20[no]?>&olddate=<?=$olddate?>" class="view1_button">수정</a></td>
		<td align="center" <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?>><a href="ep_del.php?no=<?=$dep20[no]?>&olddate=<?=$olddate?>" class="view1_button">삭제</a></td>
	</tr>
<?
$tal1 += $dep20[money];
if($depmom||$depmom2)
$tal2 += $dep20[moneys];
}}
?>
	<tr id="qq">
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
	</tr>
	<tr id="qq">
		<td align="right">&nbsp;</td>
		<td align="right"><?=number_format($tal1+$tal2)?></td>
		<td align="right">&nbsp;</td>
		<td align="right"><?=number_format($tal1)?></td>
		<td align="right"><?=number_format($tal2)?></td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
	</tr>
<?
$qep3 = "select * from min_board_ep where olddate='$olddate'";
$rep3 = mysql_query($qep3, $connect);
$dep3 = mysql_num_rows($rep3);
if($dep3 == 0) {
?>
	<tr>
		<th colspan="9" style="background:yellow;">아직 입금한 회사가 없습니다.</th>
	</tr>
<?
}else{
?>
	<tr>
		<td colspan="9" style="background:yellow;">&nbsp;</td>
	</tr>
<?
}
$qeps6f = "2";
$qep6f = "select * from min_board_ep where olddate='$olddate' and company='$qeps6f'";
$rep6f = mysql_query($qep6f, $connect);
$dep6f = mysql_num_rows($rep6f);
$qeps6 = "1";
$qep6 = "select * from min_board_ep where olddate='$olddate' and company='$qeps6'";
$rep6 = mysql_query($qep6, $connect);
$dep6 = mysql_num_rows($rep6);
if(($dep6 != "0")&&($dep6f != "0")) {
}else{
  
  
  
//담터 갯수구하기
$adscounte1 = selectc("min_board_data2","where id='0' and olddate='$olddate'");
$adscounte2 = selectc("min_board_data2","where id='1' and olddate='$olddate'");
?>
<form action="ep_post.php">
	<tr>
		<th colspan="9">담터</th>
	</tr>
	<tr id="qq">
		<th>
			<select name="cominfo" style="width:95%;font-size:15px;border:1px solid #7F9DB9;">
				<? if($dep6==0){?><option value="<?=$olddate?>//1//담터//11"><? if($adscounte1 != 0){?>[미청구] <? }?>담터<? if($adscounte1 != 0){?> - <?=$adscounte1?><? }?></option><? }?>
				<? if($dep6f==0){?><option value="<?=$olddate?>//2//담터 FND(승주)//11"><? if($adscounte2 != 0){?>[미청구] <? }?>담터 FNB(승주)<? if($adscounte2 != 0){?> - <?=$adscounte2?><? }?></option><? }?>
			</select>
		</th>
		<td align="center">자동계산</td>
		<td align="center">전자세금 : <input type="checkbox" name="checks" value="2" /> / 일반세금 : <input type="checkbox" name="checks2" value="2" /></td>
		<td align="center"><input type="text" name="money" style="width:80px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /></td>
		<td align="center">자동계산</td>
		<td align="center">
			<input type="text" name="date2" style="width:25px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /> 월&nbsp;
			<input type="text" name="date3" style="width:25px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /> 일
		</td>
		<td align="center"><input type="text" name="memo" style="width:90px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /></td>
		<td align="center" colspan="2"><input type="submit" value="등록하기" class="view1_button" style="width:90%;"></td>
	</tr>
</form>
<?
}
?>
	<tr>
		<th colspan="9">한달결제</th>
	</tr>
<form action="ep_post.php">
	<tr id="qq">
		<th>
		<select name="cominfo" style="width:95%;font-size:15px;border:1px solid #7F9DB9;">
<?
$query = "select * from min_board_admin where orders='1' order by name asc";
$result = mysql_query($query, $connect);
while($data = mysql_fetch_array($result)) {
$qep1 = "select * from min_board_ep where olddate='$olddate' and company='$data[company]'";
$rep1 = mysql_query($qep1, $connect);
$dep1 = mysql_fetch_array($rep1);
if($dep1[no]) {
}else{
  
  
//1건이라도 있는 회사 찾기
$counr = mysql_query("select * from min_board_admin_count where company='$data[company]' and olddate='$olddate'",$connect);
$cound = mysql_fetch_array($counr);
  
//숨김회사 숨기기
$hides = selectc("min_board_admin_hide","where olddate='$_GET[olddate]' and company='$data[company]'");
if($hides!=0) continue;
?>
			<option value="<?=$olddate?>//<?=$data[company]?>//<?=$data[name]?>//1"><? if($cound[counts] != 0){?><span style="font-weight:bold;">[미청구] </span><? }?><?=$data[name]?><? if($cound[counts] != 0){?> - <?=$cound[counts]?><? }?></option>
<?
}}
?>
		</select>
		</th>
		<td align="center">자동계산</td>
		<td align="center">전자세금 : <input type="checkbox" name="checks" value="2" /> / 일반세금 : <input type="checkbox" name="checks2" value="2" /></td>
		<td align="center"><input type="text" name="money" style="width:80px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /></td>
		<td align="center">자동계산</td>
		<td align="center">
			<input type="text" name="date2" style="width:25px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /> 월&nbsp;
			<input type="text" name="date3" style="width:25px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /> 일
		</td>
		<td align="center"><input type="text" name="memo" style="width:90px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /></td>
		<td align="center" colspan="2"><input type="submit" value="등록하기" class="view1_button" style="width:90%;"></td>
	</tr>
</form>
	<tr>
		<th colspan="9">그때그때결제</th>
	</tr>
<form action="ep_post.php">
	<tr id="qq">
		<th>
			<select name="cominfo" style="width:95%;font-size:15px;border:1px solid #7F9DB9;">
<?
$query2 = "select * from min_board_admin where orders='2' order by name asc";
$result2 = mysql_query($query2, $connect);
while($data2 = mysql_fetch_array($result2)) {
$qep1 = "select * from min_board_ep where olddate='$olddate' and company='$data2[company]'";
$rep1 = mysql_query($qep1, $connect);
$dep1 = mysql_fetch_array($rep1);
if($dep1[no]) {
}else{
  
  
  
//1건이라도 있는 회사 찾기
$counr = mysql_query("select * from min_board_admin_count where company='$data2[company]' and olddate='$olddate'",$connect);
$cound = mysql_fetch_array($counr);


  //숨김회사 숨기기
$hides = selectc("min_board_admin_hide","where olddate='$_GET[olddate]' and company='$data2[company]'");
if($hides!=0) continue;
?>
				<option value="<?=$olddate?>//<?=$data2[company]?>//<?=$data2[name]?>//2"><?=$data2[name]?><? if($cound[counts] != 0){?> - <?=$cound[counts]?><? }?></option>
<?
}}
?>
			</select>
		</th>
		<td align="center">자동계산</td>
		<td align="center">전자세금 : <input type="checkbox" name="checks" value="2" /> / 일반세금 : <input type="checkbox" name="checks2" value="2" /></td>
		<td align="center"><input type="text" name="money" style="width:80px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /></td>
		<td align="center">자동계산</td>
		<td align="center">
			<input type="text" name="date2" style="width:25px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /> 월&nbsp;
			<input type="text" name="date3" style="width:25px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /> 일
		</td>
		<td align="center"><input type="text" name="memo" style="width:90px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /></td>
		<td align="center" colspan="2"><input type="submit" value="등록하기" class="view1_button" style="width:90%;"></td>
	</tr>
</form>
	<tr>
		<th colspan="9">기사에게입금</th>
	</tr>
<form action="ep_post.php">
	<tr id="qq">
		<th>
			<select name="cominfo" style="width:95%;font-size:15px;border:1px solid #7F9DB9;">
<?
$query3 = "select * from min_board_admin where orders='3' order by name asc";
$result3 = mysql_query($query3, $connect);
while($data3 = mysql_fetch_array($result3)) {
$qep1 = "select * from min_board_ep where olddate='$olddate' and company='$data3[company]'";
$rep1 = mysql_query($qep1, $connect);
$dep1 = mysql_fetch_array($rep1);
if($dep1[no]) {
}else{
  
  
  //1건이라도 있는 회사 찾기
$counr = mysql_query("select * from min_board_admin_count where company='$data3[company]' and olddate='$olddate'",$connect);
$cound = mysql_fetch_array($counr);
  //숨김회사 숨기기
$hides = selectc("min_board_admin_hide","where olddate='$_GET[olddate]' and company='$data3[company]'");
if($hides!=0) continue;
?>
				<option value="<?=$olddate?>//<?=$data3[company]?>//<?=$data3[name]?>//3"><?=$data3[name]?><? if($cound[counts] != 0){?> - <?=$cound[counts]?><? }?></option>
<?
}}
?>
			</select>
		</th>
		<td align="center">자동계산</td>
		<td align="center">전자세금 : <input type="checkbox" name="checks" value="2" /> / 일반세금 : <input type="checkbox" name="checks2" value="2" /></td>
		<td align="center"><input type="text" name="money" style="width:80px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /></td>
		<td align="center">자동계산</td>
		<td align="center">
			<input type="text" name="date2" style="width:25px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /> 월&nbsp;
			<input type="text" name="date3" style="width:25px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /> 일
		</td>
		<td align="center"><input type="text" name="memo" style="width:90px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /></td>
		<td align="center" colspan="2"><input type="submit" value="등록하기" class="view1_button" style="width:90%;"></td>
	</tr>
</form>
	<tr>
		<th colspan="9">정렬 지정하지 않음</th>
	</tr>
<form action="ep_post.php">
	<tr id="qq">
		<th>
			<select name="cominfo" style="width:95%;font-size:15px;border:1px solid #7F9DB9;">
<?
$query0 = "select * from min_board_admin where orders='0' order by name asc";
$result0 = mysql_query($query0, $connect);
while($data0 = mysql_fetch_array($result0)) {
$qep1 = "select * from min_board_ep where olddate='$olddate' and company='$data0[company]'";
$rep1 = mysql_query($qep1, $connect);
$dep1 = mysql_fetch_array($rep1);
if($dep1[no]) {
}else{
  
  
  //1건이라도 있는 회사 찾기
$counr = mysql_query("select * from min_board_admin_count where company='$data2[company]' and olddate='$olddate'",$connect);
$cound = mysql_fetch_array($counr);
  //숨김회사 숨기기
$hides = selectc("min_board_admin_hide","where olddate='$_GET[olddate]' and company='$data0[company]'");
if($hides!=0) continue;
?>
				<option value="<?=$olddate?>//<?=$data0[company]?>//<?=$data0[name]?>//0"><?=$data0[name]?><? if($cound[counts] != 0){?> - <?=$cound[counts]?><? }?></option>
<?
}}
?>
			</select>
		</th>
		<td align="center">자동계산</td>
		<td align="center">전자세금 : <input type="checkbox" name="checks" value="2" /> / 일반세금 : <input type="checkbox" name="checks2" value="2" /></td>
		<td align="center"><input type="text" name="money" style="width:80px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /></td>
		<td align="center">자동계산</td>
		<td align="center">
			<input type="text" name="date2" style="width:25px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /> 월&nbsp;
			<input type="text" name="date3" style="width:25px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /> 일
		</td>
		<td align="center"><input type="text" name="memo" style="width:90px;font-size:15px;padding:2px 0 2px 0;border:1px solid #7F9DB9;" /></td>
		<td align="center" colspan="2"><input type="submit" value="등록하기" class="view1_button" style="width:90%;"></td>
	</tr>
</form>
	<tr>
		<td colspan="9" style="padding:5px;">
    	<div style="float:left;width:10%;padding:0 6px 0 0;overflow:hidden;">
				<a href="epprint.php?olddate=<?=$olddate?>" target="_blank" class="view1_button">인쇄1</a>
			</div>
    	<div style="float:left;width:10%;padding:0 6px 0 0;overflow:hidden;">
				<a href="epprint_pdf.php?olddate=<?=$olddate?>" target="_blank" class="view1_button">인쇄2</a>
			</div>
    	<div style="float:right;width:20%;overflow:hidden;">
				<a href="#toptxx" class="view1_button">맨 위로</a>
			</div>
		</td>
	</tr>
</table>
<?
include "foot.php";
?>
