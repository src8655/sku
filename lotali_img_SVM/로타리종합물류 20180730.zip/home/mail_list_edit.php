<?
include "lib.php";
include "head.php";

$query = "select * from min_board_mail_list where no='$no'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<div id="mail_left">
	<h1>메일메뉴</h1>
	<ul>
		<li><a href="mail.php">메일쓰기</a></li>
		<li><a href="mail.php?sendmail=1">보낸메일함</a></li>
		<li><a href="mail_list.php">회사이메일목록</a></li>
	</ul>
</div>
<div class="mail_t">
	회사이메일수정 <span style="font-weight:normal;font-size:13px;">이메일을 수정하는 페이지 입니다.</span>
</div>
<form action="mail_list_edit_post.php">
<input type="hidden" name="no" value="<?=$data[no]?>" />
<table cellpadding="7" cellspacing="0" width="790px" id="write1_tablec" style="font-size:17px;float:right;">
<col width="90" />
<col width="280" />
<col width="280" />
<col width="70" />
<col width="70" />
	<tr>
		<th height="25">번호</th>
		<th>회사이름</th>
		<th>이메일</th>
	</tr>
	<tr>
		<td align="center" style="font-weight:bold;">수정</td>
		<td align="center"><input type="text" name="company" value="<?=$data[company]?>" style="width:98%;font-size:17px;border:1px solid #676767;" /></td>
		<td align="center"><input type="text" name="email" value="<?=$data[email]?>" style="width:98%;font-size:17px;border:1px solid #676767;" /></td>
	</tr>
	<tr>
		<td align="center"><a href="mail_list.php" class="view1_button">취소</a></td>
		<td align="center" colspan="2"><input type="submit" value="수정하기" class="view1_button" style="border:1px solid #676767;padding:5px 10px 5px 10px;width:100px;font-size:17px;" /></td>
	</tr>
</table>
</form>
<?
include "foot.php";
?>
