<?
include "lib.php";
include "head.php";

$query = "insert into min_board_el_d(chu,ddo,car,number,phone,name,money,memo,el)
					values('$_REQUEST[date2]','$_REQUEST[ddo]','$_REQUEST[car]','$_REQUEST[number]','$_REQUEST[phone]','$_REQUEST[name]','$_REQUEST[money]','$_REQUEST[memo]','$_REQUEST[el]')";
mysql_query($query, $connect);
?>
<script>
	location.href="el_d.php?el=<?=$el?>";
</script>
<?
include "foot.php";
?>