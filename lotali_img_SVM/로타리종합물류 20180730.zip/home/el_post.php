<?
include "lib.php";
include "head.php";

$_REQUEST[datesw] = $date1w."년 ".$date2w."월 ".$date3w."일 ";
$_REQUEST[datesw2] = $date1w.$date2w.$date3w;

$qsa = "select count(*) from min_board_el where date2='$_REQUEST[datesw2]'";
$rsa = mysql_query($qsa, $connect);
$dsa = mysql_fetch_array($rsa);
$lsa = $dsa[0];

if($lsa != 0) {
	echo("
		<script>
			window.alert('이미 존재하는 날짜입니다.')
			history.go(-1)
		</script>
	");
	exit;
}

$query = "insert into min_board_el(date,date2,yos)
				values('$_REQUEST[datesw]','$_REQUEST[datesw2]','$_REQUEST[date5w]')";
mysql_query($query, $connect);
?>
<script>
	location.href="el.php";
</script>
<?
include "foot.php";
?>