<?
include "lib.php";
include "head.php";

$query = "select * from min_board_gye where no='$no'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<form action="gye_edit_post.php">
<input type="hidden" name="no" value="<?=$no?>" />
<input type="hidden" name="company" value="<?=$company?>" />
<table cellpadding="7" cellspacing="1" width="1000px" id="write1_table" border="0" style="margin-bottom:10px;">
<col width="150" />
<col width="150" />
<col width="150" />
<col width="250" />
<col width="150" />
	<tr>
		<th>이름</th>
		<th>차량번호</th>
		<th>은행</th>
		<th>계좌번호</th>
		<th>메모</th>
	</tr>
	<tr>
		<td align="center"><input type="text" name="name" value="<?=$data[name]?>" style="font-size:15px;padding:2px 0 2px 0;width:125px;" /></td>
		<td align="center"><input type="text" name="number" value="<?=$data[number]?>" style="font-size:15px;padding:2px 0 2px 0;width:125px;" /></td>
		<td align="center"><input type="text" name="bank" value="<?=$data[bank]?>" style="font-size:15px;padding:2px 0 2px 0;width:125px;" /></td>
		<td align="center"><input type="text" name="gye" value="<?=$data[gye]?>" style="font-size:15px;padding:2px 0 2px 0;width:220px;" /></td>
		<td align="center"><input type="text" name="memo" value="<?=$data[memo]?>" style="font-size:15px;padding:2px 0 2px 0;width:125px;" /></td>
	</tr>
	<tr>
		<td align="center"><a href="gye.php?company=<?=$company?>" class="view1_button">취소</a></td>
		<td align="center" colspan="4"><input type="submit" value="수정하기" class="view1_button" /></td>
	</tr>
</table>
</form>
<?
include "foot.php";
?>
