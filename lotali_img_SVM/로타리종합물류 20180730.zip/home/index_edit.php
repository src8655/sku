<?
include "lib.php";
include "head.php";

$query = "select * from min_board_admin order by name asc";
$result = mysql_query($query, $connect);
?>
<table cellpadding="7" cellspacing="1" width="500px" id="write1_table" border="0" style="margin-bottom:10px;">
  <tr>
    <td><a href="index.php?olddate=<?=$olddate?>" class="view1_button">뒤로가기</a></td>
  </tr>
</table>
<table cellpadding="7" cellspacing="1" width="500px" id="write1_table" border="0" style="margin-bottom:10px; font-size:15px;">
<col width="200" />
<col width="200" />
<col width="100" />
  <tr>
    <th colspan="3"><span style="color:green;font-size:12px;">!경고! 회사명을 수정하시면 월별 모든 장부의 회사명도 같이 변경됩니다</span></th>
  </tr>
  <tr>
    <th>회사명</th>
    <th>정렬</th>
    <th>수정</th>
  </tr>
<?
while($data = mysql_fetch_array($result)) {
?>
  <tr>
    <td align="center"><?=$data[name]?></td>
    <td align="center">[<? if($data[orders] == 0) {?>정렬 지정하지 않음<? }?><? if($data[orders] == 1) {?>한달결제<? }?><? if($data[orders] == 2) {?>그때그때결제<? }?><? if($data[orders] == 3) {?>기사에게입금<? }?>]</td>
    <td align="center"><a href="index_edit2.php?olddate=<?=$olddate?>&company=<?=$data[company]?>" class="view1_button">수정</a></td>
  </tr>
<?
}
?>
</table>
<?
include "foot.php";
?>
