<?
include "lib.php";
include "head.php";

$_REQUEST[checks] = "2";
$d1 = date("m");
$d2 = date("d");
$d3 = date("h");
$d4 = date("i");

$_REQUEST[checksdate] = $d1."-".$d2." ".$d3.":".$d4;

$query = "update min_board_memo set
          checks='$_REQUEST[checks]',
          checksdate='$_REQUEST[checksdate]' where no='$no'";
mysql_query($query, $connect);
?>
<script>
  location.href='memo_list.php?olddate=<?=$olddate?>';
</script>
