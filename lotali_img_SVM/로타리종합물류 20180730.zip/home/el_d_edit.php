<?
include "lib.php";
include "head3.php";

$query = "select * from min_board_el_d where el='$el' and no='$no'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<form action="el_d_post.php" method="post" id="writep" name="writepp">
<input type="hidden" name="el" value="<?=$el?>" />
<input type="hidden" name="no" value="<?=$no?>" />
<table cellpadding="5" cellspacing="1" id="write1_table" border="0" width="1200px" style="font-size:15px;font-family:'Arial';">
<col width="70" />
<col width="130" />
<col width="130" />
<col width="110" />
<col width="100" />
<col width="150" />
<col width="100" />
<col width="140" />
<col width="150" />
<col width="60" />
<col width="60" />
	<tr>
		<th>번호</th>
		<th>출발지</th>
		<th>도착지</th>
		<th>차량</th>
		<th>차량번호</th>
		<th>핸드폰번호</th>
		<th>성명</th>
		<th>금액</th>
		<th>비고</th>
	</tr>
	<tr>
		<th>작성</th>
		<td align="center"><input type="text" name="date2" value="<?=$data[chu]?>" style="font-size:15px;padding:2px 0 2px 0;width:110px;border:1px solid #7F9DB9;" /></td>
		<td align="center"><input type="text" name="ddo" value="<?=$data[ddo]?>" style="font-size:15px;padding:2px 0 2px 0;width:110px;border:1px solid #7F9DB9;" /></td>
		<td align="center"><input type="text" name="car" value="<?=$data[car]?>" style="font-size:15px;padding:2px 0 2px 0;width:90px;border:1px solid #7F9DB9;" /></td>
		<td align="center"><input type="text" name="number" value="<?=$data[number]?>" style="font-size:15px;padding:2px 0 2px 0;width:80px;border:1px solid #7F9DB9;" /></td>
		<td align="center"><input type="text" name="phone" value="<?=$data[phone]?>" style="font-size:15px;padding:2px 0 2px 0;width:130px;border:1px solid #7F9DB9;" /></td>
		<td align="center"><input type="text" name="name" value="<?=$data[name]?>" style="font-size:15px;padding:2px 0 2px 0;width:80px;border:1px solid #7F9DB9;" /></td>
		<td align="right"><input type="text" name="money" value="<?=$data[money]?>" style="font-size:15px;padding:2px 0 2px 0;width:50px;border:1px solid #7F9DB9;" /> ,000</td>
		<td align="center"><input type="text" name="memo" value="<?=$data[memo]?>" style="font-size:15px;padding:2px 0 2px 0;width:130px;border:1px solid #7F9DB9;" /></td>
	</tr>
	<tr>
		<td align="center"><a href="el_d.php?el=<?=$el?>" class="view1_button">취소</a></td>
		<td align="center" colspan="8"><input type="submit" value="수정하기" class="view1_button" style="width:12%;" /></td>
	</tr>
</table>
</form>
<?
include "foot3.php";
?>