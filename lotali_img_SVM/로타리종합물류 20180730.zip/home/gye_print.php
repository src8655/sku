<?
include "lib.php";
include "head2.php";

if($Search_mode) {
	if($Search_mode == "1") $temp = "name";
	if($Search_mode == "2") $temp = "number";
	if($Search_mode == "3") $temp = "memo";
	
	$where = "where company='$company' and $temp like '%$Search_text%'";
}else{
$where = "where company='$company'";
}

$eheight = "25px";

$qgye = "select * from min_board_gye $where";
$rgye = mysql_query($qgye, $connect);
$dgye = mysql_num_rows($rgye);

$query = "select * from min_board_gye $where order by name asc";
$result = mysql_query($query, $connect);
?>
<script defer>
function prints() {
factory.printing.leftMargin = "25.0";
factory.printing.topMargin = "25.0";
factory.printing.rightMargin = "25.0";
factory.printing.bottomMargin = "15.0";
factory.printing.header="";
factory.printing.footer="";
factory.printing.portrait=true;
factory.printing.Print(true);
}
function printshide() {
	pppl.style.display = "none";
}
</script>
<a href="#" onclick="printshide();prints();" id="pppl" style="display:block;width:100px;border:1px solid #676767;text-align:center;font-size:15px;margin:0 auto;margin-bottom:10px;padding:10px;"><img src="./images/print_io.jpg" style="border:0px;" /><br />인쇄하기<br /><span style="font-size:12px;color:red;">(페이지 자동조절)</span></a>
<object id="factory" viewastext style="display:none" classid="clsid:1663ed61-23eb-11d2-b92f-008048fdd814" codebase="./adr/smsx.cab#Version=6,3,436,14"></object>
<table cellpadding="3" cellspacing="0" id="print_te" style="margin-bottom:10px; font-size:18px;font-weight:bold;">
<col width="100" />
<col width="100" />
<col width="100" />
<col width="250" />
<col width="100" />
	<tr>
		<th colspan="5" height="<?=$eheight?>">
			<? if($company == "1") {?>
			계좌번호 5t 기준
			<? }else{ if($company == "2") {?>
			계좌번호 1t~3.5t
			<? }else{ if($company == "3") {?>
			계좌번호 외주차
			<? }else{ if($company == "6") {?>
			계좌번호 거래처
			<? }}}}?>
			 - <span style="color:red"><?=$dgye?></span>
		</th>
	</tr>
	<tr>
		<th height="<?=$eheight?>">이름</th>
		<th>차량번호</th>
		<th>은행</th>
		<th>계좌번호</th>
		<th>메모</th>
	</tr>
<?
while($data = mysql_fetch_array($result)) {
?>
	<tr>
		<td align="center" height="<?=$eheight?>"><?=$data[name]?></td>
		<td align="center"><?=$data[number]?></td>
		<td align="center"><span style="font-weight:bold;"><?=$data[bank]?></span></td>
		<td align="left"><span style="font-weight:bold;"><?=$data[gye]?></span></td>
		<td align="center"><?=$data[memo]?></td>
	</tr>
<?
}
?>
</table>
<?
include "foot2.php";
?>
