<?
include "lib.php";
include "head.php";

$query = "select * from min_board_jang_member where no='$no'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<table cellpadding="5" cellspacing="1" width="500px" id="write1_table" border="0" style="margin-bottom:10px;font-size:13px;">
	<tr>
		<td><a href="jang_edit.php?date=<?=$date?>" class="view1_button">뒤로가기</a></td>
	</tr>
</table>
<form action="jang_edit_post.php">
<input type="hidden" name="no" value="<?=$no?>" />
<input type="hidden" name="date" value="<?=$date?>" />
<table cellpadding="5" cellspacing="1" width="500px" id="write1_table" border="0" style="margin-bottom:10px;font-size:13px;">
<col width="200" />
<col width="200" />
<col width="100" />
	<tr>
		<th colspan="3" style="color:green;">회원 수정모드</th>
	</tr>
	<tr>
		<th>이름</th>
		<th>차량번호</th>
		<th>관리</th>
	</tr>
	<tr>
		<td align="center"><input type="text" name="name" value="<?=$data[name]?>" /></td>
		<td align="center"><input type="text" name="number" value="<?=$data[number]?>" /></td>
		<td align="center"><input type="submit" value="수정하기" class="view1_button" style="width:90%;" /></td>
	</tr>
</table>
</form>
<?
include "foot.php";
?>
