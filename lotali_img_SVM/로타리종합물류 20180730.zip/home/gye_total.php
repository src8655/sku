<?
include "lib.php";
include "head.php";

if($Search_mode) {
	if($Search_mode == "1") $temp = "name";
	if($Search_mode == "2") $temp = "number";
	if($Search_mode == "3") $temp = "memo";
	
	$where = "where $temp like '%$Search_text%'";
}else{
$where = "";
}

$qgye = "select * from min_board_gye $where";
$rgye = mysql_query($qgye, $connect);
$dgye = mysql_num_rows($rgye);

$query = "select * from min_board_gye $where order by name asc";
$result = mysql_query($query, $connect);
?>
<form action="<?=$PHP_SELF?>" name="searchtotal" id="writep">
<table cellpadding="7" cellspacing="1" width="1000px" id="write1_table" border="0" style="margin-bottom:10px;">
<col width="200" />
<col width="600" />
<col width="200" />
<input type="hidden" name="company" value="<?=$company?>" />
	<tr>
		<td><a href="index.php" class="view1_button">뒤로가기</a></td>
		<td align="center">
			<select name="Search_mode" id="searchmode">
				<option value="1" <? if($Search_mode == "1") {?>selected<? }?>>이름</option>
				<option value="2" <? if($Search_mode == "2") {?>selected<? }?>>차량번호</option>
				<option value="3" <? if($Search_mode == "3") {?>selected<? }?>>메모</option>
			</select>
			<input type="text" name="Search_text" value="<?=$Search_text?>" id="searchtext" size="30" />
			<input type="submit" value="검색" id="searchbutton" />
		</td>
		<td><a href="#bottomtxx" class="view1_button">맨아래로</a></td>
	</tr>
</table>
</form>
<table cellpadding="7" cellspacing="1" width="1000px" id="write1_table" border="0" style="margin-bottom:10px; font-size:18px;font-family:'Arial';font-weight:bold;">
<col width="130" />
<col width="150" />
<col width="150" />
<col width="120" />
<col width="250" />
<col width="150" />
	<tr>
		<th colspan="6">계좌번호 전체보기 - <span style="color:red"><?=$dgye?></span>
		</th>
	</tr>
	<tr>
		<th>위치</th>
		<th>이름</th>
		<th>차량번호</th>
		<th>은행</th>
		<th>계좌번호</th>
		<th>메모</th>
	</tr>
<?
while($data = mysql_fetch_array($result)) {
?>
	<tr id="qq">
		<td align="center">
			<? if($data[company] == 1) {?>
				5t 기준
			<? }?>
			<? if($data[company] == 2) {?>
				1t~3.5t
			<? }?>
			<? if($data[company] == 3) {?>
				외주차
			<? }?>
			<? if($data[company] == 6) {?>
				거래처
			<? }?>
		</td>
		<td align="center"><?=$data[name]?></td>
		<td align="center"><?=$data[number]?></td>
		<td align="center"><span style="font-weight:bold;"><?=$data[bank]?></span></td>
		<td align="left"><span style="font-weight:bold;"><?=$data[gye]?></span></td>
		<td align="center"><?=$data[memo]?></td>
	</tr>
<?
}
?>
	<tr>
		<td colspan="6">
    	<div style="float:left;width:10%;padding:0 6px 0 0;overflow:hidden;">
				<form action="gye_total_print.php" target="_blank">
					<input type="hidden" name="Search_text" value="<?=$Search_text?>" />
					<input type="hidden" name="Search_mode" value="<?=$Search_mode?>" />
					<input type="submit" value="인쇄1" class="view1_button" style="width:100%;" />
				</form>
			</div>
    	<div style="float:left;width:10%;padding:0 6px 0 0;overflow:hidden;">
				<form action="gye_total_print_pdf.php" target="_blank">
					<input type="hidden" name="Search_text" value="<?=$Search_text?>" />
					<input type="hidden" name="Search_mode" value="<?=$Search_mode?>" />
					<input type="submit" value="인쇄2" class="view1_button" style="width:100%;" />
				</form>
			</div>
    	<div style="float:right;width:20%;overflow:hidden;">
				<a href="#toptxx" class="view1_button">맨 위로</a>
			</div>
		</td>
	</tr>
</table>
<?
include "foot.php";
?>
