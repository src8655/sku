<?
include "lib.php";
include "head.php";

$query = "update min_board_info set
          company='$_REQUEST[company]',
          addr='$_REQUEST[addr]',
          tel1='$_REQUEST[tel1]',
          tel2='$_REQUEST[tel2]',
          tel3='$_REQUEST[tel3]',
          fax1='$_REQUEST[fax1]',
          fax2='$_REQUEST[fax2]',
          fax3='$_REQUEST[fax3]',
          email='$_REQUEST[email]',
          name='$_REQUEST[name]',
          phone1='$_REQUEST[phone1]',
          phone2='$_REQUEST[phone2]',
          phone3='$_REQUEST[phone3]',
          memo='$_REQUEST[memo]',
          addr2='$_REQUEST[addr2]',
          addrnum='$_REQUEST[addrnum]' where no='$no'";
mysql_query($query, $connect);
?>
<script>
  location.href='company_info.php?onon=<?=$no?>&page=<?=$page?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>#<?=$no?>';
</script>
