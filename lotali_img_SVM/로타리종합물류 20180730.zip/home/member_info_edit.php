<?
include "lib.php";
include "head.php";

$query = "select * from min_board_member where no='$no'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<form action="member_info_edit_post.php">
<input type="hidden" name="no" value="<?=$no?>" />
<input type="hidden" name="page" value="<?=$page?>" />
<input type="hidden" name="Search_mode" value="<?=$Search_mode?>" />
<input type="hidden" name="Search_text" value="<?=$Search_text?>" />
<div class="box" id="companyboxr">
  <h1>수정하기</h1>
 	<p>
 		<span style="font-weight:bold;">이름</span> : <input type="text" name="name" value="<?=$data[name]?>" size="13" />
 	</p>
 	<p>
    <span style="font-weight:bold;">전화번호</span> : <input type="text" name="phone1" value="<?=$data[phone1]?>" size="5">-<input type="text" name="phone2" value="<?=$data[phone2]?>" size="5">-<input type="text" name="phone3" value="<?=$data[phone3]?>" size="5">
 	</p>
 	<p>
    <span style="font-weight:bold;">메모</span> : <input type="text" name="memo" value="<?=$data[memo]?>" size="50" />
 	</p>
 	<p>
    <span style="font-weight:bold;">이메일</span> : <input type="text" name="email" value="<?=$data[email]?>" size="50" />
 	</p>
 	<p>
    <span style="font-weight:bold;">차량번호</span> : <input type="text" name="car_num" value="<?=$data[car_num]?>" size="13" />
 	</p>
 	<p>
    <span style="font-weight:bold;">차량</span> : 
    <select name="ton_no" style="padding:2px 0 2px 0;">
      <option value="">없음</option>
      <option value="1" <? if($data[ton_no] == "1") {?>selected<? }?>>오토바이</option>
      <option value="2" <? if($data[ton_no] == "2") {?>selected<? }?>>다마스/라보</option>
      <option value="3" <? if($data[ton_no] == "3") {?>selected<? }?>>1톤</option>
      <option value="4" <? if($data[ton_no] == "4") {?>selected<? }?>>1.4톤</option>
      <option value="5" <? if($data[ton_no] == "5") {?>selected<? }?>>2.5톤</option>
      <option value="6" <? if($data[ton_no] == "6") {?>selected<? }?>>3.5톤</option>
      <option value="7" <? if($data[ton_no] == "7") {?>selected<? }?>>5톤카고</option>
      <option value="8" <? if($data[ton_no] == "8") {?>selected<? }?>>5톤윙</option>
    </select>
 	</p>
 	<p>
    <span style="font-weight:bold;">코드</span> : <input type="text" name="codes" value="<?=$data[codes]?>" size="13" />
 	</p>
 	<p style="padding:10px 0 0 0;margin:10px 0 0 0;border-top:1px solid #777777">
   	<div style="float:left;width:80px;text-align:right;"><a href="member_info.php" class="view1_button">취소</a></div><div style="float:right;width:120px;margin:0 200px 0 0;"><input type="submit" value="수정하기" class="view1_button" style="padding:5px 7px 5px 7px;border:1px solid #777777;" /></div>
 	</p>
</div>
</form>
<?
include "foot.php";
?>
