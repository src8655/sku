<?
include "../30b6d5c9f4f00f8f2d4d3101a0657688/lib.php";
include "head.php";

$_REQUEST[ips] = $_SERVER["REMOTE_ADDR"];
$_REQUEST[sessions] = session_id();
$_REQUEST[statuse] = "0";
$_REQUEST[date] = date("Y")."-".date("m")."-".date("d")." ".date("A")." ".date("h").":".date("i")." ".date("s");
$_REQUEST[computers] = "0";

$qlo1 = "insert into min_board_login_list(ip, session, status, date, computer)
					values('$_REQUEST[ips]','$_REQUEST[sessions]','$_REQUEST[statuse]','$_REQUEST[date]','$_REQUEST[computers]')";
mysql_query($qlo1, $connect);

if(!$id){
  echo("
    <script>
      window.alert('아이디를 입력해주세요.')
      history.go(-1)
    </script>
  ");
exit;
}
if(!$password){
  echo("
    <script>
      window.alert('비밀번호를 입력해주세요.')
      history.go(-1)
    </script>
  ");
exit;
}

$pass = md5($password);

$query = "select * from min_board_login where user_id='$id' and password='$pass'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);

if(!$data[no]){
  echo("
    <script>
      window.alert('아이디 혹은 비밀번호가 틀렸습니다.')
      history.go(-1)
    </script>
  ");
exit;
}

$_REQUEST[sta2] = "1";

$qlo2 = "update min_board_login_list set
				status='$_REQUEST[sta2]' where ip='$_REQUEST[ips]' and session='$_REQUEST[sessions]' and status='$_REQUEST[statuse]' and date='$_REQUEST[date]'";
mysql_query($qlo2, $connect);

$_SESSION["user_id"] = $data[user_id];
$_SESSION["password"] = $data[password];
?>
<script> 
  location.href='./index.php'; 
</script>
