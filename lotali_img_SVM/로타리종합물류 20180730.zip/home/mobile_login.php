<?
include "../30b6d5c9f4f00f8f2d4d3101a0657688/lib.php";
include "head.php";

if(!$passworde) {
	echo("
		<script>
			window.alert('비밀번호를 입력해주세요')
			history.go(-1)
		</script>
	");
	exit;
}
if($passworde != "2537") {
	echo("
		<script>
			window.alert('비밀번호가 틀렸습니다')
			history.go(-1)
		</script>
	");
	exit;
}

$idz = "qwq6735";
$passwordz = "dbswornjs1";

$passz = md5($passwordz);

$queryz = "select * from min_board_login where user_id='$idz' and password='$passz'";
$resultz = mysql_query($queryz, $connect);
$dataz = mysql_fetch_array($resultz);

$_SESSION["user_id"] = $dataz[user_id];
$_SESSION["password"] = $dataz[password];
?>
<script> 
  location.href='index.php'; 
</script>
