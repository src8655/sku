<?
include "lib.php";
include "head.php";

if($Search_mode) {
  if($Search_mode == 1) $tmp = "name";
  if($Search_mode == 2) $tmp = "memo";
  
  $where = "where $tmp like '%$Search_text%'";
  }else{
    $where = "";
    }

$qinfos = "select count(*) from min_board_member $where";
$rinfos = mysql_query($qinfos, $connect);
$dinfos = mysql_fetch_array($rinfos);
$infocounts = $dinfos[0];

if(!$page) {
$page = "1";
}

$pagenum1 = "10";
$pagenum2 = ($pagenum1*$page)-$pagenum1;

$limits = "limit $pagenum2, $pagenum1";

$ai1 = $page-5;
$ai2 = $page+5;

$paging = ceil($infocounts/$pagenum1);

$query = "select * from min_board_member $where order by name asc $limits";
$result = mysql_query($query, $connect);
?>
<div style="width:730px;float:left;">
<form action="member_info_search.php" id="writep" name="searchtotal">
<table cellpadding="7" cellspacing="1" id="write1_table" border="0" width="730px" style="margin:0 0 10px 0;">
<col width="170" />
<col width="390" />
<col width="170" />
  <tr>
    <td><a href="index.php" class="view1_button">뒤로가기</a></td>
    <td align="center">
      <select name="Search_mode" id="searchmode">
        <option value="1" <? if($Search_mode == 1) {?>selected<? }?>>이름</option>
        <option value="2" <? if($Search_mode == 2) {?>selected<? }?>>메모</option>
      </select>
      <input type="text" name="Search_text" id="searchtext" size="20" <? if($Search_mode) {?>value="<?=$Search_text?>"<? }?> />
      <input type="submit" value="검색" id="searchbutton" />
    </td>
    <td><a href="#bottomtxx" class="view1_button">맨아래로</a></td>
  </tr>
</table>
</form>
<div class="box">
	<h1><div style="float:left;width:120px;">&nbsp;</div><div style="float:left;width:445px;text-align:center;">기사정보 - <span style="color:red;"><?=$infocounts?></span></div><div style="float:right;width:120px;"><a href="member_info_write.php" class="view1_button">작성하기</a></div></h1>
	<p style="text-align:center;">
			<a href="member_info.php?page=1&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>"><<</a>&nbsp;
<?
for($i=$ai1;$i<$ai2;$i++) {
if($i<1) {
}else{
if($i>$paging) {
}else{
?>
			<a href="member_info.php?page=<?=$i?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>" <? if($i == $page) {?>style="font-weight:bold;color:red;"<? }?>>[<?=$i?>]</a>&nbsp;
<?
}}}
?>
			<a href="member_info.php?page=<?=$paging?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>">>></a>
	</p>
</div>
<?
while($data = mysql_fetch_array($result)) {
?>
<div class="box">
	<h1><div style="float:left;width:300px;"><?=$data[name]?></div><div style="float:right;width:300px;"><a href="member_info_del.php?no=<?=$data[no]?>" class="view1_button" style="float:right;width:60px;">삭제</a><a href="member_info_edit.php?no=<?=$data[no]?>&page=<?=$page?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>" class="view1_button" style="float:right;width:60px;margin:0 5px 0 0;">수정</a></div></h1>
	<p <? $ksps = $data[phone1].$data[phone2].$data[phone3]; if(!$ksps) {?>style="display:none;"<? }?>>
		<span style="font-weight:bold;">전화번호</span> : <?=$data[phone1]?>-<?=$data[phone2]?>-<?=$data[phone3]?>
	</p>
	<p <? if(!$data[memo]) {?>style="display:none;"<? }?>>
		<span style="font-weight:bold;">메모</span> : <?=$data[memo]?>
	</p>
	<p <? if(!$data[email]) {?>style="display:none;"<? }?>>
		<span style="font-weight:bold;">이메일</span> : <?=$data[email]?>
	</p>
	<p <? if(!$data[car_num]) {?>style="display:none;"<? }?>>
		<span style="font-weight:bold;">차량번호</span> : <?=$data[car_num]?>
	</p>
	<p <? if(!$data[ton_no]) {?>style="display:none;"<? }?>>
<?
$q_tmp = "select * from min_board_tmp_ton where no='$data[ton_no]'";
$r_tmp = mysql_query($q_tmp, $connect);
$d_tmp = mysql_fetch_array($r_tmp);
?>
		<span style="font-weight:bold;">차량</span> : <?=$d_tmp[ton]?>
	</p>
</div>
<?
}
?>
<div class="box">
	<p style="text-align:center;">
			<a href="member_info.php?page=1&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>"><<</a>&nbsp;
<?
for($i=$ai1;$i<$ai2;$i++) {
if($i<1) {
}else{
if($i>$paging) {
}else{
?>
			<a href="member_info.php?page=<?=$i?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>" <? if($i == $page) {?>style="font-weight:bold;color:red;"<? }?>>[<?=$i?>]</a>&nbsp;
<?
}}}
?>
			<a href="member_info.php?page=<?=$paging?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>">>></a>
	</p>
</div>
</div>
<div style="float:right;width:260px;overflow:hidden;">
	<div class="box">
		<h1>최근 검색목록</h1>
	<?
	$quia = "select * from min_board_member_searchc order by no desc limit 0,10";
	$ruia = mysql_query($quia, $connect);
	$ccn = 1;
	while($duia = mysql_fetch_array($ruia)) {
	?>
			<form action="member_info_search.php" name="aa<?=$duia[no]?>z">
				<input type="hidden" name="Search_mode" value="<?=$duia[mode]?>" />
				<input type="hidden" name="Search_text" value="<?=$duia[gom]?>" />
			</form>
		<p class="aasee">
			<?=$ccn?>. <a href="#" onclick="haaz(aa<?=$duia[no]?>z);"><?=$duia[gom]?></a>
		</p>
	<?
	$ccn++;
	}
	?>
	</div>
	<div class="box">
		<h1>자주쓰는 검색목록</h1>
	<?
	$ttty =  date("Y").date("m");
	
	$quia2 = "select * from min_board_member_searchi where date='$ttty' order by hit desc limit 0,10";
	$ruia2 = mysql_query($quia2, $connect);
	$ccn2 = 1;
	while($duia2 = mysql_fetch_array($ruia2)) {
	?>
			<form action="member_info_search.php" name="aaz<?=$duia2[no]?>z">
				<input type="hidden" name="Search_mode" value="<?=$duia2[mode]?>" />
				<input type="hidden" name="Search_text" value="<?=$duia2[gom]?>" />
			</form>
		<p class="aasee">
			<?=$ccn2?>. <a href="#" onclick="haaz(aaz<?=$duia2[no]?>z);"><?=$duia2[gom]?></a> <span style="font-size:11px;">-</span> <?=$duia2[hit]?>
		</p>
	<?
	$ccn2++;
	}
	?>
	</div>
</div>
<script type="text/javascript">
	function haaz(aazz) {
		var asdf = aazz;
		asdf.submit();
	}
</script>
<?
include "foot.php";
?>
