<?
include "lib.php";
include "head.php";

$query = "delete from min_board_memo where no='$no'";
mysql_query($query, $connect);
?>
<script>
  location.href='memo_list.php?olddate=<?=$olddate?>';
</script>
