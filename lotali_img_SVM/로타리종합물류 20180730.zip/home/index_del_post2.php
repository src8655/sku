<?
include "lib.php";
include "head.php";

$query = "select * from min_board_admin where company='$company'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<table cellpadding="7" cellspacing="1" id="write1_table" border="0">
<col width="80" />
<col width="80" />
  <tr>
    <th colspan="2">[<span style="color:red; font-size:12px;"><?=$data[name]?></span>] 회사를 삭제합니다<br /><span style="color:red; font-size:12px;">!경고! 삭제하고자 하는 회사의 데이터가 하나라도 있으면 삭제가 안됩니다. 존재한다면 해당 데이터를 모두 삭제한 후 시도해야 합니다.</span></th>
  </tr>
  <tr>
    <td align="center"><a href="index.php?olddate=<?=$olddate?>" class="view1_button">취소</a></td>
    <td align="center"><a href="index_del_post.php?company=<?=$company?>&olddate=<?=$olddate?>" class="view1_button">삭제</a></td>
  </tr>
</table>
<?
include "foot.php";
?>
