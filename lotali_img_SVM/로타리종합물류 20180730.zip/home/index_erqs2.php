<?
include "lib.php";
include "head.php";

$query = "insert into min_board_admin_hide(olddate, company)
          values('$_REQUEST[olddate]','$_REQUEST[company]')";
mysql_query($query, $connect);
?>
<script>
  location.href='index.php?olddate=<?=$olddate?>&erqs=<?=$erqs?>&company=<?=$company?>&ipgm=<?=$_GET[ipgm]?>&erqs2=1';
</script>
