<?
include "lib.php";
include "head.php";

$query = "update min_board_jang_member set
					name='$_REQUEST[name]',
					number='$_REQUEST[number]' where no='$no'";
mysql_query($query, $connect);
?>
<script>
	location.href='jang_check.php?date=<?=$date?>';
</script>
