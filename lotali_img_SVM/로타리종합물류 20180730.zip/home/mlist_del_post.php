<?
include "lib.php";
include "head.php";

$query = "delete from min_board_mlist where no='$no' and olddate='$olddate'";
mysql_query($query, $connect);
?>
<script>
  location.href='mlist.php?olddate=<?=$olddate?>';
</script>
<?
include "foot.php";
?>
