<?
include "lib.php";
include "head2.php";

if($Search_mode) {
	if($Search_mode == "1") $temp = "name";
	if($Search_mode == "2") $temp = "number";
	if($Search_mode == "3") $temp = "memo";
	
	$where = "where $temp like '%$Search_text%'";
}else{
$where = "";
}

$eheight = "25px";

$qgye = "select * from min_board_gye $where";
$rgye = mysql_query($qgye, $connect);
$dgye = mysql_num_rows($rgye);

$query = "select * from min_board_gye $where order by name asc";
$result = mysql_query($query, $connect);
?>
<script defer>
function prints() {
factory.printing.leftMargin = "15.0";
factory.printing.topMargin = "25.0";
factory.printing.rightMargin = "15.0";
factory.printing.bottomMargin = "15.0";
factory.printing.header="";
factory.printing.footer="";
factory.printing.portrait=true;
factory.printing.Print(true);
}
function printshide() {
	pppl.style.display = "none";
}
</script>
<a href="#" onclick="printshide();prints();" id="pppl" style="display:block;width:100px;border:1px solid #676767;text-align:center;font-size:15px;margin:0 auto;margin-bottom:10px;padding:10px;"><img src="./images/print_io.jpg" style="border:0px;" /><br />인쇄하기<br /><span style="font-size:12px;color:red;">(페이지 자동조절)</span></a>
<object id="factory" viewastext style="display:none" classid="clsid:1663ed61-23eb-11d2-b92f-008048fdd814" codebase="./adr/smsx.cab#Version=6,3,436,14"></object>
<table cellpadding="3" cellspacing="0" id="print_te" style="margin-bottom:10px; font-size:15px;font-weight:bold;">
<col width="100" />
<col width="100" />
<col width="100" />
<col width="100" />
<col width="200" />
<col width="100" />
	<tr>
		<th colspan="6" height="<?=$eheight?>">계좌번호 전체보기 - <span style="color:red"><?=$dgye?></span>
		</th>
	</tr>
	<tr>
		<th height="<?=$eheight?>">위치</th>
		<th>이름</th>
		<th>차량번호</th>
		<th>은행</th>
		<th>계좌번호</th>
		<th>메모</th>
	</tr>
<?
while($data = mysql_fetch_array($result)) {
?>
	<tr>
		<td align="center" height="<?=$eheight?>">
			<? if($data[company] == 1) {?>
				5t 기준
			<? }?>
			<? if($data[company] == 2) {?>
				1t~3.5t
			<? }?>
			<? if($data[company] == 3) {?>
				외주차
			<? }?>
			<? if($data[company] == 6) {?>
				거래처
			<? }?>
		</td>
		<td align="center"><?=$data[name]?></td>
		<td align="center"><?=$data[number]?></td>
		<td align="center"><span style="font-weight:bold;"><?=$data[bank]?></span></td>
		<td align="left"><span style="font-weight:bold;"><?=$data[gye]?></span></td>
		<td align="center"><?=$data[memo]?></td>
	</tr>
<?
}
?>
</table>
<?
include "foot2.php";
?>
