<?
include "lib.php";
include "head.php";
?>
<table cellpadding="7" cellspacing="1" id="write1_table" border="0">
<col width="80" />
<col width="80" />
  <tr>
    <th colspan="2">삭제하시겠습니까?</th>
  </tr>
  <tr>
    <td align="center"><a href="el.php?page=<?=$page?>" class="view1_button">취소</a></td>
    <td align="center"><a href="el_del_post.php?no=<?=$no?>&page=<?=$page?>" class="view1_button">삭제</a></td>
  </tr>
</table>
<?
include "foot.php";
?>