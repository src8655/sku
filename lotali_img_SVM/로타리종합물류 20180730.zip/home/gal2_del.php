<?
include "lib.php";
include "head.php";

$query = "select * from min_board_cal where date='$date'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<table cellpadding="7" cellspacing="1" id="write1_table" border="0" style="margin-bottom:10px;">
	<tr>
		<th colspan="2"><?=nl2br($data[memo])?></th>
	</tr>
	<tr>
		<th colspan="2">정말로 삭제하시겠습니까?</th>
	</tr>
	<tr>
		<td><a href="gal2.php?years=<?=$years?>&mons=<?=$mons?>" class="view1_button">취소</a></td>
		<td><a href="gal2_del_post.php?date=<?=$date?>&years=<?=$years?>&mons=<?=$mons?>" class="view1_button">삭제</a></td>
	</tr>
</table>
<?
include "foot.php";
?>
