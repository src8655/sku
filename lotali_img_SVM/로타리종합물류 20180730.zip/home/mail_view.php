<?
include "lib.php";
include "head.php";

$query = "select * from min_board_mail where no='$no'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<div id="mail_left">
	<h1>메일메뉴</h1>
	<ul>
		<li><a href="mail.php">메일쓰기</a></li>
		<li><a href="mail.php?sendmail=1">보낸메일함</a></li>
		<li><a href="mail_list.php">회사이메일목록</a></li>
	</ul>
</div>
<div class="mail_t">
	보낸메일보기 <span style="font-weight:normal;font-size:13px;">보낸메일을 자세히 볼 수 있는 페이지 입니다.</span>
</div>
<table cellpadding="10" cellspacing="0" width="790px" id="write1_tablec" style="font-size:17px;float:right;">
<col width="200" />
<col width="800" />
	<tr>
		<th>받는사람</th>
		<td><?=$data[ba]?></td>
	</tr>
	<tr>
		<th>보낸사람</th>
		<td><?=$data[bo]?></td>
	</tr>
	<tr>
		<th>제목</th>
		<td><?=$data[subject]?></td>
	</tr>
	<tr>
		<th>내용</th>
		<td><?=nl2br($data[memo])?></td>
	</tr>
	<tr>
		<th>첨부파일 1</th>
		<td><a href="../data/<?=$data[files]?>"><?=$data[files]?></a></td>
	</tr>
	<tr>
		<th>첨부파일 2</th>
		<td><a href="../data/<?=$data[files2]?>"><?=$data[files2]?></a></td>
	</tr>
</table>
<?
include "foot.php";
?>
