<?
include "lib.php";
include "head.php";


if($_GET[tmp]) { //�����϶�
$teeemp = "";
$query = "update min_board_admin_damt set
          ipgm='$teeemp' where tmp='$_GET[tmp]'";
mysql_query($query, $connect);
?>
<script>
location.href = 'view2.php?olddate=<?=$olddate?>&view2_password=<?=$view2_password?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&mmmq=<?=$mmmq?>&mon=<?=$mon?>&id=<?=$id?>';
</script>
<?
}else{
$teeemp = "";
$query = "update min_board_admin set
          ipgm='$teeemp' where company='$_GET[company]'";
mysql_query($query, $connect);
?>
<script>
location.href = 'view1.php?company=<?=$company?>&olddate=<?=$olddate?>';
</script>
<?
}
include "foot.php";
?>
