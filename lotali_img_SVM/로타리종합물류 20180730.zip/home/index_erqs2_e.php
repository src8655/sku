<?
include "lib.php";
include "head.php";


$qu = "delete from min_board_admin_hide where olddate='$olddate' and company='$company'";
mysql_query($qu, $connect);
?>
<script>
  location.href='index.php?olddate=<?=$olddate?>&erqs=<?=$erqs?>&company=<?=$company?>&ipgm=<?=$_GET[ipgm]?>&erqs2=1';
</script>
