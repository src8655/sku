<?
include "lib.php";
include "head.php";

$query = "select * from min_board_data3 where no='$no' and olddate='$olddate'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);

$ddmso = $data[money]/1000;

$q = "select * from min_board_admin where company='$company'";
$r = mysql_query($q, $connect);
$admin = mysql_fetch_array($r);


?>
<div style="width:1000px; margin:0 auto;">

<form action="edit3_post.php">
<input type="hidden" name="no" value="<?=$no?>" />
<input type="hidden" name="olddate" value="<?=$olddate?>" />
<input type="hidden" name="company" value="<?=$company?>" />
<input type="hidden" name="page" value="<?=$page?>" />
<?
if($Search_mode == 10) {
?>
<input type="hidden" name="Search_mode" value="<?=$Search_mode?>" />
<input type="hidden" name="mmmq" value="<?=$mmmq?>" />
<input type="hidden" name="Search_text" value="<?=$Search_text?>" />
<?
}
?>
<table cellpadding="7" cellspacing="1" id="write1_table" border="0" width="1000px">
<col width="70" />
<col width="50" />
<col width="70" />
<col width="80" />
<col width="80" />
<col width="80" />
<col width="100" />
<col width="130" />
<col width="80" />
<col width="80" />
<col width="30" />
  <tr>
    <th colspan="11" align="center">로타리장부 <span style="color:red;">수정하기</span></th>
  </tr>
  <tr>
    <th>월/일</th>
    <th>요일</th>
    <th>출발지</th>
    <th>도착지</th>
    <th>차량번호</th>
    <th>이름</th>
    <th>금액</th>
    <th>전화번호</th>
    <th>숫자</th>
    <th>메모</th>
    <th>완</th>
  </tr>
  <tr>
    <td align="center">
      <input type="text" name="date2" value="<?=$data[date2]?>" style="font-size:15px;padding:2px 0 2px 0;width:30px;border:1px solid #7F9DB9;margin:0 0 2px 0;" />
      월
      <br />
      <input type="text" name="date3" value="<?=$data[date3]?>" style="font-size:15px;padding:2px 0 2px 0;width:30px;border:1px solid #7F9DB9;" />
      일
    </td>
    <td align="center"><input type="text" name="yo" class="write1_input" value="<?=$data[yo]?>" style="font-size:15px;padding:2px 0 2px 0;" /></td>
    <td align="center"><input type="text" name="chu" class="write1_input" value="<?=$data[chu]?>" style="font-size:15px;padding:2px 0 2px 0;" /></td>
    <td align="center"><input type="text" name="ddo" class="write1_input" value="<?=$data[ddo]?>" style="font-size:15px;padding:2px 0 2px 0;" /></td>
    <td align="center"><input type="text" name="number" class="write1_input" value="<?=$data[number]?>" style="font-size:15px;padding:2px 0 2px 0;" /></td>
    <td align="center"><input type="text" name="name" class="write1_input" value="<?=$data[name]?>" style="font-size:15px;padding:2px 0 2px 0;" /></td>
    <td align="center"><input type="text" name="money1" value="<?=$data[money1]?>" style="width:45px;font-size:15px;padding:2px 0 2px 0;" />,000<br />-<br /><input type="text" name="money2" value="<?=$data[money2]?>" style="width:45px;font-size:15px;padding:2px 0 2px 0;" />,000</td>
    <td align="center"><input type="text" name="phone" class="write1_input" value="<?=$data[phone]?>" style="font-size:15px;padding:2px 0 2px 0;" /></td>
    <td align="center">자동계산</td>
    <td align="center"><input type="text" name="memos" style="font-size:15px;padding:2px 0 2px 0;width:60px;border:1px solid #7F9DB9;" value="<?=$data[memos]?>" /></td>
    <td align="center"><input type="checkbox" name="wan" <? if($data[wan] == "(완)") {?>checked<? }?> /><br /><input type="text" name="wandate" value="<?=$data[wandate]?>" style="width:35px;font-size:15px;padding:2px 0 2px 0;" /></td>
  </tr>
  <tr>
    <td align="center"><a href="view3.php?olddate=<?=$olddate?>&company=<?=$company?>&page=<?=$page?>&mmmq=<?=$mmmq?>" class="view1_button">취소</a></td>
    <td colspan="10" align="center"><input type="submit" value="수정하기" class="view1_button" /></td>
  </tr>
</table>
</form>
</div>
<?
include "foot.php";
?>
