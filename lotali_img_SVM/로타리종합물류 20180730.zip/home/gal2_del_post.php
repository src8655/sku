<?
include "lib.php";
include "head.php";

$query = "delete from min_board_cal where date='$date'";
mysql_query($query, $connect);
?>
<script>
	location.href='gal2.php?years=<?=$years?>&mons=<?=$mons?>';
</script>
