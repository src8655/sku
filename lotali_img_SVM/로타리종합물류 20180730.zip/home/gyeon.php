<?
include "lib.php";
include "head.php";
?>
<div class="box" style="margin:0 auto;margin-bottom:10px;width:758px;">
    <h1 style="border:0px;padding:0px;margin:0px;">
    	<div style="float:left;width:200px;">
    		<div style="float:left;width:120px;">
		    	<input type="button" value="엑셀로저장" onclick="javascript:gyeonprint.action='../phpexcel/Examples/gyeon_xls.php';javascript:gyeonprint.submit();" class="view1_button" style="width:100%;" />
		  	</div>
    	</div>
    	<div style="font-size:27px;float:left;width:355px;text-align:center;">
    		견적서
    	</div>
    	<div style="float:right;width:200px;">
    		<div style="float:left;width:95px;">
		    	<input type="button" value="인쇄하기1" onclick="javascript:gyeonprint.action='gyeon_print.php';javascript:gyeonprint.submit();" class="view1_button" style="width:100%;" />
		  	</div>
    		<div style="float:right;width:95px;">
		    	<input type="submit" value="인쇄하기2" onclick="javascript:gyeonprint.action='gyeon_pdf.php';javascript:gyeonprint.submit();" class="view1_button" style="width:100%;" />
		  	</div>
    	</div>
    </h1>
</div>
<form action="gyeon_print.php" target="_BLANK" name="gyeonprint">


<div style="width:800px;margin:0 auto;overflow:hidden;">
  <table cellpadding="5" cellspacing="1" id="write1_table" border="0" style="font-size:15px;width:280px;float:left;border:3px solid #000000;">
  <col width="80px" />
  <col width="130px" />
    <tr>
      <th>견적 일자</th>
      <td><input type="text" name="dates" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
    </tr>
    <tr>
      <th>업체명</th>
      <td><input type="text" name="companys" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
    </tr>
    <tr>
      <th>담당자</th>
      <td><input type="text" name="names" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
    </tr>
    <tr>
      <th>연락처</th>
      <td><input type="text" name="phones" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
    </tr>
    <tr>
      <th>팩스번호</th>
      <td><input type="text" name="faxs" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
    </tr>
    <tr>
      <th>납기</th>
      <td><input type="text" name="nabgi" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
    </tr>
    <tr>
      <th>지불조건</th>
      <td><input type="text" name="jijo" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
    </tr>
  </table>
  
  
  <table cellpadding="5" cellspacing="1" id="write1_table" border="0" style="font-size:15px;width:350px;float:right;border:3px solid #000000;">
  <col width="80px" />
  <col width="130px" />
    <tr>
      <th height="25px">상호</th>
      <td>로타리종합물류</td>
    </tr>
    <tr>
      <th height="25px">등록번호</th>
      <td>127-24-44779</td>
    </tr>
    <tr>
      <th height="25px">주소</th>
      <td>경기도 양주시 은현면 화합로 959</td>
    </tr>
    <tr>
      <th height="25px">전화번호</th>
      <td>031-836-6677~6688</td>
    </tr>
    <tr>
      <th height="25px">팩스번호</th>
      <td>031-836-8558</td>
    </tr>
    <tr>
      <th height="25px">소장님</th>
      <td>010-3349-5262</td>
    </tr>
  </table>
  <p style="font-size:20px;font-weight:bold;margin:0px;padding:30px 0 30px 0;width:100%;overflow:hidden;">
    *아래와 같이 견적합니다.
  </p>
  <table cellpadding="5" cellspacing="1" id="write1_table" border="0" style="font-size:15px;width:100%;float:right;border:3px solid #000000;">
  <col width="300px" />
  <col width="125px" />
  <col width="125px" />
  <col width="125px" />
  <col width="125px" />
    <tr>
      <th>내용</th>
      <th>단가</th>
      <th>금액</th>
      <th>세액</th>
      <th>비고</th>
    </tr>
    <tr>
      <td><input type="text" name="memos1" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="dans1" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="moneys1" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="se1" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="bigo1" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
    </tr>
    <tr>
      <td><input type="text" name="memos2" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="dans2" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="moneys2" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="se2" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="bigo2" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
    </tr>
    <tr>
      <td><input type="text" name="memos3" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="dans3" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="moneys3" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="se3" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="bigo3" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
    </tr>
    <tr>
      <td><input type="text" name="memos4" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="dans4" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="moneys4" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="se4" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="bigo4" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
    </tr>
    <tr>
      <td><input type="text" name="memos5" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="dans5" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="moneys5" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="se5" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="bigo5" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
    </tr>
    <tr>
      <td><input type="text" name="memos6" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="dans6" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="moneys6" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="se6" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
      <td><input type="text" name="bigo6" style="border:1px solid #676767;font-size:15px;width:98%;height:25px;" /></td>
    </tr>
    <tr>
      <th>합계</th>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <div style="margin:0px;padding:20px 0 0 0;width:100%;overflow:hidden;">
    <h1 style="margin:0px;padding:10px;width:50px;text-align:center;font-size:20px;border:3px solid #000000;border-bottom:0px;overflow:hidden;">기타</h1>
    <p style="margin:0px;padding:45px 10px 45px 10px;border:3px solid #000000;overflow:hidden;">
      <input type="text" name="gitars" value="* 상세내용은 친절하게 상담해 드리도록 하겠습니다. -감사합니다-" style="height:25px;border:1px solid #676767;font-size:15px;width:98%;" />
    </p>
  </div>
</div>

</form>
<?
include "foot.php";
?>
