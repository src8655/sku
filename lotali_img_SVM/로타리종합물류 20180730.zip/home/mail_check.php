<?
include "../30b6d5c9f4f00f8f2d4d3101a0657688/lib.php";
include "head.php";

$_REQUEST[ss] = "2";

$query = "update min_board_mail set
					checks='$_REQUEST[ss]' where no='$no'";
mysql_query($query, $connect);
?>
