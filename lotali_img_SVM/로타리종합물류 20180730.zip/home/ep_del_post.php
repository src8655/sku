<?
include "lib.php";
include "head.php";

$query = "delete from min_board_ep where olddate='$olddate' and no='$no'";
mysql_query($query, $connect);
?>
<script>
	location.href='ep.php?olddate=<?=$olddate?>';
</script>
