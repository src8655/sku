<?
include "lib.php";
include "head.php";

$query = "insert into min_board_gye(memo, name, number, bank, gye, company)
					values('$_REQUEST[memo]','$_REQUEST[name]','$_REQUEST[number]','$_REQUEST[bank]','$_REQUEST[gye]','$_REQUEST[company]')";
mysql_query($query, $connect);
?>
<script>
location.href='gye.php?company=<?=$company?>';
</script>
