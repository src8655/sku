<?
include "lib.php";
include "head.php";

// 날짜정리

if($date2 == "1") {
$date2 = "01";
}
if($date2 == "2") {
$date2 = "02";
}
if($date2 == "3") {
$date2 = "03";
}
if($date2 == "4") {
$date2 = "04";
}
if($date2 == "5") {
$date2 = "05";
}
if($date2 == "6") {
$date2 = "06";
}
if($date2 == "7") {
$date2 = "07";
}
if($date2 == "8") {
$date2 = "08";
}
if($date2 == "9") {
$date2 = "09";
}
if($date3 == "1") {
$date3 = "01";
}
if($date3 == "2") {
$date3 = "02";
}
if($date3 == "3") {
$date3 = "03";
}
if($date3 == "4") {
$date3 = "04";
}
if($date3 == "5") {
$date3 = "05";
}
if($date3 == "6") {
$date3 = "06";
}
if($date3 == "7") {
$date3 = "07";
}
if($date3 == "8") {
$date3 = "08";
}
if($date3 == "9") {
$date3 = "09";
}

$_REQUEST[dates] = $date2."/".$date3;

// 날짜정리

$qmlist = "insert into min_board_mlist(date,date2,date3,ne,ep,je,be,olddate)
						values('$_REQUEST[dates]','$date2','$date3','$_REQUEST[ne]','$_REQUEST[ep]','$_REQUEST[je]','$_REQUEST[be]','$_REQUEST[olddate]')";
mysql_query($qmlist, $connect);
?>
<script>
	location.href="mlist.php?olddate=<?=$olddate?>";
</script>
<?
include "foot.php";
?>
