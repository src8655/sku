<?
include "lib.php";
include "head.php";

$querys2 = "select * from min_board_mail_list";
$results2 = mysql_query($querys2, $connect);
$datas2 = mysql_num_rows($results2);
$couuuu = $datas2;

if(!$page) {
$page = "1";
}
$pagenum1 = "10";
$pagenum2 = ($pagenum1*$page)-$pagenum1;

$paging = ceil($couuuu/$pagenum1);

$limits = "limit $pagenum2, $pagenum1";

$query = "select * from min_board_mail_list order by no desc $limits";
$result = mysql_query($query, $connect);
?>
<div id="mail_left">
	<h1>메일메뉴</h1>
	<ul>
		<li><a href="mail.php">메일쓰기</a></li>
		<li><a href="mail.php?sendmail=1">보낸메일함</a></li>
		<li><a href="mail_list.php">회사이메일목록</a></li>
	</ul>
</div>
<div class="mail_t">
	회사이메일목록 <span style="font-weight:normal;font-size:13px;">이메일을 관리하는 페이지 입니다.</span>
</div>
<form action="mail_list_post.php">
<table cellpadding="7" cellspacing="0" width="790px" id="write1_tablec" style="font-size:17px;float:right;">
<col width="90" />
<col width="280" />
<col width="280" />
<col width="70" />
<col width="70" />
	<tr>
		<th height="25">번호</th>
		<th>회사이름</th>
		<th>이메일</th>
		<th colspan="2">관리</th>
	</tr>
	<tr>
		<td align="center" style="font-weight:bold;">추가</td>
		<td align="center"><input type="text" name="company" style="width:98%;font-size:17px;border:1px solid #676767;" /></td>
		<td align="center"><input type="text" name="email" style="width:98%;font-size:17px;border:1px solid #676767;" /></td>
		<td align="center" colspan="2"><input type="submit" value="작성하기" class="view1_button" style="width:99%;border:1px solid #676767;font-size:17px;" /></td>
	</tr>
<?
$cnt = 1;
while($data = mysql_fetch_array($result)) {
?>
	<tr>
		<td align="center"><?=$couuuu-$cnt-$pagenum2+1?></td>
		<td align="center"><?=$data[company]?></td>
		<td align="center"><?=$data[email]?></td>
		<td align="center"><a href="mail_list_edit.php?no=<?=$data[no]?>" class="view1_button">수정</a></td>
		<td align="center"><a class="view1_button" onclick="confirms('삭제하시겠습니까?','mail_list_del.php?no=<?=$data[no]?>');">삭제</a></td>
	</tr>
<?
$cnt++;
}
?>
	<tr>
		<td colspan="5" align="center" style="font-size:15px;">
			<a href="mail_list.php?page=1"><<</a>
<?
$a1 = $page-5;
$a2 = $page+6;

for($i=$a1;$i<$a2;$i++) {
if($i<1) {
}else{
if($i>$paging) {
}else{
?>
			<a href="mail_list.php?page=<?=$i?>" <? if($i == $page) {?>style="font-weight:bold;color:red;"<? }?>>[<?=$i?>]</a>
<?
}}}
?>
			<a href="mail_list.php?page=<?=$paging?>">>></a>
		</td>
	</tr>
</table>
</form>
<?
include "foot.php";
?>
