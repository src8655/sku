<div id="copyrights2">
  Copyright ⓒ 2010~<?=date("Y")?> 로타리종합물류 All rights reserved.
</div>
</div>
<a name="bottomtxx"></a>
</body>
</html>
