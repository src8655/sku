<?
include "lib.php";
include "head.php";

$query = "delete from min_board_memo2 where no='$no'";
mysql_query($query, $connect);
?>
<script>
  location.href='index.php?olddate=<?=$olddate?>';
</script>
