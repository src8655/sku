<?
include "lib.php";
include "head.php";

$query = "select * from min_board_info where no='$no'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<form action="company_info_edit_post.php">
<input type="hidden" name="no" value="<?=$no?>" />
<input type="hidden" name="page" value="<?=$page?>" />
<input type="hidden" name="Search_mode" value="<?=$Search_mode?>" />
<input type="hidden" name="Search_text" value="<?=$Search_text?>" />
<div class="box" id="companyboxr">
  <h1>수정하기</h1>
 	<p>
 		<span style="font-weight:bold;">회사명</span> : <input type="text" name="company" value="<?=$data[company]?>" size="13" />
 	</p>
 	<p>
    <span style="font-weight:bold;">[지번] 주소</span> : <input type="text" name="addr" value="<?=$data[addr]?>" size="60" />
 	</p>
 	<p>
    <span style="font-weight:bold;">[도로명] 주소</span> : <input type="text" name="addr2" value="<?=$data[addr2]?>" size="60" />
 	</p>
 	<p>
    <span style="font-weight:bold;">우편번호</span> : <input type="text" name="addrnum" value="<?=$data[addrnum]?>" style="width:100px;font-size:15px;padding:2px 0 2px 0;" />
 	</p>
 	<p>
    <span style="font-weight:bold;">전화번호</span> : <input type="text" name="tel1" value="<?=$data[tel1]?>" size="3">-<input type="text" name="tel2" value="<?=$data[tel2]?>" size="3">-<input type="text" name="tel3" value="<?=$data[tel3]?>" size="3"> 　　　<span style="font-weight:bold;">FAX번호</span> : <input type="text" name="fax1" value="<?=$data[fax1]?>" size="3">-<input type="text" name="fax2" value="<?=$data[fax2]?>" size="3">-<input type="text" name="fax3" value="<?=$data[fax3]?>" size="3">
 	</p>
 	<p>
    <span style="font-weight:bold;">이메일</span> : <input type="text" name="email" value="<?=$data[email]?>" size="50" />
 	</p>
 	<p>
    <span style="font-weight:bold;">담당자</span> : <input type="text" name="name" value="<?=$data[name]?>" size="10" /> 　　　<span style="font-weight:bold;">담당자번호</span> : <input type="text" name="phone1" value="<?=$data[phone1]?>" size="5">-<input type="text" name="phone2" value="<?=$data[phone2]?>" size="5">-<input type="text" name="phone3" value="<?=$data[phone3]?>" size="5">
 	</p>
 	<p>
    <span style="font-weight:bold;">메모</span> : <input type="text" name="memo" value="<?=$data[memo]?>" size="50" />
 	</p>
 	<p style="padding:10px 0 0 0;margin:10px 0 0 0;border-top:1px solid #777777">
   	<div style="float:left;width:80px;text-align:right;"><a href="company_info.php" class="view1_button">취소</a></div><div style="float:right;width:120px;margin:0 200px 0 0;"><input type="submit" value="수정하기" class="view1_button" style="padding:5px 7px 5px 7px;border:1px solid #777777;" /></div>
 	</p>
</div>
</form>
<?
include "foot.php";
?>
