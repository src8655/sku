<?
include "lib.php";
include "head.php";

$conn = mysql_pconnect("183.97.67.31","src8655","snrnsnrn11");
mysql_select_db("lsm8655",$conn);
if(!$conn) {
  echo "err";
  }
$qbk = "android_data";
$rbk = mysql_query("select * from $qbk",$conn);
while($dbk = mysql_fetch_array($rbk)) {
  echo "insert into android_data (no, sang, sangmemo, sangtime, ha, hatime, objectname, pay, car, ton, money1, money2, memo, writer_number, writer_imei, writer_time, writer_time_t, reader_number, reader_imei, reader_time, reader_time_t, status, list_status, dh, p1, p2, times, read_time, sangbang, habang)
        values($dbk[no],$dbk[sang],$dbk[sangmemo],$dbk[sangtime],$dbk[ha],$dbk[hatime],$dbk[objectname],$dbk[pay],$dbk[car],$dbk[ton],$dbk[money1],$dbk[money2],$dbk[memo],$dbk[writer_number],$dbk[writer_imei],$dbk[writer_time],$dbk[writer_time_t],$dbk[reader_number],$dbk[reader_imei],$dbk[reader_time],$dbk[reader_time_t],$dbk[status],$dbk[list_status],$dbk[dh],$dbk[p1],$dbk[p2],$dbk[times],$dbk[read_time],$dbk[sangbang],$dbk[habang])";
}


/*
mysql_query("insert into android_data(no, sang, sangmemo, sangtime, ha, hatime, objectname, pay, car, ton, money1, money2, memo, writer_number, writer_imei, writer_time, writer_time_t, reader_number, reader_imei, reader_time, reader_time_t, status, list_status, dh, p1, p2, times, read_time, sangbang, habang)  values('$dbk[no]','$dbk[sang]','$dbk[sangmemo]','$dbk[sangtime]','$dbk[ha]','$dbk[hatime]','$dbk[objectname]','$dbk[pay]','$dbk[car]','$dbk[ton]','$dbk[money1]','$dbk[money2]','$dbk[memo]','$dbk[writer_number]','$dbk[writer_imei]','$dbk[writer_time]','$dbk[writer_time_t]','$dbk[reader_number]','$dbk[reader_imei]','$dbk[reader_time]','$dbk[reader_time_t]','$dbk[status]','$dbk[list_status]','$dbk[dh]','$dbk[p1]','$dbk[p2]','$dbk[times]','$dbk[read_time]','$dbk[sangbang]','$dbk[habang]') ",$conn);


mysql_query("insert into android_member(no, name, phone, imei, number, car, ton, adm, admins, mymoney, banks, admins_st, cants)  values('$dbk[no]','$dbk[name]','$dbk[phone]','$dbk[imei]','$dbk[number]','$dbk[car]','$dbk[ton]','$dbk[adm]','$dbk[admins]','$dbk[mymoney]','$dbk[banks]','$dbk[admins_st]','$dbk[cants]') ",$conn);


mysql_query("insert into android_member_pay(no, phone, imei, dates, times) values('$dbk[no]','$dbk[phone]','$dbk[imei]','$dbk[dates]','$dbk[times]') ",$conn);


mysql_query("insert into android_pay(no, dates, money, memo, phone, imei, money2)  values('$dbk[no]','$dbk[dates]','$dbk[money]','$dbk[memo]','$dbk[phone]','$dbk[imei]','$dbk[money2]') ",$conn);


mysql_query("insert into ho_board_admin(no, id, name, level_write, level_read, level_list, sitemap, menu) values('$dbk[no]','$dbk[id]','$dbk[name]','$dbk[level_write]','$dbk[level_read]','$dbk[level_list]','$dbk[sitemap]','$dbk[menu]') ",$conn);


mysql_query("insert into ho_board_ban(no, ip)  values('$dbk[no]','$dbk[ip]') ",$conn);


mysql_query("insert into ho_board_ban2(no, ip)  values('$dbk[no]','$dbk[ip]') ",$conn);


mysql_query("insert into ho_board_comment(no, name,password,memo,date,ip,linkno)  values('$dbk[no]','$dbk[name]','$dbk[password]','$dbk[memo]','$dbk[date]','$dbk[ip]','$dbk[linkno]') ",$conn);


mysql_query("insert into ho_board_count(no, date, ip, hour, links)  values('$dbk[no]','$dbk[date]','$dbk[ip]','$dbk[hour]','$dbk[links]') ",$conn);


mysql_query("insert into ho_board_data(no, subject, memo, name, password, hit, date, ip, id, comment, secret)  values('$dbk[no]','$dbk[subject]','$dbk[memo]','$dbk[name]','$dbk[password]','$dbk[hit]','$dbk[date]','$dbk[ip]','$dbk[id]','$dbk[comment]','$dbk[secret]') ",$conn);


mysql_query("insert into ho_board_info(no, sang, ddo, cart, cari, sangb, hab, ton, money, hon, memo, date, result, id, olcarnum, olname, olphone, olid, bacarnum, baname, baphone, baid, badate)  values('$dbk[no]','$dbk[sang]','$dbk[ddo]','$dbk[cart]','$dbk[cari]','$dbk[sangb]','$dbk[hab]','$dbk[ton]','$dbk[money]','$dbk[hon]','$dbk[memo]','$dbk[date]','$dbk[result]','$dbk[id]','$dbk[olcarnum]','$dbk[olname]','$dbk[olphone]','$dbk[olid]','$dbk[bacarnum]','$dbk[baname]','$dbk[baphone]','$dbk[baid]','$dbk[badate]') ",$conn);


mysql_query("insert into ho_board_limit(no, rc, ip, time, count)  values('$dbk[no]','$dbk[rc]','$dbk[ip]','$dbk[time]','$dbk[count]') ",$conn);


mysql_query("insert into ho_board_member(no, user_id, password, name, email, addr, birth, number, phone, level, ip, date, memo, info_w, carnum) values('$dbk[no]','$dbk[user_id]','$dbk[password]','$dbk[name]','$dbk[email]','$dbk[addr]','$dbk[birth]','$dbk[number]','$dbk[phone]','$dbk[level]','$dbk[ip]','$dbk[date]','$dbk[memo]','$dbk[info_w]','$dbk[carnum]') ",$conn);


mysql_query("insert into min_board_admin(company, companys, name, orders) values('$dbk[company]','$dbk[companys]','$dbk[name]','$dbk[orders]') ",$conn);


mysql_query("insert into min_board_admin_check(no, company, olddate)  values('$dbk[no]','$dbk[company]','$dbk[olddate]') ",$conn);


mysql_query("insert into min_board_admin_hide(no, olddate, company)  values('$dbk[no]','$dbk[olddate]','$dbk[company]') ",$conn);


mysql_query("insert into min_board_cal(no, memo, date) values('$dbk[no]','$dbk[memo]','$dbk[date]') ",$conn);


mysql_query("insert into min_board_custom(no, name, ip, date, session) values('$dbk[no]','$dbk[name]','$dbk[ip]','$dbk[date]','$dbk[session]') ",$conn);


mysql_query("insert into min_board_data1(no, date, date2, date3, yo, ddo, number, name, money, memo1, phone, company, old, companys, del, secrets, olddate, wan, wandate, memo2, memocc, chu, memos, money1, money2, virtualmoney) values('$dbk[no]','$dbk[date]','$dbk[date2]','$dbk[date3]','$dbk[yo]','$dbk[ddo]','$dbk[number]','$dbk[name]','$dbk[money]','$dbk[memo1]','$dbk[phone]','$dbk[company]','$dbk[old]','$dbk[companys]','$dbk[del]','$dbk[secrets]','$dbk[olddate]','$dbk[wan]','$dbk[wandate]','$dbk[memo2]','$dbk[memocc]','$dbk[chu]','$dbk[memos]','$dbk[money1]','$dbk[money2]','$dbk[virtualmoney]') ",$conn);


mysql_query("insert into min_board_data2(no, yo, date, date2, date3, chu, gu, ddo, number, name, ton, su, money, ox, old, secrets, memos, olddate, wan, wandate, phone, companys, memo1, memo2, money1, money2) values('$dbk[no]','$dbk[yo]','$dbk[date]','$dbk[date2]','$dbk[date3]','$dbk[chu]','$dbk[gu]','$dbk[ddo]','$dbk[number]','$dbk[name]','$dbk[ton]','$dbk[su]','$dbk[money]','$dbk[ox]','$dbk[old]','$dbk[secrets]','$dbk[memos]','$dbk[olddate]','$dbk[wan]','$dbk[wandate]','$dbk[phone]','$dbk[companys]','$dbk[memo1]','$dbk[memo2]','$dbk[money1]','$dbk[money2]') ",$conn);


mysql_query("insert into min_board_data3(no, date, date2, date3, yo, chu, ddo, name, number, money, money1, money2, phone, memo, old, olddate, wan, wandate, company, companys, memo1, memo2, memos) values('$dbk[no]','$dbk[date]','$dbk[date2]','$dbk[date3]','$dbk[yo]','$dbk[chu]','$dbk[ddo]','$dbk[name]','$dbk[number]','$dbk[money]','$dbk[money1]','$dbk[money2]','$dbk[phone]','$dbk[memo]','$dbk[old]','$dbk[olddate]','$dbk[wan]','$dbk[wandate]','$dbk[company]','$dbk[companys]','$dbk[memo1]','$dbk[memo2]','$dbk[memos]') ",$conn);


mysql_query("insert into min_board_ep(no, olddate, company, date, name, money, checks, se1, moneys, checks2, memo, date2, orders) values('$dbk[no]','$dbk[olddate]','$dbk[company]','$dbk[date]','$dbk[name]','$dbk[money]','$dbk[checks]','$dbk[se1]','$dbk[moneys]','$dbk[checks2]','$dbk[memo]','$dbk[date2]','$dbk[orders]') ",$conn);


mysql_query("insert into min_board_gye(no, memo, name, number, bank, gye, company) values('$dbk[no]','$dbk[memo]','$dbk[name]','$dbk[number]','$dbk[bank]','$dbk[gye]','$dbk[company]') ",$conn);


mysql_query("insert into min_board_info(no, company, addr, addr2, tel1, tel2, tel3, fax1, fax2, fax3, email, name, phone1, phone2, phone3, memo) values('$dbk[no]','$dbk[company]','$dbk[addr]','$dbk[addr2]','$dbk[tel1]','$dbk[tel2]','$dbk[tel3]','$dbk[fax1]','$dbk[fax2]','$dbk[fax3]','$dbk[email]','$dbk[name]','$dbk[phone1]','$dbk[phone2]','$dbk[phone3]','$dbk[memo]') ",$conn);


mysql_query("insert into min_board_info_plus(no, name, phone1, phone2, phone3, id)  values('$dbk[no]','$dbk[name]','$dbk[phone1]','$dbk[phone2]','$dbk[phone3]','$dbk[id]') ",$conn);


mysql_query("insert into min_board_jang_check(no, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, date, member) values('$dbk[no]','$dbk[a1]','$dbk[a2]','$dbk[a3]','$dbk[a4]','$dbk[a5]','$dbk[a6]','$dbk[a7]','$dbk[a8]','$dbk[a9]','$dbk[a10]','$dbk[a11]','$dbk[a12]','$dbk[date]','$dbk[member]') ",$conn);


mysql_query("insert into min_board_jang_date(no, date)  values('$dbk[no]','$dbk[date]') ",$conn);


mysql_query("insert into min_board_jang_member(no, name, number) values('$dbk[no]','$dbk[name]','$dbk[number]') ",$conn);


mysql_query("insert into min_board_login(no, user_id, password, com)  values('$dbk[no]','$dbk[user_id]','$dbk[password]','$dbk[com]') ",$conn);


mysql_query("insert into min_board_mail(no, bo, ba, subject, memo, files, checks, date, files2)  values('$dbk[no]','$dbk[bo]','$dbk[ba]','$dbk[subject]','$dbk[memo]','$dbk[files]','$dbk[checks]','$dbk[date]','$dbk[files2]') ",$conn);


mysql_query("insert into min_board_mail_list(no, company, email)  values('$dbk[no]','$dbk[company]','$dbk[email]') ",$conn);


mysql_query("insert into min_board_member(no, name, phone1, phone2, phone3, memo, email) values('$dbk[no]','$dbk[name]','$dbk[phone1]','$dbk[phone2]','$dbk[phone3]','$dbk[memo]','$dbk[email]') ",$conn);


mysql_query("insert into min_board_mlist(no, date, date2, date3, ne, ep, je, be, olddate)  values('$dbk[no]','$dbk[date]','$dbk[date2]','$dbk[date3]','$dbk[ne]','$dbk[ep]','$dbk[je]','$dbk[be]','$dbk[olddate]') ",$conn);


mysql_query("insert into min_board_money(no, number, companyn, name, addr, upte, jong, files)  values('$dbk[no]','$dbk[number]','$dbk[companyn]','$dbk[name]','$dbk[addr]','$dbk[upte]','$dbk[jong]','$dbk[files]') ",$conn);


mysql_query("insert into min_board_olddate(olddate, date)  values('$dbk[olddate]','$dbk[date]') ",$conn);

*/
?>

<?

include "foot.php";
?>