<?
include "lib.php";
include "head.php";
?>
<table cellpadding="7" cellspacing="1" id="write1_table" border="0">
<col width="80px" />
<col width="80px" />
  <tr>
    <th colspan="2">삭제하시겠습니까?</th>
  </tr>
  <tr>
    <td><a href="member_info.php" class="view1_button">취소</a></td>
    <td><a href="member_info_del_post.php?no=<?=$no?>" class="view1_button">삭제</a></td>
  </tr>
</table>
<?
include "foot.php";
?>
