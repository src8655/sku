<?
include "lib.php";
include "head.php";

$query = "insert into min_board_jang_member(name, number)
					values('$_REQUEST[name]','$_REQUEST[numbers]')";
mysql_query($query, $connect);
?>
<script>
	location.href='jang_check.php?date=<?=$date?>';
</script>
