<?
include "lib.php";
include "head2.php";

$wheree = "where olddate='$olddate'";

if($Search_text){
  if($Search_mode==1) $tmp = "date";
  if($Search_mode==2) $tmp = "ne";
  if($Search_mode==3) $tmp = "ep";
  if($Search_mode==4) $tmp = "je";
  if($Search_mode==5) $tmp = "be";
  
  if(!$company) {
    $where = "$wheree and $tmp like '%$Search_text%'";
  }else{
    $where = "$wheree and $tmp like '%$Search_text%'";
  }
}else{
$where = "$wheree";
}

$mlistall = selectc("min_board_mlist","$where");

$qmlist = "select * from min_board_mlist $where order by date asc, no asc";
$rmlist = mysql_query($qmlist, $connect);

$ef = "select * from min_board_olddate where olddate='$olddate'";
$df = mysql_query($ef, $connect);
$cf = mysql_fetch_array($df);
?>
<script defer>
function prints() {
factory.printing.leftMargin = "15.0";
factory.printing.topMargin = "25.0";
factory.printing.rightMargin = "15.0";
factory.printing.bottomMargin = "15.0";
factory.printing.header="";
factory.printing.footer="";
factory.printing.portrait=true;
factory.printing.Print(true);
}
function printshide() {
	pppl.style.display = "none";
}
</script>
<a href="#" onclick="printshide();prints();" id="pppl" style="display:block;width:100px;border:1px solid #676767;text-align:center;font-size:15px;margin:0 auto;margin-bottom:10px;padding:10px;"><img src="./images/print_io.jpg" style="border:0px;" /><br />인쇄하기<br /><span style="font-size:12px;color:red;">(페이지 자동조절)</span></a>
<object id="factory" viewastext style="display:none" classid="clsid:1663ed61-23eb-11d2-b92f-008048fdd814" codebase="./adr/smsx.cab#Version=6,3,436,14"></object>
<table cellpadding="5" cellspacing="0" id="print_te" style="font-size:15px;">
<col width="130" />
<col width="170" />
<col width="130" />
<col width="130" />
<col width="130" />
<col width="170" />
	<tr>
		<th colspan="8" height="23px"><?=$cf[date]?> 경비내역 - </span><span style="font-size:13px; color:red;"><?=$mlistall?></span></th>
	</tr>
	<tr>
		<th height="23px">날짜</th>
		<th>내역</th>
		<th>입금</th>
		<th>지출</th>
		<th>잔액</th>
		<th>비고</th>
	</tr>
<?
while($dmlist = mysql_fetch_array($rmlist)) {
$epmje += $dmlist[ep];
$epmje -= $dmlist[je];
?>
	<tr>
		<td align="center" height="23px"><?=$dmlist[date]?></td>
		<td align="center"><?=$dmlist[ne]?></td>
		<td align="right"><?=number_format($dmlist[ep])?></td>
		<td align="right"><?=number_format($dmlist[je])?></td>
		<td align="right"><? if($Search_text) {?>검색은 자동계산이 제한됩니다.<? }else{?><?=number_format($epmje)?><? }?></td>
		<td align="center"><?=$dmlist[be]?></td>
	</tr>
<?
$eps += $dmlist[ep];
$jes += $dmlist[je];
}
?>
	<tr>
		<td height="23px">　</td>
		<td>　</td>
		<td>　</td>
		<td>　</td>
		<td align="center">총잔액</td>
		<td>　</td>
	</tr>
	<tr>
		<td height="23px">　</td>
		<td>　</td>
		<td align="right"><?=number_format($eps)?></td>
		<td align="right"><?=number_format($jes)?></td>
		<td align="right"><? if($Search_text) {?>검색은 자동계산이 제한됩니다.<? }else{?><?=number_format($epmje)?><? }?></td>
		<td>　</td>
	</tr>
</table>
<?
include "foot2.php";
?>
