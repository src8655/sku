<? 
    // 년도를 구하는 부분 
  if(!$year)   $year = date("Y");  
     
    // 월을 구하는 부분    
   if(!$month)    $month = date("n"); 
     
    // 일을 구하는 부분 
   if(!$day)  $day = date("j"); 
      
     
    // 현재월의 1일의 시작요일값을 (0:일, 6:토) 
    // strototime("2006-12-31"); -> 해당일의 타임스템프 값을 반환  
    $start_week = date("w",strtotime("$year-$month-1")); 
     
    // 해당월의 마지막 날자를 구하는 부분 (31)  
    $max = date("t",strtotime("$year-$month-$day")); 
     
?> 

<div align=center> 
     <?=$year?>년 <?=$month?>월  
<table width=500 border=1>      
    <tr> 
        <td> 일 
        <td> 월 
        <td> 화 
        <td> 수 
        <td> 목 
        <td> 금 
        <td> 토  
    <tr> 
<? 
     // 1일 이전의 값을 공백으로 채우기  
    for($i=0;$i<$start_week;$i++){  
?> 
    <td> &nbsp; </td>  
<? }?>  
     
<? 
     // 1일부터 해당월의 마지막날까지 출력하는 부분  
    for($i=1;$i<=$max;$i++){ 
     
     
       $tmp =  date("w",strtotime("$year-$month-".$i)); 
       if($tmp==0) echo "</tr><tr>"; 
     
?> 
        <td> <?=$i?> </td> 
<? 
    } 
?> 
    </tr>  

</table> 

</div> 
