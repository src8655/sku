<?
include "lib.php";
include "head.php";

// 그때그때결제

$gudda = selectc("min_board_admin","where company='$company' and orders='2'");

// 그때그때결제

$query = "select * from min_board_data1 where company='$company' and no='$no'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
$ddmso = $data[money]/1000;

$q = "select * from min_board_admin where company='$company'";
$r = mysql_query($q, $connect);
$admin = mysql_fetch_array($r);


?>
<div style="width:1000px; margin:0 auto;">

<form action="edit1_post.php">
<input type="hidden" value="<?=$company?>" name="company" />
<input type="hidden" value="<?=$no?>" name="no" />
<input type="hidden" value="<?=$page?>" name="page" />
<input type="hidden" value="<?=$olddate?>" name="olddate" />
<input type="hidden" value="<?=$mmmq?>" name="mmmq" />
<table cellpadding="7" cellspacing="1" id="write1_table" border="0" width="1000px">
<col width="70" />
<col width="60" />
<col width="100" />
<col width="80" />
<col width="80" />
<col width="100" />
<col width="100" />
<col width="100" />
<col width="130" />
<col width="70" />
<col width="65" />
  <tr>
    <th colspan="11" align="center"><?=$admin[name]?> <span style="color:red;">수정하기</span></th>
  </tr>
  <tr>
    <th>월 / 일</th>
    <th>요일</th>
    <th>도착지</th>
    <th>차량번호</th>
    <th>이름</th>
    <th>금액</th>
    <th>메모</th>
    <th>기타</th>
    <th>전화번호</th>
    <th>숫자</th>
    <th>완</th>
  </tr>
  <tr>
    <td align="center">
      <input type="text" name="date2" value="<?=$data[date2]?>" style="font-size:15px;padding:2px 0 2px 0;width:30px;border:1px solid #7F9DB9;margin:0 0 2px 0;" />
      월
      <input type="text" name="date3" value="<?=$data[date3]?>" style="font-size:15px;padding:2px 0 2px 0;width:30px;border:1px solid #7F9DB9;" />
      일
    </td>
    <td align="center"><input type="text" name="yo" class="write1_input" style="font-size:15px;padding:2px 0 2px 0;" value="<?=$data[yo]?>" /></td>
    <td align="center"><input type="text" name="ddo" class="write1_input" style="font-size:15px;padding:2px 0 2px 0;" value="<?=$data[ddo]?>" /></td>
    <td align="center"><input type="text" name="number" class="write1_input" style="font-size:15px;padding:2px 0 2px 0;" value="<?=$data[number]?>" /></td>
    <td align="center"><input type="text" name="name" class="write1_input" style="font-size:15px;padding:2px 0 2px 0;" value="<?=$data[name]?>" /></td>
    <td align="right"><input type="text" name="money" style="width:40px;font-size:15px;padding:2px 0 2px 0;" value="<?=$ddmso?>" />,000<br />
    
      <input type="checkbox" name="virtualmoney" value="1" <? if($data[virtualmoney] == 1) {?>checked<? }?> />
      <span style="color:red;font-size:15px;font-weight:bold;">[착불]</span>
    </td>
    
    <td align="center"><input type="text" name="memo1" class="write1_input" style="font-size:15px;padding:2px 0 2px 0;" value="<?=$data[memo1]?>" /></td>
    <td align="center">
    	<input type="text" name="memo2" class="write1_input" value="<?=$data[memo2]?>" style="font-size:15px;padding:2px 0 2px 0;" />
    	<? if($gudda == 1) {?>
    	<br /> 입금체크<input type="checkbox" name="memocc" value="1" <? if($data[memocc] == 1) {?>checked<? }?> />
    	<? }?>
    </td>
    <td align="center"><input type="text" name="phone" class="write1_input" style="font-size:15px;padding:2px 0 2px 0;" value="<?=$data[phone]?>" /></td>
    <td align="center"><input type="text" name="secrets" class="write1_input" style="width:40px;font-size:15px;padding:2px 0 2px 0;" value="<?=$data[secrets]?>" /></td>
    <td align="center"><input type="checkbox" name="wan" <? if($data[wan] == "(완)") {?>checked<? }?> /><br /><input type="text" name="wandate" style="width:35px;font-size:15px;padding:2px 0 2px 0;" value="<?=$data[wandate]?>" /></td>
  </tr>
  <tr>
    <td align="center"><a href="view1.php?company=<?=$company?>&olddate=<?=$olddate?>&page=<?=$page?>&mmmq=<?=$mmmq?>" class="view1_button">취소</a></td>
    <td colspan="10" align="center"><input type="submit" value="수정하기" class="view1_button" /></td>
  </tr>
</table>
</form>
</div>
<?
include "foot.php";
?>
