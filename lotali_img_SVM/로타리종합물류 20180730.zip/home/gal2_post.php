<?
include "lib.php";
include "head.php";

if(!$memo) {
	echo("
		<script>
			window.alert('내용을 입력해주세요.')
			history.go(-1)
		</script>
	");
	exit;
}

$query = "insert into min_board_cal(memo, date)
					values('$_REQUEST[memo]','$_REQUEST[date]')";
mysql_query($query, $connect);
?>
<script>
	location.href='gal2.php?years=<?=$years?>&mons=<?=$mons?>';
</script>
