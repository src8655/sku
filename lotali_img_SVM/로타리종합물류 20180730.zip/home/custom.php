<?
$dates1pp = date("Y");
$dates2pp = date("m");
$dates3pp = date("d");
$dates4pp = date("h");
$dates5pp = date("i");

$_REQUEST[ipspp] = $_SERVER["REMOTE_ADDR"];

$_REQUEST[datespp] = $dates1pp."-".$dates2pp."-".$dates3pp." ".$dates4pp.":".$dates5pp;
$_REQUEST[sessionspp] = session_id();

$qcustom1 = "select * from min_board_custom where date='$_REQUEST[datespp]' and session='$_REQUEST[sessionspp]'";
$rcustom1 = mysql_query($qcustom1, $connect);
$dcustom1 = mysql_num_rows($rcustom1);

if(!$_SESSION[user_id]) {
$_REQUEST[namespp] = "손님";
}else{
$_REQUEST[namespp] = "관리자";
}

if($dcustom1 == 0) {
$qcustom2 = "insert into min_board_custom(name, ip, date, session)
							values('$_REQUEST[namespp]','$_REQUEST[ipspp]','$_REQUEST[datespp]','$_REQUEST[sessionspp]')";
mysql_query($qcustom2, $connect);
}
$qcustom3 = "delete from min_board_custom where date!='$_REQUEST[datespp]'";
mysql_query($qcustom3, $connect);

$qcustom5 = "select * from min_board_custom where date='$_REQUEST[datespp]'";
$rcustom5 = mysql_query($qcustom5, $connect);
?>
	<div style="overflow:scroll;overflow-x:hidden;float:left;margin:8px 0 0 10px;border:0px solid #c4c4c4;font-size:12px;font-family:'Arial';width:170px;height:50px;padding:5px;">
<?
while($dcustom5 = mysql_fetch_array($rcustom5)) {
?>
		<?=$dcustom5[name]?> <?=$dcustom5[ip]?><br />
<?
}
?>
	</div>
