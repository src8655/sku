<?
include "lib.php";
include "head.php";

$query = "delete from min_board_mail_list where no='$no'";
mysql_query($query, $connect);
?>
<script>
	location.href="mail_list.php";
</script>
<?
include "foot.php";
?>
