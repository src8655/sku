<?
include "lib.php";
include "head.php";

$_REQUEST[checks] = "1";

$_REQUEST[checksdate] = "";

$query = "update min_board_memo set
          memo='$_REQUEST[memo]',
          checks='$_REQUEST[checks]',
          checksdate='$_REQUEST[checksdate]' where no='$no'";
mysql_query($query, $connect);
?>
<script>
  location.href='memo_list.php?olddate=<?=$olddate?>';
</script>
