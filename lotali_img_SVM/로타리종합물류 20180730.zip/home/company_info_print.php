<?
include "lib.php";
include "head2.php";


$query = "select * from min_board_info $where order by company asc";
$result = mysql_query($query, $connect);
?>
<script defer>
function prints() {
factory.printing.leftMargin = "7.0";
factory.printing.topMargin = "25.0";
factory.printing.rightMargin = "7.0";
factory.printing.bottomMargin = "7.0";
factory.printing.header="";
factory.printing.footer="";
factory.printing.portrait=true;
factory.printing.Print(true);
}
function printshide() {
	pppl.style.display = "none";
}
</script>
<a href="#" onclick="printshide();prints();" id="pppl" style="display:block;width:100px;border:1px solid #676767;text-align:center;font-size:15px;margin:0 auto;margin-bottom:10px;padding:10px;"><img src="./images/print_io.jpg" style="border:0px;" /><br />인쇄하기<br /><span style="font-size:12px;color:red;">(페이지 자동조절)</span></a>
<object id="factory" viewastext style="display:none" classid="clsid:1663ed61-23eb-11d2-b92f-008048fdd814" codebase="./adr/smsx.cab#Version=6,3,436,14"></object>





<table cellpadding="8" cellspacing="0" id="print_te" style="width:100%;">
	<tr>
<?
$tem = 0;
while($data = mysql_fetch_array($result)) {
$tem = $tem+1;
?>
		<td style="font-size:14px;">
			<h1><div style="float:left;width:300px;font-size:20px;"><?=$data[company]?></div></h1><br />
			<p <? if(!$data[addr]) {?>style="display:none;"<? }?>>
				<span style="font-weight:bold;">[지번] 주소</span> : <span style="color:red;font-weight:bold;"><?=$data[addr]?></span>
			</p>
			<p <? if(!$data[addr2]) {?>style="display:none;"<? }?>>
				<span style="font-weight:bold;">[도로명] 주소</span> : <span style="color:blue;font-weight:bold;"><?=$data[addr2]?></span>
			</p>
			<p <? $okl = $data[tel1].$data[tel2].$data[tel3].$data[fax1].$data[fax2].$data[fax3]; if(!$okl) {?>style="display:none;"<? }?>>
				<span <? $okl2 = $data[tel1].$data[tel2].$data[tel3]; if(!$okl2) {?>style="display:none;"<? }?>><span style="font-weight:bold;">전화번호</span> : <?=$data[tel1]?>-<?=$data[tel2]?>-<?=$data[tel3]?> 　　　</span><span <? $okl1 = $data[fax1].$data[fax2].$data[fax3]; if(!$okl1) {?>style="display:none;"<? }?>><span style="font-weight:bold;">FAX번호</span> : <?=$data[fax1]?>-<?=$data[fax2]?>-<?=$data[fax3]?></span>
			</p>
			<p <? if(!$data[email]) {?>style="display:none;"<? }?>>
				<span style="font-weight:bold;">이메일</span> : <?=$data[email]?>
			</p>
			<p <? $okl3 = $data[name].$data[phone1].$data[phone2].$data[phone3]; if(!$okl3) {?>style="display:none;"<? }?>>
				<span style="font-weight:bold;">담당자</span> : <?=$data[name]?> 　　　<span style="font-weight:bold;">담당자번호</span> : <?=$data[phone1]?>-<?=$data[phone2]?>-<?=$data[phone3]?>
			</p>
	<?
	$quer = "select * from min_board_info_plus where id='$data[no]' order by no desc";
	$reer = mysql_query($quer, $connect);
	while($daer = mysql_fetch_array($reer)) {
	?>
	      <p>
	      	<span style="font-weight:bold;">담당자</span> : <?=$daer[name]?> 　　　<span style="font-weight:bold;">담당자번호</span> : <?=$daer[phone1]?>-<?=$daer[phone2]?>-<?=$daer[phone3]?> 　　<a href="company_info_plus_del2.php?no=<?=$daer[no]?>&onon=<?=$data[no]?>&page=<?=$page?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>"><span style="font-weight:normal; font-size:11px; color:red;">(삭제)</span></a>
	      </p>
	<?
	}
	?>
	      <p <? if(!$data[memo]) {?>style="display:none;"<? }?>>
	      	<span style="font-weight:bold;">메모</span> : <?=$data[memo]?>
	      </p>
    </td>
    <?
    if($tem == 2) {
    	$tem = 0;
    ?>
  </tr>
  <tr>
  <?
		}
  ?>
<?
}
?>
	</table>
<?
include "foot2.php";
?>
