<?
setcookie("bodybg",$idbb,time()+3860000,"/");
?>
<script type="text/javascript">
self.close();
</script>
