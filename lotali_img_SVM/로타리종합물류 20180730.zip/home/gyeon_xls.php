<?
include "lib.php";
?>


<?
header("Content-Type: application/vnd.ms-excel");
header("Content-Dis: attachment; filename=$i_nvoice.xls");
?>


<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=ProgId content=Excel.Sheet>
<meta name=Generator content="Microsoft Excel 11">
<link rel=File-List href="print1_xls.files/filelist.xml">
<link rel=Edit-Time-Data href="print1_xls.files/editdata.mso">
<link rel=OLE-Object-Data href="print1_xls.files/oledata.mso">
<!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:LastAuthor>윤민호</o:LastAuthor>
  <o:LastPrinted>2014-10-28T12:40:19Z</o:LastPrinted>
  <o:LastSaved>2014-10-28T12:40:21Z</o:LastSaved>
  <o:Version>11.5606</o:Version>
 </o:DocumentProperties>
</xml><![endif]-->
<style>
<!--table
	{mso-displayed-decimal-separator:"\.";
	mso-displayed-thousand-separator:"\,";}
@page
	{margin:1.0in .62in 1.0in .75in;
	mso-header-margin:.5in;
	mso-footer-margin:.5in;}
tr
	{mso-height-source:auto;
	mso-ruby-visibility:none;}
col
	{mso-width-source:auto;
	mso-ruby-visibility:none;}
br
	{mso-data-placement:same-cell;}
.style0
	{mso-number-format:General;
	text-align:general;
	vertical-align:middle;
	white-space:nowrap;
	mso-rotate:0;
	mso-background-source:auto;
	mso-pattern:auto;
	color:windowtext;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:돋움, monospace;
	mso-font-charset:129;
	border:none;
	mso-protection:locked visible;
	mso-style-name:표준;
	mso-style-id:0;}
td
	{mso-style-parent:style0;
	padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:돋움, monospace;
	mso-font-charset:129;
	mso-number-format:General;
	text-align:general;
	vertical-align:middle;
	border:none;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:locked visible;
	white-space:nowrap;
	mso-rotate:0;}
.xl24
	{mso-style-parent:style0;
	text-align:left;
	border-top:1.5pt solid windowtext;
	border-right:1.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl25
	{mso-style-parent:style0;
	text-align:left;
	border-top:none;
	border-right:1.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl26
	{mso-style-parent:style0;
	text-align:left;
	border-top:none;
	border-right:1.5pt solid windowtext;
	border-bottom:1.5pt solid windowtext;
	border-left:none;}
.xl27
	{mso-style-parent:style0;
	font-size:14.0pt;
	font-weight:700;}
.xl28
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:1.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl29
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:1.5pt solid windowtext;
	border-right:1.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl30
	{mso-style-parent:style0;
	text-align:right;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl31
	{mso-style-parent:style0;
	text-align:center;
	border-top:none;
	border-right:1.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl32
	{mso-style-parent:style0;
	text-align:right;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:1.5pt solid windowtext;
	border-left:none;}
.xl33
	{mso-style-parent:style0;
	text-align:center;
	border-top:none;
	border-right:1.5pt solid windowtext;
	border-bottom:1.5pt solid windowtext;
	border-left:none;}
.xl34
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:1.5pt solid windowtext;
	border-right:1.5pt solid windowtext;
	border-bottom:none;
	border-left:1.5pt solid windowtext;}
.xl35
	{mso-style-parent:style0;
	font-size:36.0pt;
	font-weight:700;
	text-align:center;}
.xl36
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:1.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:1.5pt solid windowtext;}
.xl37
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:1.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl38
	{mso-style-parent:style0;
	text-align:left;
	border-top:1.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid black;}
.xl39
	{mso-style-parent:style0;
	text-align:left;
	border-top:1.5pt solid windowtext;
	border-right:1.5pt solid black;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl40
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:1.5pt solid windowtext;}
.xl41
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl42
	{mso-style-parent:style0;
	text-align:left;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid black;}
.xl43
	{mso-style-parent:style0;
	text-align:left;
	border-top:.5pt solid windowtext;
	border-right:1.5pt solid black;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl44
	{mso-style-parent:style0;
	font-size:10.0pt;
	text-align:left;
	border-top:.5pt solid windowtext;
	border-right:1.5pt solid black;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl45
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:1.5pt solid windowtext;
	border-left:1.5pt solid windowtext;}
.xl46
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:1.5pt solid windowtext;
	border-left:none;}
.xl47
	{mso-style-parent:style0;
	text-align:left;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:1.5pt solid windowtext;
	border-left:.5pt solid black;}
.xl48
	{mso-style-parent:style0;
	text-align:left;
	border-top:.5pt solid windowtext;
	border-right:1.5pt solid black;
	border-bottom:1.5pt solid windowtext;
	border-left:none;}
.xl49
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:1.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl50
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:1.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid black;}
.xl51
	{mso-style-parent:style0;
	text-align:center;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:1.5pt solid windowtext;}
.xl52
	{mso-style-parent:style0;
	text-align:center;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl53
	{mso-style-parent:style0;
	text-align:center;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl54
	{mso-style-parent:style0;
	text-align:center;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid black;}
.xl55
	{mso-style-parent:style0;
	text-align:right;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid black;}
.xl56
	{mso-style-parent:style0;
	text-align:right;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl57
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:1.5pt solid windowtext;
	border-left:none;}
.xl58
	{mso-style-parent:style0;
	text-align:center;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:1.5pt solid windowtext;
	border-left:.5pt solid black;}
.xl59
	{mso-style-parent:style0;
	text-align:center;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:1.5pt solid windowtext;
	border-left:none;}
.xl60
	{mso-style-parent:style0;
	text-align:right;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:1.5pt solid windowtext;
	border-left:.5pt solid black;}
.xl61
	{mso-style-parent:style0;
	text-align:right;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:1.5pt solid windowtext;
	border-left:none;}
.xl62
	{mso-style-parent:style0;
	text-align:left;
	border-top:1.5pt solid windowtext;
	border-right:none;
	border-bottom:1.5pt solid windowtext;
	border-left:1.5pt solid windowtext;}
.xl63
	{mso-style-parent:style0;
	text-align:left;
	border-top:1.5pt solid windowtext;
	border-right:none;
	border-bottom:1.5pt solid windowtext;
	border-left:none;}
.xl64
	{mso-style-parent:style0;
	text-align:left;
	border-top:1.5pt solid windowtext;
	border-right:1.5pt solid black;
	border-bottom:1.5pt solid windowtext;
	border-left:none;}
.xl65
	{mso-style-parent:style0;
	font-size:10.0pt;
	text-align:left;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid black;
	white-space:normal;}
ruby
	{ruby-align:left;}
rt
	{color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:돋움, monospace;
	mso-font-charset:129;
	mso-char-type:none;
	display:none;}
-->
</style>
<!--[if gte mso 9]><xml>
 <x:ExcelWorkbook>
  <x:ExcelWorksheets>
   <x:ExcelWorksheet>
    <x:Name>sadflkjl</x:Name>
    <x:WorksheetOptions>
     <x:DefaultRowHeight>270</x:DefaultRowHeight>
     <x:Print>
      <x:ValidPrinterInfo/>
      <x:PaperSizeIndex>9</x:PaperSizeIndex>
      <x:VerticalResolution>0</x:VerticalResolution>
     </x:Print>
     <x:Selected/>
     <x:DoNotDisplayGridlines/>
     <x:Panes>
      <x:Pane>
       <x:Number>3</x:Number>
       <x:ActiveRow>5</x:ActiveRow>
       <x:ActiveCol>8</x:ActiveCol>
       <x:RangeSelection>$I$6:$J$6</x:RangeSelection>
      </x:Pane>
     </x:Panes>
     <x:ProtectContents>False</x:ProtectContents>
     <x:ProtectObjects>False</x:ProtectObjects>
     <x:ProtectScenarios>False</x:ProtectScenarios>
    </x:WorksheetOptions>
   </x:ExcelWorksheet>
  </x:ExcelWorksheets>
  <x:WindowHeight>8670</x:WindowHeight>
  <x:WindowWidth>15360</x:WindowWidth>
  <x:WindowTopX>120</x:WindowTopX>
  <x:WindowTopY>90</x:WindowTopY>
  <x:ProtectStructure>False</x:ProtectStructure>
  <x:ProtectWindows>False</x:ProtectWindows>
 </x:ExcelWorkbook>
</xml><![endif]-->
</head>

<body link=blue vlink=purple>

<table x:str border=0 cellpadding=0 cellspacing=0 width=682 style='border-collapse:
 collapse;table-layout:fixed;width:513pt'>
 <col width=62 style='mso-width-source:userset;mso-width-alt:1763;width:47pt'>
 <col width=34 style='mso-width-source:userset;mso-width-alt:967;width:26pt'>
 <col width=159 style='mso-width-source:userset;mso-width-alt:4522;width:119pt'>
 <col width=5 style='mso-width-source:userset;mso-width-alt:142;width:4pt'>
 <col width=41 style='mso-width-source:userset;mso-width-alt:1166;width:31pt'>
 <col width=69 style='mso-width-source:userset;mso-width-alt:1962;width:52pt'>
 <col width=32 style='mso-width-source:userset;mso-width-alt:910;width:24pt'>
 <col width=75 style='mso-width-source:userset;mso-width-alt:2133;width:56pt'>
 <col width=102 style='mso-width-source:userset;mso-width-alt:2901;width:77pt'>
 <col width=103 style='mso-width-source:userset;mso-width-alt:2929;width:77pt'>
 <tr height=62 style='height:46.5pt'>
  <td colspan=10 height=62 class=xl35 width=682 style='height:46.5pt;
  width:513pt'>견<span style='mso-spacerun:yes'>  </span>적<span
  style='mso-spacerun:yes'>  </span>서</td>
 </tr>
 <tr height=33 style='mso-height-source:userset;height:24.75pt'>
  <td height=33 colspan=10 style='height:24.75pt;mso-ignore:colspan'></td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=2 height=35 class=xl36 style='border-right:.5pt solid black;
  height:26.25pt'>견적 일자</td>
  <td class=xl24><?=$_GET[dates]?></td>
  <td colspan=3 style='mso-ignore:colspan'></td>
  <td colspan=2 class=xl36 style='border-right:.5pt solid black'>상호</td>
  <td colspan=2 class=xl38 style='border-right:1.5pt solid black;border-left:
  none'>로타리종합물류</td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=2 height=35 class=xl40 style='border-right:.5pt solid black;
  height:26.25pt'>업체명</td>
  <td class=xl25><?=$_GET[companys]?></td>
  <td colspan=3 style='mso-ignore:colspan'></td>
  <td colspan=2 class=xl40 style='border-right:.5pt solid black'>등록번호</td>
  <td colspan=2 class=xl42 style='border-right:1.5pt solid black;border-left:
  none'>127-24-44779</td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=2 height=35 class=xl40 style='border-right:.5pt solid black;
  height:26.25pt'>담당자</td>
  <td class=xl25><?=$_GET[names]?></td>
  <td colspan=3 style='mso-ignore:colspan'></td>
  <td colspan=2 class=xl40 style='border-right:.5pt solid black'>주소</td>
  <td colspan=2 class=xl65 width=205 style='border-right:1.5pt solid black;
  border-left:none;width:154pt'>경기도 양주시 은현면 화합로<br>
    <span style='mso-spacerun:yes'> </span>959</td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=2 height=35 class=xl40 style='border-right:.5pt solid black;
  height:26.25pt'>연락처</td>
  <td class=xl25><?=$_GET[phones]?></td>
  <td colspan=3 style='mso-ignore:colspan'></td>
  <td colspan=2 class=xl40 style='border-right:.5pt solid black'>전화번호</td>
  <td colspan=2 class=xl42 style='border-right:1.5pt solid black;border-left:
  none'>031-836-6677~6688</td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=2 height=35 class=xl40 style='border-right:.5pt solid black;
  height:26.25pt'>팩스번호</td>
  <td class=xl25><?=$_GET[faxs]?></td>
  <td colspan=3 style='mso-ignore:colspan'></td>
  <td colspan=2 class=xl40 style='border-right:.5pt solid black'>팩스번호</td>
  <td colspan=2 class=xl42 style='border-right:1.5pt solid black;border-left:
  none'>031-836-8558</td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=2 height=35 class=xl40 style='border-right:.5pt solid black;
  height:26.25pt'>납기</td>
  <td class=xl25><?=$_GET[nabgi]?></td>
  <td colspan=3 style='mso-ignore:colspan'></td>
  <td colspan=2 class=xl45 style='border-right:.5pt solid black'>소장님</td>
  <td colspan=2 class=xl47 style='border-right:1.5pt solid black;border-left:
  none'>010-3349-5262</td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=2 height=35 class=xl45 style='border-right:.5pt solid black;
  height:26.25pt'>지불조건</td>
  <td class=xl26><?=$_GET[jijo]?></td>
  <td colspan=7 style='mso-ignore:colspan'></td>
 </tr>
 <tr height=19 style='height:14.25pt'>
  <td height=19 colspan=10 style='height:14.25pt;mso-ignore:colspan'></td>
 </tr>
 <tr height=25 style='height:18.75pt'>
  <td height=25 class=xl27 colspan=3 style='height:18.75pt;mso-ignore:colspan'>*아래와
  같이 견적합니다.</td>
  <td colspan=7 style='mso-ignore:colspan'></td>
 </tr>
 <tr height=19 style='height:14.25pt'>
  <td height=19 colspan=10 style='height:14.25pt;mso-ignore:colspan'></td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=4 height=35 class=xl36 style='border-right:.5pt solid black;
  height:26.25pt'>내용</td>
  <td colspan=2 class=xl50 style='border-right:.5pt solid black;border-left:
  none'>단가</td>
  <td colspan=2 class=xl50 style='border-right:.5pt solid black;border-left:
  none'>금액</td>
  <td class=xl28>세액</td>
  <td class=xl29>비고</td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=4 height=35 class=xl51 style='border-right:.5pt solid black;
  height:26.25pt'><?=$_GET[memos1]?></td>
  <td colspan=2 class=xl54 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[dans1])?></td>
  <td colspan=2 class=xl55 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[moneys1])?></td>
  <td class=xl30><?=number_format($_GET[se1])?></td>
  <td class=xl31><?=$_GET[bigo1]?></td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=4 height=35 class=xl51 style='border-right:.5pt solid black;
  height:26.25pt'><?=$_GET[memos2]?></td>
  <td colspan=2 class=xl54 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[dans2])?></td>
  <td colspan=2 class=xl55 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[moneys2])?></td>
  <td class=xl30><?=number_format($_GET[se2])?></td>
  <td class=xl31><?=$_GET[bigo2]?></td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=4 height=35 class=xl51 style='border-right:.5pt solid black;
  height:26.25pt'><?=$_GET[memos3]?></td>
  <td colspan=2 class=xl54 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[dans3])?></td>
  <td colspan=2 class=xl55 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[moneys3])?></td>
  <td class=xl30><?=number_format($_GET[se3])?></td>
  <td class=xl31><?=$_GET[bigo3]?></td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=4 height=35 class=xl51 style='border-right:.5pt solid black;
  height:26.25pt'><?=$_GET[memos4]?></td>
  <td colspan=2 class=xl54 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[dans4])?></td>
  <td colspan=2 class=xl55 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[moneys4])?></td>
  <td class=xl30><?=number_format($_GET[se4])?></td>
  <td class=xl31><?=$_GET[bigo4]?></td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=4 height=35 class=xl51 style='border-right:.5pt solid black;
  height:26.25pt'><?=$_GET[memos5]?></td>
  <td colspan=2 class=xl54 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[dans5])?></td>
  <td colspan=2 class=xl55 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[moneys5])?></td>
  <td class=xl30><?=number_format($_GET[se5])?></td>
  <td class=xl31><?=$_GET[bigo5]?></td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=4 height=35 class=xl51 style='border-right:.5pt solid black;
  height:26.25pt'><?=$_GET[memos6]?></td>
  <td colspan=2 class=xl54 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[dans6])?></td>
  <td colspan=2 class=xl55 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[moneys6])?></td>
  <td class=xl30><?=number_format($_GET[se6])?></td>
  <td class=xl31><?=$_GET[bigo6]?></td>
 </tr>
 <tr height=35 style='mso-height-source:userset;height:26.25pt'>
  <td colspan=4 height=35 class=xl45 style='border-right:.5pt solid black;
  height:26.25pt'>합계</td>
  <td colspan=2 class=xl58 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[dans1]+$_GET[dans2]+$_GET[dans3]+$_GET[dans4]+$_GET[dans5]+$_GET[dans6])?></td>
  <td colspan=2 class=xl60 style='border-right:.5pt solid black;border-left:
  none'><?=number_format($_GET[moneys1]+$_GET[moneys2]+$_GET[moneys3]+$_GET[moneys4]+$_GET[moneys5]+$_GET[moneys6])?></td>
  <td class=xl32><?=number_format($_GET[se1]+$_GET[se2]+$_GET[se3]+$_GET[se4]+$_GET[se5]+$_GET[se6])?></td>
  <td class=xl33>　</td>
 </tr>
 <tr height=19 style='height:14.25pt'>
  <td height=19 colspan=10 style='height:14.25pt;mso-ignore:colspan'></td>
 </tr>
 <tr height=19 style='height:14.25pt'>
  <td height=19 colspan=10 style='height:14.25pt;mso-ignore:colspan'></td>
 </tr>
 <tr height=43 style='mso-height-source:userset;height:32.25pt'>
  <td height=43 class=xl34 style='height:32.25pt'>기타</td>
  <td colspan=9 style='mso-ignore:colspan'></td>
 </tr>
 <tr height=103 style='mso-height-source:userset;height:77.25pt'>
  <td colspan=10 height=103 class=xl62 style='border-right:1.5pt solid black;
  height:77.25pt'><?=$_GET[gitars]?></td>
 </tr>
 <tr height=19 style='height:14.25pt'>
  <td height=19 colspan=10 style='height:14.25pt;mso-ignore:colspan'></td>
 </tr>
 <![if supportMisalignedColumns]>
 <tr height=0 style='display:none'>
  <td width=62 style='width:47pt'></td>
  <td width=34 style='width:26pt'></td>
  <td width=159 style='width:119pt'></td>
  <td width=5 style='width:4pt'></td>
  <td width=41 style='width:31pt'></td>
  <td width=69 style='width:52pt'></td>
  <td width=32 style='width:24pt'></td>
  <td width=75 style='width:56pt'></td>
  <td width=102 style='width:77pt'></td>
  <td width=103 style='width:77pt'></td>
 </tr>
 <![endif]>
</table>

</body>

</html>

