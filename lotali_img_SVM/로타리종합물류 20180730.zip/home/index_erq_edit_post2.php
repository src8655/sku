<?
include "lib.php";
include "head.php";

$query = "delete from min_board_admin_check where no='$no'";
mysql_query($query, $connect);
?>

<script>
location.href="index.php?olddate=<?=$olddate?>&erqs=<?=$erqs?>&ipgm=<?=$_GET[ipgm]?>&erq=1";	
</script>
