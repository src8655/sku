<?
include "lib.php";
include "head2.php";
?>
<script defer>
function prints() {
factory.printing.leftMargin = "15.0";
factory.printing.topMargin = "25.0";
factory.printing.rightMargin = "15.0";
factory.printing.bottomMargin = "15.0";
factory.printing.header="";
factory.printing.footer="";
factory.printing.portrait=true;
factory.printing.Print(true);
}
function printshide() {
	pppl.style.display = "none";
}
</script>

<a href="#" onclick="printshide();prints();" id="pppl" style="display:block;width:100px;border:1px solid #676767;text-align:center;font-size:15px;margin:0 auto;margin-bottom:10px;padding:10px;"><img src="./images/print_io.jpg" style="border:0px;" /><br />인쇄하기<br /><span style="font-size:12px;color:red;">(페이지 자동조절)</span></a>
<object id="factory" viewastext style="display:none" classid="clsid:1663ed61-23eb-11d2-b92f-008048fdd814" codebase="./adr/smsx.cab#Version=6,3,436,14"></object>
<table cellpadding="8" cellspacing="0" id="print_te">
<col width="200" />
<col width="200" />
  <tr>
    <th colspan="2">거래처 입금자 목록</th>
  </tr>
<?
$cnt = 1;

$ipgm_result = mysql_query("select * from min_board_admin_damt where ipgm!='' order by no asc",$connect);
while($ipgm_data = mysql_fetch_array($ipgm_result)) {
?>
  <tr>
    <td><?=$cnt?>. <?=$ipgm_data[company]?></td>
    <td>입금자:[<?=$ipgm_data[ipgm]?>]</td>
  </tr>
<?
$cnt++;
}
$ipgm_result = mysql_query("select * from min_board_admin where ipgm!='' order by name asc",$connect);
while($ipgm_data = mysql_fetch_array($ipgm_result)) {
?>
  <tr>
    <td><?=$cnt?>. <?=$ipgm_data[name]?></td>
    <td>입금자:[<?=$ipgm_data[ipgm]?>]</td>
  </tr>
<?
$cnt++;
}
?>
</table>
<?
include "foot2.php";
?>
