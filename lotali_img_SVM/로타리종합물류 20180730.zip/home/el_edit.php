<?
include "lib.php";
include "head.php";

$query = "select * from min_board_el where no='$no'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);

if($data[yos] == "일요일") $ccs = 0;
if($data[yos] == "월요일") $ccs = 1;
if($data[yos] == "화요일") $ccs = 2;
if($data[yos] == "수요일") $ccs = 3;
if($data[yos] == "목요일") $ccs = 4;
if($data[yos] == "금요일") $ccs = 5;
if($data[yos] == "토요일") $ccs = 6;
?>
<form action="el_edit_post.php" method="post" id="writep" name="writepp">
<input type="hidden" name="page" value="<?=$page?>" />
<input type="hidden" name="no" value="<?=$no?>" />
<table cellpadding="6" cellspacing="1" width="1000px" id="write1_table" style="margin-bottom:10px;font-size:17px;">
<col width="200" />
<col width="" />
<col width="150" />
<col width="150" />
	<tr>
		<th colspan="2">수정하기</th>
	</tr>
	<tr>
		<th>번호</th>
		<th>날짜</th>
	</tr>
	<tr>
		<th>수정하기</th>
		<td align="center" style="font-weight:bold;">
			<?=$data[date]?>
			<select name="date5w" style="font-size:17px;">
				<?
				for($i=0;$i<7;$i++) {
				if($i==0) $yos="일요일";
				if($i==1) $yos="월요일";
				if($i==2) $yos="화요일";
				if($i==3) $yos="수요일";
				if($i==4) $yos="목요일";
				if($i==5) $yos="금요일";
				if($i==6) $yos="토요일";
				?>
				<option value="<?=$yos?>" <? if($i==$ccs){?>selected<? }?>><?=$yos?></option>
				<? }?>
			</select>
			<span style="color:red;">요일만 수정 가능합니다.</span>
		</td>
	</tr>
	<tr>
		<td><a href="el.php?page=<?=$page?>" class="view1_button">취소</a></td>
		<td align="center"><input type="submit" value="수정하기" class="view1_button" style="width:15%;" /></td>
	</tr>
</table>
</form>
<?
include "foot.php";
?>