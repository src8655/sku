<?

if(!$years) {
$years = date("Y");
}
if(!$mons) {
$mons = date("n");
}
if(!$days) {
$days = date("j");
}
$smmmz = date("n",strtotime("$years-$mons-1"));

$max_mons = date("t",strtotime("$years-$mons-1"));

$max_weeks = date("w",strtotime("$years-$mons-1"));

if($mons != 1) {
$cala1 = $years;
$cala2 = $mons-1;
}else{
$cala1 = $years-1;
$cala2 = 12;
}
if($mons != 12) {
$calaa1 = $years;
$calaa2 = $mons+1;
}else{
$calaa1 = $years+1;
$calaa2 = 1;
}
?>
<table cellspacing="0" cellpadding="0" width="288" style="font-size:13px;font-family:'Arial';" id="calse">
<col width="143" />
<col width="143" />
<col width="143" />
<col width="143" />
<col width="143" />
<col width="143" />
<col width="143" />
	<tr>
		<th colspan="7">
			<?=$years?>년 <?=$smmmz?>월
		</th>
	</tr>
	<tr id="timqq">
		<th>일</th>
		<th>월</th>
		<th>화</th>
		<th>수</th>
		<th>목</th>
		<th>금</th>
		<th>토</th>
	</tr>
	<tr>
<?
for($i=0;$i<$max_weeks;$i++) {
?>
		<td>　</td>
<?
}
?>
<?
for($i=1;$i<=$max_mons;$i++) {
$tempszz = date("w",strtotime("$years-$mons-$i"));
if($tempszz == 0) {
?>
	</tr>
	<tr>
<?
}
?>
		<td align="center" height="45px" <? if($mons == date("n")) {if($years == date("Y")) {if($i == $days) {?>style="font-weight:bold;font-size:17px;"<? }}}?>>
			<span <? if($tempszz == 0) {?>style="color:red;"<? }else{if($tempszz == 6) {?>style="color:blue;"<? }}?>><?=$i?></span>
			<? if($mons == date("n")) {if($years == date("Y")) {if($i == $days) {?>
			<? }}}?>
		</td>
<?
}
$mmmax1 = date("w",strtotime("$years-$mons-$max_mons"));
$mmmax2 = 6-$mmmax1;
for($i=1;$i<=$mmmax2;$i++) {
?>
		<td>　</td>
<?
}
?>
	</tr>
</table>
