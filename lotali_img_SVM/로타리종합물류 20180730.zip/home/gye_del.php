<?
include "lib.php";
include "head.php";

$query = "select * from min_board_gye where no='$no'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);
?>
<table cellpadding="7" cellspacing="1" width="1000px" id="write1_table" border="0" style="margin-bottom:10px;">
<col width="100" />
<col width="100" />
<col width="100" />
<col width="100" />
<col width="450" />
	<tr>
		<th>메모</th>
		<th>이름</th>
		<th>차량번호</th>
		<th>은행</th>
		<th>계좌번호</th>
	</tr>
	<tr>
		<td align="center"><?=$data[memo]?></td>
		<td align="center"><?=$data[name]?></td>
		<td align="center"><?=$data[number]?></td>
		<td align="center"><?=$data[bank]?></td>
		<td align="center"><?=$data[gye]?></td>
	</tr>
</table>
<table cellpadding="7" cellspacing="1" id="write1_table" border="0" style="margin-bottom:10px;">
	<tr>
		<th colspan="2"><span style="color:red;">위 내용을 삭제하겠습니까?</span></th>
	</tr>
	<tr>
		<td><a href="gye.php?company=<?=$company?>" class="view1_button">취소</a></td>
		<td><a href="gye_del_post.php?company=<?=$company?>&no=<?=$no?>" class="view1_button">삭제</a></td>
	</tr>
</table>
<?
include "foot.php";
?>
