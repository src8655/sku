<?
define('FPDF_FONTPATH','./mpdf/font/');  
require_once './mpdf/mpdf.php';
 
// 함수의 원형 : function mPDF($mode='',$format='A4',$default_font_size=0,$default_font='',$mgl=15,$mgr=15,$mgt=16,$mgb=16,$mgh=9,$mgf=9, $orientation='P')
$pdf = new mPDF('ko');


ob_start(); 
?>
<?
include "lib.php";
include "head2.php";

if($olddate) {
$ef = "select * from min_board_olddate where olddate='$olddate'";
$df = mysql_query($ef, $connect);
$cf = mysql_fetch_array($df);
}else{}
$eheight = "25px";
?>
<?
$qeps = "select * from min_board_ep where olddate='$olddate'";
$reps = mysql_query($qeps, $connect);
$deps = mysql_num_rows($reps);
?>
<table cellpadding="3" cellspacing="0" id="print_a" style="font-size:13px;">
<col width="110">
<col width="90">
<col width="120">
<col width="90">
<col width="90">
<col width="110">
<col width="100">
	<tr>
    <th colspan="7" height="<?=$eheight?>" style="font-size:17px;">
			<?=$cf[date]?> 입금현황  - <span style="color:red;font-family:'Arial';"><?=$deps?></span>
    </th>
	</tr>
	<tr>
		<th height="<?=$eheight?>" width="110">상호</th>
		<th width="90">발행 총금액</th>
		<th width="120">세금계산서</th>
		<th width="90">공급가액</th>
		<th width="90">세액</th>
		<th width="110">입금확인</th>
		<th width="100">메모</th>
	</tr>
<?

$tal1 = 0;
$tal2 = 0;

$qmmeq211 = "select count(*) from min_board_ep where olddate='$olddate' and orders='11'";
$qmmer211 = mysql_query($qmmeq211, $connect);
$qmmed211 = mysql_fetch_array($qmmer211);
if($qmmed211[0] == 0) {
}else{
?>
	<tr>
		<th colspan="7" height="<?=$eheight?>">담터</th>
	</tr>
<?
$qep211 = "select * from min_board_ep where olddate='$olddate' and orders='11' order by name asc";
$rep211 = mysql_query($qep211, $connect);
while($dep211 = mysql_fetch_array($rep211)) {
if($dep211[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep211[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
	<tr>
		<th height="<?=$eheight?>" <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?> id="sdf"><?=$dep211[name]?></th>
		<td <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><?=number_format($dep211[money])?><? }else{?><?=number_format($dep211[money]+$dep211[moneys])?><? }?></td>
		<td <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?> align="center"><?=$depmom?> <?=$depmom2?></th>
		<td <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?> align="right"><?=number_format($dep211[money])?></td>
		<td <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?> align="right"><<? if(!$depmom&&!$depmom2){?><? }else{?><?=number_format($dep211[moneys])?><? }?></td>
		<td align="center" <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?>><? if($dep211[date]) {if($dep211[date2]) {?><?=$dep211[date]?>월<?=$dep211[date2]?>일 입금<? }}?></td>
		<td align="center" <? if($empq == $dep211[no]) {?> style="background:yellow;"<? }?>><?=$dep211[memo]?></td>
	</tr>
<?
$tal1 += $dep211[money];
if($depmom||$depmom2)
$tal2 += $dep211[moneys];
}}
?>
<?
$qmmeq2 = "select count(*) from min_board_ep where olddate='$olddate' and orders='1'";
$qmmer2 = mysql_query($qmmeq2, $connect);
$qmmed2 = mysql_fetch_array($qmmer2);
if($qmmed2[0] == 0) {
}else{
?>
	<tr>
		<th colspan="7" height="<?=$eheight?>">한달결제</th>
	</tr>
<?
$qep2 = "select * from min_board_ep where olddate='$olddate' and orders='1' order by name asc";
$rep2 = mysql_query($qep2, $connect);
while($dep2 = mysql_fetch_array($rep2)) {
if($dep2[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep2[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
	<tr>
		<th height="<?=$eheight?>" <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?> id="sdf"><?=$dep2[name]?></th>
		<td <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><?=number_format($dep2[money])?><? }else{?><?=number_format($dep2[money]+$dep2[moneys])?><? }?></td>
		<td <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?> align="center"><?=$depmom?> <?=$depmom2?></th>
		<td <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?> align="right"><?=number_format($dep2[money])?></td>
		<td <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><? }else{?><?=number_format($dep2[moneys])?><? }?></td>
		<td align="center" <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?>><? if($dep2[date]) {if($dep2[date2]) {?><?=$dep2[date]?>월<?=$dep2[date2]?>일 입금<? }}?></td>
		<td align="center" <? if($empq == $dep2[no]) {?> style="background:yellow;"<? }?>><?=$dep2[memo]?></td>
	</tr>
<?
$tal1 += $dep2[money];
if($depmom||$depmom2)
$tal2 += $dep2[moneys];
}}
?>
<?
$qmmeq22 = "select count(*) from min_board_ep where olddate='$olddate' and orders='2'";
$qmmer22 = mysql_query($qmmeq22, $connect);
$qmmed22 = mysql_fetch_array($qmmer22);
if($qmmed22[0] == 0) {
}else{
?>
	<tr>
		<th colspan="7" height="<?=$eheight?>">그때그때결제</th>
	</tr>
<?
$qep22 = "select * from min_board_ep where olddate='$olddate' and orders='2' order by name asc";
$rep22 = mysql_query($qep22, $connect);
while($dep22 = mysql_fetch_array($rep22)) {
if($dep22[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep22[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
	<tr>
		<th height="<?=$eheight?>" <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?> id="sdf"><?=$dep22[name]?></th>
		<td <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><?=number_format($dep22[money])?><? }else{?><?=number_format($dep22[money]+$dep22[moneys])?><? }?></td>
		<td <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?> align="center"><?=$depmom?> <?=$depmom2?></th>
		<td <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?> align="right"><?=number_format($dep22[money])?></td>
		<td <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><? }else{?><?=number_format($dep22[moneys])?><? }?></td>
		<td align="center" <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?>><? if($dep22[date]) {if($dep22[date2]) {?><?=$dep22[date]?>월<?=$dep22[date2]?>일 입금<? }}?></td>
		<td align="center" <? if($empq == $dep22[no]) {?> style="background:yellow;"<? }?>><?=$dep22[memo]?></td>
	</tr>
<?
$tal1 += $dep22[money];
if($depmom||$depmom2)
$tal2 += $dep22[moneys];
}}
?>
<?
$qmmeq23 = "select count(*) from min_board_ep where olddate='$olddate' and orders='3'";
$qmmer23 = mysql_query($qmmeq23, $connect);
$qmmed23 = mysql_fetch_array($qmmer23);
if($qmmed23[0] == 0) {
}else{
?>
	<tr>
		<th colspan="7" height="<?=$eheight?>">기사에게입금</th>
	</tr>
<?
$qep23 = "select * from min_board_ep where olddate='$olddate' and orders='3' order by name asc";
$rep23 = mysql_query($qep23, $connect);
while($dep23 = mysql_fetch_array($rep23)) {
if($dep23[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep23[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
	<tr>
		<th height="<?=$eheight?>" <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?> id="sdf"><?=$dep23[name]?></th>
		<td <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><?=number_format($dep23[money])?><? }else{?><?=number_format($dep23[money]+$dep23[moneys])?><? }?></td>
		<td <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?> align="center"><?=$depmom?> <?=$depmom2?></th>
		<td <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?> align="right"><?=number_format($dep23[money])?></td>
		<td <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><? }else{?><?=number_format($dep23[moneys])?><? }?></td>
		<td align="center" <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?>><? if($dep23[date]) {if($dep23[date2]) {?><?=$dep23[date]?>월<?=$dep23[date2]?>일 입금<? }}?></td>
		<td align="center" <? if($empq == $dep23[no]) {?> style="background:yellow;"<? }?>><?=$dep23[memo]?></td>
	</tr>
<?
$tal1 += $dep23[money];
if($depmom||$depmom2)
$tal2 += $dep23[moneys];
}}
?>
<?
$qmmeq20 = "select count(*) from min_board_ep where olddate='$olddate' and orders='0'";
$qmmer20 = mysql_query($qmmeq20, $connect);
$qmmed20 = mysql_fetch_array($qmmer20);
if($qmmed20[0] == 0) {
}else{
?>
	<tr>
		<th colspan="7" height="<?=$eheight?>">정렬 지정하지 않음</th>
	</tr>
<?
$qep20 = "select * from min_board_ep where olddate='$olddate' and orders='0' order by name asc";
$rep20 = mysql_query($qep20, $connect);
while($dep20 = mysql_fetch_array($rep20)) {
if($dep20[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep20[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
	<tr>
		<th height="<?=$eheight?>" <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?> id="sdf"><?=$dep20[name]?></th>
		<td <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><?=number_format($dep20[money])?><? }else{?><?=number_format($dep20[money]+$dep20[moneys])?><? }?></td>
		<td <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?> align="center"><?=$depmom?> <?=$depmom2?></th>
		<td <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?> align="right"><?=number_format($dep20[money])?></td>
		<td <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?> align="right"><? if(!$depmom&&!$depmom2){?><? }else{?><?=number_format($dep20[moneys])?><? }?></td>
		<td align="center" <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?>><? if($dep20[date]) {if($dep20[date2]) {?><?=$dep20[date]?>월<?=$dep20[date2]?>일 입금<? }}?></td>
		<td align="center" <? if($empq == $dep20[no]) {?> style="background:yellow;"<? }?>><?=$dep20[memo]?></td>
	</tr>
<?
$tal1 += $dep20[money];
if($depmom||$depmom2)
$tal2 += $dep20[moneys];
}}
?>
	<tr>
		<td align="right" height="<?=$eheight?>">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
	</tr>
	<tr id="qq">
		<td align="right" height="<?=$eheight?>">&nbsp;</td>
		<td align="right"><?=number_format($tal1+$tal2)?></td>
		<td align="right">&nbsp;</td>
		<td align="right"><?=number_format($tal1)?></td>
		<td align="right"><?=number_format($tal2)?></td>
		<td align="right">&nbsp;</td>
		<td align="right">&nbsp;</td>
	</tr>
</table>
<?
include "foot2.php";
?>

<?
$html=ob_get_contents(); 
ob_end_clean(); 
$html = iconv("UTF-8","UTF-8",$html);

$pdf->SetTopMargin(25);
$pdf->SetFont('Arial');
$pdf->Bookmark("로타리장부",0);
// $pdf->SetDisplayMode('fullpage');   // pdf가 열릴때 창크기에 맞게 보여지도록 함. 이부분이 주석처리되거나 삭제되면 창크기에 맞춰지지 않고 pdf Viewer의 설정을 따르게됨
 
$pdf->WriteHTML($html);
$pdf->Output();     // 웹상에서 열림
?>
