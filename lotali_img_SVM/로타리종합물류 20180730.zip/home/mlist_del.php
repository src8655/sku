<?
include "lib.php";
include "head.php";

$qmlist = "select * from min_board_mlist where no='$no' and olddate='$olddate'";
$rmlist = mysql_query($qmlist, $connect);
$dmlist = mysql_fetch_array($rmlist);
?>
<table cellpadding="5" cellspacing="1" id="write1_table" border="0" width="1000px" style="margin-bottom:10px;font-size:15px;font-family:'Arial';">
<col width="130" />
<col width="170" />
<col width="130" />
<col width="130" />
<col width="130" />
<col width="170" />
	<tr>
		<th>날짜</th>
		<th>내역</th>
		<th>입금</th>
		<th>지출</th>
		<th>잔액</th>
		<th>비고</th>
	</tr>
	<tr id="qq">
		<td align="center"><?=$dmlist[date]?></td>
		<td align="center"><?=$dmlist[ne]?></td>
		<td align="right"><?=number_format($dmlist[ep])?></td>
		<td align="right"><?=number_format($dmlist[je])?></td>
		<td align="center">자동계산</td>
		<td align="center"><?=$dmlist[be]?></td>
	</tr>
</table>
<table cellpadding="7" cellspacing="1" id="write1_table" border="0">
<col width="80" />
<col width="80" />
  <tr>
    <th colspan="2">위 내용을 삭제합니다</th>
  </tr>
  <tr>
    <td align="center"><a href="mlist.php?olddate=<?=$olddate?>" class="view1_button">취소</a></td>
    <td align="center"><a href="mlist_del_post.php?no=<?=$no?>&olddate=<?=$olddate?>" class="view1_button">삭제</a></td>
  </tr>
</table>
<?
include "foot.php";
?>
