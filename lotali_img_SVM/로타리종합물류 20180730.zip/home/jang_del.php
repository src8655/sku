<?
include "lib.php";
include "head.php";

$query = "select * from min_board_jang_member order by name asc";
$result = mysql_query($query, $connect);
?>
<table cellpadding="5" cellspacing="1" width="500px" id="write1_table" border="0" style="margin-bottom:10px;font-size:13px;">
	<tr>
		<td><a href="jang_check.php?date=<?=$date?>" class="view1_button">뒤로가기</a></td>
	</tr>
</table>
<table cellpadding="5" cellspacing="1" width="500px" id="write1_table" border="0" style="margin-bottom:10px;font-size:13px;">
<col width="200" />
<col width="200" />
<col width="100" />
	<tr>
		<th colspan="3" style="color:red;">회원 삭제모드</th>
	</tr>
	<tr>
		<th>이름</th>
		<th>차량번호</th>
		<th>관리</th>
	</tr>
<?
while($data = mysql_fetch_array($result)) {
?>
	<tr>
		<td align="center"><?=$data[name]?></td>
		<td align="center"><?=$data[number]?></td>
		<td align="center"><a href="jang_del_post.php?date=<?=$date?>&no=<?=$data[no]?>" class="view1_button">삭제하기</a></td>
	</tr>
<?
}
?>
</table>
<?
include "foot.php";
?>
