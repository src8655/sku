<?
include "lib.php";
include "head.php";
?>
<div id="mail_left">
	<h1>메일메뉴</h1>
	<ul>
		<li><a href="mail.php">메일쓰기</a></li>
		<li><a href="mail.php?sendmail=1">보낸메일함</a></li>
		<li><a href="mail_list.php">회사이메일목록</a></li>
	</ul>
</div>
<?
if(!$sendmail) {
?>
<div class="mail_t">
	메일쓰기 <span style="font-weight:normal;font-size:13px;">메일작성 페이지 입니다. 다음(@hanmail.net)메일은 스팸메일로 도착할수 있습니다.</span>
</div>
<form action="mail_post.php" method="post" enctype="multipart/form-data">
<table cellpadding="10" cellspacing="0" width="790px" id="write1_tablec" style="font-size:17px;float:right;">
<col width="150px" />
<col width="200px" />
<col width="440px" />
	<tr>
		<th>메일보내기</th>
		<th align="left" colspan="2"><input type="submit" value="보내기" style="height:30px;border:1px solid #888888;" /></th>
	</tr>
	<tr>
		<th>받는사람</th>
		<td>
			<input type="text" name="ba" value="<?=$mail_ba?>" />
		</td>
		<td>
			<div id="mailgom" style="display:block;overflow:hidden;">
			<a class="view1_button" style="width:20%;float:left;">회사검색</a>
				<div id="mail_aa" style="display:none;margin:0px;">
					<table cellpadding="5" cellspacing="0" width="300" id="write1_tablec">
						<col width="100px" />
						<col width="200px" />
	<?
	$qmail = "select * from min_board_mail_list order by company asc";
	$rmail = mysql_query($qmail, $connect);
	while($dmail = mysql_fetch_array($rmail)) {
	?>
						<tr>
							<td><a href="mail.php?mail_ba=<?=$dmail[email]?>&subjects=<?=urlencode($_GET[subjects])?>&links=<?=urlencode($_GET[links])?>&links2=<?=urlencode($_GET[links2])?>"><?=$dmail[company]?></a></td>
							<td><a href="mail.php?mail_ba=<?=$dmail[email]?>&subjects=<?=urlencode($_GET[subjects])?>&links=<?=urlencode($_GET[links])?>&links2=<?=urlencode($_GET[links2])?>"><?=$dmail[email]?></a></td>
						</tr>
	<?
	}
	?>
					</table>
				</div>
				<p style="line-height:30px;margin:0 0 0 10px;padding:0px;float:left;"></p>
			</div>
		</td>
	</tr>
	<tr>
		<th>보내는사람</th>
		<td colspan="2"><input type="text" name="bo" value="qwq6735@naver.com" /></td>
	</tr>
	<tr>
		<th>제목</th>
		<td colspan="2"><input type="text" name="subject" style="width:99%;" value="<?=$_GET[subjects]?>" /></td>
	</tr>
	<tr>
		<th>내용</th>
		<td colspan="2">
		  <textarea name="memo"><? if($_GET[links]!="") {?>엑셀파일로다운 : <?=$_GET[links]?><? }?></textarea>
		</td>
	</tr>
</table>
</form>
<?
}else{
$querys2 = "select * from min_board_mail";
$results2 = mysql_query($querys2, $connect);
$datas2 = mysql_num_rows($results2);
$couuuu = $datas2;

if(!$page) {
$page = "1";
}
$pagenum1 = "10";
$pagenum2 = ($pagenum1*$page)-$pagenum1;

$paging = ceil($couuuu/$pagenum1);

$limits = "limit $pagenum2, $pagenum1";

$query = "select * from min_board_mail order by no desc $limits";
$result = mysql_query($query, $connect);
?>
<div class="mail_t">
	보낸메일함 <span style="font-weight:normal;font-size:13px;">보낸메일함 페이지 입니다. 수신확인은 받는사람의 환경에 따라 작동여부가 달라집니다.</span>
</div>
<table cellpadding="5" cellspacing="0" width="790px" id="write1_tablec" style="font-size:17px;float:right;">
<col width="55" />
<col width="230" />
<col width="90" />
<col width="90" />
	<tr>
		<th height="30">번호</th>
		<th>제목</th>
		<th>받는사람</th>
		<th>보낸날짜</th>
	</tr>
<?
$cnt = 1;
while($data = mysql_fetch_array($result)) {
?>
	<tr>
		<td align="center" height="25"><?=$couuuu-$cnt-$pagenum2+1?></td>
		<td align="left"><a href="mail_view.php?sendmail=1&no=<?=$data[no]?>"><?=$data[subject]?></a></td>
		<td align="center"><?=$data[ba]?></td>
		<td align="center"><?=$data[date]?></td>
	</tr>
<?
$cnt++;
}
?>
	<tr>
		<td colspan="6" align="center" style="font-size:15px;">
			<a href="mail.php?sendmail=1&page=1"><<</a>
<?
$a1 = $page-5;
$a2 = $page+6;

for($i=$a1;$i<$a2;$i++) {
if($i<1) {
}else{
if($i>$paging) {
}else{
?>
			<a href="mail.php?sendmail=1&page=<?=$i?>" <? if($i == $page) {?>style="font-weight:bold;color:red;"<? }?>>[<?=$i?>]</a>
<?
}}}
?>
			<a href="mail.php?sendmail=1&page=<?=$paging?>">>></a>
		</td>
	</tr>
</table>
<?
}
include "foot.php";
?>
