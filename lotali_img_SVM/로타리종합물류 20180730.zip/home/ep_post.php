<?
include "lib.php";
include "head.php";

if(!$money) {
	echo("
		<script>
			window.alert('공급가액을 입력해주세요.')
			history.go(-1)
		</script>
	");
	exit;
}

$ali = explode("//",$cominfo);

$_REQUEST[olddate] = $ali[0];
$_REQUEST[company] = $ali[1];
$_REQUEST[name] = $ali[2];
$_REQUEST[orders] = $ali[3];


$_REQUEST[moneymm] = $money;

$_REQUEST[moneys] = $_REQUEST[moneymm]/10;
$_REQUEST[ses] = $_REQUEST[moneymm]+$_REQUEST[moneys];

if(!$checks) {
$_REQUEST[checks] = "1";
}
if(!$checks2) {
$_REQUEST[checks2] = "1";
}

$query = "insert into min_board_ep(olddate, company, date, name, se1, checks, money, moneys, checks2, memo, date2, orders)
					values('$_REQUEST[olddate]','$_REQUEST[company]','$_REQUEST[date2]','$_REQUEST[name]','$_REQUEST[ses]','$_REQUEST[checks]','$_REQUEST[moneymm]','$_REQUEST[moneys]','$_REQUEST[checks2]','$_REQUEST[memo]','$_REQUEST[date3]','$_REQUEST[orders]')";
mysql_query($query, $connect);
?>
<script>
location.href='ep.php?olddate=<?=$_REQUEST[olddate]?>';
</script>
