<?
include "lib.php";
include "head.php";

$memos = $_REQUEST[memo];

if($is == "a1") {
if(!$memo) {
$a1 = "(완)";
}else{
$a1 = "(완)<br />$memos";
}
$a2 = "";
$a3 = "";
$a4 = "";
$a5 = "";
$a6 = "";
$a7 = "";
$a8 = "";
$a9 = "";
$a10 = "";
$a11 = "";
$a12 = "";
}else{
if($is == "a2") {
$a1 = "";
if(!$memo) {
$a2 = "(완)";
}else{
$a2 = "(완)<br />$memos";
}
$a3 = "";
$a4 = "";
$a5 = "";
$a6 = "";
$a7 = "";
$a8 = "";
$a9 = "";
$a10 = "";
$a11 = "";
$a12 = "";
}else{
if($is == "a3") {
$a1 = "";
$a2 = "";
if(!$memo) {
$a3 = "(완)";
}else{
$a3 = "(완)<br />$memos";
}
$a4 = "";
$a5 = "";
$a6 = "";
$a7 = "";
$a8 = "";
$a9 = "";
$a10 = "";
$a11 = "";
$a12 = "";
}else{
if($is == "a4") {
$a1 = "";
$a2 = "";
$a3 = "";
if(!$memo) {
$a4 = "(완)";
}else{
$a4 = "(완)<br />$memos";
}
$a5 = "";
$a6 = "";
$a7 = "";
$a8 = "";
$a9 = "";
$a10 = "";
$a11 = "";
$a12 = "";
}else{
if($is == "a5") {
$a1 = "";
$a2 = "";
$a3 = "";
$a4 = "";
if(!$memo) {
$a5 = "(완)";
}else{
$a5 = "(완)<br />$memos";
}
$a6 = "";
$a7 = "";
$a8 = "";
$a9 = "";
$a10 = "";
$a11 = "";
$a12 = "";
}else{
if($is == "a6") {
$a1 = "";
$a2 = "";
$a3 = "";
$a4 = "";
$a5 = "";
if(!$memo) {
$a6 = "(완)";
}else{
$a6 = "(완)<br />$memos";
}
$a7 = "";
$a8 = "";
$a9 = "";
$a10 = "";
$a11 = "";
$a12 = "";
}else{
if($is == "a7") {
$a1 = "";
$a2 = "";
$a3 = "";
$a4 = "";
$a5 = "";
$a6 = "";
if(!$memo) {
$a7 = "(완)";
}else{
$a7 = "(완)<br />$memos";
}
$a8 = "";
$a9 = "";
$a10 = "";
$a11 = "";
$a12 = "";
}else{
if($is == "a8") {
$a1 = "";
$a2 = "";
$a3 = "";
$a4 = "";
$a5 = "";
$a6 = "";
$a7 = "";
if(!$memo) {
$a8 = "(완)";
}else{
$a8 = "(완)<br />$memos";
}
$a9 = "";
$a10 = "";
$a11 = "";
$a12 = "";
}else{
if($is == "a9") {
$a1 = "";
$a2 = "";
$a3 = "";
$a4 = "";
$a5 = "";
$a6 = "";
$a7 = "";
$a8 = "";
if(!$memo) {
$a9 = "(완)";
}else{
$a9 = "(완)<br />$memos";
}
$a10 = "";
$a11 = "";
$a12 = "";
}else{
if($is == "a10") {
$a1 = "";
$a2 = "";
$a3 = "";
$a4 = "";
$a5 = "";
$a6 = "";
$a7 = "";
$a8 = "";
$a9 = "";
if(!$memo) {
$a10 = "(완)";
}else{
$a10 = "(완)<br />$memos";
}
$a11 = "";
$a12 = "";
}else{
if($is == "a11") {
$a1 = "";
$a2 = "";
$a3 = "";
$a4 = "";
$a5 = "";
$a6 = "";
$a7 = "";
$a8 = "";
$a9 = "";
$a10 = "";
if(!$memo) {
$a11 = "(완)";
}else{
$a11 = "(완)<br />$memos";
}
$a12 = "";
}else{
if($is == "a12") {
$a1 = "";
$a2 = "";
$a3 = "";
$a4 = "";
$a5 = "";
$a6 = "";
$a7 = "";
$a8 = "";
$a9 = "";
$a10 = "";
$a11 = "";
if(!$memo) {
$a12 = "(완)";
}else{
$a12 = "(완)<br />$memos";
}
}else{
}}}}}}}}}}}}

$query = "insert into min_board_jang_check(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, date, member)
					values('$a1','$a2','$a3','$a4','$a5','$a6','$a7','$a8','$a9','$a10','$a11','$a12','$_REQUEST[date]','$_REQUEST[members]')";
mysql_query($query, $connect);
?>
<script>
	location.href='jang_check.php?date=<?=$date?>&oldu=1';
</script>
