<?
include "lib.php";
include "head.php";

if(!$memo) {
  echo("
    <script>
      window.alert('내용을 입력해주세요')
      history.go(-1)
    </script>
  ");
  exit;
}

$qnq1 = date("Y");
$qnq2 = date("m");
$qnq3 = date("d");
$qnq4 = date("h");
$qnq5 = date("i");

$_REQUEST[checks] = "1";

$qnqa = $qnq2."/".$qnq3;

$_REQUEST[dates] = $qnqa;
$_REQUEST[ip] = $_SERVER['REMOTE_ADDR'];

$nosi = "1";

$query = "insert into min_board_memo(date, memo, checks, ips)
          values('$_REQUEST[dates]','$_REQUEST[memo]','$_REQUEST[checks]','$_REQUEST[ip]')";
mysql_query($query, $connect);
?>
<script>
  location.href='index.php?olddate=<?=$olddate?>';
</script>
