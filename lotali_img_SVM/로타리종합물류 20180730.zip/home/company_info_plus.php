<?
include "lib.php";
include "head.php";

$query = "insert into min_board_info_plus(name, phone1, phone2, phone3, id)
          values('$_REQUEST[name]','$_REQUEST[phone1]','$_REQUEST[phone2]','$_REQUEST[phone3]','$_REQUEST[id]')";
mysql_query($query, $connect);
?>
<script>
  location.href='company_info.php?onon=<?=$id?>&page=<?=$page?>&Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>#<?=$id?>';
</script>
