<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=$dadmin[name]?></title>
<link rel="stylesheet" type="text/css" href="mmsm.css" />
<link rel="stylesheet" type="text/css" href="./CLEditor/jquery.cleditor.css" />
<link rel="shortcut icon" href="./images/ic_launcher.png" />

<script src="./jquery/jquery-1.4.2.min.js" type="text/javascript"></script>
<script type="text/javascript" src="./alditor/alditor2.js"></script>
<script type="text/javascript">

function submits(aa) {
  if(document.wt_b.subject.value=="") {
    alert("제목을 입력해주세요.");
  }else if(document.wt_b.name.value=="") {
    alert("이름을 입력해주세요.");
  }else if(document.wt_b.passworde.value=="") {
    alert("비멀번호를 입력해주세요.");
  }else if(document.wt_b.memo.value=="") {
    alert("내용을 입력해주세요.");
  }else if(document.wt_b.hiddens.value=="") {
    alert("자동등록방지를 입력해주세요.");
  }else if(document.wt_b.hiddens.value!=aa) {
    alert("자동등록방지가 틀렸습니다.");
  }else{
    document.wt_b.submit();
  }
}
function submits2() {
  if(document.ed_b.subject.value=="") {
    alert("제목을 입력해주세요.");
  }else if(document.ed_b.name.value=="") {
    alert("이름을 입력해주세요.");
  }else if(document.ed_b.passworde.value=="") {
    alert("비멀번호를 입력해주세요.");
  }else if(document.ed_b.memo.value=="") {
    alert("내용을 입력해주세요.");
  }else{
    document.ed_b.submit();
  }
}
function submits3(aa) {
  if(document.cm_b.name.value=="") {
    alert("이름을 입력해주세요.");
  }else if(document.cm_b.passz.value=="") {
    alert("비멀번호를 입력해주세요.");
  }else if(document.cm_b.memo.value=="") {
    alert("내용을 입력해주세요.");
  }else if(document.cm_b.hiddens.value=="") {
    alert("자동등록방지를 입력해주세요.");
  }else if(document.cm_b.hiddens.value!=aa) {
    alert("자동등록방지가 틀렸습니다.");
  }else{
    document.cm_b.submit();
  }
}


$(function(){
	var wd = $(".xxxxx .photo ul li").width();
	var ln = $(".xxxxx .photo ul li").length;
	$(".xxxxx .photo ul").css("width",wd * ln);	
	$(".xxxxx .btn li").mouseover(function(){	
		pos = $(this).parent().parent().find(".photo li").eq($(this).index()).position().left;		
		$(this).parent().parent().find(".photo").stop().animate({'scrollLeft':pos},500);	
		$(this).parent().parent().find(".btn li").removeClass("on");
		$(this).addClass("on");
	});
	
});

</script>
</head>
<body>
<div id="header">
	<ul id="tmenu">
		<li><a href="map.php?id=map"><img src="./images/tmenu3.jpg" alt="오시는길" /></a></li>
		<? if($dlog[no]) {?>
		<li><a href="logout.php"><img src="./images/tmenu4.jpg" alt="로그아웃" /></a></li>
		<? }else{?>
		<li><a href="join.php"><img src="./images/tmenu2.jpg" alt="회원가입" /></a></li>
		<li><a href="login.php"><img src="./images/tmenu1.jpg" alt="로그인" /></a></li>
		<? }?>
	</ul>
	<h1><a href="index.php">로타리종합물류</a></h1>
	<ul id="mainmenu">
		<li class="mainm1"><a href="companyh.php?id=companyh">회사소개</a></li>
		<li class="mainm2"><a href="board.php?id=notice">공지사항</a></li>
		<li class="mainm3"><a href="map.php?id=map">오시는길</a></li>
		<li class="mainm4"><a href="carinfo.php?id=carinfo">차량정보</a></li>
		<li class="mainm5"><a href="board.php?id=q">고객센터</a></li>
		<li style="float:right;" class="mainm6"><a href="sitemap.php" style="width:190px;">사이트맵</a></li>
	</ul>
</div>
<div id="main_sub">
5톤 윙바디 카고 화물 운송주선 업체
1톤~25톤 화물 5톤 윙바디
</div>
<div id="contents">
	<div id="con1">
		<?=$dadmin[menu]?>
  	<div class="icons" id="icons_3" style="margin:0 0 10px 0;padding:0 15px 0 15px;">
  		  <a href="#">전화문의</a>
  	</div>
	</div>
	<div id="con2">
  	<?=$dadmin[sitemap]?>
  	<? if($id) {?>
  	<h1 id="home_com1" style="background:url(./images/home_t_<?=$id?>.jpg) no-repeat left top;"></h1>
  	<div id="home_coml1"><div id="home_coml2"></div></div>
  	<? }?>
  