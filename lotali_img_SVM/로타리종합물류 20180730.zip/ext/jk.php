<?
include "lib.php";
include "head.php";

$q = "select * from mschool_jk where no='1'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

?>
<script language="JavaScript" type="text/javascript" src="/alditor/alditor.js"></script>
<div class="goodminho2" style="margin-bottom:10px;margin-left:100px;width:793px;font-family:'Arial';">
    <h1>
      <a href="./print3_pdf.php" target="_BLANK" style="float:right;width:100%;display:block;text-align:center;color:blue;">
        인쇄하기
      </a>
    </h1>
<? if($dmember[admins] == 1) {?>
  <form action="jk_edit.php" method="post">
    <div style="width:100%;overflow:hidden;">
      <input type="submit" value="저장하기" style="float:right;font-weight:bold;width:793px;color:#000000;line-height:33px;border:1px solid #c6c6c6;background:none;padding:0px;margin:0px;font-size:15px;" />
    </div>
    <div id="jk_ed" style="overflow:hidden;">
      <textarea name="memos" style="width:788px;height:600px;"><?=$d[memos]?></textarea>
    </div>
  </form>
<? }else{?>
    <div id="jk_vw" style="padding:20px;overflow:hidden;">
      <?=$d[memos]?>
    </div>
<? }?>
</div>
<?
include "foot.php";
?>
