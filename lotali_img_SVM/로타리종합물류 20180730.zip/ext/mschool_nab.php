<?
include "lib.php";
include "head.php";
//손님이 불법방지
if($dmember[admins] != 1) {
  echo("
    <script>
      window.alert('잘못된 접근입니다.')
      history.go(-1)
    </script>
  ");
exit;
}
if(!$_GET[dates0]) {
  echo("
    <script>
      window.alert('월을 입력해주세요')
      history.go(-1)
    </script>
  ");
exit;
}
if(!$_GET[dates1]) {
  echo("
    <script>
      window.alert('일을 입력해주세요')
      history.go(-1)
    </script>
  ");
exit;
}






$q = "select count(*) from mschool_list where year='$_GET[oldd]' and members='$_GET[no]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);
if($d[0] != 0) {
  echo("
    <script>
      window.alert('이미 입금내역이 존재합니다.')
      history.go(-1)
    </script>
  ");
  exit;
}

$dates0s = $_GET[dates0];
$dates1s = $_GET[dates1];

if($_GET[dates1] == "1") $_GET[dates1] = "01";
if($_GET[dates1] == "2") $_GET[dates1] = "02";
if($_GET[dates1] == "3") $_GET[dates1] = "03";
if($_GET[dates1] == "4") $_GET[dates1] = "04";
if($_GET[dates1] == "5") $_GET[dates1] = "05";
if($_GET[dates1] == "6") $_GET[dates1] = "06";
if($_GET[dates1] == "7") $_GET[dates1] = "07";
if($_GET[dates1] == "8") $_GET[dates1] = "08";
if($_GET[dates1] == "9") $_GET[dates1] = "09";

if($_GET[dates0] == "1") $_GET[dates0] = "01";
if($_GET[dates0] == "2") $_GET[dates0] = "02";
if($_GET[dates0] == "3") $_GET[dates0] = "03";
if($_GET[dates0] == "4") $_GET[dates0] = "04";
if($_GET[dates0] == "5") $_GET[dates0] = "05";
if($_GET[dates0] == "6") $_GET[dates0] = "06";
if($_GET[dates0] == "7") $_GET[dates0] = "07";
if($_GET[dates0] == "8") $_GET[dates0] = "08";
if($_GET[dates0] == "9") $_GET[dates0] = "09";

$datess = $_GET[dates0]."/".$_GET[dates1];


if($_GET[dates0]) $_GET[dates] = $_GET[dates0]."월";
if($_GET[dates1]) $_GET[dates] = $_GET[dates].$_GET[dates1]."일";


//이름찾기
$qss = "select * from mschool_member where no='$_GET[no]'";
$rss = mysql_query($qss, $connect);
$dss = mysql_fetch_array($rss);

$_GET[moneys2] = 0;


//식별타임
$times = time();

//사용내역에 추가
$q = "insert into mschool_bank(dates, dates1, dates2, names, moneys1, moneys2, memos, years, nos)
                  values('$datess','$dates0s','$dates1s','$dss[names]','$_GET[moneys]','$_GET[moneys2]','$_GET[memos]','$_GET[oldd]','$times')";
mysql_query($q, $connect);



//납부현황에 추가
$q = "insert into mschool_list(years, check_dates, members, moneys, nos)
                  values('$_GET[oldd]','$_GET[dates]','$_GET[no]','$_GET[moneys]', '$times')";
mysql_query($q, $connect);
?>
<script>
  location.href="mschool.php?oldd=<?=$_GET[oldd]?>&hides=1";
</script>
<?
include "foot.php";
?>
