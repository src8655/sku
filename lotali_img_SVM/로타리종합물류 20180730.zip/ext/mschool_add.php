<?
include "lib.php";
include "head.php";

//손님이 불법방지
if($dmember[admins] != 1) {
  echo("
    <script>
      window.alert('잘못된 접근입니다.')
      history.go(-1)
    </script>
  ");
exit;
}



$q = "select count(*) from mschool_olddate where dates='$_GET[datey]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);
if($d[0] != 0) {
  echo("
    <script>
      window.alert('이미 존재하는 날짜입니다.')
      history.go(-1)
    </script>
  ");
exit;
}

$q = "insert into mschool_olddate(dates)
                  values('$_GET[datey]')";
mysql_query($q, $connect);
?>
<script>
  location.href="mschool.php?hides=1";
</script>
<?
include "foot.php";
?>
