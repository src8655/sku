<?
include "lib.php";
include "head.php";
?>

<?
include "foot.php";
?>