<?
$connect = mysql_connect("localhost","lsm8655","snrnsi11"); 
mysql_select_db("lsm8655", $connect);

mysql_query("set names utf8"); 
session_start();
include "head.php";



if(!$_GET[password_ext]){
  echo("
    <script>
      window.alert('비밀번호를 입력해주세요.')
      history.go(-1)
    </script>
  ");
exit;
}


//멤버에 있으면 로그인
$q = "select * from mschool_member where phones='$_GET[password_ext]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

if($d[no]) {
  $_GET[id_ext] = "guest";
  $_GET[password_ext] = "kw238";
}



$pass_ext = md5($_GET[password_ext]);

$query = "select * from mschool_login where user_pw='$pass_ext'";
$result = mysql_query($query, $connect);
$data = mysql_fetch_array($result);

if(!$data[no]){
  echo("
    <script>
      window.alert('아이디 혹은 비밀번호가 틀렸습니다.')
      history.go(-1)
    </script>
  ");
exit;
}

$_SESSION["user_id_ext"] = $data[user_id];
$_SESSION["password_ext"] = $data[user_pw];
?>
<script> 
  location.href='./mschool.php'; 
</script>
