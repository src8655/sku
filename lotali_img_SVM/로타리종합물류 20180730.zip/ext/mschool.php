<?

include "lib.php";
include "head.php";



$q_no = "select * from mschool_notice";
$r_no = mysql_query($q_no, $connect);
$d_no = mysql_fetch_array($r_no);


?>
<div style="overflow:hidden;width:230px;float:left;">


<div class="goodminho2" style="margin-bottom:10px;width:214px;font-family:'Arial';">
    <h1><a href="jk.php" style="display:block;text-align:center;color:blue;">동창회 회칙</a></h1>
</div>

<input type="hidden" name="oldd" value="<?=$_GET[oldd]?>" />
<form action="mschool_notice_edit.php">
<div id="goodminho3" style="width:214px; margin:0 0 10px 0;overflow:hidden;">
      <h1>
        <a href="#10"style="">공지사항</a>
        <? if($dmember[admins] == 1) {?>
        <a href="#10" onclick="displays(notices1);displays(notices2);displays(notices3);" style="color:blue;">[편집]</a>
        <input type="submit" value="저장" id="notices3" style="display:none;" />
        
      <? }?>
      </h1>
    <ul id="notices1" style="padding:0px;list-style:none;margin:0px;height:200px;overflow-y:scroll;">
      <li style="margin:0px;padding:5px;"><span style="font-size:15px;font-family:'Arial';"><?=nl2br($d_no[memos])?></span></li>
    </ul>
    <ul id="notices2" style="padding:0px;display:none;list-style:none;margin:0px;height:200px;;">
      <li style="margin:0px;padding:5px;text-align:left;"><textarea name="memos" style="font-size:15px;font-family:'Arial';width:97%;height:186px;"><?=$d_no[memos]?></textarea></li>
    </ul>
</div>
</form>



  <div class="goodminho2" style="margin:0 10px 10px 0;font-family:'Arial';">
    <h1>날짜선택</h1>
    <ul>
      <? if($dmember[admins] == 1) {?>
      <li style="border-bottom:1px solid #eeeeee;height:33px;line-height:33px;text-align:center;font-size:15px;">
        <form action="mschool_add.php">
          <select name="datey" class="ind_select">
          <?
          $sedate = date("Y");
          $cndate1 = $sedate-1;
          $cndate2 = $sedate+10;
          for($i=$cndate1;$i<$cndate2;$i++) {
          ?>
            <option value="<?=$i?>" <? if($sedate==$i) {?>selected<? }?>><?=$i?></option>
          <?
          }
          ?>
          </select>년
          <input type="submit" value="등록" style="font-size:15px;background:#ffffff;border:1px solid #676767;font-weight:bold;" />
        </form>
      </li>
      <? }?>
<?
$gatt = 9; //보이는 갯수
$gatt_cnt = 0;
$is_oldd = 0;

$u = "select * from mschool_olddate order by dates desc";
$j = mysql_query($u, $connect);
while($m = mysql_fetch_array($j)) {
if(!$is_oldd && !$_GET[oldd]) {
  $_GET[oldd] = $m[no];
  $is_oldd = 1;
}
?>

      <li><a href="mschool.php?oldd=<?=$m[no]?>" style="height:34px;line-height:34px;font-size:15px;font-family:'Arial';">
        <?=$m[dates]?> 년 기록부
      </a></li>
<?
}
?>

	</ul>
  </div>
  
  
  
  
  </div>
  
  
  
  
  
  
  
  
<?
if($_GET[oldd]) {
  $qu = "select * from mschool_olddate where no='$_GET[oldd]'";
  $re = mysql_query($qu, $connect);
  $da = mysql_fetch_array($re)
?>
<div class="goodminho2" style="width:750px;float:right;margin:0 10px 10px 0;font-family:'Arial';">
    <h1><a href="#10" onclick="displays(dkdkdk1);"><span style="color:blue;"><?=$da[dates]?> 년</span> 회비납부현황</a>&nbsp;&nbsp;&nbsp;
    <? if($dmember[admins] == 1) {?>
      <a href="mschool.php?oldd=<?=$_GET[oldd]?>&inpmode=1&hides=1" style="color:blue;">[멤버추가]</a>
      <a href="#10" id="dlts2" style="color:green;">[멤버수정]</a>
      <a href="#10" id="dlts" style="color:red;">[멤버삭제]</a>
    <? }?>
    
    
      <input type="text" name="name" value="" id="fdkey2" style="float:right;border:1px solid #999999;height:20px;line-height:20px;margin:2px 5px 0 0;width:120px;font-size:17px;" />
      <p style="float:right;padding:0px;margin:0 5px 0 5px;overflow:hidden;">검색하기</p>
    
    <a href="print1_pdf.php?oldd=<?=$_GET[oldd]?>" target="_BLANK" style="width:60px;float:right;font-weight:bold;text-align:center;display:block;border-left:1px solid #ABABAB;border-right:1px solid #ABABAB;font-size:15px;height:100%;">인쇄</a>
    
    </h1>
    <div style="<? if($_GET[hides] == 1){?>display:block;<? }else{?>display:block;<? }?>font-size:14px;height:350px;overflow-y:scroll;" id="dkdkdk1">
    <table cellpadding="0" cellspacing="1" class="m_table">
    <col width="80" />
    <col width="200" />
    <col width="200" />
    <col width="200" />
    <col width="250" />
    <col width="80" />
      <tr>
        <th>
          번호
        </th>
        <th>
          이름
        </th>
        <th>
          연락처
        </th>
        <th>
          회비
        </th>
        <th>
          납부여부/날짜
        </th>
        <? if($dmember[admins] == 1) {?>
        <th>
          편집
        </th>
        <? }?>
      </tr>









<?
if($_GET[inpmode] == 1) {
?>
<form action="mschool_post.php">
<input type="hidden" name="oldd" value="<?=$_GET[oldd]?>" />
      <tr>
        <td>
          추가
        </td>
        <td>
          <input type="text" name="names" style="width:85%;font-size:14px;" />
        </td>
        <td>
          <input type="text" name="phones" style="width:85%;font-size:14px;" />
        </td>
        <td>
          -
        </td>
        <td>
          -
        </td>
        <td>
          <input type="submit" value="추가" style="border:1px solid #c9c9c9;background:#ffffff;font-size:14px;font-weight:bold;padding:5px 8px 5px 8px;" />
        </td>
      </tr>
</form>
<?
}
?>




<?
$cnt = 1;
$totals = 0;

//입금한사람만 보기
$q = "select * from mschool_member order by names asc";
$r = mysql_query($q, $connect);
while($d = mysql_fetch_array($r)) {
  $str_counts = mb_strlen($d[phones], "UTF-8");  //전화번호 문자열 개수
  if($str_counts == 11) $str_phones = mb_substr($d[phones], 0, 3)."-".mb_substr($d[phones], 3, 4)."-".mb_substr($d[phones], 7, 4);
  else if($str_counts == 10) $str_phones = mb_substr($d[phones], 0, 3)."-".mb_substr($d[phones], 3, 3)."-".mb_substr($d[phones], 6, 4);
  else $str_phones = $d[phones];
  
  $qq = "select * from mschool_list where years='$_GET[oldd]' and members='$d[no]'";
  $rr = mysql_query($qq, $connect);
  $checks = mysql_fetch_array($rr);
  
  if(!$checks[no]) {
    $nab_result = "미납";
    continue;
  } else {
    $qq2 = "select * from mschool_bank where nos='$checks[nos]'";
    $rr2 = mysql_query($qq2, $connect);
    $checks2 = mysql_fetch_array($rr2);
    
    $nab_result = "<span style='color:red;'>".$checks[check_dates]." ".$checks2[memos]."</span>";
  }
?>
      <tr class="fd2">
        <td class="dels1" style="display:none;">
          <a href="#10" onclick="confirms('삭제를 하시겠습니까?','mschool_del.php?oldd=<?=$_GET[oldd]?>&no=<?=$d[no]?>');" style="font-weight:bold;color:red;border:0px;margin:0px;padding:0px;width:60px;background:none;line-height:35px;">[삭제]</a>
        </td>
        <td class="dels3" style="display:none;">
          <a href="#10" onclick="displays(edt0<?=$d[no]?>);displays(edt1<?=$d[no]?>);displays(edt2<?=$d[no]?>);" style="font-weight:bold;color:blue;border:0px;margin:0px;padding:0px;width:60px;background:none;line-height:35px;">[수정]</a>
        </td>
        <td class="dels2">
          <?=$cnt?>
        </td>
        
          <td colspan="2" id="edt2<?=$d[no]?>" style="display:none;">
        <form action="mschool_edit.php" >
          <input type="hidden" name="oldd" value="<?=$_GET[oldd]?>" />
          <input type="hidden" name="no" value="<?=$d[no]?>" />
          
            <input type="text" name="names" value="<?=$d[names]?>" style="width:80px;font-size:14px;" />&nbsp;
            
            <input type="text" name="phones" value="<?=$d[phones]?>" style="width:120px;font-size:14px;" />&nbsp;
            
            <input type="submit" value="수정" style="font-weight:bold;width:50px;color:#000000;line-height:23px;border:1px solid #c6c6c6;background:none;padding:0px;margin:0px;font-size:14px;" />
        </form>
          </td>
        
        <td id="edt0<?=$d[no]?>">
          &nbsp;<?=$d[names]?>
        </td>
        <td id="edt1<?=$d[no]?>">
          &nbsp;<?=$str_phones?>
        </td>
          <? if(!$checks[no]) {?>
            <td id="emodeoff0_<?=$d[no]?>">
              -
            </td>
          <? }else{?>
            <td id="emodeoff0_<?=$d[no]?>">
              <?=number_format($checks[moneys])?> 원&nbsp;&nbsp;
              <? $totals = $totals+$checks[moneys];?>
            </td>
          <? }?>
          <td id="emodeoff1_<?=$d[no]?>">
            <?=$nab_result?>
          </td>
            <? if($dmember[admins] == 1) {?>
          <td id="emodeoff2_<?=$d[no]?>">
            <? if(!$checks[no]) {?>
                <a href="#10" onclick="displays(emodeoff0_<?=$d[no]?>);displays(emodeoff1_<?=$d[no]?>);displays(emodeoff2_<?=$d[no]?>);displays(emodeon0_<?=$d[no]?>);displays(emodeon1_<?=$d[no]?>);" style="color:blue;font-weight:bold;width:50px;line-height:25px;border:0px;background:none;padding:0px;margin:0px;font-size:14px;">
                편집</a>
            <? }else{?>
                <a href="#10" onclick="confirms('삭제를 하시겠습니까?','mschool_nab_del.php?oldd=<?=$_GET[oldd]?>&no=<?=$checks[no]?>');" style="color:red;font-weight:bold;width:50px;line-height:25px;border:0px;background:none;padding:0px;margin:0px;font-size:14px;">
                삭제</a>
            <? }?>
          </td>
            <? }?>
        <td id="emodeon0_<?=$d[no]?>" style="display:none;padding:5px 0 5px 0;line-height:25px;" colspan="2">
        <form action="mschool_nab.php">
          <input type="hidden" name="oldd" value="<?=$_GET[oldd]?>" />
          <input type="hidden" name="no" value="<?=$d[no]?>" />
          
            <input type="text" name="moneys" style="width:100px;font-size:14px;" />원
            
            <input type="text" name="dates0" style="width:30px;font-size:14px;" />월
            <input type="text" name="dates1" style="width:30px;font-size:14px;" />일<br />
            
            메모 : <input type="text" name="memos" value="회비납부" style="width:120px;font-size:14px;" />
            <input type="submit" value="입력" style="font-weight:bold;width:50px;color:#000000;line-height:23px;border:1px solid #c6c6c6;background:none;padding:0px;margin:0px;font-size:14px;" />
        </form>
        </td>
        <td id="emodeon1_<?=$d[no]?>" style="display:none;">
          <a href="#10" onclick="displays(emodeoff0_<?=$d[no]?>);displays(emodeoff1_<?=$d[no]?>);displays(emodeoff2_<?=$d[no]?>);displays(emodeon0_<?=$d[no]?>);displays(emodeon1_<?=$d[no]?>);" style="font-weight:bold;width:50px;color:#000000;line-height:35px;border:0px;background:none;padding:0px;margin:0px;font-size:14px;">
          취소</a>
        </td>
      </tr>
<?
$cnt++;
}

//입금 안한사람만 보기
$q = "select * from mschool_member order by names asc";
$r = mysql_query($q, $connect);
while($d = mysql_fetch_array($r)) {
  $str_counts = mb_strlen($d[phones], "UTF-8");  //전화번호 문자열 개수
  if($str_counts == 11) $str_phones = mb_substr($d[phones], 0, 3)."-".mb_substr($d[phones], 3, 4)."-".mb_substr($d[phones], 7, 4);
  else if($str_counts == 10) $str_phones = mb_substr($d[phones], 0, 3)."-".mb_substr($d[phones], 3, 3)."-".mb_substr($d[phones], 6, 4);
  else $str_phones = $d[phones];
  
  $qq = "select * from mschool_list where years='$_GET[oldd]' and members='$d[no]'";
  $rr = mysql_query($qq, $connect);
  $checks = mysql_fetch_array($rr);
  
  if(!$checks[no]) {
    $nab_result = "미납";
  } else {
    $qq2 = "select * from mschool_bank where nos='$checks[nos]'";
    $rr2 = mysql_query($qq2, $connect);
    $checks2 = mysql_fetch_array($rr2);
    
    $nab_result = $checks[check_dates]." ".$checks2[memos];
    continue;
  }
?>
      <tr class="fd2">
        <td class="dels1" style="display:none;">
          <a href="#10" onclick="confirms('삭제를 하시겠습니까?','mschool_del.php?oldd=<?=$_GET[oldd]?>&no=<?=$d[no]?>');" style="font-weight:bold;color:red;border:0px;margin:0px;padding:0px;width:60px;background:none;line-height:35px;">[삭제]</a>
        </td>
        <td class="dels3" style="display:none;">
          <a href="#10" onclick="displays(edt0<?=$d[no]?>);displays(edt1<?=$d[no]?>);displays(edt2<?=$d[no]?>);" style="font-weight:bold;color:blue;border:0px;margin:0px;padding:0px;width:60px;background:none;line-height:35px;">[수정]</a>
        </td>
        <td class="dels2">
          <?=$cnt?>
        </td>
        
          <td colspan="2" id="edt2<?=$d[no]?>" style="display:none;">
        <form action="mschool_edit.php" >
          <input type="hidden" name="oldd" value="<?=$_GET[oldd]?>" />
          <input type="hidden" name="no" value="<?=$d[no]?>" />
          
            <input type="text" name="names" value="<?=$d[names]?>" style="width:80px;font-size:14px;" />&nbsp;
            
            <input type="text" name="phones" value="<?=$d[phones]?>" style="width:120px;font-size:14px;" />&nbsp;
            
            <input type="submit" value="수정" style="font-weight:bold;width:50px;color:#000000;line-height:23px;border:1px solid #c6c6c6;background:none;padding:0px;margin:0px;font-size:14px;" />
        </form>
          </td>
        
        <td id="edt0<?=$d[no]?>">
          &nbsp;<?=$d[names]?>
        </td>
        <td id="edt1<?=$d[no]?>">
          &nbsp;<?=$str_phones?>
        </td>
          <? if(!$checks[no]) {?>
            <td id="emodeoff0_<?=$d[no]?>">
              -
            </td>
          <? }else{?>
            <td id="emodeoff0_<?=$d[no]?>">
              <?=number_format($checks[moneys])?> 원&nbsp;&nbsp;
              <? $totals = $totals+$checks[moneys];?>
            </td>
          <? }?>
          <td id="emodeoff1_<?=$d[no]?>">
            <?=$nab_result?>
          </td>
            <? if($dmember[admins] == 1) {?>
          <td id="emodeoff2_<?=$d[no]?>">
            <? if(!$checks[no]) {?>
                <a href="#10" onclick="displays(emodeoff0_<?=$d[no]?>);displays(emodeoff1_<?=$d[no]?>);displays(emodeoff2_<?=$d[no]?>);displays(emodeon0_<?=$d[no]?>);displays(emodeon1_<?=$d[no]?>);" style="color:blue;font-weight:bold;width:50px;line-height:25px;border:0px;background:none;padding:0px;margin:0px;font-size:14px;">
                편집</a>
            <? }else{?>
                <a href="#10" onclick="confirms('삭제를 하시겠습니까?','mschool_nab_del.php?oldd=<?=$_GET[oldd]?>&no=<?=$checks[no]?>');" style="color:red;font-weight:bold;width:50px;line-height:25px;border:0px;background:none;padding:0px;margin:0px;font-size:14px;">
                삭제</a>
            <? }?>
          </td>
            <? }?>
        <td id="emodeon0_<?=$d[no]?>" style="display:none;padding:5px 0 5px 0;line-height:25px;" colspan="2">
        <form action="mschool_nab.php">
          <input type="hidden" name="oldd" value="<?=$_GET[oldd]?>" />
          <input type="hidden" name="no" value="<?=$d[no]?>" />
          
            <input type="text" name="moneys" style="width:100px;font-size:14px;" />원
            
            <input type="text" name="dates0" style="width:30px;font-size:14px;" />월
            <input type="text" name="dates1" style="width:30px;font-size:14px;" />일<br />
            
            메모 : <input type="text" name="memos" value="회비납부" style="width:120px;font-size:14px;" />
            <input type="submit" value="입력" style="font-weight:bold;width:50px;color:#000000;line-height:23px;border:1px solid #c6c6c6;background:none;padding:0px;margin:0px;font-size:14px;" />
        </form>
        </td>
        <td id="emodeon1_<?=$d[no]?>" style="display:none;">
          <a href="#10" onclick="displays(emodeoff0_<?=$d[no]?>);displays(emodeoff1_<?=$d[no]?>);displays(emodeoff2_<?=$d[no]?>);displays(emodeon0_<?=$d[no]?>);displays(emodeon1_<?=$d[no]?>);" style="font-weight:bold;width:50px;color:#000000;line-height:35px;border:0px;background:none;padding:0px;margin:0px;font-size:14px;">
          취소</a>
        </td>
      </tr>
<?
$cnt++;
}
?>


      <tr>
        <td>
          &nbsp;
        </td>
        <td>
          &nbsp;
        </p>
        <td>
          합계
        </p>
        <td>
          <?=number_format($totals)?> 원
        </p>
        <td>
          &nbsp;
        </p>
        <? if($dmember[admins] == 1) {?>
        <td>
          &nbsp;
        </p>
        <? }?>
      </tr>
    </table>
	</div>
</div>
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
<div class="goodminho2" style="width:750px;float:right;margin:0 10px 10px 0;font-family:'Arial';">
    <h1><a href="#10" onclick="displays(dkdkdk2);"><span style="color:blue;"><?=$da[dates]?> 년</span> 회비 입출금내역</a>&nbsp;&nbsp;&nbsp;
    <? if($dmember[admins] == 1) {?>
      <a href="mschool.php?oldd=<?=$_GET[oldd]?>&inpmodes=1&hides=2" style="color:blue;">[추가하기]</a>
    <? }?>
      <input type="text" name="name" value="" id="fdkey3" style="float:right;border:1px solid #999999;height:20px;line-height:20px;margin:2px 5px 0 0;width:120px;font-size:17px;" />
      <p style="float:right;padding:0px;margin:0 5px 0 5px;overflow:hidden;">검색하기</p>
      
      
    <a href="print2_pdf.php?oldd=<?=$_GET[oldd]?>" target="_BLANK" style="width:60px;float:right;font-weight:bold;text-align:center;display:block;border-left:1px solid #ABABAB;border-right:1px solid #ABABAB;font-size:15px;height:100%;">인쇄</a>
    
    
    
    </h1>
    <div style="<? if($_GET[hides] == 2){?>display:block;<? }else{?>display:block;<? }?>font-size:14px;height:350px;overflow-y:scroll;" id="dkdkdk2">
      <table cellpadding="0" cellspacing="1" class="m_table">
      <col width="60" />
      <col width="100" />
      <col width="100" />
      <col width="100" />
      <col width="100" />
      <col width="150" />
      <col width="50" />
      <tr>
        <th>
          월/일
        </th>
        <th>
          이름
        </th>
        <th>
          입금
        </th>
        <th>
          지출
        </th>
        <th>
          잔액
        </th>
        <th>
          내용
        </th>
        <? if($dmember[admins] == 1) {?>
        <th>
          편집
        </th>
        <? }?>
      </tr>









<?
if($_GET[inpmodes] == 1) {
?>
<form action="mschool_bank_post.php">
<input type="hidden" name="oldd" value="<?=$_GET[oldd]?>" />
      <tr>
        <td style="padding:0px;">
          <input type="text" name="dates1" style="width:35%;font-size:14px;" />/
          <input type="text" name="dates2" style="width:35%;font-size:14px;" />
        </td>
        <td>
          <input type="text" name="names" style="width:85%;font-size:14px;" />
        </td>
        <td>
          <input type="text" name="moneys1" style="width:85%;font-size:14px;" />
        </td>
        <td>
          <input type="text" name="moneys2" style="width:85%;font-size:14px;" />
        </td>
        <td>
          -
        </td>
        <td>
          <input type="text" name="memos" style="width:85%;font-size:14px;" />
        </td>
        <td>
          <input type="submit" value="추가" style="border:1px solid #c9c9c9;background:#ffffff;font-size:14px;font-weight:bold;padding:5px 8px 5px 8px;margin:2px 0 0 5px;" />
        </td>
      </tr>
</form>
<?
}
?>




<?
$cnt = 1;
$money_cnt = 0;
$money_cnt1 = 0;
$money_cnt2 = 0;
$q = "select * from mschool_bank where years='$_GET[oldd]' order by dates asc, no asc";
$r = mysql_query($q, $connect);
while($d = mysql_fetch_array($r)) {
  $money_cnt = $money_cnt+$d[moneys1];
  $money_cnt = $money_cnt-$d[moneys2];
  
  //합계
  $money_cnt1 = $money_cnt1+$d[moneys1];
  $money_cnt2 = $money_cnt2+$d[moneys2];
?>
      <tr class="fd3">
        <td>
          <?=$d[dates]?>
        </td>
        <td>
          <?=$d[names]?>
        </td>
        <td style="text-align:right;">
          <?=number_format($d[moneys1])?> 원
        </td>
        <td style="text-align:right;">
            <?=number_format($d[moneys2])?> 원
        </td>
        <td style="text-align:right;">
            <?=number_format($money_cnt)?> 원
        </td>
        <td>
            <?=$d[memos]?>
        </td>
        <? if($dmember[admins] == 1) {?>
        <td>
          <a href="#10" onclick="confirms('삭제를 하시겠습니까?','mschool_bank_del.php?oldd=<?=$_GET[oldd]?>&no=<?=$d[no]?>');" style="color:red;font-weight:bold;width:50px;line-height:25px;border:0px;background:none;padding:0px;margin:0px;font-size:14px;">
          삭제</a>
        </td>
        <? }?>
      </td>
<?
$cnt++;
}
?>



      <tr>
        <td>
          &nbsp;
        </td>
        <td>
          합계
        </td>
        <td style="text-align:right;">
          <?=number_format($money_cnt1)?> 원
        </td>
        <td style="text-align:right;">
          <?=number_format($money_cnt2)?> 원
        </td>
        <td style="text-align:right;">
          <?=number_format($money_cnt1-$money_cnt2)?> 원
        </td>
        <td>
          &nbsp;
        </td>
        <? if($dmember[admins] == 1) {?>
        <td>
          &nbsp;
        </td>
        <? }?>
      </tr>
      
      
      
    </table>
	</div>
</div>
  
  
  
  
  
  
  
  
  
  
  
  
  
  
<?
}
?>
<?
include "foot.php";
?>
