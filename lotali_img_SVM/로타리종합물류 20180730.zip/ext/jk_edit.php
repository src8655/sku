<?
include "lib.php";
include "head.php";
//손님이 불법방지
if($dmember[admins] != 1) {
  echo("
    <script>
      window.alert('잘못된 접근입니다.')
      history.go(-1)
    </script>
  ");
exit;
}

$q = "update mschool_jk set
      memos='$_POST[memos]' where no='1'";
mysql_query($q, $connect);
?>
<script>
  location.href="jk.php";
</script>
<?
include "foot.php";
?>
