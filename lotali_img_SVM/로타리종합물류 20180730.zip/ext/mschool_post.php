<?
include "lib.php";
include "head.php";
//�մ��� �ҹ�����
if($dmember[admins] != 1) {
  echo("
    <script>
      window.alert('�߸��� �����Դϴ�.')
      history.go(-1)
    </script>
  ");
exit;
}
$q = "insert into mschool_member(names, phones)
                  values('$_GET[names]','$_GET[phones]')";
mysql_query($q, $connect);
?>
<script>
  location.href="mschool.php?oldd=<?=$_GET[oldd]?>&inpmode=1&hides=1";
</script>
<?
include "foot.php";
?>
