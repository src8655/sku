<?
$connect = mysql_connect("localhost","lsm8655","snrnsi11"); 
mysql_select_db("lsm8655", $connect);

mysql_query("set names utf8");






//전화번호가 없으면
  if(!$_GET[phone]) exit;
  
$temp = $_GET[phone];

//관리자면 로그인
$qad = "select * from mschool_login where user_pw='$temp'";
$rad = mysql_query($qad, $connect);
$dad = mysql_fetch_array($rad);

//멤버에 있으면 로그인
$q = "select * from mschool_member where encodes='$_GET[phone]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

//성공하면 20 실패하면 18하고종료
if($d[no] || $dad[no]) {
  if(!$_GET[order]) {
    if($dad[no]) echo "0-=-21-=-0";
    else echo "0-=-20-=-0";
  }
}else{
  echo "0-=-18-=-0";
  exit;
}














//납부현황 날짜리스트
if($_GET[order] == 1) {
  
  $q = "select count(*) from mschool_olddate order by dates desc";
  $r = mysql_query($q, $connect);
  $d = mysql_fetch_array($r);
  echo $d[0];
  $u = "select * from mschool_olddate order by dates desc";
  $j = mysql_query($u, $connect);
  while($m = mysql_fetch_array($j)) {
        echo "-=-".$m[no]."_=_".$m[dates]."_=_0";
  }
}
//납부현황 리스트
if($_GET[order] == 2) {
  $q = "select count(*) from mschool_member where names like '%$_GET[stxt]%'";
  $r = mysql_query($q, $connect);
  $d = mysql_fetch_array($r);
  echo $d[0];
  
  $cnt = 1;
  
  //입금한 사람만
  $q = "select * from mschool_member where names like '%$_GET[stxt]%' order by names asc";
  $r = mysql_query($q, $connect);
  while($d = mysql_fetch_array($r)) {
    $qq = "select * from mschool_list where years='$_GET[oldd]' and members='$d[no]'";
    $rr = mysql_query($qq, $connect);
    $checks = mysql_fetch_array($rr);
    
    if(!$checks[no]) {
      $nab_result = 0;
      $nab_result2 = "미납";
      $checks[moneys] = "0원";
      continue;
    }else{
      $nab_result = 1;
      
      $qq2 = "select * from mschool_bank where nos='$checks[nos]'";
      $rr2 = mysql_query($qq2, $connect);
      $checks2 = mysql_fetch_array($rr2);
      
      $nab_result2 = $checks[check_dates]." ".$checks2[memos];
      $checks[moneys] = number_format($checks[moneys])."원";
    }
    
    if(!$checks[no]) ;
    else ;
    
    
    echo "-=-".$cnt."_=_".$d[names]."_=_".$nab_result."_=_".$nab_result2."_=_".$checks[moneys]."_=_".$d[no]."_=_".$checks[no]."_=_0";
  $cnt++;
  }
  
  
  //입금하지 않은 사람만
  $q = "select * from mschool_member where names like '%$_GET[stxt]%' order by names asc";
  $r = mysql_query($q, $connect);
  while($d = mysql_fetch_array($r)) {
    $qq = "select * from mschool_list where years='$_GET[oldd]' and members='$d[no]'";
    $rr = mysql_query($qq, $connect);
    $checks = mysql_fetch_array($rr);
    
    if(!$checks[no]) {
      $nab_result = 0;
      $nab_result2 = "미납";
      $checks[moneys] = "0원";
    }else{
      $nab_result = 1;
      
      $qq2 = "select * from mschool_bank where nos='$checks[nos]'";
      $rr2 = mysql_query($qq2, $connect);
      $checks2 = mysql_fetch_array($rr2);
      
      $nab_result2 = $checks[check_dates]." ".$checks2[memos];
      $checks[moneys] = number_format($checks[moneys])."원";
      continue;
    }
    
    if(!$checks[no]) ;
    else ;
    
    
    echo "-=-".$cnt."_=_".$d[names]."_=_".$nab_result."_=_".$nab_result2."_=_".$checks[moneys]."_=_".$d[no]."_=_".$checks[no]."_=_0";
  $cnt++;
  }
}

//멤버리스트
if($_GET[order] == 3) {
  $q = "select count(*) from mschool_member where names like '%$_GET[stxt]%'";
  $r = mysql_query($q, $connect);
  $d = mysql_fetch_array($r);
  echo $d[0];
  
  $q = "select * from mschool_member where names like '%$_GET[stxt]%' order by names asc";
  $r = mysql_query($q, $connect);
  while($d = mysql_fetch_array($r)) {
    echo "-=-".$d[names]."_=_".$d[phones]."_=_".$d[no]."_=_0";
  }
}


//입출금현황
if($_GET[order] == 5) {

  $wheres = "";
  //이름이 존재하면
  if($_GET[names]) $wheres = " and names like '%$_GET[names]%'";

  $q = "select count(*) from mschool_bank where years='$_GET[oldd]' $wheres";
  $r = mysql_query($q, $connect);
  $d = mysql_fetch_array($r);
  echo $d[0];


  $cnt = 1;
  $money_cnt = 0;
  $money_cnt1 = 0;
  $money_cnt2 = 0;
  $q = "select * from mschool_bank where years='$_GET[oldd]' order by dates asc, no asc";
  $r = mysql_query($q, $connect);
  while($d = mysql_fetch_array($r)) {
    $set_visible = 1; //1이면 보이고 0이면 안보임
    
    $money_cnt = $money_cnt+$d[moneys1];
    $money_cnt = $money_cnt-$d[moneys2];
    
    //합계
    $money_cnt1 = $money_cnt1+$d[moneys1];
    $money_cnt2 = $money_cnt2+$d[moneys2];
    
    //입력된 검색어가 있으면
    if($_GET[names]) {
      $qs = "select count(*) from mschool_bank where no='$d[no]' and names like '%$_GET[names]%'";
      $rs = mysql_query($qs, $connect);
      $ds = mysql_fetch_array($rs);
      if($ds[0] == 0) $set_visible = 0;
    }
    
    if($set_visible == 1)
      echo "-=-".$d[dates1]."월".$d[dates2]."일"."_=_".$d[names]."_=_".number_format($d[moneys1])."원_=_".number_format($d[moneys2])."원_=_".number_format($money_cnt)."원_=_".$d[memos]."_=_".$d[no]."_=_0";
  
  
  $cnt++;
  }
}


//공지사항
if($_GET[order] == 6) {

$q_no = "select * from mschool_notice";
$r_no = mysql_query($q_no, $connect);
$d_no = mysql_fetch_array($r_no);

echo "0-=-".urlencode($d_no[memos])."-=-0";
}















//편집///////////////////////////////////////////////





//멤버삭제
if($_GET[order] == 7) {

//관리자면 로그인
$qad = "select * from mschool_login where user_pw='$temp'";
$rad = mysql_query($qad, $connect);
$dad = mysql_fetch_array($rad);

if(!$dad[no]) exit; //잘못된 접근
if(!$_GET[no]) exit;  //잘못된 접근

$q = "delete from mschool_member where no='$_GET[no]'";
mysql_query($q, $connect);
}


//멤버수정
if($_GET[order] == 8) {

//관리자면 로그인
$qad = "select * from mschool_login where user_pw='$temp'";
$rad = mysql_query($qad, $connect);
$dad = mysql_fetch_array($rad);

if(!$dad[no]) exit; //잘못된 접근
if(!$_GET[no]) exit;  //잘못된 접근

$mds = md5($_GET[phones]);  //암호화
$q = "update mschool_member set
      names='$_GET[names]',
      phones='$_GET[phones]',
      encodes='$mds' where no='$_GET[no]'";
mysql_query($q, $connect);
}

//멤버추가
if($_GET[order] == 9) {

//관리자면 로그인
$qad = "select * from mschool_login where user_pw='$temp'";
$rad = mysql_query($qad, $connect);
$dad = mysql_fetch_array($rad);

if(!$dad[no]) exit; //잘못된 접근

$mds = md5($_GET[phones]);  //암호화
$q = "insert into mschool_member(names, phones, encodes)
                  values('$_GET[names]','$_GET[phones]','$mds')";
mysql_query($q, $connect);
}











//납부추가
if($_GET[order] == 10) {
  //관리자면 로그인
$qad = "select * from mschool_login where user_pw='$temp'";
$rad = mysql_query($qad, $connect);
$dad = mysql_fetch_array($rad);

if(!$dad[no]) exit; //잘못된 접근
if(!$_GET[dates0]) exit;
if(!$_GET[dates1]) exit;






$q = "select count(*) from mschool_list where year='$_GET[oldd]' and members='$_GET[no]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);
if($d[0] != 0) exit;

$dates0s = $_GET[dates0];
$dates1s = $_GET[dates1];

if($_GET[dates1] == "1") $_GET[dates1] = "01";
if($_GET[dates1] == "2") $_GET[dates1] = "02";
if($_GET[dates1] == "3") $_GET[dates1] = "03";
if($_GET[dates1] == "4") $_GET[dates1] = "04";
if($_GET[dates1] == "5") $_GET[dates1] = "05";
if($_GET[dates1] == "6") $_GET[dates1] = "06";
if($_GET[dates1] == "7") $_GET[dates1] = "07";
if($_GET[dates1] == "8") $_GET[dates1] = "08";
if($_GET[dates1] == "9") $_GET[dates1] = "09";

if($_GET[dates0] == "1") $_GET[dates0] = "01";
if($_GET[dates0] == "2") $_GET[dates0] = "02";
if($_GET[dates0] == "3") $_GET[dates0] = "03";
if($_GET[dates0] == "4") $_GET[dates0] = "04";
if($_GET[dates0] == "5") $_GET[dates0] = "05";
if($_GET[dates0] == "6") $_GET[dates0] = "06";
if($_GET[dates0] == "7") $_GET[dates0] = "07";
if($_GET[dates0] == "8") $_GET[dates0] = "08";
if($_GET[dates0] == "9") $_GET[dates0] = "09";

$datess = $_GET[dates0]."/".$_GET[dates1];


if($_GET[dates0]) $_GET[dates] = $_GET[dates0]."월";
if($_GET[dates1]) $_GET[dates] = $_GET[dates].$_GET[dates1]."일";


//이름찾기
$qss = "select * from mschool_member where no='$_GET[no]'";
$rss = mysql_query($qss, $connect);
$dss = mysql_fetch_array($rss);

$_GET[moneys2] = 0;


//식별타임
$times = time();

//사용내역에 추가
$q = "insert into mschool_bank(dates, dates1, dates2, names, moneys1, moneys2, memos, years, nos)
                  values('$datess','$dates0s','$dates1s','$dss[names]','$_GET[moneys]','$_GET[moneys2]','$_GET[memos]','$_GET[oldd]','$times')";
mysql_query($q, $connect);



//납부현황에 추가
$q = "insert into mschool_list(years, check_dates, members, moneys, nos)
                  values('$_GET[oldd]','$_GET[dates]','$_GET[no]','$_GET[moneys]', '$times')";
mysql_query($q, $connect);
}



//납부삭제
if($_GET[order] == 11) {
//관리자면 로그인
$qad = "select * from mschool_login where user_pw='$temp'";
$rad = mysql_query($qad, $connect);
$dad = mysql_fetch_array($rad);

if(!$dad[no]) exit; //잘못된 접근

if(!$_GET[no]) exit;

$q = "select count(*) from mschool_list where no='$_GET[no]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);
if($d[0] == 0) exit;

$q = "select * from mschool_list where no='$_GET[no]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

if($d[nos]) {
  $qr = "delete from mschool_bank where nos='$d[nos]'";
  mysql_query($qr, $connect);
}

//납부현황에 추가
$q = "delete from mschool_list where no='$_GET[no]'";
mysql_query($q, $connect);
}





//입출금추가
if($_GET[order] == 12) {
//관리자면 로그인
$qad = "select * from mschool_login where user_pw='$temp'";
$rad = mysql_query($qad, $connect);
$dad = mysql_fetch_array($rad);

if(!$dad[no]) exit; //잘못된 접근

if(!$_GET[dates1]) exit;
if(!$_GET[dates2]) exit;

$dates1 = $_GET[dates1];
$dates2 = $_GET[dates2];
if($_GET[dates1] == "1") $_GET[dates1] = "01";
if($_GET[dates1] == "2") $_GET[dates1] = "02";
if($_GET[dates1] == "3") $_GET[dates1] = "03";
if($_GET[dates1] == "4") $_GET[dates1] = "04";
if($_GET[dates1] == "5") $_GET[dates1] = "05";
if($_GET[dates1] == "6") $_GET[dates1] = "06";
if($_GET[dates1] == "7") $_GET[dates1] = "07";
if($_GET[dates1] == "8") $_GET[dates1] = "08";
if($_GET[dates1] == "9") $_GET[dates1] = "09";

if($_GET[dates2] == "1") $_GET[dates2] = "01";
if($_GET[dates2] == "2") $_GET[dates2] = "02";
if($_GET[dates2] == "3") $_GET[dates2] = "03";
if($_GET[dates2] == "4") $_GET[dates2] = "04";
if($_GET[dates2] == "5") $_GET[dates2] = "05";
if($_GET[dates2] == "6") $_GET[dates2] = "06";
if($_GET[dates2] == "7") $_GET[dates2] = "07";
if($_GET[dates2] == "8") $_GET[dates2] = "08";
if($_GET[dates2] == "9") $_GET[dates2] = "09";

$dates = $_GET[dates1]."/".$_GET[dates2];



$q = "insert into mschool_bank(dates, dates1, dates2, names, moneys1, moneys2, memos, years)
                  values('$dates','$dates1','$dates2','$_GET[names]','$_GET[moneys1]','$_GET[moneys2]','$_GET[memos]','$_GET[oldd]')";
mysql_query($q, $connect);
}


//입출금삭제
if($_GET[order] == 13) {
//관리자면 로그인
$qad = "select * from mschool_login where user_pw='$temp'";
$rad = mysql_query($qad, $connect);
$dad = mysql_fetch_array($rad);

if(!$dad[no]) exit; //잘못된 접근

if(!$_GET[no]) exit;

$q = "select * from mschool_bank where no='$_GET[no]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);


if($d[nos]) {
  $qr = "delete from mschool_list where nos='$d[nos]'";
  mysql_query($qr, $connect);
}
  
  
$q = "delete from mschool_bank where no='$_GET[no]'";
mysql_query($q, $connect);
}




//입출금삭제
if($_GET[order] == 15) {
//관리자면 로그인
$qad = "select * from mschool_login where user_pw='$temp'";
$rad = mysql_query($qad, $connect);
$dad = mysql_fetch_array($rad);

if(!$dad[no]) exit; //잘못된 접근

$q = "update mschool_notice set
      memos='$_GET[memos]'";
mysql_query($q, $connect);
}
















function img_resize_only($imgs, $maxwidth, $maxheight) {
  
	if($imgs) {
		// $img는 이미지의 경로(예:./images/phplove.gif) 
		$imgsize = getimagesize($imgs); 
		if($imgsize[0]>$maxwidth || $imgsize[1]>$maxheight) { 
			// 가로길이가 가로limit값보다 크거나 세로길이가 세로limit보다 클경우 
			$sumw = (100*$maxheight)/$imgsize[1]; 
			$sumh = (100*$maxwidth)/$imgsize[0]; 
			if($sumw < $sumh) { 
			// 가로가 세로보다 클경우 
			$img_width = ceil(($imgsize[0]*$sumw)/100); 
			$img_height = $maxheight; 
			} else { 
			// 세로가 가로보다 클경우 
			$img_height = ceil(($imgsize[1]*$sumh)/100); 
			$img_width = $maxwidth; 
			} 
		} else { 
			// limit보다 크지 않는 경우는 원본 사이즈 그대로..... 
			$img_width = $imgsize[0]; 
			$img_height = $imgsize[1]; 
		} 
		
		$imgsize[0] = $img_width;
		$imgsize[1] = $img_height;
	} else {
		$imgsize[0] = $maxwidth;
		$imgsize[1] = $maxheight;
	}
	
	
	$info_image=getimagesize($imgs);
    switch($info_image['mime']){
    case "image/gif";
      $new_image=imagecreatefromgif($imgs);
      break;
    case "image/jpeg";
      $new_image=imagecreatefromjpeg($imgs);
      break;
    case "image/png";
      $new_image=imagecreatefrompng($imgs);
      break;
    case "image/bmp";
      $new_image=imagecreatefrombmp($imgs);
      break;
    }
    $w=$imgsize[0];
    $h=$imgsize[1];
    $canvas=imagecreatetruecolor($w,$h);
    imagecopyresampled($canvas,$new_image,0,0,0,0,$w,$h,$info_image[0],$info_image[1]);
    imagegif($canvas,$imgs);
}


//갤러리 저장하기
if($_GET[order] == 16) {
  if(!$_GET[subjects]) exit;
  
  $files0 = "none";
  $files1 = "none";
  $files2 = "none";
  $files3 = "none";
  $files4 = "none";
  $files5 = "none";
  $files6 = "none";
  $files7 = "none";
  $files8 = "none";
  $files9 = "none";
  $dir_n = "none";
  
  $times = time();
  
  if($_FILES['uploadedfile0']['name']) {
    move_uploaded_file($_FILES['uploadedfile0']['tmp_name'],"./data/".$times.$_FILES['uploadedfile0']['name']);
    $files0 = $times.$_FILES['uploadedfile0']['name'];
    $file_f = "./data/".$times.$_FILES['uploadedfile0']['name'];
    
    img_resize_only($file_f, 2000, 2000); //리사이즈
    
    
    
    
    
    $info_image=getimagesize($file_f);
    switch($info_image['mime']){
    case "image/gif";
      $new_image=imagecreatefromgif($file_f);
      break;
    case "image/jpeg";
      $new_image=imagecreatefromjpeg($file_f);
      break;
    case "image/png";
      $new_image=imagecreatefrompng($file_f);
      break;
    case "image/bmp";
      $new_image=imagecreatefrombmp($file_f);
      break;
    }
    $w=200;
    $h=200;
    $canvas=imagecreatetruecolor($w,$h);
    imagecopyresampled($canvas,$new_image,0,0,0,0,$w,$h,$info_image[0],$info_image[1]);
    $dir_n="./data/thumbs_".$times.$_FILES['uploadedfile0']['name'];
    imagegif($canvas,$dir_n);
    $dir_n="thumbs_".$times.$_FILES['uploadedfile0']['name'];
  }
  if($_FILES['uploadedfile1']['name']) {
    
    move_uploaded_file($_FILES['uploadedfile1']['tmp_name'],"./data/".$times.$_FILES['uploadedfile1']['name']);
    $files1 = $times.$_FILES['uploadedfile1']['name'];
    $file_f = "./data/".$times.$_FILES['uploadedfile1']['name'];
    
    img_resize_only($file_f, 2000, 2000); //리사이즈
  }
  if($_FILES['uploadedfile2']['name']) {
    move_uploaded_file($_FILES['uploadedfile2']['tmp_name'],"./data/".$times.$_FILES['uploadedfile2']['name']);
    $files2 = $times.$_FILES['uploadedfile2']['name'];
    $file_f = "./data/".$times.$_FILES['uploadedfile2']['name'];
    
    img_resize_only($file_f, 2000, 2000); //리사이즈
  }
  if($_FILES['uploadedfile3']['name']) {
    move_uploaded_file($_FILES['uploadedfile3']['tmp_name'],"./data/".$times.$_FILES['uploadedfile3']['name']);
    $files3 = $times.$_FILES['uploadedfile3']['name'];
    $file_f = "./data/".$times.$_FILES['uploadedfile3']['name'];
    
    img_resize_only($file_f, 2000, 2000); //리사이즈
  }
  if($_FILES['uploadedfile4']['name']) {
    move_uploaded_file($_FILES['uploadedfile4']['tmp_name'],"./data/".$times.$_FILES['uploadedfile4']['name']);
    $files4 = $times.$_FILES['uploadedfile4']['name'];
    $file_f = "./data/".$times.$_FILES['uploadedfile4']['name'];
    
    img_resize_only($file_f, 2000, 2000); //리사이즈
  }
  if($_FILES['uploadedfile5']['name']) {
    move_uploaded_file($_FILES['uploadedfile5']['tmp_name'],"./data/".$times.$_FILES['uploadedfile5']['name']);
    $files5 = $times.$_FILES['uploadedfile5']['name'];
    $file_f = "./data/".$times.$_FILES['uploadedfile5']['name'];
    
    img_resize_only($file_f, 2000, 2000); //리사이즈
  }
  if($_FILES['uploadedfile6']['name']) {
    move_uploaded_file($_FILES['uploadedfile6']['tmp_name'],"./data/".$times.$_FILES['uploadedfile6']['name']);
    $files6 = $times.$_FILES['uploadedfile6']['name'];
    $file_f = "./data/".$times.$_FILES['uploadedfile6']['name'];
    
    img_resize_only($file_f, 2000, 2000); //리사이즈
  }
  if($_FILES['uploadedfile7']['name']) {
    move_uploaded_file($_FILES['uploadedfile7']['tmp_name'],"./data/".$times.$_FILES['uploadedfile7']['name']);
    $files7 = $times.$_FILES['uploadedfile7']['name'];
    $file_f = "./data/".$times.$_FILES['uploadedfile7']['name'];
    
    img_resize_only($file_f, 2000, 2000); //리사이즈
  }
  if($_FILES['uploadedfile8']['name']) {
    move_uploaded_file($_FILES['uploadedfile8']['tmp_name'],"./data/".$times.$_FILES['uploadedfile8']['name']);
    $files8 = $times.$_FILES['uploadedfile8']['name'];
    $file_f = "./data/".$times.$_FILES['uploadedfile8']['name'];
    
    img_resize_only($file_f, 2000, 2000); //리사이즈
  }
  if($_FILES['uploadedfile9']['name']) {
    move_uploaded_file($_FILES['uploadedfile9']['tmp_name'],"./data/".$times.$_FILES['uploadedfile9']['name']);
    $files9 = $times.$_FILES['uploadedfile9']['name'];
    $file_f = "./data/".$times.$_FILES['uploadedfile9']['name'];
    
    img_resize_only($file_f, 2000, 2000); //리사이즈
  }
  
  $dates = date("Y")."/".date("m")."/".date("d");
  
  $q = "insert into mshcool_board(phones, dates, subjects, hits, data1,data2,data3,data4,data5,data6,data7,data8,data9,data10,thumbs)
        values('$_GET[phone]','$dates','$_GET[subjects]','0','$files0','$files1','$files2','$files3','$files4','$files5','$files6','$files7','$files8','$files9','$dir_n')";
  mysql_query($q, $connect);
}





//갤러리 리스트
if($_GET[order] == 17) {
  
  $p_c = "6";
  $p_s = $_GET[page] * $p_c;
  $p_e = $p_s + $p_c-1;
  /*
  $q = "select count(*) from mshcool_board order by no desc limit $p_s, $p_c";
  $r = mysql_query($q, $connect);
  $d = mysql_fetch_array($r);
  echo $d[0];
  */
  
  $cnt = 0;
  $q = "select * from mshcool_board where subjects like '%$_GET[search]%' order by no desc limit $p_s, $p_c";
  $r = mysql_query($q, $connect);
  while($d = mysql_fetch_array($r)) {
    $cnt++;
  }
  echo $cnt;
  $q = "select * from mshcool_board where subjects like '%$_GET[search]%' order by no desc limit $p_s, $p_c";
  $r = mysql_query($q, $connect);
  while($d = mysql_fetch_array($r)) {
    $q2 = "select * from mschool_member where encodes='$d[phones]'";
    $r2 = mysql_query($q2, $connect);
    $d2 = mysql_fetch_array($r2);
    
    if(mb_strlen($d[subjects],"utf-8") > 13)
      $subjects_tmp = mb_substr($d[subjects],0,13,"utf-8")."...";
    else $subjects_tmp = $d[subjects];
    echo "-=-".$d[no]."_=_".$subjects_tmp."_=_".$d2[names]."_=_".$d[dates]."_=_".$d[hits]."_=_".$d[thumbs]."_=_0";
  }
}


//갤러리 보기
if($_GET[order] == 18) {
  if(!$_GET[no]) exit;
  

  
  $q = "select * from mshcool_board where no='$_GET[no]'";
  $r = mysql_query($q, $connect);
  $d = mysql_fetch_array($r);
  $q2 = "select * from mschool_member where encodes='$d[phones]'";
  $r2 = mysql_query($q2, $connect);
  $d2 = mysql_fetch_array($r2);
    
  echo $d[phones]."-=-".$d[subjects]."-=-".$d2[names]."-=-".$d[dates]."-=-".$d[hits]."-=-".$d[thumbs]."-=-".$d[data1]."-=-".$d[data2]."-=-".$d[data3]."-=-".$d[data4]."-=-".$d[data5]."-=-".$d[data6]."-=-".$d[data7]."-=-".$d[data8]."-=-".$d[data9]."-=-".$d[data10]."-=-0";

  //조회수 증가
  $tmp = $d[hits]+1;
  $q = "update mshcool_board set
        hits='$tmp' where no='$_GET[no]'";
  mysql_query($q, $connect);
}


//갤러리 삭제
if($_GET[order] == 19) {
  if(!$_GET[no]) exit;
  
  $q = "select * from mshcool_board where no='$_GET[no]'";
  $r = mysql_query($q, $connect);
  $d = mysql_fetch_array($r);
  
  //전화번호가 같을 경우만 삭제
  if($d[phones] != $_GET[phone]) exit;
  
  if($d[data1] != "none") unlink("./data/".$d[data1]);
  if($d[data2] != "none") unlink("./data/".$d[data2]);
  if($d[data3] != "none") unlink("./data/".$d[data3]);
  if($d[data4] != "none") unlink("./data/".$d[data4]);
  if($d[data5] != "none") unlink("./data/".$d[data5]);
  if($d[data6] != "none") unlink("./data/".$d[data6]);
  if($d[data7] != "none") unlink("./data/".$d[data7]);
  if($d[data8] != "none") unlink("./data/".$d[data8]);
  if($d[data9] != "none") unlink("./data/".$d[data9]);
  if($d[data10] != "none") unlink("./data/".$d[data10]);
  if($d[thumbs] != "none") unlink("./data/".$d[thumbs]);
  
  $qq = "delete from mshcool_board where no='$_GET[no]'";
  mysql_query($qq, $connect);
}


//동창회 회칙
if($_GET[order] == 20) {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<title>관인중고등학교238회</title>
</head>
<body style="margin:0px;padding:0px;">
<?
$qjk = "select * from mschool_jk where no='1'";
$rjk = mysql_query($qjk, $connect);
$djk = mysql_fetch_array($rjk);
?>
<?=$djk[memos]?>
</body>
</html>
<?
}















//날짜추가
if($_GET[order] == 21) {
//관리자면 로그인
$qad = "select * from mschool_login where user_pw='$temp'";
$rad = mysql_query($qad, $connect);
$dad = mysql_fetch_array($rad);

if(!$dad[no]) exit; //잘못된 접근


$q = "select count(*) from mschool_olddate where dates='$_GET[datey]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

//이미 존재하는 날짜
if($d[0] != 0) {
exit;
}

$q = "insert into mschool_olddate(dates)
                  values('$_GET[datey]')";
mysql_query($q, $connect);

}
?>