
<div class="kw_m_copy">
&nbsp;&nbsp;ⓒ2017 관인중고등학교238회 All rights reserved.
</div>

<? if($mobile == 0) {?>
</div>
<? }?>
<a name="bottomtxx"></a>
</body>
</html>
