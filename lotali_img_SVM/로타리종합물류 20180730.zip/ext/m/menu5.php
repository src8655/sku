<?
include "lib.php";
include "head.php";



$q = "select * from mschool_jk where no='1'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);


?>
<a href="index.php"><img src="./images/kw_m_menu5_top.png" width="100%;" /></a>

<? if($dmember[admins] == 1) {?>
<a href="menu5_add.php" class="kw_p_btn" style="width:95%;padding:10px 0 10px 0;">[날짜 추가하기]</a>
<? }?>

<div style="overflow:hidden;width:95%;margin:0 auto;margin-bottom:15px;padding:0px;border:3px solid #f2f2f2;background:#fafafa;font-size:20px;">
<div style="overflow:hidden;width:100%;border-bottom:3px solid #f2f2f2;">
  <div style="overflow:hidden;float:left;width:65px;">
    <img src="./images/kw_m_cal.png" width="25px" style="margin:10px 20px 10px 20px;" />
  </div>
  <div style="overflow:hidden;float:left;line-height:45px;">
    회비 납부연도 선택
  </div>
</div>
<ul class="kw_m_ul">
<?
$u = "select * from mschool_olddate order by dates desc";
$j = mysql_query($u, $connect);
while($m = mysql_fetch_array($j)) {
?>
  <li>
    <a href="menu5_in.php?oldd=<?=$m[no]?>" style="display:block;text-align:center;padding:20px 0 20px 0;"><?=$m[dates]?>년 납부내역</a>
  </li>
  
<?
}
?>
</ul>
</div>

<?
include "foot.php";
?>
