<?
include "lib.php";
include "head.php";



$q = "select * from mschool_jk where no='1'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);


?>
<script language="JavaScript" type="text/javascript" src="/alditor/alditor.js"></script>
<a href="index.php"><img src="./images/kw_m_menu2_top.png" width="100%;" /></a>

<form action="menu2_edit_post.php" method="post" id="edits">
<a href="#10" onclick="getElementById('edits').submit();" class="kw_p_btn" style="width:95%;padding:10px 0 10px 0;">[수정하기]</a>


<div style="overflow:hidden;width:95%;margin:0 auto;margin-bottom:15px;padding:0px;border:3px solid #f2f2f2;background:#fafafa;font-size:20px;">
  <textarea name="memos" style="width:394px;height:600px;"><?=$d[memos]?></textarea>
</div>
</form>
<?
include "foot.php";
?>
