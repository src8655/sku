<?
include "lib.php";
include "head.php";




?>
<a href="index.php"><img src="./images/kw_m_menu4_top.png" width="100%;" /></a>
<form action="menu4_add_post.php" id="adds">
<a href="#10" onclick="getElementById('adds').submit();" class="kw_p_btn" style="width:95%;padding:10px 0 10px 0;">[추가하기]</a>



<div style="overflow:hidden;width:95%;margin:0 auto;margin-bottom:15px;padding:0px;border:3px solid #f2f2f2;background:#fafafa;font-size:20px;">
<table border="0" cellpadding="5" cellspacing="0" class="kw_m_table">
<col width="25%" />
<col width="50%" />
<col width="25%" />

  <tr>
    <td height="30px;">이름</td>
    <td><input type="text" name="names" style="width:85%;font-size:20px;" /></td>
  </tr>
  <tr>
    <td height="30px;">전화번호</td>
    <td><input type="text" name="phones" style="width:85%;font-size:20px;" /></td>
  </tr>
  <tr>
    <td height="30px;" colspan="2">예) 01000000000</td>
  </tr>
</table>
</div>

<div style="width:1px;height:1px;overflow:hidden;"><input type="submit" value="<?=$_GET[no]?>" /></div>
</form>
<?
include "foot.php";
?>
