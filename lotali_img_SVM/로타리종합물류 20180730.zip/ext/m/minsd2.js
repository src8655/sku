
function displays(okl) {
	if(okl.style.display == "none") {
		okl.style.display = "";
	}else{
		okl.style.display = "none";
	}
}
function confirms(mass,urs) {
	var amms = confirm(mass);
	if(amms == false) {
		
	}else{
		location.href=urs;
	}
}
function locas(sdds) {
	location.href=sdds;
}




////////////////jquery


$(function(){
	// 달력
	$('.suv a').hover(function(){
		var mm = $(this).next();
		$(mm).slideToggle(200);
	});
	// 달력
	
	
	// 메일 회사검색
	$('#mailgom').hover(function(){
		$('#mail_aa').show(100);
	}, function(){
		$('#mail_aa').hide(100);
	});
	// 메일 회사검색
	
	
	// 날짜선택 더보기
	$('.olddatemore').click(function(){
		$('.olddatemo').slideToggle();
	}, function(){
		$('.olddatemo').slideToggle();
	});
	// 날짜선택 더보기
	
	
	// 메모창
	$('.memobuttons').click(function(){
		var ase = $('#memoz').val();
		var as = escape(ase);
		$('#querysz').load('memo_post.php?memo='+as);
		$('#zx1').load('index.php #zx1');
		$('#zx1').load('index.php #zx1');
		$('#zx3').load('index.php #zx3');
		$('#ze2').load('index.php #ze2');
	});
	$('.acv a').click(function(){
		var am = $(this).attr('class');
		var ams = am.split("a");
		var tm = "c"+am;
		$('#'+tm).addClass('hiddens');
		$('#querysz').load("memo_check2.php?no="+ams[1]);
		$('#zx3').load('index.php #zx3');
		$('#ze2').load('index.php #ze2');
	});
	// 메모창


	//배경색
	$('.colorp').click(function(){
		$('#topsaxx').slideToggle();
	});
	//배경식
	
	
	
	//회사찾기
	$("#fdkey").focus();
	$("#fdkey").bind('keyup',function(e){
	var key = $("#fdkey").val();
	var lens = key.length;
	var exh,ext,exta,exhtml;
	$("#cda").slideDown(100);
	$(".fd1").each(function(){
	  var fdtext = $(this).text();
	  $(this).html(fdtext);
	  var index = fdtext.search(key);
	  if(index >= 0) {
	    exh = fdtext.substr(0,index);
	    ext = fdtext.substr(index,lens);
	    exta = fdtext.substr(index+lens);
	    exhtml = exh+"<span style='background:yellow;font-weight:bold;'>"+ext+"</span>"+exta;
	    $(this).html(exhtml);
	  }else{ //대소문자모두찾기
	    index = fdtext.search(key.toUpperCase());
	    if(index >= 0) {
  	    exh = fdtext.substr(0,index);
  	    ext = fdtext.substr(index,lens);
  	    exta = fdtext.substr(index+lens);
  	    exhtml = exh+"<span style='background:yellow;font-weight:bold;'>"+ext+"</span>"+exta;
  	    $(this).html(exhtml);
	    }
	    index = fdtext.search(key.toLowerCase());
	    if(index >= 0) {
  	    exh = fdtext.substr(0,index);
  	    ext = fdtext.substr(index,lens);
  	    exta = fdtext.substr(index+lens);
  	    exhtml = exh+"<span style='background:yellow;font-weight:bold;'>"+ext+"</span>"+exta;
  	    $(this).html(exhtml);
	    }
	  }
	});
	
	});
	
	
	//회사찾기
	
	//입금자 회사찾기
	$("#fdkey2").bind('keyup',function(e){
	var key = $("#fdkey2").val();
	var lens = key.length;
	var exh,ext,exta,exhtml;
	$("#ipgm_list_hd").slideDown(100);
	$(".fd2").each(function(){
	  var fdtext = $(this).text();
	  var index = fdtext.search(key);
	  if(index >= 0) {
	    $(this).css("display","");
	  }else{ //대소문자모두찾기
	    
	    index = fdtext.search(key.toUpperCase());
	    if(index >= 0) 
  	    $(this).css("display","");
	    else{
  	    index = fdtext.search(key.toLowerCase());
  	    if(index >= 0) 
    	    $(this).css("display","");
  	    else{
  	      $(this).css("display","none");
  	    }
	    }
	  }
	});
	
	});
	
	
	//입금자 회사찾기
	
	
	
	//입금자 회사찾기
	$("#fdkey3").bind('keyup',function(e){
	var key = $("#fdkey3").val();
	var lens = key.length;
	var exh,ext,exta,exhtml;
	$("#ipgm_list_hd").slideDown(100);
	$(".fd3").each(function(){
	  var fdtext = $(this).text();
	  var index = fdtext.search(key);
	  if(index >= 0) {
	    $(this).css("display","");
	  }else{ //대소문자모두찾기
	    
	    index = fdtext.search(key.toUpperCase());
	    if(index >= 0) 
  	    $(this).css("display","");
	    else{
  	    index = fdtext.search(key.toLowerCase());
  	    if(index >= 0) 
    	    $(this).css("display","");
  	    else{
  	      $(this).css("display","none");
  	    }
	    }
	  }
	});
	
	});
	
	
	//입금자 회사찾기
	
	
	
	
	//입금자 회사찾기
	$("#dlts").click(function(){
	  $(".dels1").each(function(){
	    $(this).css("display","block");
	  });
	  $(".dels2").each(function(){
	      $(this).css("display","none");
	  });
	  $(".dels3").each(function(){
	      $(this).css("display","none");
	  });
	});
	$("#dlts2").click(function(){
	  $(".dels1").each(function(){
	    $(this).css("display","none");
	  });
	  $(".dels2").each(function(){
	      $(this).css("display","none");
	  });
	  $(".dels3").each(function(){
	      $(this).css("display","block");
	  });
	});
	
	
	
	
	
	
	});






////////////////jquery