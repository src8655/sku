<?
session_start();

unset($_SESSION["user_id_ext"]);
unset($_SESSION["password_ext"]);
?>
<script> 
  location.href='index.php'; 
</script>
