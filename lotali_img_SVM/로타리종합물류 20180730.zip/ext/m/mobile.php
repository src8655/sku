<?
include "./lib.php";
include "./head.php";

$_SESSION[mobiles] = 1;
?>
<script type="text/javascript">
  location.href="../mschool.php";
</script>
<?
include "./foot.php";
?>