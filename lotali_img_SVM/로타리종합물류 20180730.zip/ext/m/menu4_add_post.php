<?
include "lib.php";
include "head.php";
//�մ��� �ҹ�����
if($dmember[admins] != 1) {
  echo("
    <script>
      window.alert('�߸��� �����Դϴ�.')
      history.go(-1)
    </script>
  ");
exit;
}

$mds = md5($_GET[phones]);  //��ȣȭ
$q = "insert into mschool_member(names, phones, encodes)
                  values('$_GET[names]','$_GET[phones]','$mds')";
mysql_query($q, $connect);
?>
<script>
  location.href="menu4.php";
</script>
<?
include "foot.php";
?>
