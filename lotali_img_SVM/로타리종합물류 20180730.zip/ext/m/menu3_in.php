<?
include "lib.php";
include "head.php";



$q = "select * from mschool_jk where no='1'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);


?>
<a href="index.php"><img src="./images/kw_m_menu3_top.png" width="100%;" /></a>
<div style="overflow:hidden;width:95%;margin:0 auto;margin-bottom:15px;padding:0px;font-size:20px;">

<table border="0" cellpadding="5" cellspacing="0" class="kw_m_table2">
<col width="25%" />
<col width="75%" />
<?
$q = "select * from mshcool_board where no='$_GET[no]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

$qs = "select * from mschool_member where phones='$d[phones]'";
$rs = mysql_query($qs, $connect);
$ds = mysql_fetch_array($rs)
?>
  <tr>
    <td style="border-bottom:2px solid #f2f2f2;"><img src="../data/<?=$d[thumbs]?>" width="100%" /></td>
    <td style="text-align:left;border-bottom:2px solid #f2f2f2;">
      <a href="menu3_in.php?no=<?=$d[no]?>" style="display:block;">
        <span style="font-weight:bold;"><?=$d[subjects]?></span><br />
        작성일 : <?=$d[dates]?> 조회수 : <?=$d[hits]?><br />
        작성자 : <?=$ds[names]?>
      </a>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <? if($d[data1] != "none") {?><img src="../data/<?=$d[data1]?>" width="100%" /><br /><? }?>
      <? if($d[data2] != "none") {?><img src="../data/<?=$d[data2]?>" width="100%" /><br /><? }?>
      <? if($d[data3] != "none") {?><img src="../data/<?=$d[data3]?>" width="100%" /><br /><? }?>
      <? if($d[data4] != "none") {?><img src="../data/<?=$d[data4]?>" width="100%" /><br /><? }?>
      <? if($d[data5] != "none") {?><img src="../data/<?=$d[data5]?>" width="100%" /><br /><? }?>
      <? if($d[data6] != "none") {?><img src="../data/<?=$d[data6]?>" width="100%" /><br /><? }?>
      <? if($d[data7] != "none") {?><img src="../data/<?=$d[data7]?>" width="100%" /><br /><? }?>
      <? if($d[data8] != "none") {?><img src="../data/<?=$d[data8]?>" width="100%" /><br /><? }?>
      <? if($d[data9] != "none") {?><img src="../data/<?=$d[data9]?>" width="100%" /><br /><? }?>
      <? if($d[data10] != "none") {?><img src="../data/<?=$d[data10]?>" width="100%" /><br /><? }?>
    </div>
  </tr>
</table>
</div>
<?
include "foot.php";
?>
