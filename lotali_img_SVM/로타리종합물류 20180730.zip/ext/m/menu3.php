<?
include "lib.php";
include "head.php";



$q = "select * from mschool_jk where no='1'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);


?>
<a href="index.php"><img src="./images/kw_m_menu3_top.png" width="100%;" /></a>
<div style="overflow:hidden;width:95%;margin:0 auto;margin-bottom:15px;padding:0px;border:3px solid #f2f2f2;background:#fafafa;font-size:20px;">
<form action="<?=$PHP_SELF?>" id="searchs">
<div style="overflow:hidden;width:100%;">
  <div style="overflow:hidden;float:left;width:20%;">
    <img src="./images/kw_m_search.png" width="40px" style="margin:5px;" />
  </div>
  <div style="overflow:hidden;float:left;width:60%;">
    <input type="text" name="subjects" value="<?=$_GET[subjects]?>" placeholder="제목을 입력해주세요." style="margin:9px 0 0 0;background:#fafafa;border:0px;width:100%;font-size:20px;padding:5px 0 5px 0;" />
    <div style="width:1px;height:1px;overflow:hidden;"><input type="submit" value="0" /></div>
  </div>
  <div style="overflow:hidden;float:right;width:20%;text-align:right;">
    <a href="#" onclick="getElementById('searchs').submit();" style="display:block;padding:5px;"><img src="./images/kw_m_search_b.png" width="40px" /></a>
  </div>
</div>
</form>
</div>
<div style="overflow:hidden;width:95%;margin:0 auto;margin-bottom:15px;padding:0px;font-size:20px;">

<table border="0" cellpadding="5" cellspacing="0" class="kw_m_table2">
<col width="25%" />
<col width="75%" />
<?
$q = "select * from mshcool_board where subjects like '%$_GET[subjects]%' order by no desc";
$r = mysql_query($q, $connect);
while($d = mysql_fetch_array($r)) {
  $qs = "select * from mschool_member where phones='$d[phones]'";
  $rs = mysql_query($qs, $connect);
  $ds = mysql_fetch_array($rs)
?>
  <tr>
    <td style="border-bottom:2px solid #f2f2f2;"><img src="../data/<?=$d[thumbs]?>" width="100%" /></td>
    <td style="text-align:left;border-bottom:2px solid #f2f2f2;">
      <a href="menu3_in.php?no=<?=$d[no]?>" style="display:block;">
        <span style="font-weight:bold;"><?=$d[subjects]?></span><br />
        작성일 : <?=$d[dates]?> 조회수 : <?=$d[hits]?><br />
        작성자 : <?=$ds[names]?>
      </a>
    </td>
  </tr>
  
<?
}
?>
</table>
</div>
<?
include "foot.php";
?>
