<?
include "lib.php";
include "head.php";
//손님이 불법방지
if($dmember[admins] != 1) {
  echo("
    <script>
      window.alert('잘못된 접근입니다.')
      history.go(-1)
    </script>
  ");
exit;
}
if(!$_GET[no]) {
  echo("
    <script>
      window.alert('잘못된 접근입니다.')
      history.go(-1)
    </script>
  ");
  exit;
}

$mds = md5($_GET[phones]);  //암호화
$q = "update mschool_member set
      names='$_GET[names]',
      phones='$_GET[phones]',
      encodes='$mds' where no='$_GET[no]'";
mysql_query($q, $connect);
?>
<script>
  location.href="menu4.php";
</script>
<?
include "foot.php";
?>
