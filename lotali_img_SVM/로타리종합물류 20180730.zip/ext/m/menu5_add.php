<?
include "lib.php";
include "head.php";



$q = "select * from mschool_jk where no='1'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);


?>
<a href="index.php"><img src="./images/kw_m_menu5_top.png" width="100%;" /></a>

<form action="menu5_add_post.php" id="adds">
<a href="#10" onclick="getElementById('adds').submit();" class="kw_p_btn" style="width:95%;padding:10px 0 10px 0;">[추가하기]</a>

<div style="overflow:hidden;width:95%;margin:0 auto;margin-bottom:15px;padding:10px 0 10px 0;border:3px solid #f2f2f2;background:#fafafa;font-size:20px; text-align:center;">
          <select name="datey" class="ind_select" style="font-size:20px;">
          <?
          $sedate = date("Y");
          $cndate1 = $sedate-1;
          $cndate2 = $sedate+10;
          for($i=$cndate1;$i<$cndate2;$i++) {
          ?>
            <option value="<?=$i?>" <? if($sedate==$i) {?>selected<? }?>><?=$i?></option>
          <?
          }
          ?>
          </select>&nbsp;년
</div>

<div style="width:1px;height:1px;overflow:hidden;"><input type="submit" value="<?=$_GET[no]?>" /></div>
</form>
<?
include "foot.php";
?>
