<?
include "lib.php";
include "head.php";
//손님이 불법방지
if($dmember[admins] != 1) {
  echo("
    <script>
      window.alert('잘못된 접근입니다.')
      history.go(-1)
    </script>
  ");
exit;
}
if(!$_GET[no]) {
  echo("
    <script>
      window.alert('잘못된 접근입니다.')
      history.go(-1)
    </script>
  ");
  exit;
}





$q = "select count(*) from mschool_list where no='$_GET[no]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);
if($d[0] == 0) {
  echo("
    <script>
      window.alert('존재하지 않는 납부내역 입니다.')
      history.go(-1)
    </script>
  ");
  exit;
}







$q = "select * from mschool_list where no='$_GET[no]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

if($d[nos]) {
  echo("
  <script>
    window.alert('회비 입출금 내역도 함께 삭제되었습니다.');
  </script>
  ");
  $qr = "delete from mschool_bank where nos='$d[nos]'";
  mysql_query($qr, $connect);
}




//납부현황에 추가
$q = "delete from mschool_list where no='$_GET[no]'";
mysql_query($q, $connect);
?>
<script>
  location.href="menu5_in.php?oldd=<?=$_GET[oldd]?>";
</script>
<?
include "foot.php";
?>
