<?
include "lib.php";
include "head.php";
//손님이 불법방지
if($dmember[admins] != 1) {
  echo("
    <script>
      window.alert('잘못된 접근입니다.')
      history.go(-1)
    </script>
  ");
exit;
}
if(!$_GET[no]) {
  echo("
    <script>
      window.alert('잘못된 접근입니다.')
      history.go(-1)
    </script>
  ");
  exit;
}



$q = "select * from mschool_bank where no='$_GET[no]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

echo("
  <script>
    window.alert('삭제되었습니다.');
  </script>
");

if($d[nos]) {
  echo("
  <script>
    window.alert('회비납부현황도 함께 삭제되었습니다.');
  </script>
  ");
  $qr = "delete from mschool_list where nos='$d[nos]'";
  mysql_query($qr, $connect);
}
  
  
  
  


  
  
  
$q = "delete from mschool_bank where no='$_GET[no]'";
mysql_query($q, $connect);
?>
<script>
  location.href="menu6_in.php?oldd=<?=$_GET[oldd]?>";
</script>
<?
include "foot.php";
?>
