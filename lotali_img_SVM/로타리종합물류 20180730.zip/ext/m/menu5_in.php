<?
include "lib.php";
include "head.php";



$q = "select * from mschool_jk where no='1'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);


?>
<a href="index.php"><img src="./images/kw_m_menu5_top_in.png" width="100%;" /></a>

<a href="menu5_in_pdf.php?oldd=<?=$_GET[oldd]?>" target="_BLANK" class="kw_p_btn" style="width:95%;padding:10px 0 10px 0;color:#000000;">[인쇄하기]</a>

<div style="overflow:hidden;width:95%;margin:0 auto;margin-bottom:15px;padding:0px;border:3px solid #f2f2f2;background:#fafafa;font-size:20px;">
<form action="<?=$PHP_SELF?>" id="searchs">
<input type="hidden" name="oldd" value="<?=$_GET[oldd]?>" />
<div style="overflow:hidden;width:100%;border-bottom:3px solid #f2f2f2;">
  <div style="overflow:hidden;float:left;width:20%;">
    <img src="./images/kw_m_search.png" width="40px" style="margin:5px;" />
  </div>
  <div style="overflow:hidden;float:left;width:60%;">
    <input type="text" name="names" value="<?=$_GET[names]?>" placeholder="이름을 입력해주세요." style="margin:9px 0 0 0;background:#fafafa;border:0px;width:100%;font-size:20px;padding:5px 0 5px 0;" />
    <div style="width:1px;height:1px;overflow:hidden;"><input type="submit" value="0" /></div>
  </div>
  <div style="overflow:hidden;float:right;width:20%;text-align:right;">
    <a href="#" onclick="getElementById('searchs').submit();" style="display:block;padding:5px;"><img src="./images/kw_m_search_b.png" width="40px" /></a>
  </div>
</div>
</form>
<table border="0" cellpadding="15" cellspacing="0" class="kw_m_table">
<col width="25%" />
<col width="50%" />
<col width="25%" />
<?
$cnt = 1;
$totals = 0;

//입금한사람만 보기
$q = "select * from mschool_member where names like '%$_GET[names]%' order by names asc";
$r = mysql_query($q, $connect);
while($d = mysql_fetch_array($r)) {
  $qq = "select * from mschool_list where years='$_GET[oldd]' and members='$d[no]'";
  $rr = mysql_query($qq, $connect);
  $checks = mysql_fetch_array($rr);
  
  if(!$checks[no]) {
    $nab_result = "미납";
    continue;
  } else {
    $qq2 = "select * from mschool_bank where nos='$checks[nos]'";
    $rr2 = mysql_query($qq2, $connect);
    $checks2 = mysql_fetch_array($rr2);
    
    $nab_result = "<span style='color:red;'>".$checks[check_dates]." ".$checks2[memos]."<br />".number_format($checks[moneys])."원</span>";
  }
?>
  <tr>
    <td><?=$d[names]?></td>
    <td><?=$nab_result?></td>
    
<? if($dmember[admins] == 1) {?>
    <td>
      <a href="#10" onclick="confirms('삭제를 하시겠습니까?','menu5_in_del.php?no=<?=$checks[no]?>&oldd=<?=$_GET[oldd]?>');" style="font-size:17px;color:red;">[삭제]</a><br />
    </td>
<? }?>

  </tr>
<?
$cnt++;
}

//입금 안한사람만 보기
$q = "select * from mschool_member where names like '%$_GET[names]%' order by names asc";
$r = mysql_query($q, $connect);
while($d = mysql_fetch_array($r)) {
  $qq = "select * from mschool_list where years='$_GET[oldd]' and members='$d[no]'";
  $rr = mysql_query($qq, $connect);
  $checks = mysql_fetch_array($rr);
  
  if(!$checks[no]) {
    $nab_result = "<span style='color:blue;'>[미납]</span>";
  } else {
    continue;
  }
?>
  <tr>
    <td><?=$d[names]?></td>
    <td><?=$nab_result?></td>
    
<? if($dmember[admins] == 1) {?>
    <td>
      <a href="menu5_in_add.php?no=<?=$d[no]?>&oldd=<?=$_GET[oldd]?>" style="font-size:17px;color:blue;">[추가]</a><br />
    </td>
<? }?>

  </tr>
<?
$cnt++;
}
?>
</table>
</div>

<?
include "foot.php";
?>
