<?
include "lib.php";
include "head.php";



$q_no = "select * from mschool_notice";
$r_no = mysql_query($q_no, $connect);
$d_no = mysql_fetch_array($r_no);


?>
<a href="index.php"><img src="./images/kw_m_menu1_top.png" width="100%;" /></a>

<? if($dmember[admins] == 1) {?>
<a href="menu1_edit.php" class="kw_p_btn">[수정하기]</a>
<? }?>

<div style="overflow:hidden;width:85%;margin:0 auto;margin-bottom:15px;padding:15px;border:3px solid #f2f2f2;background:#fafafa;font-size:20px;">
<?=nl2br($d_no[memos])?>
</div>

<?
include "foot.php";
?>
