<?
include "lib.php";
include "head.php";



$q = "select * from mschool_jk where no='1'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);


?>
<a href="index.php"><img src="./images/kw_m_menu4_top.png" width="100%;" /></a>

<? if($dmember[admins] == 1) {?>
<a href="menu4_add.php" class="kw_p_btn" style="width:95%;padding:10px 0 10px 0;">[추가하기]</a>
<? }?>


<div style="overflow:hidden;width:95%;margin:0 auto;margin-bottom:15px;padding:0px;border:3px solid #f2f2f2;background:#fafafa;font-size:20px;">
<form action="<?=$PHP_SELF?>" id="searchs">
<div style="overflow:hidden;width:100%;border-bottom:3px solid #f2f2f2;">
  <div style="overflow:hidden;float:left;width:20%;">
    <img src="./images/kw_m_search.png" width="40px" style="margin:5px;" />
  </div>
  <div style="overflow:hidden;float:left;width:60%;">
    <input type="text" name="names" value="<?=$_GET[names]?>" placeholder="이름을 입력해주세요." style="margin:9px 0 0 0;background:#fafafa;border:0px;width:100%;font-size:20px;padding:5px 0 5px 0;" />
    <div style="width:1px;height:1px;overflow:hidden;"><input type="submit" value="0" /></div>
  </div>
  <div style="overflow:hidden;float:right;width:20%;text-align:right;">
    <a href="#" onclick="getElementById('searchs').submit();" style="display:block;padding:5px;"><img src="./images/kw_m_search_b.png" width="40px" /></a>
  </div>
</div>
</form>
<table border="0" cellpadding="5" cellspacing="0" class="kw_m_table">
<col width="25%" />
<col width="50%" />
<col width="25%" />
<?
$q = "select * from mschool_member where names like '%$_GET[names]%' order by names asc";
$r = mysql_query($q, $connect);
while($d = mysql_fetch_array($r)) {
  $str_counts = mb_strlen($d[phones], "UTF-8");  //전화번호 문자열 개수
  if($str_counts == 11) $str_phones = mb_substr($d[phones], 0, 3)."-".mb_substr($d[phones], 3, 4)."-".mb_substr($d[phones], 7, 4);
  else if($str_counts == 10) $str_phones = mb_substr($d[phones], 0, 3)."-".mb_substr($d[phones], 3, 3)."-".mb_substr($d[phones], 6, 4);
  else $str_phones = $d[phones];
?>
  <tr>
    <td height="30px;"><?=$d[names]?></td>
    <td><?=$str_phones?></td>
    <? if($dmember[admins] == 1) {?>
      <td>
        <a href="menu4_edit.php?no=<?=$d[no]?>" style="font-size:17px;color:blue;">[수정]</a><br />
        <a href="#10" onclick="confirms('삭제를 하시겠습니까?','menu4_del.php?no=<?=$d[no]?>');" style="font-size:17px;color:red;">[삭제]</a>
      </td>
    <? }else{?>
    <td style="margin-top:5px;"><a href="tel:<?=$str_phones?>"><img src="./images/kw_m_call.png" width="80%" /></a></td>
    <? }?>
  </tr>
  
<?
}
?>
</table>
</div>

<?
include "foot.php";
?>
