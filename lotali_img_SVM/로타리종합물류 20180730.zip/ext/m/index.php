<?
include "lib.php";
include "head.php";



$q_no = "select * from mschool_notice";
$r_no = mysql_query($q_no, $connect);
$d_no = mysql_fetch_array($r_no);


?>
<a href="logout.php"><img src="./images/kw_m_bg.png" width="100%" /></a>
<div style="width:100%;">
  <div style="width:100%;">
    <div style="width:50%;float:left;">
      <a href="menu1.php"><img src="./images/kw_m_menu1.png" width="100%" /></a>
    </div>
    <div style="width:50%;float:right;">
      <a href="menu2.php"><img src="./images/kw_m_menu2.png" width="100%" /></a>
    </div>
  </div>
  <div style="width:100%;">
    <div style="width:50%;float:left;">
      <a href="menu3.php"><img src="./images/kw_m_menu3.png" width="100%" /></a>
    </div>
    <div style="width:50%;float:right;">
      <a href="menu4.php"><img src="./images/kw_m_menu4.png" width="100%" /></a>
    </div>
  </div>
  <div style="width:100%;">
    <div style="width:50%;float:left;">
      <a href="menu5.php"><img src="./images/kw_m_menu5.png" width="100%" /></a>
    </div>
    <div style="width:50%;float:right;">
      <a href="menu6.php"><img src="./images/kw_m_menu6.png" width="100%" /></a>
    </div>
  </div>
</div>


<?
include "foot.php";
?>
