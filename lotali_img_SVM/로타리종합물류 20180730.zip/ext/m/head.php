<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<title>관인중고등학교238회</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="naver-site-verification" content="82f8bf99af4e285d4b28ccb95bd67ab4a7f07754"/>
<link rel="stylesheet" type="text/css" href="./mkwgoo.css" />
<script type="text/javascript" src="./minsd2.js"></script>
</head>
<body id="bodys">
<a name="toptxx"></a>

<? if($mobile == 0) {?>
<div class="kw_p_content" style="background:#ffffff;margin:0 auto;width:400px;">
  <div class="kw_m_copy">
  &nbsp;&nbsp;[PC버전]
  &nbsp;&nbsp;<a href="https://play.google.com/store/apps/details?id=com.kwmiddleschool.kw238" style="font-weight:bold;color:#ffffff;">[앱 설치]</a>
  &nbsp;&nbsp;<a href="../readerdc_install.exe" style="font-weight:bold;color:#ffffff;">[인쇄가 안될때]</a>
  </div>
<? }?>