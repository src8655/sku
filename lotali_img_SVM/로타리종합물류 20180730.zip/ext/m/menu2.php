<?
include "lib.php";
include "head.php";



$q = "select * from mschool_jk where no='1'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);


?>
<a href="index.php"><img src="./images/kw_m_menu2_top.png" width="100%;" /></a>

<a href="menu2_pdf.php" target="_BLANK" class="kw_p_btn" style="color:#000000;">[인쇄하기]</a>
<? if($dmember[admins] == 1) {?>
<a href="menu2_edit.php" class="kw_p_btn">[수정하기]</a>
<? }?>

<div style="overflow:hidden;width:85%;margin:0 auto;margin-bottom:15px;padding:15px;border:3px solid #f2f2f2;background:#fafafa;font-size:20px;">
<?=$d[memos]?>
</div>

<?
include "foot.php";
?>
