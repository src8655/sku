<?
include "lib.php";
include "head.php";
//손님이 불법방지
if($dmember[admins] != 1) {
  echo("
    <script>
      window.alert('잘못된 접근입니다.')
      history.go(-1)
    </script>
  ");
exit;
}
if(!$_GET[dates1]) {
  echo("
    <script>
      window.alert('월을 입력해주세요')
      history.go(-1)
    </script>
  ");
exit;
}
if(!$_GET[dates2]) {
  echo("
    <script>
      window.alert('일을 입력해주세요')
      history.go(-1)
    </script>
  ");
exit;
}
$dates1 = $_GET[dates1];
$dates2 = $_GET[dates2];
if($_GET[dates1] == "1") $_GET[dates1] = "01";
if($_GET[dates1] == "2") $_GET[dates1] = "02";
if($_GET[dates1] == "3") $_GET[dates1] = "03";
if($_GET[dates1] == "4") $_GET[dates1] = "04";
if($_GET[dates1] == "5") $_GET[dates1] = "05";
if($_GET[dates1] == "6") $_GET[dates1] = "06";
if($_GET[dates1] == "7") $_GET[dates1] = "07";
if($_GET[dates1] == "8") $_GET[dates1] = "08";
if($_GET[dates1] == "9") $_GET[dates1] = "09";

if($_GET[dates2] == "1") $_GET[dates2] = "01";
if($_GET[dates2] == "2") $_GET[dates2] = "02";
if($_GET[dates2] == "3") $_GET[dates2] = "03";
if($_GET[dates2] == "4") $_GET[dates2] = "04";
if($_GET[dates2] == "5") $_GET[dates2] = "05";
if($_GET[dates2] == "6") $_GET[dates2] = "06";
if($_GET[dates2] == "7") $_GET[dates2] = "07";
if($_GET[dates2] == "8") $_GET[dates2] = "08";
if($_GET[dates2] == "9") $_GET[dates2] = "09";

$dates = $_GET[dates1]."/".$_GET[dates2];



$q = "insert into mschool_bank(dates, dates1, dates2, names, moneys1, moneys2, memos, years)
                  values('$dates','$dates1','$dates2','$_GET[names]','$_GET[moneys1]','$_GET[moneys2]','$_GET[memos]','$_GET[oldd]')";
mysql_query($q, $connect);
?>
<script>
  location.href="menu6_in.php?oldd=<?=$_GET[oldd]?>";
</script>
<?
include "foot.php";
?>
