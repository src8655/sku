<?
define('FPDF_FONTPATH','../home/mpdf/font/');  
require_once '../home/mpdf/mpdf.php';
 
// 함수의 원형 : function mPDF($mode='',$format='A4',$default_font_size=0,$default_font='',$mgl=15,$mgr=15,$mgt=16,$mgb=16,$mgh=9,$mgf=9, $orientation='P')
$pdf = new mPDF('ko');

ob_start(); 
?>
<?
include "lib.php";
include "head2.php";

$q = "select * from mschool_jk where no='1'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);


?>


<?=$d[memos]?>





<?
include "foot2.php";
?>

<?
$html=ob_get_contents(); 
ob_end_clean(); 
$html = iconv("UTF-8","UTF-8",$html);
$pdf->SetTopMargin(25);
$pdf->bookmark("회비납부현황",0);
// $pdf->SetDisplayMode('fullwidth');   // pdf가 열릴때 창크기에 맞게 보여지도록 함. 이부분이 주석처리되거나 삭제되면 창크기에 맞춰지지 않고 pdf Viewer의 설정을 따르게됨
$pdf->WriteHTML($html);
$pdf->Output();     // 웹상에서 열림
?>
