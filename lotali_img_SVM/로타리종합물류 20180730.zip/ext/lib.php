<?
extract($_GET);
extract($_POST);
extract($_SERVER);
extract($_COOKIE);

$connect = mysql_connect("localhost","lsm8655","snrnsi11"); 
mysql_select_db("lsm8655", $connect);

mysql_query("set names utf8"); 

//함수

function selectc($sq1,$sq2) {
	global $connect;
	$result1 = "select count(*) from $sq1 $sq2";
	$result2 = mysql_query($result1, $connect);
	$result3 = mysql_fetch_array($result2);
	$result = $result3[0];
	
	return $result;
}

function toString($text){
   return iconv('UTF-16LE', 'UTF-8', chr(hexdec(substr($text[1], 2, 2))).chr(hexdec(substr($text[1], 0, 2))));
}
function unescape($text){
   return urldecode(preg_replace_callback('/%u([[:alnum:]]{4})/', 'toString', $text));
}

//함수

$yyo = "1";
$qyyo = "select count(*) from min_board_memo where checks='$yyo'";
$ryyo = mysql_query($qyyo, $connect);
$dyyo = mysql_fetch_array($ryyo);
$dyyocount = $dyyo[0];



$comasss = md5("dbswornjs1");

session_start();

if($_SESSION["user_id_ext"] && $_SESSION["password_ext"]) {

$user_idsop = $_SESSION["user_id_ext"];
$passwordsop = $_SESSION["password_ext"];

$qmember = "select * from mschool_login where user_id='$user_idsop' and user_pw='$passwordsop'";
$rmember = mysql_query($qmember, $connect);
$dmember = mysql_fetch_array($rmember);
}

?>
<?
if(!$dmember[user_id]) {
include "head.php";
?>
<div id="login_oo">
  <h1>LOGIN</h1>
  <form action="login.php" name="loginfocus">
  <div style="float:left; width:227px;">
    <div id="login_left_oo">전화번호</div>
    <div id="login_right_oo">
      <input type="text" name="password_ext" class="login_in_oo0" />
    </div>
  </div>
  <div style="float:right;">
    <input type="submit" value="LOGIN" id="login_bu_oo" style="height:32px;" />
  </div>
  </form>
  <div style="text-align:center;font-family:'Arial';font-size:15px;width:100%;overflow:hidden;">
    예) 01000000000
  </div>
</div>
<?
include "foot.php";
exit;
}
?>
