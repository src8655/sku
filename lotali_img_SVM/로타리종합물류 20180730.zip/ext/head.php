<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>관인중고등학교238회</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="naver-site-verification" content="82f8bf99af4e285d4b28ccb95bd67ab4a7f07754"/>
<link rel="stylesheet" type="text/css" href="./minhogood2.css" />
<script src="../jquery/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="./minsd2.js"></script>
<script type="text/javascript">
</script>
</head>
<body id="bodys" onLoad="firstfocus()">
<a name="toptxx"></a>
<div style="background:#ffffff; width:1000px; margin:0 auto; padding:10px;overflow:hidden;">
<div id="header">
  <div id="calsmm" class="suv" style="width:189px;float:left;margin:18px 0 0 20px;">
		<a href="./mschool.php"><img src="./images/logos222.png" alt="관인중고등학교238회" width="189" height="40" /></a>
  </div>
  
  <div id="calsmm" class="suv">
		<a href="./logout.php"><img src="./images/logs.png" width="75" height="76" /></a>
  </div>
  <div id="calsmm" class="suv">
		<a href="./readerdc_install.exe"><img src="./images/adobes.png" width="75" height="76" /></a>
  </div>
  <div id="calsmm" class="suv">
		<a href="https://play.google.com/store/apps/details?id=com.kwmiddleschool.kw238"><img src="./images/apps.png" width="75" height="76" /></a>
  </div>
</div>
<script>
      location.href='./m/index.php'
</script>
<?
//모바일
$mobile = !!(FALSE !== strstr(strtolower($_SERVER['HTTP_USER_AGENT']), 'mobile'));

if(($_SESSION[mobiles] != 1)&&($mobile != 0)) {
  echo("
    <script>
      location.href='./m/index.php'
    </script>
  ");
}
?>