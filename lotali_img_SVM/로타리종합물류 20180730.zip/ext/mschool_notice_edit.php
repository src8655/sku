<?
include "lib.php";
include "head.php";
//손님이 불법방지
if($dmember[admins] != 1) {
  echo("
    <script>
      window.alert('잘못된 접근입니다.')
      history.go(-1)
    </script>
  ");
exit;
}


$q = "update mschool_notice set
      memos='$_GET[memos]'";
mysql_query($q, $connect);
?>
<script>
  location.href="mschool.php?oldd=<?=$_GET[oldd]?>";
</script>
<?
include "foot.php";
?>
