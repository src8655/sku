<?
define('FPDF_FONTPATH','../home/mpdf/font/');  
require_once '../home/mpdf/mpdf.php';
 
// 함수의 원형 : function mPDF($mode='',$format='A4',$default_font_size=0,$default_font='',$mgl=15,$mgr=15,$mgt=16,$mgb=16,$mgh=9,$mgf=9, $orientation='P')
$pdf = new mPDF('ko');

ob_start(); 
?>
<?
include "lib.php";
include "head2.php";


//날짜
  $qu = "select * from mschool_olddate where no='$_GET[oldd]'";
  $re = mysql_query($qu, $connect);
  $da = mysql_fetch_array($re);


$cnt = 1;
$money_cnt = 0;
$money_cnt1 = 0;
$money_cnt2 = 0;
$q = "select * from mschool_bank where years='$_GET[oldd]' order by dates asc, no asc";
$r = mysql_query($q, $connect);

?>
<div style="text-align:center;width:100%;font-size:25px;padding:0 0 25px 0;"><?=$da[dates]?>년 회비 입출금내역</div>
<table cellpadding="3" cellspacing="0" width="100%" id="print_a">
<col width="100" />
<col width="100" />
<col width="120" />
<col width="120" />
<col width="120" />
<col width="170" />
  <tr>
    <th width="100" height="30">월/일</th>
    <th width="100">이름</th>
    <th width="120">입금</th>
    <th width="120">지출</th>
    <th width="120">잔액</th>
    <th width="170">내용</th>
  </tr>
<?

while($d = mysql_fetch_array($r)) {
  $money_cnt = $money_cnt+$d[moneys1];
  $money_cnt = $money_cnt-$d[moneys2];
  
  //합계
  $money_cnt1 = $money_cnt1+$d[moneys1];
  $money_cnt2 = $money_cnt2+$d[moneys2];
?>
  <tr>
    <td align="center" height="30">&nbsp;<?=$d[dates]?></td>
    <td align="center">&nbsp;<?=$d[names]?></td>
    <td align="right"><?=number_format($d[moneys1])?> 원</td>
    <td align="right"><?=number_format($d[moneys2])?> 원</td>
    <td align="right"><?=number_format($money_cnt)?> 원</td>
    <td align="center">&nbsp;<?=$d[memos]?></td>
  </tr>
<?
$cnt++;
}
?>


  <tr>
    <td align="center" height="30">&nbsp;</td>
    <td align="center">&nbsp;합계</td>
    <td align="right"><?=number_format($money_cnt1)?> 원</td>
    <td align="right"><?=number_format($money_cnt2)?> 원</td>
    <td align="right"><?=number_format($money_cnt1-$money_cnt2)?> 원</td>
    <td align="center">&nbsp;</td>
  </tr>
  
  
</table>
<?
include "foot2.php";
?>

<?
$html=ob_get_contents(); 
ob_end_clean(); 
$html = iconv("UTF-8","UTF-8",$html);
$pdf->SetTopMargin(25);
$pdf->bookmark("회비납부현황",0);
// $pdf->SetDisplayMode('fullwidth');   // pdf가 열릴때 창크기에 맞게 보여지도록 함. 이부분이 주석처리되거나 삭제되면 창크기에 맞춰지지 않고 pdf Viewer의 설정을 따르게됨
$pdf->WriteHTML($html);
$pdf->Output();     // 웹상에서 열림
?>
