<div id="copyrights">
  Copyright ⓒ 2017~<?=date("Y")?> 관인중고등학교238회 All rights reserved.
</div>
<?
if($mobile != 0) {
?>
<a href="mobile.php" style="text-decoration:none;color:#676767;padding:10px 0 10px 0;text-align:center;display:block;width:998px;margin:0 auto;border:1px solid #676767;font-size:50px;">모바일 버전으로 보기</a>
<?
}
?>
</div>
<a name="bottomtxx"></a>
</body>
</html>
