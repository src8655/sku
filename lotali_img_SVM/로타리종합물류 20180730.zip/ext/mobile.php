<?
include "./libs.php";
include "./head.php";

$_SESSION[mobiles] = 0;
?>
<script type="text/javascript">
  location.href="./index.php";
</script>
<?
include "./foot.php";
?>