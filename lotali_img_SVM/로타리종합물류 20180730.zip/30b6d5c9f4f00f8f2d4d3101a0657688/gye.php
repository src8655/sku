<?
include "lib.php";
include "head.php";

if($Search_mode) {
	if($Search_mode == 1) $temp = "name";
	if($Search_mode == 2) $temp = "number";
	
	$wheres = "where company='$company' and $temp like '%$Search_text%'";
}else{
	$wheres = "where company='$company'";
}

$query = "select * from min_board_gye $wheres order by name asc";
$result = mysql_query($query, $connect);

$qgye1 = "select count(*) from min_board_gye $wheres";
$rgye1 = mysql_query($qgye1, $connect);
$dgye1 = mysql_fetch_array($rgye1);
?>

<div class="imbody" style="text-align:center;font-weight:bold;">
	<h1 style="font-size:30px;color:#000000;margin:5px 0 10px 0;padding:0 0 5px 0;border-bottom:1px solid #676767;">
		<? if($company == "1") {?>
		계좌번호 5t 기준
		<? }else{ if($company == "2") {?>
		계좌번호 1t~3.5t
		<? }else{ if($company == "3") {?>
		계좌번호 외주차
		<? }else{ if($company == "6") {?>
		계좌번호 거래처
		<? }}}}?>
		 - <span style="color:red"><?=$dgye1[0]?></span>
	</h1>
<form action="<?=$PHP_SELF?>">
<input type="hidden" name="company" value="<?=$company?>" />
      <select name="Search_mode" style="font-size:17px;padding:5px;display:none;">
				<option value="1">이름</option>
				<option value="2">차량번호</option>
      </select>
      <input type="text" name="Search_text" <? if($Search_mode) {?>value="<?=$Search_text?>"<? }?> style="border:1px solid #676767;font-size:22px;padding:5px 0 5px 0;width:66%;" />
      <input type="submit" value="검색" style="border:1px solid #676767;width:28%;background:#ffffff;font-size:22px;padding:5px;font-weight:bold;" />
</div>
<?
while($data = mysql_fetch_array($result)) {
?>
<div class="imbody" style="font-weight:bold;">
		<h1><?=$data[name]?> <? if($data[number]) {?>[<?=$data[number]?>]<? }?></h1>
		<?=$data[bank]?> <?=$data[gye]?>
</div>
<?
}
?>
<?
include "foot.php";
?>
