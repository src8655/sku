<?
include "lib.php";
include "head.php";
?>
	<script>
		var amm = confirm('체크를 하시겠습니까?');
		if(amm == false){
			history.go(-1)
		}else{
			location.href="memo_checks.php?no=<?=$no?>";
		}
	</script>
<?
include "foot.php";
?>
