<?
include "lib.php";
include "head.php";


$qhc = "select * from min_board_admin where orders='1'";
$rhc = mysql_query($qhc, $connect);
$hidecnt = 0;
while($dhc = mysql_fetch_array($rhc)) {
	$qhi = "select count(*) from min_board_admin_hide where olddate='$olddate' and company='$dhc[company]'";
	$rhi = mysql_query($qhi, $connect);
	$dhi = mysql_fetch_array($rhi);
	if($dhi[0] == 0) $hidecnt += 1;
}

$qqqorban1 = ceil($hidecnt/2);
$qmemos = "select * from min_board_memo where checks='1' order by no asc";
$rmemos = mysql_query($qmemos, $connect);
?>
<?
while($dmemos = mysql_fetch_array($rmemos)) {
?>
	<div id="memo_body">
		<div id="memo_left">
			<?=$dmemos[date]?><a href="memo_check.php?no=<?=$dmemos[no]?>" id="memo_button">확인안함</a>
		</div>
		<div id="memo_right">
			<?=nl2br($dmemos[memo])?>
		</div>
	</div>
<?
}
?>
<?
$qqmemos = "select * from min_board_memo where checks='1'";
$rrmemos = mysql_query($qqmemos, $connect);
$ddmemos = mysql_fetch_array($rrmemos);
if(!$ddmemos[no]) {
?>
	<div class="imbody">
		새로쓴 메모가 없습니다.
	</div>
<?
}
?>
<?
if(!$olddate) {
$u = "select * from min_board_olddate order by date desc";
$j = mysql_query($u, $connect);

$qinfo = "select count(*) from min_board_info";
$rinfo = mysql_query($qinfo, $connect);
$dinfo = mysql_fetch_array($rinfo);
$infocount = $dinfo[0];

$qinfos = "select count(*) from min_board_member";
$rinfos = mysql_query($qinfos, $connect);
$dinfos = mysql_fetch_array($rinfos);
$infocounts = $dinfos[0];
?>
  <div class="goodminho">
    <h1>정보</h1>
    <ul>
      <li style="width:100%;"><a href="company_info.php" style="width:100%;">회사정보 - <span style="font-size:25px; color:red;"><?=$infocount?></span></a></li>
      <li style="width:100%;"><a href="member_info.php" style="width:100%;">기사정보 - <span style="font-size:25px; color:red;"><?=$infocounts?></span></a></li>
      
      <li style="width:100%;display:none;">
      	<a href="sms:?body=<?="등록번호:127-41-44169 상호:로타리종합물류 성명:전명숙 주소:경기도 양주시 은현면 화합로 959  업태:서비스업  종목:운송주선사업  우편:11430"?>" style="width:65%;float:left;color:blue;font-weight:bold;">세금계산서 문자</a>
				<a href="copy.php?ss=<?=urlencode('등록번호:127-41-44169 상호:로타리종합물류 성명:전명숙 주소:경기도 양주시 은현면 화합로 959  업태:서비스업  종목:운송주선사업  우편:11430')?>" id="copy-description" style="line-height:43px;padding:0px;width:27%;float:right;background:blue;color:#ffffff;font-weight:bold;text-align:center;">복사</a>
      </li>
      <li style="width:100%;">
      	<a href="sms:?body=<?="등록번호:127-24-44779 상호:로타리종합물류 성명:윤재권 주소:경기도 양주시 은현면 화합로 959(1층) 업태:서비스업 종목:화물운송대행 우편:11430"?>" style="height:47px;line-height:47px;padding:0 0 0 13px;width:65%;float:left;color:blue;font-weight:bold;">세금계산서 문자</a>
				<a href="copy.php?ss=<?=urlencode('등록번호:127-24-44779 상호:로타리종합물류 성명:윤재권 주소:경기도 양주시 은현면 화합로 959(1층) 업태:서비스업 종목:화물운송대행 우편:11430')?>" id="copy-description" style="height:47px;display:block;line-height:47px;padding:0px;width:27%;float:right;background:blue;color:#ffffff;font-weight:bold;text-align:center;">복사</a>
      </li>
    	
    	
      <form action="mass.php">
      	<input type="hidden" name="bodys" value="로타리종합물류 계좌 농협 351-0737-4897-53 윤재권" />
      <li style="width:100%;">
      	<input type="submit" value=" 계좌번호 문자" style="height:47px;line-height:47px;padding:0 0 0 7px;color:blue;text-align:left;background:#ffffff;font-size:30px;border:none;width:65%;float:left;font-weight:bold;" />
				<a href="copy.php?ss=<?=urlencode('로타리종합물류 계좌 농협 351-0737-4897-53 윤재권')?>" id="copy-description" style="height:47px;background:blue;color:#ffffff;font-weight:bold;width:27%;line-height:47px;display:block;padding:0px;float:right;text-align:center;">복사</a>
      </li>
      <li style="width:100%;padding:20px 0 20px 0;" class="mmoneys">
      	<div style="width:160px;margin:0 auto;">
	      	<input type="checkbox" id="moneys1s" name="moneys1" value="1만원" />
	      	<label for="moneys1s">1</label>
	      	<input type="checkbox" id="moneys2s" name="moneys2" value="2만원" />
	      	<label for="moneys2s">2</label>
	      	<input type="checkbox" id="moneys3s" name="moneys3" value="3만원" />
	      	<label for="moneys3s" style="margin:0px;">3</label>
      	</div>
      </li>
      
    	</form>
    	
      <li style="width:100%;">
      	<a href="sms:?body=<?="로타리종합물류 이메일주소 : qwq6735@naver.com"?>" style="height:47px;line-height:47px;padding:0 0 0 13px;width:65%;float:left;color:blue;font-weight:bold;">이메일 문자</a>
				<a href="copy.php?ss=<?=urlencode('로타리종합물류 이메일주소 : qwq6735@naver.com')?>" id="copy-description" style="height:47px;display:block;line-height:47px;padding:0px;width:27%;float:right;background:blue;color:#ffffff;font-weight:bold;text-align:center;">복사</a>
      </li>
    </ul>
  </div>
  
  
<script>
	function getCookie(cookieName){
		var cookieValue=null;
		if(document.cookie){
			var array=document.cookie.split((escape(cookieName)+'='));
			if(array.length >= 2){
				var arraySub=array[1].split(';');
				cookieValue=unescape(arraySub[0]);
				}
			}
		return cookieValue;
	}
	function findnum(a) {
		var b = getCookie("mnpn");
		var ee = document.getElementById(a);
		ee.innerHTML = b;
	}
</script>
  
  <div class="goodminho">
    <h1>날짜선택</h1>
    <ul>
<?
$gatt = "6";
$gcnt = "1";
$gcnt2 = "1";

$qg = "select * from min_board_olddate order by date desc";
$rg = mysql_query($qg, $connect);

while($m = mysql_fetch_array($j)) {

$olst = "1";
$olsxxt = "1";

$qst = "select count(*) from min_board_data1 where olddate='$m[olddate]' and del='$olsxxt'";
$rst = mysql_query($qst, $connect);
$adst = mysql_fetch_array($rst);
$adscountt = $adst[0];

$qsts = "select count(*) from min_board_data2 where olddate='$m[olddate]'";
$rsts = mysql_query($qsts, $connect);
$adsts = mysql_fetch_array($rsts);
$adscountts = $adsts[0];

$qsts2 = "select count(*) from min_board_data3 where olddate='$m[olddate]'";
$rsts2 = mysql_query($qsts2, $connect);
$adsts2 = mysql_fetch_array($rsts2);
$adscountts2 = $adsts2[0];

$adstotal = $adscountt+$adscountts+$adscountts2;

//미입금현황
$qr = "select count(*) from min_board_ep where olddate='$m[olddate]' and date='' and date2=''";
$rr = mysql_query($qr, $connect);
$eps = mysql_fetch_array($rr);
$ep = $eps[0];
$ep2 = selectc("min_board_ep","where olddate='$m[olddate]'");
?>
      <li style="width:100%;<? if($gcnt > $gatt) {?>display:none;<? }?>" <? if($gcnt > $gatt) {?>id="gmmq<?=$m[olddate]?>"<? }?>><a href="index.php?olddate=<?=$m[olddate]?>" style="width:100%;"><?=$m[date]?> - <span style="font-size:25px; color:red;"><?=$adstotal?></span> <span style="font-size:25px; color:orange;"><? if(($ep2!=0)&&($ep==0)) {?>완결<? }else{?>(<?=$ep?>)<? }?></span></a></li>
			<? if($gcnt == $gatt) {?><li style="width:100%;"><a onclick="<? while($dg = mysql_fetch_array($rg)) {if($gcnt2 > $gatt) {?>golem(gmmq<?=$dg[olddate]?>);<? } $gcnt2 += 1;}?>" style="background:none;text-align:center;padding-left:0px;">-&nbsp;&nbsp;&nbsp;더보기&nbsp;&nbsp;&nbsp;-</a></li><? }?>
<?
$gcnt += 1;
}

$qinfo = "select count(*) from min_board_info";
$rinfo = mysql_query($qinfo, $connect);
$dinfo = mysql_fetch_array($rinfo);
$infocount = $dinfo[0];

$qinfos = "select count(*) from min_board_member";
$rinfos = mysql_query($qinfos, $connect);
$dinfos = mysql_fetch_array($rinfos);
$infocounts = $dinfos[0];
?>
    </ul>
  </div>
<?
$qgye1 = "select count(*) from min_board_gye";
$rgye1 = mysql_query($qgye1, $connect);
$dgye1 = mysql_fetch_array($rgye1);

$qgye2 = "select count(*) from min_board_gye where company='1'";
$rgye2 = mysql_query($qgye2, $connect);
$dgye2 = mysql_fetch_array($rgye2);

$qgye3 = "select count(*) from min_board_gye where company='2'";
$rgye3 = mysql_query($qgye3, $connect);
$dgye3 = mysql_fetch_array($rgye3);

$qgye4 = "select count(*) from min_board_gye where company='3'";
$rgye4 = mysql_query($qgye4, $connect);
$dgye4 = mysql_fetch_array($rgye4);

$qgye6 = "select count(*) from min_board_gye where company='6'";
$rgye6 = mysql_query($qgye6, $connect);
$dgye6 = mysql_fetch_array($rgye6);
?>
  <div class="goodminho">
    <h1>계좌번호</h1>
    <ul>
      <li style="width:100%;"><a href="gye_total.php" style="width:100%;">계좌번호 전체보기<span style="font-size:17px;"> - </span><span style="font-size:25px; color:red;"><?=$dgye1[0]?></span></a></li>
      <li style="width:100%;"><a href="gye.php?company=1" style="width:100%;">계좌번호 5t 기준<span style="font-size:17px;"> - </span><span style="font-size:25px; color:red;"><?=$dgye2[0]?></span></a></li>
      <li style="width:100%;"><a href="gye.php?company=2" style="width:100%;">계좌번호 1t~3.5t<span style="font-size:17px;"> - </span><span style="font-size:25px; color:red;"><?=$dgye3[0]?></span></a></li>
      <li style="width:100%;"><a href="gye.php?company=3" style="width:100%;">계좌번호 외주차<span style="font-size:17px;"> - </span><span style="font-size:25px; color:red;"><?=$dgye4[0]?></span></a></li>
      <li style="width:100%;"><a href="gye.php?company=6" style="width:100%;">계좌번호 거래처<span style="font-size:17px;"> - </span><span style="font-size:25px; color:red;"><?=$dgye6[0]?></span></a></li>
    </ul>
  </div>
  
  
    <div class="goodminho">
      <h1><a href="#10" onclick="ememaee(ipgm_list_hd);" style="color:blue;text-decoration:none;">거래처 입금자 확인</a></h1>
		<ul class="ipgm_list" id="ipgm_list_hd" style="display:none;font-weight:bold;">
<?
$cnt = 1;

$ipgm_result = mysql_query("select * from min_board_admin_damt where ipgm!='' order by no asc",$connect);
while($ipgm_data = mysql_fetch_array($ipgm_result)) {
?>
  <li style="padding:5px;width:98%;overflow:hidden;font-size:23px;">
  <div style="float:left;width:48%;border-right:1px solid #ABABAB;overflow:hidden;"><?=$cnt?>. <?=$ipgm_data[company]?></div>
  <div style="float:right;width:48%;text-align:center;overflow:hidden;"><span style="background:yellow;">입금자:[<?=$ipgm_data[ipgm]?>]</span></div>
  </li>
<?
$cnt++;
}
$ipgm_result = mysql_query("select * from min_board_admin where ipgm!='' order by name asc",$connect);
while($ipgm_data = mysql_fetch_array($ipgm_result)) {
?>
  <li style="padding:5px;width:98%;overflow:hidden;font-size:23px;">
  <div style="float:left;width:48%;border-right:1px solid #ABABAB;overflow:hidden;"><?=$cnt?>. <?=$ipgm_data[name]?></div>
  <div style="float:right;width:48%;text-align:center;overflow:hidden;"><span style="background:yellow;">입금자:[<?=$ipgm_data[ipgm]?>]</span></div>
  </li>
<?
$cnt++;
}
?>
		</ul>
  </div>
  
  
<?
}else{
$olst = "1";
$olsxxt = "1";

$qst = "select count(*) from min_board_data1 where olddate='$olddate' and del='$olsxxt'";
$rst = mysql_query($qst, $connect);
$adst = mysql_fetch_array($rst);
$adscountt = $adst[0];

$qsts = "select count(*) from min_board_data2 where olddate='$olddate'";
$rsts = mysql_query($qsts, $connect);
$adsts = mysql_fetch_array($rsts);
$adscountts = $adsts[0];

$qsts2 = "select count(*) from min_board_data3 where olddate='$olddate'";
$rsts2 = mysql_query($qsts2, $connect);
$adsts2 = mysql_fetch_array($rsts2);
$adscountts2 = $adsts2[0];

$adstotal = $adscountt+$adscountts+$adscountts2;

$ppr1 = "1";
$ppr2 = "2";

$qpprs1 = "select count(*) from min_board_data3 where company='$ppr1' and olddate='$olddate'";
$rpprs1 = mysql_query($qpprs1, $connect);
$dpprs1 = mysql_fetch_array($rpprs1);
$dpprs1c = $dpprs1[0];

$qpprs2 = "select count(*) from min_board_data3 where company='$ppr2' and olddate='$olddate'";
$rpprs2 = mysql_query($qpprs2, $connect);
$dpprs2 = mysql_fetch_array($rpprs2);
$dpprs2c = $dpprs2[0];

$q0 = "select * from min_board_admin where orders='0' order by name asc";
$r0 = mysql_query($q0, $connect);

$qqqorq = "select count(*) from min_board_admin where orders='1'";
$qqqorr = mysql_query($qqqorq, $connect);
$qqqord = mysql_fetch_array($qqqorr);

$qqqorban1 = ceil($qqqord[0]/2);

$q1 = "select * from min_board_admin where orders='1' order by name asc";
$r1 = mysql_query($q1, $connect);


$q2 = "select * from min_board_admin where orders='2' order by name asc";
$r2 = mysql_query($q2, $connect);

$q3 = "select * from min_board_admin where orders='3' order by name asc";
$r3 = mysql_query($q3, $connect);
?>
  <div class="goodminho2" style="margin-right:0px;">
    <h1><a href="index.php?olddate=<?=$_GET[olddate]?><? if(!$_GET[ipgm]){?>&ipgm=1<? }?>" style="color:blue;text-decoration:none;">입금자 보기</a></h1>
  </div>
 <div style="overflow:hidden;">
  <div class="goodminho2" style="width:47%;margin-right:0px;float:left;">
    <h1>한달결제</h1>
    <ul>
    	<li style="width:100%;"><a href="view1_total.php?olddate=<?=$olddate?>">&nbsp;전체자료<span style="color:red;font-family:'Arial';"><?=$adstotal?></span></a></li>
    </ul>
    <ul>
      <?
      while($admin1 = mysql_fetch_array($r1)) {
        
        //미청구한 회사찾기
        $ep2 = selectc("min_board_ep","where olddate='$_GET[olddate]' and company='$admin1[company]'");
        
        
      	$dhide = selectc("min_board_admin_hide","where olddate='$olddate' and company='$admin1[company]'");
      	if($dhide == 0) {
      
      $counr = mysql_query("select * from min_board_admin_count where company='$admin1[company]' and olddate='$olddate'",$connect);
      $cound = mysql_fetch_array($counr);
      if($cound[counts] == 0)
      $adscount = 0;
      else $adscount = $cound[counts];
      //$adscount = selectc("min_board_data1","where company='$admin1[company]' and olddate='$olddate' and del='1'");
      ?>
      <li style="line-height:23px;padding:7px 0 7px 7px;">
      	<a href="view1.php?company=<?=$admin1[company]?>&olddate=<?=$olddate?>"><?=$admin1[name]?><span style="font-size:20px; color:red;font-family:'Arial';"><?=$adscount?></span></a>
      	<?
$erqeerq1 = "select * from min_board_admin_check where company='$admin1[company]' and olddate='$olddate'";
$erqeerr1 = mysql_query($erqeerq1, $connect);
$erqeerd1 = mysql_fetch_array($erqeerr1);
?>
      	<? if($erqeerd1[no]) {?><span style="color:#AC6100;font-weight:bold;font-size:12px;">[입]</span><? }?>
      	<? if(($_GET[ipgm] == 1)&&($admin1[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:17px;">입금자:[<?=$admin1[ipgm]?>]</span>
      	<? }?>
      	<? if(($cound[counts] != 0)&&($ep2==0)&&($_GET[olddate]>72)&&($cf[date]!=date("Y")."년".date("m")."월")) {//미청구한회사찾기?><span style="font-weight:bold;font-size:17px;">(미청구)</span><? }?>
      </li>
      <?
    		}
      }
      ?>
    </ul>
  </div>
  <div class="goodminho2" style="width:47%;margin-left:0px;float:right;">
    <h1>그때그때결제</h1>
    <ul>
      <?
      while($admin2 = mysql_fetch_array($r2)) {
      $dhide = selectc("min_board_admin_hide","where olddate='$olddate' and company='$admin2[company]'");
      	if($dhide == 0) {
      	  
      	  
      	  
      $ols = "1";
      $olsxx = "1";
      
      
      $counr = mysql_query("select * from min_board_admin_count where company='$admin2[company]' and olddate='$olddate'",$connect);
      $cound = mysql_fetch_array($counr);
      if($cound[counts] == 0)
      $adscount = 0;
      else $adscount = $cound[counts];
      ?>
      <li style="line-height:23px;padding:7px 0 7px 7px;">
      	<a href="view1.php?company=<?=$admin2[company]?>&olddate=<?=$olddate?>">&nbsp;<?=$admin2[name]?><span style="color:red;font-family:'Arial';font-size:20px;"><?=$adscount?></span></a>
<?
$erqeerq2 = "select * from min_board_admin_check where company='$admin2[company]' and olddate='$olddate'";
$erqeerr2 = mysql_query($erqeerq2, $connect);
$erqeerd2 = mysql_fetch_array($erqeerr2);
?>
      	<? if($erqeerd2[no]) {?><span style="color:#AC6100;font-weight:bold;font-size:12px;">[입]</span><? }?>
      	<? if(($_GET[ipgm] == 1)&&($admin2[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:17px;">입금자:[<?=$admin2[ipgm]?>]</span>
      	<? }?>
      </li>
      <?
      }}
      ?>
    </ul>
  </div>
  <div class="goodminho2" style="width:47%;margin-left:0px;float:left;">
    <h1>기사에게입금</h1>
    <ul>
      <?
      while($admin3 = mysql_fetch_array($r3)) {
      $dhide = selectc("min_board_admin_hide","where olddate='$olddate' and company='$admin3[company]'");
      	if($dhide == 0) {
      $ols = "1";
      $olsxx = "1";
      
      $counr = mysql_query("select * from min_board_admin_count where company='$admin3[company]' and olddate='$olddate'",$connect);
      $cound = mysql_fetch_array($counr);
      if($cound[counts] == 0)
      $adscount = 0;
      else $adscount = $cound[counts];
      ?>
      <li style="line-height:23px;padding:7px 0 7px 7px;">
      	<a href="view1.php?company=<?=$admin3[company]?>&olddate=<?=$olddate?>">&nbsp;<?=$admin3[name]?><span style="color:red;font-family:'Arial';font-size:20px;"><?=$adscount?></span></a>
<?
$erqeerq3 = "select * from min_board_admin_check where company='$admin3[company]' and olddate='$olddate'";
$erqeerr3 = mysql_query($erqeerq3, $connect);
$erqeerd3 = mysql_fetch_array($erqeerr3);
?>
      	<? if($erqeerd3[no]) {?><span style="color:#AC6100;font-weight:bold;font-size:12px;">[입]</span><? }?>
      	<? if(($_GET[ipgm] == 1)&&($admin3[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:17px;">입금자:[<?=$admin3[ipgm]?>]</span>
      	<? }?>
      </li>
      <?
      }}
      ?>
    </ul>
  </div>
  <div class="goodminho2" style="width:47%;margin-left:0px;float:right;">
    <h1>정렬 지정하지 않음</h1>
    <ul>
      <?
      while($admin0 = mysql_fetch_array($r0)) {
      $dhide = selectc("min_board_admin_hide","where olddate='$olddate' and company='$admin0[company]'");
      	if($dhide == 0) {
      $ols = "1";
      $olsxx = "1";
      
      $counr = mysql_query("select * from min_board_admin_count where company='$admin0[company]' and olddate='$olddate'",$connect);
      $cound = mysql_fetch_array($counr);
      if($cound[counts] == 0)
      $adscount = 0;
      else $adscount = $cound[counts];
      ?>
      <li style="line-height:23px;padding:7px 0 7px 7px;">
      	<a href="view1.php?company=<?=$admin0[company]?>&olddate=<?=$olddate?>">&nbsp;<?=$admin0[name]?><span style="color:red;font-family:'Arial';font-size:20px;"><?=$adscount?></span></a>
<?
$erqeerq0 = "select * from min_board_admin_check where company='$admin0[company]' and olddate='$olddate'";
$erqeerr0 = mysql_query($erqeerq0, $connect);
$erqeerd0 = mysql_fetch_array($erqeerr0);
?>
      	<? if($erqeerd0[no]) {?><span style="color:#AC6100;font-weight:bold;font-size:12px;">[입]</span><? }?>
      	<? if(($_GET[ipgm] == 1)&&($admin0[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:17px;">입금자:[<?=$admin0[ipgm]?>]</span>
      	<? }?>
      </li>
      <?
      }}
      ?>
    </ul>
  </div>
<?
$adscounte1f = selectc("min_board_data2","where id='0' and olddate='$olddate'");
$adscounte2f = selectc("min_board_data2","where id='1' and olddate='$olddate'");
$adscounte3f = selectc("min_board_data2","where olddate='$olddate'");
?>
  <div class="goodminho2" style="width:47%;margin-left:0px;float:right;">
    <h1>담터자료</h1>
    <ul>
      <li>
      	<a href="view2.php?olddate=<?=$olddate?>&id=99" style="width:100%;">&nbsp;담터 전체<span style="font-size:11px;"></span><span style="font-size:17px; color:red;font-size:20px;"><?=$adscounte3f?></span></a>
      </li>
      <li style="line-height:23px;padding:7px 0 7px 7px;">
      	<a href="view2.php?olddate=<?=$olddate?>&id=0" style="width:100%;">&nbsp;담터<span style="font-size:11px;"></span><span style="font-size:17px; color:red;font-size:20px;"><?=$adscounte1f?></span></a>
<?
$erqeerq11 = "select * from min_board_admin_check where company='dam' and olddate='$olddate'";
$erqeerr11 = mysql_query($erqeerq11, $connect);
$erqeerd11 = mysql_fetch_array($erqeerr11);

$q_damt1 = "select * from min_board_admin_damt where no='0'";
$r_damt1 = mysql_query($q_damt1, $connect);
$d_damt1 = mysql_fetch_array($r_damt1);
?>
      	<? if($erqeerd11[no]) {?><span style="color:#AC6100;font-weight:bold;font-size:12px;">[입]</span><? }?>
        <? if(($_GET[ipgm] == 1)&&($d_damt1[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:17px;">입금자:[<?=$d_damt1[ipgm]?>]</span>
      	<? }?>
      </li>
      <li style="line-height:23px;padding:7px 0 7px 7px;">
      	<a href="view2.php?olddate=<?=$olddate?>&id=1" style="width:100%;">&nbsp;담터FND(승주)<span style="font-size:11px;"></span><span style="font-size:17px; color:red;font-size:20px;"><?=$adscounte2f?></span></a>
<?
$erqeerq11 = "select * from min_board_admin_check where company='dam2' and olddate='$olddate'";
$erqeerr11 = mysql_query($erqeerq11, $connect);
$erqeerd11 = mysql_fetch_array($erqeerr11);

$q_damt2 = "select * from min_board_admin_damt where no='1'";
$r_damt2 = mysql_query($q_damt2, $connect);
$d_damt2 = mysql_fetch_array($r_damt2);
?>
      	<? if($erqeerd11[no]) {?><span style="color:#AC6100;font-weight:bold;font-size:12px;">[입]</span><? }?>
        <? if(($_GET[ipgm] == 1)&&($d_damt2[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:17px;">입금자:[<?=$d_damt2[ipgm]?>]</span>
      	<? }?>
      </li>
    </ul>
  </div>
  <div class="goodminho2" style="width:47%;margin-left:0px;float:right;">
    <h1>로타리장부</h1>
    <ul>
      <li><a href="view3_total.php?olddate=<?=$olddate?>" style="width:100%;">&nbsp;전체보기<span style="font-size:20px; color:red;"><?=$adscountts2?></span></a></li>
      <li><a href="view3.php?olddate=<?=$olddate?>&company=1" style="width:100%;">&nbsp;로타리장부1<span style="font-size:20px; color:red;"><?=$dpprs1c?></span></a></li>
      <li><a href="view3.php?olddate=<?=$olddate?>&company=2" style="width:100%;">&nbsp;로타리장부2<span style="font-size:20px; color:red;"><?=$dpprs2c?></span></a></li>
    </ul>
  </div>
  <div class="goodminho2" style="width:47%;margin-left:0px;float:right;">
    <h1>숨김 업체</h1>
    <ul>
      <?
      $qh = "select * from min_board_admin order by name asc";
			$rh = mysql_query($qh, $connect);
			$hamcnt = 0;
      while($adminh = mysql_fetch_array($rh)) {
      	$dhide = selectc("min_board_admin_hide","where olddate='$olddate' and company='$adminh[company]'");
      	if($dhide != 0) {
      $counr = mysql_query("select * from min_board_admin_count where company='$adminh[company]' and olddate='$olddate'",$connect);
      $cound = mysql_fetch_array($counr);
      if($cound[counts] == 0)
      $adscount = 0;
      else $adscount = $cound[counts];
      //$adscount = selectc("min_board_data1","where company='$adminh[company]' and olddate='$olddate' and del='1'");
      ?>
      <li style="line-height:23px;padding:7px 0 7px 7px;<? if($erqs){if($adscount == 0){?>display:none;<? }}?>">
      	<a href="view1.php?company=<?=$adminh[company]?>&olddate=<?=$olddate?>"><?=$adminh[name]?><span style="font-size:20px; color:red;font-family:'Arial';"><?=$adscount?></span></a>
      	<? if($erqeerd0[no]) {?><span style="color:#AC6100;font-weight:bold;font-size:12px;">[입]</span><? }?>
      	<? if(($_GET[ipgm] == 1)&&($adminh[ipgm])) {?>
      	<br />
      	<span style="background:yellow;font-weight:bold;font-size:17px;">입금자:[<?=$adminh[ipgm]?>]</span>
      	<? }?>
<?
$erqeerq0 = "select * from min_board_admin_check where company='$adminh[company]' and olddate='$olddate'";
$erqeerr0 = mysql_query($erqeerq0, $connect);
$erqeerd0 = mysql_fetch_array($erqeerr0);
?>
      	
      </li>
      <?
      		$hamcnt += 1;
      		if($hamcnt == 5) {
      			?>
      				<li><a href="#223" onclick="sdfsdf1(cda);" style="font-size:25px;margin:0px;padding:5px 0 5px 0;width:155px;text-align:center;display:block;">더보기</a></li>
      			</ul>
      			<ul id="cda" style="display:none;">
      			<?
      		}
      	}
      }
      ?>
    </ul>
	</div>
 </div>
<?
$qepz = "select count(*) from min_board_ep where olddate='$olddate'";
$repz = mysql_query($qepz, $connect);
$depz = mysql_fetch_array($repz);
?>
 <div class="goodminho2">
    <h1>입금확인</h1>
    <ul>
      <li><a href="ep.php?olddate=<?=$olddate?>" style="width:100%;">&nbsp;입금확인 바로가기<span style="font-size:20px; color:red;"><?=$depz[0]?></span></a></li>
    </ul>
  </div>
<?
}
include "foot.php";
?>
