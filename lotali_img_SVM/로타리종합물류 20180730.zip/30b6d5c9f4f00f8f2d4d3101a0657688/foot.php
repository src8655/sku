<div class="imbody" style="text-align:center;">
	<a href="#tops" class="footop" style="margin:0px;padding:5px 0 5px 0;font-size:25px;">맨위로</a>
</div>
<div id="copyfoot">
  Copyright ⓒ <?=date("Y")?> 로타리종합물류 All rights reserved.
</div>
<a name="bottomtxx"></a>
</body>
</html>
