<?
include "lib.php";
include "head.php";

$bo = $bodys." ".$moneys1." ".$moneys2." ".$moneys3;
echo("<script>
				location.href='sms:?body=$bo';
				setTimeout('act()',1000);
				function act() {
					history.go(-1)
				}
			</script>");
?>

<?
include "foot.php";
?>