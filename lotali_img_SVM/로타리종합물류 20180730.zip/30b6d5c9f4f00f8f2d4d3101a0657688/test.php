<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<title>로타리종합물류</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.zclip.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('a#copy-description').zclip({
        path:'js/ZeroClipboard.swf',
        copy:$('a#copy-description').next().text()
        
		// 현재 a 안에 있는텍스트를 카피 하려면?
		// copy:$('this.a#copy-description').text() 이런식으로 하면 될거 같은데...
		// 아신다면 확인좀..
    });
});
		  function bodysb1() {
	    bodys.style.background="FFFFFF";
	    window.open("bodybg1s.php?idbb=FFFFFF","new","width=1, height=1");
	    }
	  function bodysb2() {
	    bodys.style.background="#ECECEC";
	    window.open("bodybg1s.php?idbb=ECECEC","new","width=1, height=1");
	    }
	  function bodysb3() {
	    bodys.style.background="#ECFCD2";
	    window.open("bodybg1s.php?idbb=ECFCD2","new","width=1, height=1");
	    }
	  function bodysb4() {
	    bodys.style.background="#FFFECB";
	    window.open("bodybg1s.php?idbb=FFFECB","new","width=1, height=1");
	    }
	  function bodysb5() {
	    bodys.style.background="#EBD4F7";
	    window.open("bodybg1s.php?idbb=EBD4F7","new","width=1, height=1");
	    }
	  function bodysb6() {
	    bodys.style.background="#B4BFCC";
	    window.open("bodybg1s.php?idbb=B4BFCC","new","width=1, height=1");
	    }
	  function bodysb7() {
	    bodys.style.background="#FF943D";
	    window.open("bodybg1s.php?idbb=FF943D","new","width=1, height=1");
	    }
	  function bodysb8() {
	    bodys.style.background="#0099FF";
	    window.open("bodybg1s.php?idbb=0099FF","new","width=1, height=1");
	    }
	  function bodysb9() {
	    bodys.style.background="#8EDC0C";
	    window.open("bodybg1s.php?idbb=8EDC0C","new","width=1, height=1");
	    }
	  function bodysb10() {
	    bodys.style.background="#000099";
	    window.open("bodybg1s.php?idbb=000099","new","width=1, height=1");
	    }
	  function bodysb11() {
	    bodys.style.background="#000000";
	    window.open("bodybg1s.php?idbb=000000","new","width=1, height=1");
	    }
	  function bodysb12() {
	    bodys.style.background="#C7141A";
	    window.open("bodybg1s.php?idbb=C7141A","new","width=1, height=1");
	    }
	  function allc() {
	    if(col1.style.display == "none") {
	      col1.style.display = "";
	      col2.style.display = "";
	      col3.style.display = "";
	      }else{
	        col1.style.display = "none";
	        col2.style.display = "none";
	        col3.style.display = "none";
	        }
	    }
	   function sdfsdf1(assa) {
	   	if(assa.style.display == "none") {
	   		assa.style.display = "";
	   	}else{
	   		assa.style.display = "none";
	   	}
	   }
	   function sdfsdf2(assa) {
	   	if(assa.style.display == "none") {
	   		assa.style.display = "";
	   	}else{
	   		assa.style.display = "none";
	   	}
	   }
	   function sdfsdf3(assa) {
	   	if(assa.style.display == "none") {
	   		assa.style.display = "";
	   	}else{
	   		assa.style.display = "none";
	   	}
	   }
	   function sdfsdf5(assa) {
	   	if(assa.style.display == "none") {
	   		assa.style.display = "";
	   	}else{
	   		assa.style.display = "none";
	   	}
	   }
	   function sdfsdf6(assa) {
	   	if(assa.style.display == "none") {
	   		assa.style.display = "";
	   	}else{
	   		assa.style.display = "none";
	   	}
	   }
		function firstfocus() {
			if(document.writepp) {
			document.writepp.date2.focus();
			}else{
			if(document.passcoco) {
			document.passcoco.view2_password.focus();
			}else{
			if(document.searchtotal) {
			document.searchtotal.Search_text.focus();
			}else{
			if(document.loginfocus) {
			document.loginfocus.id.focus();
			}else{
			}}}}
		}
		function mmmacc(asssss) {
			if(asssss.style.display == "none") {
			asssss.style.display = "";
			}else{
			asssss.style.display = "none";
			}
		}
		function emmeviiv() {
			if(viiv.style.display == "none") {
			viiv.style.display = "";
			}else{
			viiv.style.display = "none";
			}
		}
	function uols(assas) {
		if(assas.style.display == "none") {
			assas.style.display = "";
		}else{
			assas.style.display = "none";
		}
	}
	function uolsm(assas) {
		if(assas.style.display == "") {
			assas.style.display = "none";
		}else{
			assas.style.display = "";
			assas.form.memo.focus();
		}
	}
	function chaing() {
		if(cha.style.display == "none") {
			cha.style.display = "";
		}else{
			cha.style.display = "none";
		}
	}
	function chaings(aab) {
		if(aab.style.display == "none") {
			aab.style.display = "";
		}else{
			aab.style.display = "none";
		}
	}
	function ebsofm(assa) {
		if(assa.style.background != "orange") {
			assa.style.background = "orange";
		}else{
			assa.style.background = "";
		}
	}
	function ememaee(assa) {
		if(assa.style.display == "none") {
			assa.style.display = "";
		}else{
			assa.style.display = "none";
		}
	}
	function golem(okl) {
		if(okl.style.display == "none") {
			okl.style.display = "";
		}else{
			okl.style.display = "none";
		}
	}
	function confirms(mass,urs) {
		var amms = confirm(mass);
		if(amms == false) {
			
		}else{
			location.href=urs;
		}
	}
	function locas(sdds) {
		location.href=sdds;
	}
</script>
<link rel="stylesheet" type="text/css" href="mm.css" />
</head>
<body style="margin:5px; padding:0px; font-size:17px;">
<a name="tops"></a>
<div id="headersm">
  <h1 style="float:left; width:210px;">
    <a href="./index.php">로타리종합물류<span style="font-size:15px;">[스마트폰]</span><br /><span id="hind">http://로타리종합물류.com/</span></a>
  </h1>
  <div style="width:70px;float:right;text-align:right;margin:8px 8px 8px 0;overflow:hidden;">
    <a href="../home/index.php" id="pcversion">PC버전</a>
  </div>
</div>
<?
if($olddate) {
$ef = "select * from min_board_olddate where olddate='$olddate'";
$df = mysql_query($ef, $connect);
$cf = mysql_fetch_array($df);
}else{}
?>
  <h1 id="headdate">
    <div style="float:left;width:156px;overflow:hidden;">
      <div style="float:left;overflow:hidden;"><? if($olddate) {?><?=$cf[date]?> 장부<? }else{?>공통<? }?></div>
    </div>
    <div style="float:right;width:134px;padding:2px 0 0 0;overflow:hidden;">
      <? if($dyyocount == 0) {?>
        <marquee behavior="scroll" direction="left" scrollDelay="65" scrollAmount="3" style="float:right; width:130px;margin:1px 0 0 100px;border:2px solid #B4BFCC;border-top:none;border-bottom:none;"><span style="font-size:15px;">새로운 메모가 없습니다.</span></marquee>
      <? }else{?>
        <marquee behavior="scroll" direction="left" scrollDelay="65" scrollAmount="3" style="float:right; width:130px;margin:1px 0 0 100px;border:2px solid #B4BFCC;border-top:none;border-bottom:none;"><span style="font-size:15px;color:red;"><?=$dyyocount?> 개의 새로운 메모가 있습니다.</span></marquee>
      <? }?>
    </div>
  </h1>
<?
if(!$dmember[user_id]) {
include "login_first.php";
}
?>
<a href="#bottomtxx" class="footop" style="margin:10px 0 10px 0;">맨아래로</a>
<a href="#" id="copy-description" style="width:49%;float:right;">복사하기</a><div style="display:none;">sdf</div>