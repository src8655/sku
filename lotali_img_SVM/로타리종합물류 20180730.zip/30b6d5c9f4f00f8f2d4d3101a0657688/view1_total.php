<?
include "lib.php";
include "head.php";



$wheree = "where olddate='$olddate'";

if($Search_text){  
  $where = "$wheree and (yo like '%$Search_text%' or date like '%$Search_text%' or number like '%$Search_text%' or name like '%$Search_text%' or phone like '%$Search_text%' or companys like '%$Search_text%' or ddo like '%$Search_text%' or chu like '%$Search_text%' or money like '%$Search_text%' or memo1 like '%$Search_text%' or memo2 like '%$Search_text%' or memos like '%$Search_text%' or money1 like '%$Search_text%' or money2 like '%$Search_text%')";
}else{
$where = "$wheree";
}


$olst = "1";

$qs1 = "select count(*) from min_board_data1 $where and del='$olst'";
$rs1 = mysql_query($qs1, $connect);
$ads1 = mysql_fetch_array($rs1);
$adscount1 = $ads1[0];

$qs2 = "select count(*) from min_board_data2 $where";
$rs2 = mysql_query($qs2, $connect);
$ads2 = mysql_fetch_array($rs2);
$adscount2 = $ads2[0];

$qs3 = "select count(*) from min_board_data3 $where";
$rs3 = mysql_query($qs3, $connect);
$ads3 = mysql_fetch_array($rs3);
$adscount3 = $ads3[0];

$adscount = $adscount1+$adscount2+$adscount3;

$dell = "1";

$query = "select * from min_board_data1 $where and del='$dell' order by date asc, no asc";
$result = mysql_query($query, $connect);

$q = "select * from min_board_admin where company='$company'";
$r = mysql_query($q, $connect);
$admin = mysql_fetch_array($r);
?>
<div class="imbody" style="text-align:center;">
<form action=<?=$PHP_SELF?> >
<select name="Search_mode" style="font-size:17px;width:65px;padding:5px;display:none;">
<option value="1" <? if($Search_mode == 1){?>selected<? }?>>이름</option>
</select>
<input type="hidden" name="company" value="<?=$company?>" />
<input type="hidden" name="olddate" value="<?=$olddate?>" />
	<h1 style="font-size:30px;color:#000000;margin:5px 0 10px 0;padding:0 0 5px 0;border-bottom:1px solid #676767;">전체보기<span stlye="font-size:17px;"> - </span><span style="font-size:25px; color:red;"><?=$adscount?></span></h1>
	<div style="width:33%;float:left;"><a href="index.php?olddate=<?=$olddate?>" class="view1_button" style="font-size:25px;">뒤로가기</a></div>
  <div style="width:24%;float:right;overflow:hidden;"><input type="submit" value="검색" style="padding:5px;border:1px solid #676767;font-size:25px;background:#ffffff;width:91%;margin:0 0 0 5px;" /></div>
  <div style="width:41%;float:right;overflow:hidden;"><input type="text" name="Search_text" value="<?=$Search_text?>" size="8" style="font-size:25px;padding:5px 0 5px 0;margin:0px;border:1px solid #676767;width:99%;" /></div>
</form>
</div>
<?
$a = 0;
$yyyom3 = 0;
$chack_money = 0; //착불건만 더할것
$real_money = 0;  //장부1,2빼고 금액
while($data = mysql_fetch_array($result)) {
?>
<div class="imbody">
    	<span style="font-weight:bold;"><?=$data[companys]?>&nbsp;|
    	<?=$data[date]?></span><br />
    	<?=$data[ddo]?>&nbsp;
    	<?=$data[number]?>&nbsp;
    	<span style="font-weight:bold;color:blue;"><?=$data[name]?></span>&nbsp;
    	
<?
if($data[virtualmoney] != 1) {
  $real_money = $real_money+$data[money];
?>
	    <span style="font-weight:bold;color:red;"><?=number_format($data[money])?></span><br />
<?
}else{//착불일때
$chack_money = $chack_money+$data[money];
?>
	    <span style="font-weight:bold;color:orange;">착불(<?=number_format($data[money])?>)</span><br />
<?
}
?>
    	
    	
    	<?=$data[memo1]?>&nbsp;
    	<?=$data[phone]?>&nbsp;
    	숫자 : <?=$data[secrets]?>
</div>
<?
if($data[virtualmoney] != 1) {
  $a += $data[money];
}
if($data[secrets] != 0) {
	if($data[money] != 0) {
	  if($data[virtualmoney] != 1) {
  		$yya1 = $data[secrets]."000";
  		$yya2 = $data[money]-$yya1;
  		$yyyom3 += $yya2;
}}}
}
?>





<?
$qotp = "select * from min_board_data2 $where order by date asc, no asc";
$rotp = mysql_query($qotp, $connect);
while($dotp = mysql_fetch_array($rotp)) {
  $real_money = $real_money+($dotp[secrets]."000");
?>
<div class="imbody">
    	<span style="font-weight:bold;">담터&nbsp;|
    	<?=$dotp[date]?></span><br />
    	<?=$dotp[chu]?> - <?=$dotp[gu]?> - <?=$dotp[ddo]?><br />
    	<?=$dotp[number]?>&nbsp;
    	<span style="font-weight:bold;color:blue;"><?=$dotp[name]?></span>&nbsp;
    	<span style="font-weight:bold;color:red;"><?=number_format($dotp[secrets]."000")?></span><br />
    	<?=$dotp[memos]?>&nbsp;
    	<?=$dotp[phone]?>
</div>
<?
}

$qotps = "select * from min_board_data3 $where order by date asc, no asc";
$rotps = mysql_query($qotps, $connect);
while($dotps = mysql_fetch_array($rotps)) {
?>
<div class="imbody">
    	<span style="font-weight:bold;">로타리장부<?=$dotps[company]?>&nbsp;|
    	<?=$dotps[date]?></span><br />
    	<?=$dotps[ddo]?>&nbsp;
    	<?=$dotps[number]?>&nbsp;
    	<span style="font-weight:bold;color:blue;"><?=$dotps[name]?></span>&nbsp;
    	<span style="font-weight:bold;color:red;"><?=number_format($dotps[money1]."000")?></span><br />
    	<?=$dotps[phone]?>&nbsp;
    	숫자 : <?=$dotps[money2]?>
</div>
<?
}
?>


<?
$smm = "1";

$qbbb = "select * from min_board_data2 $where";
$rbbb = mysql_query($qbbb, $connect);
for($ibbb=0;$cbbb = mysql_fetch_assoc($rbbb);$ibbb++) {
  $dbbb += $cbbb[secrets];
  }
$qbbb2 = "select * from min_board_data3 $where";
$rbbb2 = mysql_query($qbbb2, $connect);
for($ibbb2=0;$cbbb2 = mysql_fetch_assoc($rbbb2);$ibbb2++) {
  $dbbb2 += $cbbb2[money1];
  }
  
$qbbb3 = "select * from min_board_data3 $where";
$rbbb3 = mysql_query($qbbb3, $connect);
for($ibbb3=0;$cbbb3 = mysql_fetch_assoc($rbbb3);$ibbb3++) {
  $dbbb3 += $cbbb3[memo];
  }

$as1 = $a;
$as2 = $dbbb."000";
$as3 = $dbbb2."000";

$as = $as1+$as2+$as3;




$asch1 = $yyyom3;
$asch2 = $dbbb3."000";
$asch = $asch1+$asch2;
?>
<div class="imbody">
	<a style="display:block;height:25px;width:100%;" onclick="allc()"></a>
</div>
<div id="col1" class="imbody" style="text-align:center;display:none;">
    	계 : <span style="font-weight:bold;color:red;"><?=number_format($as)?></span> / <?=number_format($asch)?><br />
    	계(착불건) : <span style="font-weight:bold;color:orange;"><?=number_format($chack_money)?></span><br />
    	합계(착불포함) : <span style="font-weight:bold;color:red;"><?=number_format($as+$chack_money)?></span><br />
    	계(장부빼고) : <span style="font-weight:bold;color:red;"><?=number_format($real_money)?></span>
    	
</div>
<?
include "foot.php";
?>
