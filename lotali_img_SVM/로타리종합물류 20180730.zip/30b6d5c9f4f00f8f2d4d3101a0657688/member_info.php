<?
include "lib.php";
include "head.php";

if($Search_mode) {
  if($Search_mode == 1) $tmp = "name";
  if($Search_mode == 2) $tmp = "memo";
  
  $where = "where $tmp like '%$Search_text%'";
  }else{
    $where = "";
    }

$qinfos = "select count(*) from min_board_member $where";
$rinfos = mysql_query($qinfos, $connect);
$dinfos = mysql_fetch_array($rinfos);
$infocounts = $dinfos[0];

$query = "select * from min_board_member $where order by name asc";
$result = mysql_query($query, $connect);
?>

<div class="imbody" style="text-align:center;font-weight:bold;">
	<h1 style="font-size:30px;color:#000000;margin:5px 0 10px 0;padding:0 0 5px 0;border-bottom:1px solid #676767;">기사정보 - <span style="color:red;"><?=$infocounts?></span></h1>
<form action="member_info_search.php">
      <select name="Search_mode" style="font-size:17px;padding:5px;display:none;">
        <option value="1" <? if($Search_mode == 1) {?>selected<? }?>>이름</option>
      </select>
      <input type="text" name="Search_text" <? if($Search_mode) {?>value="<?=$Search_text?>"<? }?> style="border:1px solid #676767;font-size:22px;padding:5px 0 5px 0;width:66%;" />
      <input type="submit" value="검색" style="border:1px solid #676767;width:28%;background:#ffffff;font-size:22px;padding:5px;font-weight:bold;" />
</form>
</div>


<?
while($data = mysql_fetch_array($result)) {
?>
<form action="member_info_call.php">
<input type="hidden" name="Search_mode" value="<?=$Search_mode?>" />
<input type="hidden" name="Search_text" value="<?=$Search_text?>" />
<div class="imbody">
    	<h1>
      	<div class="checkboxbox" style="display:none;"><input type="checkbox" name="callinfo[]" value="이름 : <?=$data[name]?>" id="ach<?=$data[no]?>a" checked /><label for="ach<?=$data[no]?>a"></label></div>
      	<?=$data[name]?>
      </h1>
    	<div <? $spp1 = $data[phone1].$data[phone2].$data[phone3]; if(!$spp1) {?>style="display:none;"<? }?>>
      	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="전화번호 : <?=$data[phone1]?>-<?=$data[phone2]?>-<?=$data[phone3]?>" id="ach<?=$data[no]?>b" /><label for="ach<?=$data[no]?>b"></label></div>
      	<label for="ach<?=$data[no]?>b"><span style="font-weight:bold;color:green;">전화번호 : </span><span style="font-weight:bold;color:red;"><?=$data[phone1]?>-<?=$data[phone2]?>-<?=$data[phone3]?></span></label>
      </div>
    	<div <? if(!$data[memo]) {?>style="display:none;"<? }?>>
      	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="메모 : <?=$data[memo]?>" id="ach<?=$data[no]?>c" /><label for="ach<?=$data[no]?>c"></label></div>
      	<label for="ach<?=$data[no]?>c"><span style="font-weight:bold;color:green;">메모 : </span><span style="font-weight:bold;color:red;"><?=$data[memo]?></span></label>
      </div>
    	<div <? if(!$data[email]) {?>style="display:none;"<? }?>>
      	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="이메일 : <?=$data[email]?>" id="ach<?=$data[no]?>d" /><label for="ach<?=$data[no]?>d"></label></div>
      	<label for="ach<?=$data[no]?>d"><span style="font-weight:bold;color:green;">이메일 : </span><span style="font-weight:bold;color:red;"><?=$data[email]?></span></label>
      </div>
      
      <div style="width:100%;">
      	<input type="submit" value="문자보내기" class="callbu" style="width:150px;background:#ffffff;font-weight:bold;float:left;" />
      	
      </div>
</div>
</form>
<?
}
?>
<a name="bottoms"></a>
<?
include "foot.php";
?>
