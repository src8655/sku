<?
include "lib.php";
include "head.php";

if($id==99) {
  $wid = " ";
}else{
  $wid = " id='$id' and ";
}

if($Search_text){  
  $where = "where $wid olddate='$olddate' and (date like '%$Search_text%' or yo like '%$Search_text%' or chu like '%$Search_text%' or gu like '%$Search_text%' or ddo like '%$Search_text%' or number like '%$Search_text%' or name like '%$Search_text%' or ton like '%$Search_text%' or su like '%$Search_text%' or money like '%$Search_text%' or secrets like '%$Search_text%' or memos like '%$Search_text%' or phone like '%$Search_text%')";
}else{
$where = "where $wid olddate='$olddate'";
}

$olse = "1";

$qse = "select count(*) from min_board_data2 $where";
$rse = mysql_query($qse, $connect);
$adse = mysql_fetch_array($rse);
$adscounte = $adse[0];

$query = "select * from min_board_data2 $where order by date asc, no asc"; 
$result = mysql_query($query, $connect);
?>
<?
$mmm = md5("2537");
if($view2_ch == $mmm) {
?>
<div class="imbody" style="text-align:center;">
<form action=<?=$PHP_SELF?> >
<input type="hidden" name="view2_ch" value="<?=$view2_ch?>" />
<select name="Search_mode" style="font-size:17px;width:65px;padding:5px;display:none;">
<option value="6" <? if($Search_mode == 6){?>selected<? }?>>이름</option>
</select>
<input type="hidden" name="company" value="<?=$company?>" />
<input type="hidden" name="olddate" value="<?=$olddate?>" />
<input type="hidden" name="id" value="<?=$id?>" />
	<h1 style="font-size:30px;color:#000000;margin:5px 0 10px 0;padding:0 0 5px 0;border-bottom:1px solid #676767;">담터<span stlye="font-size:17px;"> - </span><span style="font-size:25px; color:red;"><?=$adscounte?></span>
	    	<?
$q_damt = "select * from min_board_admin_damt where no='$_GET[id]'";
$r_damt = mysql_query($q_damt, $connect);
$d_damt = mysql_fetch_array($r_damt);
?>
    	<? if($d_damt[ipgm]) {?>
    	<br />
    	<span style="background:yellow;font-weight:bold;font-size:23px;">입금자:[<?=$d_damt[ipgm]?>]</span>
    	<? }?>
	</h1>
	<div style="width:33%;float:left;"><a href="index.php?olddate=<?=$olddate?>" class="view1_button" style="font-size:25px;">뒤로가기</a></div>
  <div style="width:24%;float:right;overflow:hidden;"><input type="submit" value="검색" style="padding:5px;border:1px solid #676767;font-size:25px;background:#ffffff;width:91%;margin:0 0 0 5px;" /></div>
  <div style="width:41%;float:right;overflow:hidden;"><input type="text" name="Search_text" value="<?=$Search_text?>" size="8" style="font-size:25px;padding:5px 0 5px 0;margin:0px;border:1px solid #676767;width:99%;" /></div>
</form>
</div>
<?
while($data = mysql_fetch_array($result)) {
?>
<div class="imbody">
    	<span style="font-weight:bold;"><?=$data[date]?></span><br />
    	<?=$data[chu]?> - <?=$data[gu]?> - <?=$data[ddo]?><br />
    	<?=$data[number]?>&nbsp;
    	<span style="font-weight:bold;color:blue;"><?=$data[name]?></span>&nbsp;
    	<?=$data[ton]?>&nbsp;
    	<?=$data[su]?><br />
    	<span style="font-weight:bold;color:red;"><?=number_format($data[money])?></span>&nbsp;
    	숫자 : <?=$data[secrets]?><br />
    	<?=$data[memos]?>&nbsp;
    	<?=$data[phone]?>
</div>
<?
}
?>
<div class="imbody">
	<a style="display:block;height:25px;width:100%;" onclick="allc()"></a>
</div>
<?
$wf = "select * from min_board_data2 $where";
$sf = mysql_query($wf, $connect);
for($i;$xf = mysql_fetch_assoc($sf);$i++) {
$xfmoney += $xf[money];
$xfmoney2 += $xf[secrets];
}
$xfmoney2s = $xfmoney2."000";
$xfmoney2se = $xfmoney-$xfmoney2s;
?>
<div class="imbody" id="col1" style="text-align:center;display:none;">
  		계 : <span style="font-weight:bold;color:red;"><?=number_format($xfmoney)?></span> / <?=number_format($xfmoney2se)?>
</div>
<?
}else{
?>
<div class="imbody" style="text-align:center;">
<form action="view2_ch.php">
  <input type="hidden" name="olddate" value="<?=$olddate?>" />
  <input type="hidden" name="id" value="<?=$id?>" />
  <input type="password" name="passwords" style="width:60%;font-size:22px;padding:5px;background:#ffffff;border:1px solid #676767;overflow:hidden;" />
  <input type="submit" value="등록" style="font-size:22px;padding:5px;width:30%;background:#ffffff;border:1px solid #676767;overflow:hidden;" />
</form>
</div>
<?
}
?>
<?
include "foot.php";
?>
