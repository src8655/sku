<?
$_REQUEST[ipsz] = $_SERVER["REMOTE_ADDR"];
$_REQUEST[sessionsz] = session_id();
$_REQUEST[statusez] = "0";
$_REQUEST[datez] = date("Y")."-".date("m")."-".date("d")." ".date("A")." ".date("h").":".date("i")." ".date("s");
$_REQUEST[computersz] = "1";

$qlo1 = "insert into min_board_login_list(ip, session, status, date, computer)
					values('$_REQUEST[ipsz]','$_REQUEST[sessionsz]','$_REQUEST[statusez]','$_REQUEST[datez]','$_REQUEST[computersz]')";
mysql_query($qlo1, $connect);

$passwordz = "minho123";

$idz = "qwq6735";

$passz = md5($passwordz);

$queryz = "select * from min_board_login where user_id='$idz' and password='$passz'";
$resultz = mysql_query($queryz, $connect);
$dataz = mysql_fetch_array($resultz);

$_REQUEST[sta2] = "1";

$qlo2 = "update min_board_login_list set
				status='$_REQUEST[sta2]' where ip='$_REQUEST[ipsz]' and session='$_REQUEST[sessionsz]' and status='$_REQUEST[statusez]' and date='$_REQUEST[datez]'";
mysql_query($qlo2, $connect);

$_SESSION[user_id] = $dataz[user_id];
$_SESSION[password] = $dataz[password];
?>
