<div id="copyfoot">
  Copyright ⓒ <?=date("Y")?> 로타리종합물류 All rights reserved.
</div>
<a name="bottomtxx"></a>
</body>
</html>
