<?
include "lib.php";
include "head.php";

if(!$Search_text) {
	echo("
		<script>
			window.alert('검색어를 입력해주세요.')
			history.go(-1)
		</script>
	");
	exit;
}

$eer = date("Y").date("m");

$qui = "select * from min_board_company_searchi where date='$eer' and gom='$Search_text' and mode='$Search_mode'";
$rui = mysql_query($qui, $connect);
$dui = mysql_fetch_array($rui);

if($dui[no]) {
	$ddreer = $dui[hit]+1;
	$quia = "update min_board_company_searchi set
						hit='$ddreer' where date='$eer' and gom='$Search_text' and mode='$Search_mode'";
	mysql_query($quia, $connect);
}else{
	$ddreerd = 1;
	$quid = "insert into min_board_company_searchi(gom,hit,date,mode)
						values('$_REQUEST[Search_text]','$ddreerd','$eer','$_REQUEST[Search_mode]')";
	mysql_query($quid, $connect);
}

$quiz = "insert into min_board_company_searchc(gom,mode)
					values('$_REQUEST[Search_text]','$_REQUEST[Search_mode]')";
mysql_query($quiz, $connect);
?>
<form action="company_info.php" name="abcz">
	<input type="hidden" name="Search_mode" value="<?=$Search_mode?>" />
	<input type="hidden" name="Search_text" value="<?=$Search_text?>" />
</form>
<script type="text/javascript">
	document.abcz.submit();
</script>
<?
include "foot.php";
?>
