<?
extract($_GET);
extract($_POST);
extract($_SERVER);
extract($_COOKIE);

$connect = mysql_connect("localhost","lsm8655","snrnsi11"); 
mysql_select_db("lsm8655", $connect);

mysql_query("set names utf8"); 

//함수

function selectc($sq1,$sq2) {
	global $connect;
	$result1 = "select count(*) from $sq1 $sq2";
	$result2 = mysql_query($result1, $connect);
	$result3 = mysql_fetch_array($result2);
	$result = $result3[0];
	
	return $result;
}

//함수

$yyo = "1";
$qyyo = "select count(*) from min_board_memo where checks='$yyo'";
$ryyo = mysql_query($qyyo, $connect);
$dyyo = mysql_fetch_array($ryyo);
$dyyocount = $dyyo[0];

$comasss = md5("dbswornjs1");

session_start();

if($_SESSION["user_id"]) {
if($_SESSION["password"]) {

$user_idsop = $_SESSION["user_id"];
$passwordsop = $_SESSION["password"];

$qmember = "select * from min_board_login where user_id='$user_idsop' and password='$passwordsop'";
$rmember = mysql_query($qmember, $connect);
$dmember = mysql_fetch_array($rmember);
}}




$dates1pp = date("Y");
$dates2pp = date("m");
$dates3pp = date("d");
$dates4pp = date("h");
$dates5pp = date("i");

$_REQUEST[ipspp] = $_SERVER["REMOTE_ADDR"];

$_REQUEST[datespp] = $dates1pp."-".$dates2pp."-".$dates3pp." ".$dates4pp.":".$dates5pp;
$_REQUEST[sessionspp] = session_id();

$qcustom1 = "select * from min_board_custom where date='$_REQUEST[datespp]' and session='$_REQUEST[sessionspp]'";
$rcustom1 = mysql_query($qcustom1, $connect);
$dcustom1 = mysql_num_rows($rcustom1);

if(!$_SESSION[user_id]) {
$_REQUEST[namespp] = "손님";
}else{
$_REQUEST[namespp] = "관리자";
}

if($dcustom1 == 0) {
$qcustom2 = "insert into min_board_custom(name, ip, date, session)
							values('$_REQUEST[namespp]','$_REQUEST[ipspp]','$_REQUEST[datespp]','$_REQUEST[sessionspp]')";
mysql_query($qcustom2, $connect);
}
$qcustom3 = "delete from min_board_custom where date!='$_REQUEST[datespp]'";
mysql_query($qcustom3, $connect);

$qcustom5 = "select * from min_board_custom where date='$_REQUEST[datespp]'";
$rcustom5 = mysql_query($qcustom5, $connect);
?>
