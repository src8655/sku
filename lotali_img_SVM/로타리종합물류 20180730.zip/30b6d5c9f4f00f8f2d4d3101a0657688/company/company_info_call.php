<?
$acn = join(" ",$callinfo);
if($counthigh != 1) {

include "lib.php";
include "head.php";

?>
<a href="company_info.php?Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&page=<?=$page?>" style="padding:5px;font-size:25px;margin:0 auto;display:block;border:1px solid #888888;margin-top:20px;text-align:center;text-decoration:none;color:red;font-weight:bold;margin-bottom:20px;">뒤로가기</a>
<?
include "foot.php";
?>
<script>
	location.href="sms:?body=<?=$acn?>";
	$(document).ready(function(){
	
	var ai1 = function(){
		history.go(-1);
		}
	setTimeout(ai1,1000);
	
	});
</script>
<?
}else{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<title>로타리종합물류</title>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.zclip.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('a#copy-description').zclip({
        path:'js/ZeroClipboard.swf',
        copy:$('a#copy-description').next().text()
        
		// 현재 a 안에 있는텍스트를 카피 하려면?
		// copy:$('this.a#copy-description').text() 이런식으로 하면 될거 같은데...
		// 아신다면 확인좀..
    });
});
</script>
<link rel="stylesheet" type="text/css" href="mm.css" />
</head>
<body style="margin:5px; padding:0px; font-size:17px;">
<a name="tops"></a>
<div id="headersm">
  <h1 style="float:left; width:210px;">
    <a href="./index.php">로타리종합물류<span style="font-size:15px;">[스마트폰]</span><br /><span id="hind">http://로타리종합물류.com/</span></a>
  </h1>
  <div style="width:70px;float:right;text-align:right;margin:8px 8px 8px 0;overflow:hidden;">
    <a href="../home/index.php" id="pcversion">PC버전</a>
  </div>
</div>
<?
if($olddate) {
$ef = "select * from min_board_olddate where olddate='$olddate'";
$df = mysql_query($ef, $connect);
$cf = mysql_fetch_array($df);
}else{}
?>
  <h1 id="headdate">
    <div style="float:left;width:156px;overflow:hidden;">
      <div style="float:left;overflow:hidden;"><? if($olddate) {?><?=$cf[date]?> 장부<? }else{?>공통<? }?></div>
    </div>
    <div style="float:right;width:134px;padding:2px 0 0 0;overflow:hidden;">
      <? if($dyyocount == 0) {?>
        <marquee behavior="scroll" direction="left" scrollDelay="65" scrollAmount="3" style="float:right; width:130px;margin:1px 0 0 100px;border:2px solid #B4BFCC;border-top:none;border-bottom:none;"><span style="font-size:15px;">새로운 메모가 없습니다.</span></marquee>
      <? }else{?>
        <marquee behavior="scroll" direction="left" scrollDelay="65" scrollAmount="3" style="float:right; width:130px;margin:1px 0 0 100px;border:2px solid #B4BFCC;border-top:none;border-bottom:none;"><span style="font-size:15px;color:red;"><?=$dyyocount?> 개의 새로운 메모가 있습니다.</span></marquee>
      <? }?>
    </div>
  </h1>
<?
if(!$dmember[user_id]) {
include "login_first.php";
}
?>
<a href="company_info.php?Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&page=<?=$page?>" style="padding:5px;font-size:25px;margin:0 auto;display:block;border:1px solid #888888;margin-top:20px;text-align:center;text-decoration:none;color:red;font-weight:bold;margin-bottom:20px;">뒤로가기</a>
<a href="#" id="copy-description" class="akmb">복사하기</a><div style="margin:0 auto;border:1px solid #676767;width:97%;padding:5px;"><?=$acn?></div>
<?
include 'foot.php';
?>
<?
}
?>