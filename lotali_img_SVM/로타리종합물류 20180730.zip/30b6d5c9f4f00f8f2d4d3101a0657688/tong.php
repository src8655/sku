<?
include "lib.php";
include "head.php";


$qallcount1 = "select count(*) from min_board_data1 where del='1'";
$rallcount1 = mysql_query($qallcount1, $connect);
$dallcount1 = mysql_fetch_array($rallcount1);
$qallcount2 = "select count(*) from min_board_data2";
$rallcount2 = mysql_query($qallcount2, $connect);
$dallcount2 = mysql_fetch_array($rallcount2);
$qallcount3 = "select count(*) from min_board_data3";
$rallcount3 = mysql_query($qallcount3, $connect);
$dallcount3 = mysql_fetch_array($rallcount3);

$dallcount = $dallcount1[0]+$dallcount2[0]+$dallcount3[0];


$qcounts2 = "select * from min_board_olddate order by date desc";
$rcounts2 = mysql_query($qcounts2, $connect);

$abbm1 = 0;

while($dcounts2 = mysql_fetch_array($rcounts2)) {
$qcc1s = "select count(*) from min_board_data1 where olddate='$dcounts2[olddate]' and del='1'";
$rcc1s = mysql_query($qcc1s, $connect);
$dcc1s = mysql_fetch_array($rcc1s);
$qcc2s = "select count(*) from min_board_data2 where olddate='$dcounts2[olddate]'";
$rcc2s = mysql_query($qcc2s, $connect);
$dcc2s = mysql_fetch_array($rcc2s);
$qcc3s = "select count(*) from min_board_data3 where olddate='$dcounts2[olddate]'";
$rcc3s = mysql_query($qcc3s, $connect);
$dcc3s = mysql_fetch_array($rcc3s);

$abbm2 = $dcc1s[0]+$dcc2s[0]+$dcc3s[0];

if($abbm2 > $abbm1) {
	$abbm1 = $abbm2;
}else{}
}
?>

<div style="margin-left:5px;margin-right:5px;overflow:hidden;">
	<div class="box" style="margin-bottom:8px;">
		<h1>월별 장부 목록</h1>
		<p>
			총 월별 장부는 <span style="font-weight:bold;color:red;"><?=$dallcount?></span> 건 입니다.
		</p>
	</div>
	<table cellpadding="5" cellspacing="0" id="write1_table" style="width:100%;margin:0 0 0px 0;">
	<col width="120" />
	<col width="208" />
		<tr>
			<th height="35">현재</th>
			<td><div style="background:blue;height:6px;"></div></td>
		</tr>
		<tr>
			<th height="35">작년</th>
			<td><div style="background:gray;height:6px;"></div></td>
		</tr>
	<?
	$qcounts = "select * from min_board_olddate order by date desc";
	$rcounts = mysql_query($qcounts, $connect);
	while($dcounts = mysql_fetch_array($rcounts)) {
	$qcc1 = "select count(*) from min_board_data1 where olddate='$dcounts[olddate]' and del='1'";
	$rcc1 = mysql_query($qcc1, $connect);
	$dcc1 = mysql_fetch_array($rcc1);
	$qcc2 = "select count(*) from min_board_data2 where olddate='$dcounts[olddate]'";
	$rcc2 = mysql_query($qcc2, $connect);
	$dcc2 = mysql_fetch_array($rcc2);
	$qcc3 = "select count(*) from min_board_data3 where olddate='$dcounts[olddate]'";
	$rcc3 = mysql_query($qcc3, $connect);
	$dcc3 = mysql_fetch_array($rcc3);
	
	$grr = (($dcc1[0]+$dcc2[0]+$dcc3[0])/$abbm1)*100;
	$grr2 = (($dcc1[0]+$dcc2[0]+$dcc3[0])/$abbm1)*100;
	
	$olddatedate = (mb_substr($dcounts[date],0,4,'UTF-8')-1).mb_substr($dcounts[date],4,4,'UTF-8');
	
	$qc = "select * from min_board_olddate where date='$olddatedate'";
	$rc = mysql_query($qc, $connect);
	$dc = mysql_fetch_array($rc);
	
	$qcc1s = "select count(*) from min_board_data1 where olddate='$dc[olddate]' and del='1'";
	$rcc1s = mysql_query($qcc1s, $connect);
	$dcc1s = mysql_fetch_array($rcc1s);
	$qcc2s = "select count(*) from min_board_data2 where olddate='$dc[olddate]'";
	$rcc2s = mysql_query($qcc2s, $connect);
	$dcc2s = mysql_fetch_array($rcc2s);
	$qcc3s = "select count(*) from min_board_data3 where olddate='$dc[olddate]'";
	$rcc3s = mysql_query($qcc3s, $connect);
	$dcc3s = mysql_fetch_array($rcc3s);
	
	$grrs = (($dcc1s[0]+$dcc2s[0]+$dcc3s[0])/$abbm1)*100;
	$grr2s = (($dcc1s[0]+$dcc2s[0]+$dcc3s[0])/$abbm1)*100;
	?>
		<tr>
			<th><?=$dcounts[date]?></th>
			<td>
				<?=$dcc1[0]+$dcc2[0]+$dcc3[0]?> <span style="font-size:20px;">(<?=round($grr2)?>%)</span>
				<div style="background:blue;width:<?=$grr?>%;height:6px;"></div>
				<div style="background:gray;width:<?=$grrs?>%;height:6px;margin-top:1px;"></div>
			</td>
		</tr>
	<?
	}
	?>
	</table>
</div>
<?
include "foot.php";
?>
