<?

include "lib.php";
include "head.php";

$acn = join(" ",$callinfo);
if($counthigh != 1) {

?>
<div class="imbody">
<a href="company_info.php?Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&page=<?=$page?>" style="padding:5px;font-size:25px;margin:0 auto;display:block;border:1px solid #888888;margin-top:20px;text-align:center;text-decoration:none;color:red;font-weight:bold;margin-bottom:20px;">뒤로가기</a>
</div>
<?
include "foot.php";
?>
<script>
	location.href="sms:?body=<?=$acn?>";
</script>
<?
}else{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<title>로타리종합물류</title>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.zclip.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('a#copy-description').zclip({
        path:'js/ZeroClipboard.swf',
        copy:$('a#copy-description').next().text()
        
		// 현재 a 안에 있는텍스트를 카피 하려면?
		// copy:$('this.a#copy-description').text() 이런식으로 하면 될거 같은데...
		// 아신다면 확인좀..
    });
});
</script>
<link rel="stylesheet" type="text/css" href="mm.css" />
</head>
<body style="margin:5px; padding:0px; font-size:17px;">
<a name="tops"></a>
<div id="headersm" style="background:#ffffff;">
  <h1 style="float:left; width:200px;">
    <a href="./index.php">로타리종합물류<br /><span id="hind">http://로타리종합물류.com/</span></a>
  </h1>
  <div style="width:82px;float:right;text-align:right;margin:8px 8px 8px 0;overflow:hidden;">
    <a href="../home/index.php" id="pcversion">PC버전</a>
  </div>
</div>
<?
if($olddate) {
$ef = "select * from min_board_olddate where olddate='$olddate'";
$df = mysql_query($ef, $connect);
$cf = mysql_fetch_array($df);
}else{}
?>
  <h1 id="headdate">
      <div style="float:left;overflow:hidden;"><? if($olddate) {?><?=$cf[date]?> 장부<? }else{?>공통<? }?></div>
  </h1>
<?
if(!$dmember[user_id]) {
include "login_first.php";
}
?>
<div class="imbody" style="text-align:center;">
<a href="company_info.php?Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&page=<?=$page?>" style="padding:5px;font-size:25px;margin:0 auto;display:block;border:1px solid #888888;text-align:center;text-decoration:none;color:red;font-weight:bold;">뒤로가기</a>
</div>
<div class="imbody">
<a href="#" id="copy-description" class="akmb">복사하기</a><div style="margin:0 auto;border:1px solid #676767;width:97%;padding:5px;"><?=$acn?></div>
</div>
<?
include 'foot.php';
?>
<?
}
?>