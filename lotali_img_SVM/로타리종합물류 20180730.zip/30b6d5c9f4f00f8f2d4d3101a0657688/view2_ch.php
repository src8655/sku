<?
include "lib.php";

if(!$passwords) {
  echo("
    <script>
      window.alert('비밀번호를 입력해주세요.')
      history.go(-1)
    </script>
  ");
  exit;
}

$klaas = md5("2537");
$klaas2 = md5($passwords);

if($klaas != $klaas2) {
  echo("
    <script>
      window.alert('비밀번호를 틀렸습니다.')
      history.go(-1)
    </script>
  ");
  exit;
}
?>
<script>
  location.href='view2.php?olddate=<?=$olddate?>&view2_ch=<?=$klaas2?>&id=<?=$id?>';
</script>
