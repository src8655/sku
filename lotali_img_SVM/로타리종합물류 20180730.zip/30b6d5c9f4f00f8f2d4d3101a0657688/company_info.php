<?
include "lib.php";
include "head.php";

if($Search_mode) {
  if($Search_mode == 1) $tmp = "company";
  if($Search_mode == 2) $tmp = "addr";
  
  $where = "where $tmp like '%$Search_text%'";
  }else{
    $where = "";
    }

if(!$page) $page = 1;


$qinfo = "select count(*) from min_board_info $where";
$rinfo = mysql_query($qinfo, $connect);
$dinfo = mysql_fetch_array($rinfo);
$infocount = $dinfo[0];

$lim1 = "10";
$lim2 = $lim1*$page-$lim1;

$pageing = ceil($infocount/$lim1);

$pa1 = $page-2;
$pa2 = $page+2;

$query = "select * from min_board_info $where order by company asc limit $lim2, $lim1";
$result = mysql_query($query, $connect);
?>
<div class="imbody" style="text-align:center;font-weight:bold;">
	<h1 style="font-size:30px;color:#000000;margin:5px 0 10px 0;padding:0 0 5px 0;border-bottom:1px solid #676767;">회사정보 - <span style="color:red;"><?=$infocount?></span></h1>
<form action="company_info_search.php">
      <select name="Search_mode" style="font-size:17px;padding:5px;display:none;">
        <option value="1" <? if($Search_mode == 1) {?>selected<? }?>>회사이름</option>
        <option value="2" <? if($Search_mode == 2) {?>selected<? }?>>주소</option>
      </select>
      <input type="text" name="Search_text" <? if($Search_mode) {?>value="<?=$Search_text?>"<? }?> style="border:1px solid #676767;font-size:25px;padding:5px 0 5px 0;width:66%;" />
      <input type="submit" value="검색" style="border:1px solid #676767;width:28%;background:#ffffff;font-size:25px;padding:5px;font-weight:bold;" />
</form>
</div>
  <div class="imbody" style="text-align:center;">
  		<a href="company_info.php?Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&page=1" style="color:#000000;text-decoration:none;"><<</a>
  		<? for($i=$pa1;$i<=$pa2;$i++) {if($i<=0) continue;if($i>$pageing)break;?>
  		<a href="company_info.php?Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&page=<?=$i?>" style="color:#000000;text-decoration:none;"><span <? if($page == $i){?>style="color:red;"<? }?>>[<?=$i?>]</span></a>
  		<? }?>
  		<a href="company_info.php?Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&page=<?=$pageing?>" style="color:#000000;text-decoration:none;">>></a>
	</div>
<?
while($data = mysql_fetch_array($result)) {
?>
<form action="company_info_call.php">
<input type="hidden" name="Search_mode" value="<?=$Search_mode?>" />
<input type="hidden" name="Search_text" value="<?=$Search_text?>" />
  <div class="imbody">
      <h1>
      	<div class="checkboxbox" style="display:none;"><input type="checkbox" name="callinfo[]" value="회사명 : <?=$data[company]?>" id="ach<?=$data[no]?>a" checked /><label for="ach<?=$data[no]?>a"></label></div>
      	<?=$data[company]?>
      </h1>
      <div <? if(!$data[addr]) {?>style="display:none;"<? }?>>
      	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="[지번] 주소 : <?=$data[addr]?>" id="ach<?=$data[no]?>b" /><label for="ach<?=$data[no]?>b"></label></div>
      	<label for="ach<?=$data[no]?>b"><span style="font-weight:bold;color:green;">[지번] 주소 : </span><span style="font-weight:bold;color:red;"><?=$data[addr]?></span></label>
      </div>
      <div <? if(!$data[addr2]) {?>style="display:none;"<? }?>>
      	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="[도로명] 주소 : <?=$data[addr2]?>" id="ach<?=$data[no]?>be" /><label for="ach<?=$data[no]?>be"></label></div>
      	<label for="ach<?=$data[no]?>be"><span style="font-weight:bold;color:green;">[도로명] 주소 : </span><span style="font-weight:bold;color:blue;"><?=$data[addr2]?></span></label>
      </div>
      <div <? if(!$data[addrnum]) {?>style="display:none;"<? }?>>
      	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="우편번호 : <?=$data[addrnum]?>" id="ach<?=$data[no]?>addrnum" /><label for="ach<?=$data[no]?>addrnum"></label></div>
      	<label for="ach<?=$data[no]?>addrnum"><span style="font-weight:bold;color:green;">우편번호 : </span><span style="font-weight:bold;color:green;"><?=$data[addrnum]?></span></label>
      </div>
      <div <? $spp1 = $data[tel1].$data[tel2].$data[tel3]; if(!$spp1) {?>style="display:none;"<? }?>>
      	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="전화번호 : <?=$data[tel1]?>-<?=$data[tel2]?>-<?=$data[tel3]?>" id="ach<?=$data[no]?>c" /><label for="ach<?=$data[no]?>c"></label></div>
      	<label for="ach<?=$data[no]?>c"><span style="font-weight:bold;color:green;">전화번호</span> : <?=$data[tel1]?><span style="font-size:11px;">&nbsp;</span>-<span style="font-size:11px;">&nbsp;</span><?=$data[tel2]?><span style="font-size:11px;">&nbsp;</span>-<span style="font-size:11px;">&nbsp;</span><?=$data[tel3]?></label>
      </div>
      <div <? $spp2 = $data[fax1].$data[fax2].$data[fax3]; if(!$spp2) {?>style="display:none;"<? }?>>
      	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="FAX번호 : <?=$data[fax1]?>-<?=$data[fax2]?>-<?=$data[fax3]?>" id="ach<?=$data[no]?>d" /><label for="ach<?=$data[no]?>d"></label></div>
      	<label for="ach<?=$data[no]?>d"><span style="font-weight:bold;color:green;">FAX번호</span> : <?=$data[fax1]?><span style="font-size:11px;">&nbsp;</span>-<span style="font-size:11px;">&nbsp;</span><?=$data[fax2]?><span style="font-size:11px;">&nbsp;</span>-<span style="font-size:11px;">&nbsp;</span><?=$data[fax3]?></label>
      </div>
      <div <? if(!$data[email]) {?>style="display:none;"<? }?>>
      	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="이메일 : <?=$data[email]?>" id="ach<?=$data[no]?>e" /><label for="ach<?=$data[no]?>e"></label></div>
      	<label for="ach<?=$data[no]?>e"><span style="font-weight:bold;color:green;">이메일</span> : <?=$data[email]?></label>
      </div>
      <div <? $spp3 = $data[name].$data[phone1].$data[phone2].$data[phone3]; if(!$spp3) {?>style="display:none;"<? }?>>
      	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="담당자 : <?=$data[name]?> 담당자번호 : <?=$data[phone1]?>-<?=$data[phone2]?>-<?=$data[phone3]?>" id="ach<?=$data[no]?>f" /><label for="ach<?=$data[no]?>f"></label></div>
      	<label for="ach<?=$data[no]?>f"><span style="font-weight:bold;color:green;">담당자</span> : <?=$data[name]?> <span style="font-weight:bold;">담당자번호</span> : <?=$data[phone1]?><span style="font-size:11px;">&nbsp;</span>-<span style="font-size:11px;">&nbsp;</span><?=$data[phone2]?><span style="font-size:11px;">&nbsp;</span>-<span style="font-size:11px;">&nbsp;</span><?=$data[phone3]?></label>
      </div>
<?
if($plus == $data[no]) {
}
$quer = "select * from min_board_info_plus where id='$data[no]' order by no desc";
$reer = mysql_query($quer, $connect);
while($daer = mysql_fetch_array($reer)) {
?>
			<div>
      	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="담당자 : <?=$daer[name]?> 담당자번호 : <?=$daer[phone1]?>-<?=$daer[phone2]?>-<?=$daer[phone3]?>"id="ach<?=$daer[no]?>g" /><label for="ach<?=$daer[no]?>g"></label></div>
      	<label for="ach<?=$daer[no]?>g"><span style="font-weight:bold;color:green;">담당자</span> : <?=$daer[name]?> <span style="font-weight:bold;">담당자번호</span> : <?=$daer[phone1]?><span style="font-size:11px;">&nbsp;</span>-<span style="font-size:11px;">&nbsp;</span><?=$daer[phone2]?><span style="font-size:11px;">&nbsp;</span>-<span style="font-size:11px;">&nbsp;</span><?=$daer[phone3]?></label>
			</div>
<?
}
?>
      <div <? if(!$data[memo]) {?>style="display:none;"<? }?>>
      	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="메모 : <?=$data[memo]?>" id="ach<?=$data[no]?>h" /><label for="ach<?=$data[no]?>h"></label></div>
      	<label for="ach<?=$data[no]?>h"><span style="font-weight:bold;color:green;">메모</span> : <?=$data[memo]?></label>
      </div>
      
      

      <div style="border-top:1px solid #676767;padding-top:5px;border-bottom:1px solid #676767;padding-bottom:7px;">
        <div style="width:48%;float:left;">
        	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="%0A%0Aㅡ세금계산서ㅡ%0A등록번호:127-24-44779 상호:로타리종합물류 성명:윤재권 주소:경기도 양주시 은현면 화합로 959(1층) 업태:서비스업 종목:화물운송대행 우편:11430" id="ach<?=$data[no]?>segum" /><label for="ach<?=$data[no]?>segum"></label></div>
        	<label for="ach<?=$data[no]?>segum"><span style="font-weight:bold;color:blue;">세금계산</span></label>
        </div>
        <div style="width:48%;float:right;">
        	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="%0A%0Aㅡ계좌번호ㅡ%0A로타리종합물류 계좌 농협 351-0737-4897-53 윤재권" id="ach<?=$data[no]?>gj" /><label for="ach<?=$data[no]?>gj"></label></div>
        	<label for="ach<?=$data[no]?>gj"><span style="font-weight:bold;color:blue;">계좌번호</span></label>
        </div>
      </div>
      
        <div style="">
        	<div class="checkboxbox"><input type="checkbox" name="callinfo[]" value="%0A%0Aㅡ이메일주소ㅡ%0Aqwq6735@naver.com%0A" id="ach<?=$data[no]?>emails" /><label for="ach<?=$data[no]?>emails"></label></div>
        	<label for="ach<?=$data[no]?>emails"><span style="font-weight:bold;color:blue;">이메일주소</span></label>
        </div>
      
      <div style="width:100%;">
      	<input type="submit" value="문자보내기" class="callbu" style="width:150px;background:#ffffff;font-weight:bold;float:left;" />
      	<div style="float:right;padding:5px 5px 0 10px;font-weight:bold;">복사하기</div><div class="checkboxbox" style="float:right;padding:3px 0 0 0;"><input type="checkbox" name="counthigh" value="1" id="ach<?=$data[no]?>i"/><label for="ach<?=$data[no]?>i" style="float:left;"></label></div>
      </div>
    </div>
</form>
<?
}
?>
<div class="imbody" style="text-align:center;">
  		<a href="company_info.php?Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&page=1" style="text-decoration:none;color:#000000;"><<</a>
  		<? for($i=$pa1;$i<=$pa2;$i++) {if($i<=0) continue;if($i>$pageing)break;?>
  		<a href="company_info.php?Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&page=<?=$i?>" style="text-decoration:none;color:#000000;"><span <? if($page == $i){?>style="color:red;"<? }?>>[<?=$i?>]</span></a>
  		<? }?>
  		<a href="company_info.php?Search_mode=<?=$Search_mode?>&Search_text=<?=$Search_text?>&page=<?=$pageing?>" style="text-decoration:none;color:#000000;">>></a>
</div>


<script>
	function getCookie(cookieName){
		var cookieValue=null;
		if(document.cookie){
			var array=document.cookie.split((escape(cookieName)+'='));
			if(array.length >= 2){
				var arraySub=array[1].split(';');
				cookieValue=unescape(arraySub[0]);
				}
			}
		return cookieValue;
	}
	function findnum(a) {
		var b = getCookie("mnpn");
		var ee = document.getElementById(a);
		ee.innerHTML = b;
	}
</script>
<?
include "foot.php";
?>
