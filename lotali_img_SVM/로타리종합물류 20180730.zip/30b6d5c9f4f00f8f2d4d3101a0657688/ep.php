<?
include "lib.php";
include "head.php";

if($Search_mode) {
	if($Search_mode == 1) $elmpsz = "name";
	
	$wheres = "and $elmpsz like '%$Search_text%'";
}

$qeps = "select * from min_board_ep where olddate='$olddate'";
$reps = mysql_query($qeps, $connect);
$deps = mysql_num_rows($reps);
?>
<div class="imbody" style="text-align:center;">
<form action=<?=$PHP_SELF?> >
<select name="Search_mode" style="width:65px;font-size:17px;padding:5px;display:none;">
<option value="1" <? if($Search_mode == 1){?>selected<? }?>>회사이름</option>
</select>
<input type="hidden" name="olddate" value="<?=$olddate?>" />
	<h1 style="font-size:30px;color:#000000;margin:5px 0 10px 0;padding:0 0 5px 0;border-bottom:1px solid #676767;">입금확인</h1>
	<div style="width:33%;float:left;"><a href="index.php?olddate=<?=$olddate?>" class="view1_button" style="font-size:25px;">뒤로가기</a></div>
  <div style="width:24%;float:right;overflow:hidden;"><input type="submit" value="검색" style="padding:5px;border:1px solid #676767;font-size:25px;background:#ffffff;width:91%;margin:0 0 0 5px;" /></div>
  <div style="width:41%;float:right;overflow:hidden;"><input type="text" name="Search_text" value="<?=$Search_text?>" size="8" style="font-size:25px;padding:5px 0 5px 0;margin:0px;border:1px solid #676767;width:99%;" /></div>
</form>
</div>

<?
$qmmeq211 = "select count(*) from min_board_ep where olddate='$olddate' $wheres and orders='11'";
$qmmer211 = mysql_query($qmmeq211, $connect);
$qmmed211 = mysql_fetch_array($qmmer211);
if($qmmed211[0] == 0) {
}else{
?>
<div class="imbody" style="text-align:center;">
	<h1 style="font-size:30px;color:#000000;margin:5px 0 10px 0;padding:0 0 5px 0;border-bottom:1px solid #676767;">담터</h1>
</div>
<?
$qep211 = "select * from min_board_ep where olddate='$olddate' and orders='11' $wheres order by name asc";
$rep211 = mysql_query($qep211, $connect);
while($dep211 = mysql_fetch_array($rep211)) {
if($dep211[checks] == 2) {
$depmom = "전자세금발행";
}else{
$depmom = "";
}
if($dep211[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
<div class="imbody">
		<span style="font-weight:bold;color:blue;"><?=$dep211[name]?></span><br />
		<span style="font-weight:bold;">입금여부 :</span> <span style="color:red;font-weight:bold;"><? if($dep211[date]) {if($dep211[date2]) {?><?=$dep211[date]?>월<?=$dep211[date2]?>일 입금<? }}else{?>미확인<? }?></span><br />
		<span style="font-weight:bold;">세금계산서 :</span> <?=$depmom?> <?=$depmom2?><br />
		<span style="font-weight:bold;">금액 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep211[money])?></span><br />
		<span style="font-weight:bold;">세액 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep211[moneys])?></span><br />
		<span style="font-weight:bold;">합계 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep211[se1])?></span><br />
		<span style="font-weight:bold;">메모 :</span> <?=$dep211[memo]?>
</div>
<?
}}
?>
<?
$qmmeq2 = "select count(*) from min_board_ep where olddate='$olddate' and orders='1' $wheres";
$qmmer2 = mysql_query($qmmeq2, $connect);
$qmmed2 = mysql_fetch_array($qmmer2);
if($qmmed2[0] == 0) {
}else{
?>
<div class="imbody" style="text-align:center;">
	<h1 style="font-size:30px;color:#000000;margin:5px 0 10px 0;padding:0 0 5px 0;border-bottom:1px solid #676767;">한달결제</h1>
</div>
<?
$qep2 = "select * from min_board_ep where olddate='$olddate' and orders='1' $wheres order by name asc";
$rep2 = mysql_query($qep2, $connect);
while($dep2 = mysql_fetch_array($rep2)) {
if($dep2[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep2[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
<div class="imbody">
			<span style="font-weight:bold;color:blue;"><?=$dep2[name]?></span><br />
			<span style="font-weight:bold;">입금여부 :</span> <span style="color:red;font-weight:bold;"><? if($dep2[date]) {if($dep2[date2]) {?><?=$dep2[date]?>월<?=$dep2[date2]?>일 입금<? }}else{?>미확인<? }?></span><br />
			<span style="font-weight:bold;">세금계산서 :</span> <?=$depmom?> <?=$depmom2?><br />
			<span style="font-weight:bold;">금액 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep2[money])?></span><br />
			<span style="font-weight:bold;">세액 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep2[moneys])?></span><br />
			<span style="font-weight:bold;">합계 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep2[se1])?></span><br />
			<span style="font-weight:bold;">메모 :</span> <?=$dep2[memo]?>
</div>
<?
}}
?>
<?
$qmmeq22 = "select count(*) from min_board_ep where olddate='$olddate' and orders='2' $wheres";
$qmmer22 = mysql_query($qmmeq22, $connect);
$qmmed22 = mysql_fetch_array($qmmer22);
if($qmmed22[0] == 0) {
}else{
?>
<div class="imbody" style="text-align:center;">
	<h1 style="font-size:30px;color:#000000;margin:5px 0 10px 0;padding:0 0 5px 0;border-bottom:1px solid #676767;">그때그때결제</h1>
</div>
<?
$qep22 = "select * from min_board_ep where olddate='$olddate' and orders='2' $wheres order by name asc";
$rep22 = mysql_query($qep22, $connect);
while($dep22 = mysql_fetch_array($rep22)) {
if($dep22[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep22[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
<div class="imbody">
			<span style="font-weight:bold;color:blue;"><?=$dep22[name]?></span><br />
			<span style="font-weight:bold;">입금여부 :</span> <span style="color:red;font-weight:bold;"><? if($dep22[date]) {if($dep22[date2]) {?><?=$dep22[date]?>월<?=$dep22[date2]?>일 입금<? }}else{?>미확인<? }?></span><br />
			<span style="font-weight:bold;">세금계산서 :</span> <?=$depmom?> <?=$depmom2?><br />
			<span style="font-weight:bold;">금액 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep22[money])?></span><br />
			<span style="font-weight:bold;">세액 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep22[moneys])?></span><br />
			<span style="font-weight:bold;">합계 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep22[se1])?></span><br />
			<span style="font-weight:bold;">메모 :</span> <?=$dep22[memo]?>
</div>
<?
}}
?>
<?
$qmmeq23 = "select count(*) from min_board_ep where olddate='$olddate' and orders='3' $wheres";
$qmmer23 = mysql_query($qmmeq23, $connect);
$qmmed23 = mysql_fetch_array($qmmer23);
if($qmmed23[0] == 0) {
}else{
?>
<div class="imbody" style="text-align:center;">
	<h1 style="font-size:30px;color:#000000;margin:5px 0 10px 0;padding:0 0 5px 0;border-bottom:1px solid #676767;">기사에게입금</h1>
</div>
<?
$qep23 = "select * from min_board_ep where olddate='$olddate' and orders='3' $wheres order by name asc";
$rep23 = mysql_query($qep23, $connect);
while($dep23 = mysql_fetch_array($rep23)) {
if($dep23[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep23[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
<div class="imbody">
			<span style="font-weight:bold;color:blue;"><?=$dep23[name]?></span><br />
			<span style="font-weight:bold;">입금여부 :</span> <span style="color:red;font-weight:bold;"><? if($dep23[date]) {if($dep23[date2]) {?><?=$dep23[date]?>월<?=$dep23[date2]?>일 입금<? }}else{?>미확인<? }?></span><br />
			<span style="font-weight:bold;">세금계산서 :</span> <?=$depmom?> <?=$depmom2?><br />
			<span style="font-weight:bold;">금액 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep23[money])?></span><br />
			<span style="font-weight:bold;">세액 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep23[moneys])?></span><br />
			<span style="font-weight:bold;">합계 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep23[se1])?></span><br />
			<span style="font-weight:bold;">메모 :</span> <?=$dep23[memo]?>
</div>
<?
}}
?>
<?
$qmmeq20 = "select count(*) from min_board_ep where olddate='$olddate' and orders='0' $wheres";
$qmmer20 = mysql_query($qmmeq20, $connect);
$qmmed20 = mysql_fetch_array($qmmer20);
if($qmmed20[0] == 0) {
}else{
?>
<div class="imbody" style="text-align:center;">
		<h1 style="font-size:30px;color:#000000;margin:5px 0 10px 0;padding:0 0 5px 0;border-bottom:1px solid #676767;">정렬 지정하지 않음</h1>
</div>
<?
$qep20 = "select * from min_board_ep where olddate='$olddate' and orders='0' $wheres order by name asc";
$rep20 = mysql_query($qep20, $connect);
while($dep20 = mysql_fetch_array($rep20)) {
if($dep20[checks] == 2) {
$depmom = "전자세금";
}else{
$depmom = "";
}
if($dep20[checks2] == 2) {
$depmom2 = "일반세금발행";
}else{
$depmom2 = "";
}
?>
<div class="imbody">
			<span style="font-weight:bold;color:blue;"><?=$dep20[name]?></span><br />
			<span style="font-weight:bold;">입금여부 :</span> <span style="color:red;font-weight:bold;"><? if($dep20[date]) {if($dep20[date2]) {?><?=$dep20[date]?>월<?=$dep20[date2]?>일 입금<? }}else{?>미확인<? }?></span><br />
			<span style="font-weight:bold;">세금계산서 :</span> <?=$depmom?> <?=$depmom2?><br />
			<span style="font-weight:bold;">금액 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep20[money])?></span><br />
			<span style="font-weight:bold;">세액 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep20[moneys])?></span><br />
			<span style="font-weight:bold;">합계 :</span> <span style="font-weight:bold;color:red;"><?=number_format($dep20[se1])?></span><br />
			<span style="font-weight:bold;">메모 :</span> <?=$dep20[memo]?>
</div>
<?
}}
?>
<?
$qep5 = "select * from min_board_ep where olddate='$olddate' $wheres";
$rep5 = mysql_query($qep5, $connect);
for($i=0;$dep5=mysql_fetch_assoc($rep5);$i++) {
$ememp1 += $dep5[se1];
$ememp2 += $dep5[money];
$ememp3 += $dep5[moneys];
}
?>
<div class="imbody">
	<span style="font-weight:bold;">총 금액 계 :</span> <span style="font-weight:bold;color:red;"><?=number_format($ememp2)?></span><br />
	<span style="font-weight:bold;">총 세액 계 :</span> <span style="font-weight:bold;color:red;"><?=number_format($ememp3)?></span><br />
	<span style="font-weight:bold;">총 합계 계 :</span> <span style="font-weight:bold;color:red;"><?=number_format($ememp1)?></span>
</div>
<?
include "foot.php";
?>
