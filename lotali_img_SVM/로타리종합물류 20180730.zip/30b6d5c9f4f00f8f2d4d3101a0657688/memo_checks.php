<?
include "lib.php";

$d1 = date("m");
$d2 = date("d");
$d3 = date("h");
$d4 = date("i");

$_REQUEST[checksdate] = $d1."-".$d2." ".$d3.":".$d4;

$query = "update min_board_memo set
					checks='2',
					checksdate='$_REQUEST[checksdate]' where no='$no'";
mysql_query($query, $connect);
?>
<script>
	location.href="index.php";
</script>
