<?
include "lib.php";
include "head.php";

$wheree = "where company='$company' and olddate='$olddate'";

if($Search_text){
    $where = "$wheree and (date like '%$Search_text%' or yo like '%$Search_text%' or ddo like '%$Search_text%' or number like '%$Search_text%' or name like '%$Search_text%' or money like '%$Search_text%' or memo1 like '%$Search_text%' or memo2 like '%$Search_text%' or phone like '%$Search_text%' or secrets like '%$Search_text%')";
}else{
$where = "$wheree";
}


$olst = "1";

$qs = "select count(*) from min_board_data1 $where and del='$olst'";
$rs = mysql_query($qs, $connect);
$ads = mysql_fetch_array($rs);
$adscount = $ads[0];

$dell = "1";

$query = "select * from min_board_data1 $where and del='$dell' order by date asc, no asc";
$result = mysql_query($query, $connect);

$q = "select * from min_board_admin where company='$company'";
$r = mysql_query($q, $connect);
$admin = mysql_fetch_array($r);
?>
<div class="imbody" style="text-align:center;">
<form action=<?=$PHP_SELF?> >
<select name="Search_mode" style="font-size:17px;width:65px;padding:5px;display:none;">
<option value="5" <? if($Search_mode == 5){?>selected<? }?>>이름</option>
</select>
<input type="hidden" name="company" value="<?=$company?>" />
<input type="hidden" name="olddate" value="<?=$olddate?>" />
	<h1 style="font-size:30px;color:#000000;margin:5px 0 10px 0;padding:0 0 5px 0;border-bottom:1px solid #676767;"><?=$admin[name]?><span stlye="font-size:17px;"> - </span><span style="font-size:25px; color:red;"><?=$adscount?></span>
	<? if($admin[ipgm]) {?>
    	<br />
    	<span style="background:yellow;font-weight:bold;font-size:23px;">입금자:[<?=$admin[ipgm]?>]</span>
  <? }?>
	</h1>
	<div style="width:33%;float:left;"><a href="index.php?olddate=<?=$olddate?>" class="view1_button" style="font-size:25px;">뒤로가기</a></div>
  <div style="width:24%;float:right;overflow:hidden;"><input type="submit" value="검색" style="padding:5px;border:1px solid #676767;font-size:25px;background:#ffffff;width:91%;margin:0 0 0 5px;" /></div>
  <div style="width:41%;float:right;overflow:hidden;"><input type="text" name="Search_text" value="<?=$Search_text?>" size="8" style="font-size:25px;padding:5px 0 5px 0;margin:0px;border:1px solid #676767;width:99%;" /></div>
</form>
</div>
<?
$a = 0;
$yyyom3 = 0;
while($data = mysql_fetch_array($result)) {
?>
<div class="imbody">
    	<span style="font-weight:bold;"><?=$data[date]?></span><br />
    	<?=$data[ddo]?>&nbsp;
	    <?=$data[number]?>&nbsp;
	    <span style="font-weight:bold;color:blue;"><?=$data[name]?></span>&nbsp;
<?
if($data[virtualmoney] != 1) {
?>
	    <span style="font-weight:bold;color:red;"><?=number_format($data[money])?></span><br />
<?
}else{
?>
	    <span style="font-weight:bold;color:orange;">착불(<?=number_format($data[money])?>)</span><br />
<?
}
?>
	    <?=$data[memo1]?>&nbsp;
	    <?=$data[memo2]?>&nbsp;
	    <?=$data[phone]?>&nbsp;
	    숫자 : <?=$data[secrets]?>
</div>
<?
if($data[virtualmoney] != 1) {
  $a += $data[money];
}
if($data[secrets] != 0) {
	if($data[money] != 0) {
	  if($data[virtualmoney] != 1) {
  		$yya1 = $data[secrets]."000";
  		$yya2 = $data[money]-$yya1;
  		$yyyom3 += $yya2;
}}}
}
?>
<div class="imbody">
	<a style="display:block;height:25px;width:100%;" onclick="allc()"></a>
</div>
<div id="col1" class="imbody" style="text-align:center;display:none;">
    	계 : <span style="font-weight:bold;color:red;"><?=number_format($a)?></span> // 
    	<?=number_format($yyyom3)?>
</div>
<?
include "foot.php";
?>
