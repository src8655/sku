<?
include "lib.php";
include "head.php";

if($Search_text){  
  $where = "where olddate='$olddate' and (date like '%$Search_text%' or yo like '%$Search_text%' or chu like '%$Search_text%' or ddo like '%$Search_text%' or name like '%$Search_text%' or number like '%$Search_text%' or money like '%$Search_text%' or phone like '%$Search_text%' or memo like '%$Search_text%')";
}else{
$where = "where olddate='$olddate'";
}

$olses = "1";

$qses = "select count(*) from min_board_data3 $where";
$rses = mysql_query($qses, $connect);
$adses = mysql_fetch_array($rses);
$adscountes = $adses[0];

$query = "select * from min_board_data3 $where order by date asc, no asc";
$result = mysql_query($query, $connect);
?>
<div class="imbody" style="text-align:center;">
<form action=<?=$PHP_SELF?> >
<select name="Search_mode" style="font-size:17px;width:65px;padding:5px;display:none;">
<option value="5" <? if($Search_mode == 5){?>selected<? }?>>이름</option>
</select>
<input type="hidden" name="company" value="<?=$company?>" />
<input type="hidden" name="olddate" value="<?=$olddate?>" />
	<h1 style="font-size:30px;color:#000000;margin:5px 0 10px 0;padding:0 0 5px 0;border-bottom:1px solid #676767;">로타리장부<?=$company?><span stlye="font-size:17px;"> - </span><span style="font-size:25px; color:red;"><?=$adscountes?></span></h1>
	<div style="width:33%;float:left;"><a href="index.php?olddate=<?=$olddate?>" class="view1_button" style="font-size:25px;">뒤로가기</a></div>
  <div style="width:24%;float:right;overflow:hidden;"><input type="submit" value="검색" style="padding:5px;border:1px solid #676767;font-size:25px;background:#ffffff;width:91%;margin:0 0 0 5px;" /></div>
  <div style="width:41%;float:right;overflow:hidden;"><input type="text" name="Search_text" value="<?=$Search_text?>" size="8" style="font-size:25px;padding:5px 0 5px 0;margin:0px;border:1px solid #676767;width:99%;" /></div>
</form>
</div>
<?
while($data = mysql_fetch_array($result)) {

$memomoney = $data[memo]."000";
?>
<div class="imbody">
    	<span style="font-weight:bold;">로타리장부<?=$data[company]?> | <?=$data[date]?></span><br />
    	<?=$data[chu]?>&nbsp;
    	<?=$data[ddo]?><br />
    	<span style="font-weight:bold;color:blue;"><?=$data[name]?></span>&nbsp;
    	<?=$data[number]?>&nbsp;
    	<span style="font-weight:bold;color:red;"><?=$data[money1]."-".$data[money2]?></span><br />
    	<?=$data[phone]?>&nbsp;
    	메모 : <?=number_format($memomoney)?>
</div>
<?
}

$queryu = "select * from min_board_data3 $where";
$resultj = mysql_query($queryu, $connect);

for($i;$us = mysql_fetch_assoc($resultj);$i++) {
$comss += $us[money1];
$comsee += $us[memo];
}
$comsse = $comss."000";
$comssee = $comsee."000";
?>
<div class="imbody">
	<a style="display:block;height:25px;width:100%;" onclick="allc()"></a>
</div>
<div id="col1" class="imbody" style="text-align:center;display:none;">
	계 : <span style="font-weight:bold;color:red;"><?=number_format($comsse)?></span> / <?=number_format($comssee)?>
</div>
<?
include "foot.php";
?>
