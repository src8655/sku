<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<title>로타리종합물류</title>
<link rel="stylesheet" type="text/css" href="mmsm.css" />
</head>
<body style="background:none;margin:5px;padding:5px;border:1px solid #787878;">
<div id="info_header">
	<div style="width:100%;overflow:hidden;">
		<h1 style="float:left;"><a href="info_list.php">로타리화물정보<br />http://로타리종합물류.com/</a></h1>
		<ul style="float:right;border:0px;">
			<li><a href="info_mylist.php" style="margin:0px;padding:0px;"><img src="./images/info_tb.jpg" alt="내가등록한화물" /></a></li>
		</ul>
	</div>
	<ul>
		<li><a href="info_list.php"><img src="./images/home_info_b1.png" alt="화물정보" /></a></li>
		<li><a href="info_write.php"><img src="./images/home_info_b2.png" alt="화물등록" /></a></li>
		<li><a href="info_result.php"><img src="./images/home_info_b3.png" alt="내가선택한화물" /></a></li>
	</ul>
</div>
<?
if(!$dlog[no]) {
?>
<div style="width:100%;padding:0 0 10px 0;font-size:15px;overflow:hidden;">
	로그인을 하지 않고 이용시 화물등록,선택한화물,등록한화물을 이용할 수 없습니다.
</div>
<?
}
?>
<script type="text/javascript">
location.href="http://로타리종합물류.com/";
</script>