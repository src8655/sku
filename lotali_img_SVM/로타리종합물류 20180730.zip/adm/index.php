<?
include "../libs.php";
include "./head.php";
?>
<h1 id="map" style="background:url(../images/adm_m0.jpg) no-repeat left top;"></h1>
<div style="width:100%;height:2px;background:#000000;margin:0 0 10px 0;overflow:hidden;"><div style="width:120px;height:2px;background:red;overflow:hidden;"></div></div>
<div class="box">
	<h1>회원관리</h1>
	<p>
		가입한 회원을 관리합니다. 가입한 회원목록을 보고, 검색할 수 있으며 수정과 삭제가 가능합니다.
	</p>
</div>
<div class="box">
	<h1>전체게시물관리</h1>
	<p>
		게시물을 관리합니다. 로타리종합물류 홈페이지 속의 모든 게시판글을 한번에 보고, 검색할 수 있으며 수정과 삭제가 가능합니다.
	</p>
</div>
<div class="box">
	<h1>전체댓글관리</h1>
	<p>
		댓글을 관리합니다. 로타리종합물류 홈페이지속의 모든 댓글을 한번에 보고, 검색할 수 있으며 수정과 삭제가 가능합니다.
	</p>
</div>
<div class="box">
	<h1>조회수관리</h1>
	<p>
		접속한 사용자를 관리합니다. 시간대별로 접속한 조회수를 확인할 수 있으며 접속자의 아이피와 상세한 시간을 볼 수 있습니다.
	</p>
</div>
<div class="box">
	<h1>밴리스트</h1>
	<p>
		접근제한 PC의 아이피를 관리합니다. 글 도배시 접근제한 목록에 자동으로 입력 되지만 필요시 직접 입력이 가능합니다. 아이피가 밴리스트에 추가되면 그 아이피로는 홈페이지에 접속이 불가능하게 됩니다.
	</p>
</div>
<?
include "./foot.php";
?>
