<?
include "../libs.php";
include "./head.php";

$abjoin = join(",",$nos);

$qmemberdel = "delete from ho_board_ban where no in($abjoin)";
mysql_query($qmemberdel, $connect);
?>
<script>
	location.href="ban.php";
</script>
<?
include "./foot.php";
?>
