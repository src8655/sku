<?
include "../libs.php";
include "./head.php";

$qmembere = "select * from ho_board_data where no='$no'";
$rmembere = mysql_query($qmembere, $connect);
$dmembere = mysql_fetch_array($rmembere);
?>
<h1 id="map" style="background:url(../images/adm_m2.jpg) no-repeat left top;"></h1>
<div style="width:100%;height:2px;background:#000000;margin:0 0 10px 0;overflow:hidden;"><div style="width:120px;height:2px;background:red;overflow:hidden;"></div></div>
<div class="box">
	<h1>게시물수정</h1>
	<p>
		제목과 내용만 수정 가능합니다.
	</p>
</div>
<form action="list_edit_post.php">
<input type="hidden" name="no" value="<?=$dmembere[no]?>" />
<table cellpadding="5" cellspacing="0" class="count" style="width:779px;">
<col width="150" />
<col width="629" />
	<tr>
		<th>제목</th>
		<td><input type="text" name="subject" value="<?=$dmembere[subject]?>" style="width:500px;" /></td>
	</tr>
	<tr>
		<th>내용</th>
		<td><textarea name="memo" cols="10" rows="10"><?=$dmembere[memo]?></textarea></td>
	</tr>
</table>
<div style="padding:10px 0 0 0;overflow:hidden;">
	<a href="list.php?Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>&amp;page=<?=$page?>" class="butt" style="float:left;margin:0px;padding:0px;height:23px;line-height:23px;width:70px;text-align:center;overflow:hidden;">취소</a>
	<input type="submit" value="수정하기" class="butt" style="float:right;margin:0px;padding:0px;height:25px;line-height:25px;width:70px;overflow:hidden;" />
</div>
</form>
<?
include "./foot.php";
?>
