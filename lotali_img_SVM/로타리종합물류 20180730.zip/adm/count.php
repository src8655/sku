<?
include "../libs.php";
include "./head.php";

// 날짜

if(!$rdatey) $rdatey = date("Y");
if(!$rdatem) $rdatem = date("m");
if(!$rdated) $rdated = date("d");

$tomon = date("t",strtotime("$rdatey-$rdatem-1"));

$mleft = ($rdatem-1);
if($mleft <= 9) $mleft = "0".$mleft;
$yleft = $rdatey;
if($mleft == 0) {
	$mleft = 12;
	$yleft = $yleft-1;
}

$mright = $rdatem+1;
if($mright <= 9) $mright = "0".$mright;
$yright = $rdatey;
if($mright == 13) {
	$mright = "01";
	$yright = $yright+1;
}

$mydate = $rdatey."-".$rdatem."-".$rdated;

// 날짜

$dcountadma = selectc("ho_board_count","where date='$mydate'");
$dcountadmaa = selectc("ho_board_count","");

$hitmo = "10";

$qcountadml = "select * from ho_board_count where date='$mydate' order by no asc limit 0,$hitmo";
$rcountadml = mysql_query($qcountadml, $connect);

$qcountadmls = "select * from ho_board_count where date='$mydate' order by no asc limit $hitmo,$dcountadma";
$rcountadmls = mysql_query($qcountadmls, $connect);

$dac = 0;

for($i=0;$i<24;$i++) {
$arc = $i;
if($arc == 0) $arc = "00";
if($arc == 1) $arc = "01";
if($arc == 2) $arc = "02";
if($arc == 3) $arc = "03";
if($arc == 4) $arc = "04";
if($arc == 5) $arc = "05";
if($arc == 6) $arc = "06";
if($arc == 7) $arc = "07";
if($arc == 8) $arc = "08";
if($arc == 9) $arc = "09";

$dcountcc = selectc("ho_board_count","where date='$mydate' and hour='$arc'");

if($dcountcc > $dac) {
	$dac = $dcountcc;
}else{}
}
?>
<h1 id="map" style="background:url(../images/adm_m4.jpg) no-repeat left top;"></h1>
<div style="width:100%;height:2px;background:#000000;margin:0 0 10px 0;overflow:hidden;"><div style="width:120px;height:2px;background:red;overflow:hidden;"></div></div>
<div class="box">
	<h1 style="text-align:center;">
		<div style="width:200px;float:left;overflow:hidden;">
			&nbsp;
		</div>
		<div style="width:337px;float:left;overflow:hidden;">
			<a href="count.php?rdatey=<?=$yleft?>&rdatem=<?=$mleft?>&rdated=<?=$rdated?>" class="lins"><<</a>&nbsp;
			<?=$rdatey?>년 <?=$rdatem?>월
			&nbsp;<a href="count.php?rdatey=<?=$yright?>&rdatem=<?=$mright?>&rdated=<?=$rdated?>" class="lins">>></a>
		</div>
		<div style="width:200px;float:right;overflow:hidden;">
			<a href="count.php" class="lins" style="float:right;display:block;padding:5px 10px 5px 10px;width:120px;border:1px solid #676767;font-size:17px;">오늘로 이동</a>
		</div>
	</h1>
	<p style="text-align:center;">
		<?
		for($i=1;$i<=$tomon;$i++) {
		$ie = $i;
		if($i == 1) $ie = "01";
		if($i == 2) $ie = "02";
		if($i == 3) $ie = "03";
		if($i == 4) $ie = "04";
		if($i == 5) $ie = "05";
		if($i == 6) $ie = "06";
		if($i == 7) $ie = "07";
		if($i == 8) $ie = "08";
		if($i == 9) $ie = "09";
		?>
		<a href="count.php?rdatey=<?=$rdatey?>&rdatem=<?=$rdatem?>&rdated=<?=$ie?>" class="lins" <? if($ie == $rdated){?>style="color:red;font-weight:bold;"<? }?>><?=$i?>일</a>&nbsp;
		<?
		}
		?>
	</p>
</div>
<div id="countl">
	<div class="box">
		<h1><?=$mydate?></h1>
		<p>
			오늘 조회수 : <?=$dcountadma?> 명<br />
			전체 조회수 : <?=$dcountadmaa?> 명
		</p>
	</div>
	<div class="box">
		<h1>오늘 접속한 사용자 목록&nbsp;&nbsp;<a style="text-decoration:none;color:red;" class="hitboxhidden">접속경로</a></h1>
		<ul class="hitbox">
<?
while($dcountadml = mysql_fetch_array($rcountadml)) {
?>
			<li><div><span style="font-weight:bold;"><?=$dcountadml[hour]?>시</span> <?=$dcountadml[ip]?></div><div style="display:none;"><span style="font-weight:bold;color:red;">접속경로</span>&nbsp;<span style="font-weight:bold;"><?=$dcountadml[hour]?>시</span> <?=$dcountadml[ip]?><br /><a href="<?=$dcountadml[links]?>" target="_BLANK"><?=$dcountadml[links]?></a></div></li>
<?
}
?>
		</ul>
<?
if($dcountadma > 10) {
?>
		<p>
			<a onclick="tebox();" style="margin:10px 0 10px 0;display:block;height:30px;line-height:30px;border:1px solid #676767;text-align:center;">더보기</a>
		</p>
		<ul class="hitbox" id="hitboxhide" style="display:none;">
<?
while($dcountadmls = mysql_fetch_array($rcountadmls)) {
?>
			<li><div><span style="font-weight:bold;"><?=$dcountadmls[hour]?>시</span> <?=$dcountadmls[ip]?></div><div style="display:none;"><span style="font-weight:bold;color:red;">접속경로</span>&nbsp;<span style="font-weight:bold;"><?=$dcountadmls[hour]?>시</span> <?=$dcountadmls[ip]?><br /><a href="<?=$dcountadmls[links]?>" target="_BLANK"><?=$dcountadmls[links]?></a></div></li>
<?
}
?>
		</ul>
<?
}
?>
	</div>
</div>
<table cellpadding="5" cellspacing="0" width="385" class="count">
<col width="70" />
<col width="70" />
<col width="245" />
<?
for($i=0;$i<24;$i++) {
$arc = $i;
if($arc == 0) $arc = "00";
if($arc == 1) $arc = "01";
if($arc == 2) $arc = "02";
if($arc == 3) $arc = "03";
if($arc == 4) $arc = "04";
if($arc == 5) $arc = "05";
if($arc == 6) $arc = "06";
if($arc == 7) $arc = "07";
if($arc == 8) $arc = "08";
if($arc == 9) $arc = "09";

$dcountadm = selectc("ho_board_count","where date='$mydate' and hour='$arc'");

$okcount1 = ($dcountadm/$dcountadma)*245;
$okcount2 = ($dcountadm/$dcountadma)*100;
?>

	<tr>
		<th><?=$arc?>시</th>
		<td align="center"><?=$dcountadm?> 명</td>
		<td><?=round($okcount2)?>%<div style="background:blue;width:<?=$okcount1?>px;height:5px;overflow:hidden;"></div></td>
	</tr>
<?
}
?>
</table>
<?
include "./foot.php";
?>
