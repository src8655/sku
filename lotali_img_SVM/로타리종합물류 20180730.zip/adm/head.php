<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>로타리종합물류</title>
<link rel="stylesheet" type="text/css" href="adms.css" />
<script type="text/javascript" src="../jquery/jquery-1.4.2.min.js"></script>
<script src="../alditor/alditor.js" type="text/javascript"></script>    
<script type="text/javascript">
	function tebox() {
		if(hitboxhide.style.display == "none") {
			hitboxhide.style.display = "";
		}else{
			hitboxhide.style.display = "none";
		}
	}
	$(function(){
		
		// 접속자정보
		$(".hitbox li").click(function(){
			$(this).find("div").slideToggle();
		});
		$(".hitboxhidden").click(function(){
			$(".hitbox li div").slideToggle();
		});
		// 접속자정보
		
	});
</script>
</head>
<body>
<? include "./geo.php";?>
<div id="header">
	<h1><a href="index.php">로타리종합물류<br /><span style="font-size:11px;font-weight:normal;">http://로타리종합물류.com/</span></a></h1>
	<p>관리자페이지</p>
</div>
<div id="con">
	<div id="nav">
		<h1>관리자페이지</h1>
		<ul>
			<li><a href="index.php">첫페이지</a></li>
			<li><a href="member.php">회원관리</a></li>
			<li><a href="list.php">전체게시물관리</a></li>
			<li><a href="comment.php">전체댓글관리</a></li>
			<li><a href="count.php">조회수관리</a></li>
			<li><a href="ban.php">밴리스트</a></li>
		</ul>
	</div>
	<div id="contents">
