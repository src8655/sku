<?
include "../libs.php";
include "./head.php";

if($Search_mode) {
	if($Search_mode == 1) $tempadm = "memo";
	if($Search_mode == 2) $tempadm = "name";
	if($Search_mode == 3) $tempadm = "date";
	if($Search_mode == 4) $tempadm = "ip";
	
	$where = "where $tempadm like '%$Search_text%'";
}else{
	$where = "";
}

$all1 = selectc("ho_board_comment","");
$all2 = selectc("ho_board_comment","$where order by no desc");

if(!$page) {
	$page = 1;
}
$limitnum = 10;
$limitstart = ($limitnum*$page)-$limitnum;

$paging = ceil($all2/$limitnum);

$qmemberadm = "select * from ho_board_comment $where order by no desc limit $limitstart,$limitnum";
$rmemberadm = mysql_query($qmemberadm, $connect);
?>
<h1 id="map" style="background:url(../images/adm_m3.jpg) no-repeat left top;"></h1>
<div style="width:100%;height:2px;background:#000000;margin:0 0 10px 0;overflow:hidden;"><div style="width:120px;height:2px;background:red;overflow:hidden;"></div></div>
<div class="box" style="width:343px;float:right;">
	<h1>전체댓글글수</h1>
	<p>
		작성된 모든 댓글은 <span style="font-weight:bold;color:red;"><?=$all1?>개</span> 입니다.
	</p>
</div>
<form action="<?=$PHP_SELF?>">
<div class="box" style="width:343px;float:left;">
	<h1>댓글검색</h1>
	<p style="text-align:center;height:25px;">
			<select name="Search_mode" class="selects">
				<option value="1" <? if($Search_mode == 1) {?>selected<? }?>>내용</option>
				<option value="2" <? if($Search_mode == 2) {?>selected<? }?>>이름</option>
				<option value="3" <? if($Search_mode == 3) {?>selected<? }?>>날짜</option>
				<option value="4" <? if($Search_mode == 4) {?>selected<? }?>>아이피</option>
			</select>
			<input type="text" name="Search_text" value="<?=$Search_text?>" class="inputs" />
			<input type="submit" value="검색" class="submits" />
	</p>
</div>
</form>
<form action="comment_del.php">
<table cellpadding="5" cellspacing="0" class="count" style="width:779px;">
<col width="50" />
<col width="" />
<col width="80" />
<col width="100" />
<col width="80" />
<col width="60" />
<col width="60" />
	<tr>
		<th height="22px">번호</th>
		<th>내용</th>
		<th>이름</th>
		<th>아이피</th>
		<th>올린날짜</th>
		<th>수정</th>
		<th>
			<? if($noz == 1) {?>
				<a href="comment.php?page=<?=$page?>&amp;Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>" class="butt">취소</a>
			<? }else{?>
				<a href="comment.php?page=<?=$page?>&amp;Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>&amp;noz=1" class="butt">전체</a>
			<? }?>
		</th>
	</tr>
<?
$cnt = 0;
while($dmemberadm = mysql_fetch_array($rmemberadm)) {
?>
	<tr>
		<td align="center"><?=$all2-$limitstart-$cnt?></td>
		<td><?=mb_substr($dmemberadm[memo],0,30,'euc-kr')?></td>
		<td align="center"><?=$dmemberadm[name]?></td>
		<td align="center"><?=$dmemberadm[ip]?></td>
		<td align="center"><?=$dmemberadm[date]?></td>
		<td align="center"><a href="comment_edit.php?no=<?=$dmemberadm[no]?>&amp;Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>&amp;page=<?=$page?>" class="butt">수정</a></td>
		<td align="center"><input type="checkbox" name="nos[]" value="<?=$dmemberadm[no]?>" <? if($noz == 1) {?>checked<? }?> style="width:15px;height:15px;" /></td>
	</tr>
<?
$cnt++;
}
?>
	<tr>
		<td align="center" colspan="6">
			<a href="comment.php?page=1&amp;Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>" style="text-decoration:none;color:#000000;"><<</a>
<?
$as1 = $page-5;
$as2 = $page+5;

for($i=$as1;$i<=$as2;$i++) {
if($i<=0) {}else{
if($i>$paging) {}else{
?>
			<a href="comment.php?page=<?=$i?>&amp;Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>" style="text-decoration:none;color:#000000;<? if($page == $i) {?>color:red;font-weight:bold;<? }?>">&nbsp;[<?=$i?>]</a>
<?
}}}
?>
			<a href="comment.php?page=<?=$paging?>&amp;Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>" style="text-decoration:none;color:#000000;">&nbsp;>></a>
		</td>
		<td><input type="submit" value="삭제" class="butt" style="width:100%;font-size:12px;" /></td>
	</tr>
</table>
</form>
<?
include "./foot.php";
?>
