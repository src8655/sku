<?
include "../libs.php";
include "./head.php";

$qmemberin = "update ho_board_data set
							subject='$_REQUEST[subject]',
							memo='$_REQUEST[memo]' where no='$no'";
mysql_query($qmemberin, $connect);
?>
<script>
	location.href="list.php";
</script>
<?
include "./foot.php";
?>
