<?
if(!$dlog[no]) {
	echo("
		<script type='text/javascript'>
			window.alert('로그인이 필요합니다')
			location.href='../login.php';
		</script>
	");
	exit;
}else{
if($dlog[level] < 3) {
	echo("
		<script type='text/javascript'>
			window.alert('권한이 없습니다.')
			location.href='../index.php';
		</script>
	");
	exit;
}}
