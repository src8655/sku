<?
include "../libs.php";
include "./head.php";

$qmembere = "select * from ho_board_member where no='$no'";
$rmembere = mysql_query($qmembere, $connect);
$dmembere = mysql_fetch_array($rmembere);
?>
<h1 id="map" style="background:url(../images/adm_m1.jpg) no-repeat left top;"></h1>
<div style="width:100%;height:2px;background:#000000;margin:0 0 10px 0;overflow:hidden;"><div style="width:120px;height:2px;background:red;overflow:hidden;"></div></div>
<div class="box">
	<h1>회원수정</h1>
	<p>
		비밀번호는 수정을 원하지 않을 경우 빈칸으로 놓아도 됩니다.
	</p>
</div>
<form action="member_edit_post.php">
<input type="hidden" name="no" value="<?=$dmembere[no]?>" />
<table cellpadding="5" cellspacing="0" class="count" style="width:779px;">
<col width="150" />
<col width="629" />
	<tr>
		<th>아이디</th>
		<td><input type="text" name="adm_user_id" value="<?=$dmembere[user_id]?>" /></td>
	</tr>
	<tr>
		<th>비밀번호</th>
		<td><input type="password" name="adm_password" /></td>
	</tr>
	<tr>
		<th>이름</th>
		<td><input type="text" name="adm_name" value="<?=$dmembere[name]?>" /></td>
	</tr>
	<tr>
		<th>이메일</th>
		<td><input type="text" name="adm_email" value="<?=$dmembere[email]?>" /></td>
	</tr>
	<tr>
		<th>생년월일</th>
		<td>
			<?
			$birz = explode("-",$dmembere[birth]);
			?>
			<select name="adm_birthy">
				<? for($i=date("Y");$i>1949;$i--) {?>
				<option value="<?=$i?>" <? if($i == $birz[0]) {?>selected<? }?>><?=$i?></option>
				<? }?>
			</select>
			년
			<select name="adm_birthm">
				<? for($i=1;$i<13;$i++) {?>
				<option value="<?=$i?>" <? if($i == $birz[1]) {?>selected<? }?>><?=$i?></option>
				<? }?>
			</select>
			월
			<select name="adm_birthd">
				<? for($i=1;$i<33;$i++) {?>
				<option value="<?=$i?>" <? if($i == $birz[2]) {?>selected<? }?>><?=$i?></option>
				<? }?>
			</select>
			일
		</td>
	</tr>
	<tr>
		<th>차량번호</th>
		<td><input type="text" name="adm_carnum" value="<?=$dmembere[carnum]?>" /></td>
	</tr>
	<tr>
		<th>휴대전화</th>
		<td>
<?
$akk = explode("-",$dmembere[phone]);
?>
			<input type="text" name="adm_phone1" value="<?=$akk[0]?>" style="width:80px;" /> - <input type="text" name="adm_phone2" value="<?=$akk[1]?>" style="width:80px;" /> - <input type="text" name="adm_phone3" value="<?=$akk[2]?>" style="width:80px;" />
		</td>
	</tr>
	<tr>
		<th>집전화</th>
		<td>
<?
$akks = explode("-",$dmembere[number]);
?>
			<input type="text" name="adm_number1" value="<?=$akks[0]?>" style="width:80px;" /> - <input type="text" name="adm_number2" value="<?=$akks[1]?>" style="width:80px;" /> - <input type="text" name="adm_number3" value="<?=$akks[2]?>" style="width:80px;" />
		</td>
	</tr>
	<tr>
		<th>주소</th>
		<td><input type="text" name="adm_addr" value="<?=$dmembere[addr]?>" style="width:500px;" /></td>
	</tr>
	<tr>
		<th>메모</th>
		<td><textarea name="adm_memo" cols="10" rows="10"><?=$dmembere[memo]?></textarea></td>
	</tr>
	<tr>
		<th>레벨</th>
		<td>
			<select name="adm_level">
				<option value="2" <? if($dmembere[level] == 2) {?>selected<? }?>>회원</option>
				<option value="3" <? if($dmembere[level] == 3) {?>selected<? }?>>관리자</option>
			</select>
		</td>
	</tr>
</table>
<div style="padding:10px 0 0 0;overflow:hidden;">
	<a href="member.php?Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>&amp;page=<?=$page?>" class="butt" style="float:left;margin:0px;padding:0px;height:23px;line-height:23px;width:70px;text-align:center;overflow:hidden;">취소</a>
	<input type="submit" value="수정하기" class="butt" style="float:right;margin:0px;padding:0px;height:25px;line-height:25px;width:70px;overflow:hidden;" />
</div>
</form>
<?
include "./foot.php";
?>
