<?
include "../libs.php";
include "./head.php";

$abjoin = join(",",$nos);

$qmemberdel = "delete from ho_board_comment where no in($abjoin)";
mysql_query($qmemberdel, $connect);
?>
<script>
	location.href="comment.php?page=<?=$page?>&amp;Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>";
</script>
<?
include "./foot.php";
?>
