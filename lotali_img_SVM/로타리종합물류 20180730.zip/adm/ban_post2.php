<?
include "../libs.php";
include "./head.php";

$qbanins = "insert into ho_board_ban2(ip)
						values('$_REQUEST[adm_ip]')";
mysql_query($qbanins, $connect);
?>
<script>
	location.href="ban.php";
</script>
<?
include "./foot.php";
?>
