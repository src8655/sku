<?
include "../libs.php";
include "./head.php";

$qmemberin = "update ho_board_comment set
							memo='$_REQUEST[memo]' where no='$no'";
mysql_query($qmemberin, $connect);
?>
<script>
	location.href="comment.php";
</script>
<?
include "./foot.php";
?>
