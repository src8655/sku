<?
include "../libs.php";
include "./head.php";

$passwordee = md5($adm_password);

if($adm_password) {
	$slslem = ",password='$passwordee'";
}else{
	$slslem = "";
}

$births = $adm_birthy."-".$adm_birthm."-".$adm_birthd;
$phones = $adm_phone1."-".$adm_phone2."-".$adm_phone3;
$numbers = $adm_number1."-".$adm_number2."-".$adm_number3;

$qmemberin = "update ho_board_member set
							user_id='$adm_user_id',
							name='$adm_name',
							email='$adm_email',
							birth='$births',
							carnum='$adm_carnum',
							phone='$phones',
							number='$numbers',
							addr='$adm_addr',
							memo='$adm_memo',
							level='$adm_level'
							$slslem where no='$no'";
mysql_query($qmemberin, $connect);
?>
<script>
	location.href="member.php";
</script>
<?
include "./foot.php";
?>
