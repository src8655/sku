<?
include "../libs.php";
include "./head.php";

//시작

if($Search_mode) {
	if($Search_mode == 1) $tempadm = "ip";
	
	$where = "where $tempadm like '%$Search_text%'";
}else{
	$where = "";
}

$dmembercadm = selectc("ho_board_ban","");
$dmembercadms = selectc("ho_board_ban","$where order by no desc");

if(!$page) {
	$page = 1;
}
$limitnum = 10;
$limitstart = ($limitnum*$page)-$limitnum;

$paging = ceil($dmembercadms/$limitnum);

$qmemberadm = "select * from ho_board_ban $where order by no desc limit $limitstart,$limitnum";
$rmemberadm = mysql_query($qmemberadm, $connect);

//시작

if($Search_modeu) {
	if($Search_modeu == 1) $tempadmu = "ip";
	
	$whereu = "where $tempadmu like '%$Search_textu%'";
}else{
	$whereu = "";
}

$dmembercadmu = selectc("ho_board_ban2","");
$dmembercadmsu = selectc("ho_board_ban2","$whereu order by no desc");

if(!$pageu) {
	$pageu = 1;
}
$limitnumu = 10;
$limitstartu = ($limitnumu*$pageu)-$limitnumu;

$pagingu = ceil($dmembercadmsu/$limitnumu);

$qmemberadmu = "select * from ho_board_ban2 $whereu order by no desc limit $limitstartu,$limitnumu";
$rmemberadmu = mysql_query($qmemberadmu, $connect);
?>
<h1 id="map" style="background:url(../images/adm_m5.jpg) no-repeat left top;"></h1>
<div style="width:100%;height:2px;background:#000000;margin:0 0 10px 0;overflow:hidden;"><div style="width:120px;height:2px;background:red;overflow:hidden;"></div></div>
<div style="width:385px;float:left;overflow:hidden;">
	<form action="<?=$PHP_SELF?>">
	<div class="box" style="width:343px;">
		<h1>3자리 아이피</h1>
		<p style="text-align:center;height:25px;">
				<select name="Search_mode" class="selects">
					<option value="1" <? if($Search_mode == 1) {?>selected<? }?>>아이피</option>
				</select>
				<input type="text" name="Search_text" value="<?=$Search_text?>" class="inputs" />
				<input type="submit" value="검색" class="submits" />
		</p>
	</div>
	</form>
	<form action="ban_post1.php">
	<table cellpadding="5" cellspacing="0" class="count" style="width:385px;margin-bottom:10px;">
	<col width="285" />
	<col width="100" />
		<tr>
			<td><input type="text" name="adm_ip" style="width:275px;" /></td>
			<td><input type="submit" value="등록" class="butt" style="font-size:12px;width:100%;" /></td>
		</tr>
	</table>
	</form>
	<form action="ban_del1.php">
	<table cellpadding="5" cellspacing="0" class="count" style="width:385px;">
	<col width="50" />
	<col width="" />
	<col width="60" />
	<col width="60" />
		<tr>
			<th height="22px">번호</th>
			<th>아이피</th>
			<th>
				<? if($noz == 1) {?>
					<a href="ban.php?page=<?=$page?>&amp;Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>" class="butt">취소</a>
				<? }else{?>
					<a href="ban.php?page=<?=$page?>&amp;Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>&amp;noz=1" class="butt">전체</a>
				<? }?>
			</th>
		</tr>
	<?
	$cnt = 0;
	while($dmemberadm = mysql_fetch_array($rmemberadm)) {
	?>
		<tr>
			<td align="center"><?=$dmembercadms-$limitstart-$cnt?></td>
			<td><?=$dmemberadm[ip]?></td>
			<td align="center"><input type="checkbox" name="nos[]" value="<?=$dmemberadm[no]?>" <? if($noz == 1) {?>checked<? }?> style="width:15px;height:15px;" /></td>
		</tr>
	<?
	$cnt++;
	}
	?>
		<tr>
			<td align="center" colspan="2">
				<a href="ban.php?page=1&amp;Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>" style="text-decoration:none;color:#000000;"><<</a>
	<?
	$as1 = $page-5;
	$as2 = $page+5;
	
	for($i=$as1;$i<=$as2;$i++) {
	if($i<=0) {}else{
	if($i>$paging) {}else{
	?>
				<a href="ban.php?page=<?=$i?>&amp;Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>" style="text-decoration:none;color:#000000;<? if($page == $i) {?>color:red;font-weight:bold;<? }?>">&nbsp;[<?=$i?>]</a>
	<?
	}}}
	?>
				<a href="ban.php?page=<?=$paging?>&amp;Search_mode=<?=$Search_mode?>&amp;Search_text=<?=$Search_text?>" style="text-decoration:none;color:#000000;">&nbsp;>></a>
			</td>
			<td><input type="submit" value="삭제" class="butt" style="width:100%;font-size:12px;" /></td>
		</tr>
	</table>
	</form>
</div>
<div style="width:385px;float:right;overflow:hidden;">
	<form action="<?=$PHP_SELF?>">
	<div class="box" style="width:343px;">
		<h1>2자리 아이피</h1>
		<p style="text-align:center;height:25px;">
				<select name="Search_modeu" class="selects">
					<option value="1" <? if($Search_modeu == 1) {?>selected<? }?>>아이피</option>
				</select>
				<input type="text" name="Search_textu" value="<?=$Search_textu?>" class="inputs" />
				<input type="submit" value="검색" class="submits" />
		</p>
	</div>
	</form>
	<form action="ban_post2.php">
	<table cellpadding="5" cellspacing="0" class="count" style="width:385px;margin-bottom:10px;">
	<col width="285" />
	<col width="100" />
		<tr>
			<td><input type="text" name="adm_ip" style="width:275px;" /></td>
			<td><input type="submit" value="등록" class="butt" style="font-size:12px;width:100%;" /></td>
		</tr>
	</table>
	</form>
	<form action="ban_del2.php">
	<table cellpadding="5" cellspacing="0" class="count" style="width:385px;">
	<col width="50" />
	<col width="" />
	<col width="60" />
	<col width="60" />
		<tr>
			<th height="22px">번호</th>
			<th>아이피</th>
			<th>
				<? if($noz == 2) {?>
					<a href="ban.php?pageu=<?=$pageu?>&amp;Search_modeu=<?=$Search_modeu?>&amp;Search_textu=<?=$Search_textu?>" class="butt">취소</a>
				<? }else{?>
					<a href="ban.php?pageu=<?=$pageu?>&amp;Search_modeu=<?=$Search_modeu?>&amp;Search_textu=<?=$Search_textu?>&amp;noz=2" class="butt">전체</a>
				<? }?>
			</th>
		</tr>
	<?
	$cntu = 0;
	while($dmemberadmu = mysql_fetch_array($rmemberadmu)) {
	?>
		<tr>
			<td align="center"><?=$dmembercadmsu-$limitstartu-$cntu?></td>
			<td><?=$dmemberadmu[ip]?></td>
			<td align="center"><input type="checkbox" name="nos[]" value="<?=$dmemberadmu[no]?>" <? if($noz == 2) {?>checked<? }?> style="width:15px;height:15px;" /></td>
		</tr>
	<?
	$cntu++;
	}
	?>
		<tr>
			<td align="center" colspan="2">
				<a href="ban.php?pageu=1&amp;Search_modeu=<?=$Search_modeu?>&amp;Search_textu=<?=$Search_textu?>" style="text-decoration:none;color:#000000;"><<</a>
	<?
	$as1u = $pageu-5;
	$as2u = $pageu+5;
	
	for($iu=$as1u;$iu<=$as2u;$iu++) {
	if($iu<=0) {}else{
	if($iu>$pagingu) {}else{
	?>
				<a href="ban.php?pageu=<?=$iu?>&amp;Search_modeu=<?=$Search_modeu?>&amp;Search_textu=<?=$Search_textu?>" style="text-decoration:none;color:#000000;<? if($pageu == $iu) {?>color:red;font-weight:bold;<? }?>">&nbsp;[<?=$iu?>]</a>
	<?
	}}}
	?>
				<a href="ban.php?pageu=<?=$pagingu?>&amp;Search_modeu=<?=$Search_modeu?>&amp;Search_textu=<?=$Search_textu?>" style="text-decoration:none;color:#000000;">&nbsp;>></a>
			</td>
			<td><input type="submit" value="삭제" class="butt" style="width:100%;font-size:12px;" /></td>
		</tr>
	</table>
	</form>
</div>
<?
include "./foot.php";
?>
