<?
include "libs.php";
include "head2.php";

if(!$id) {
	echo("
		<script>
			window.alert('잘못된 접근입니다.')
			history.go(-1)
		</script>
	");
	exit;
}

$qdmzc = "select count(*) from ho_board_data where id='$id'";
$rdmzc = mysql_query($qdmzc, $connect);
$ddmzc = mysql_fetch_array($rdmzc);

if(!$page) {
  $page = "1";
  }

$pagingnum = "7";
$pagingstart = $page*$pagingnum-$pagingnum;

$paging = ceil($ddmzc[0]/$pagingnum);

$qdmz = "select * from ho_board_data where id='$id' order by no desc limit $pagingstart, $pagingnum";
$rdmz = mysql_query($qdmz, $connect);
?>
<div class="boards_header">
	<p style="float:left;">전체게시물 : <?=$ddmzc[0]?></p>
	<p style="float:right;text-align:right;">
<? if(!$dlog[no]) {?>
		<a href="login.php">로그인</a>
		&nbsp;
		<a href="join.php">회원가입</a>
<? }else{?>
		<span style="font-weight:bold;"><?=$dlog[name]?></span>님 환영합니다.
<? }?>
	</p>
</div>
<table cellpadding="7" cellspacing="0" class="boards">
<col width="60" />
<col width="1" />
<col width="240" />
<col width="1" />
<col width="70" />
<col width="1" />
<col width="70" />
<col width="1" />
<col width="60" />
	<tr>
		<th>번호</th>
		<th><span style="font-weight:normal;">|</span></th>
		<th>제목</th>
		<th><span style="font-weight:normal;">|</span></th>
		<th>이름</th>
		<th><span style="font-weight:normal;">|</span></th>
		<th>날짜</th>
		<th><span style="font-weight:normal;">|</span></th>
		<th>조회</th>
	</tr>
<?
$string_len = 15;   //제목 노출 글자수
$cntz = "0";
while($ddmz = mysql_fetch_array($rdmz)) {
$qco = "select count(*) from ho_board_comment where linkno='$ddmz[no]'";
$rco = mysql_query($qco, $connect);
$dco = mysql_fetch_array($rco);
$dates = explode(" ",$ddmz[date2]);
?>
	<tr>
		<td align="center"><?=$ddmzc[0]-$cntz-$pagingstart?></td>
		<td></td>
		<td>
		  <a href="board_view.php?id=<?=$ddmz[id]?>&amp;no=<?=$ddmz[no]?>&amp;page=<?=$page?>">
		    <?=mb_substr($ddmz[subject],0,$string_len,'UTF-8')?><? if(mb_strlen($ddmz[subject],"UTF-8") > $string_len){?>...<? }?>
		  </a>
		  <? if($ddmz[secret] == 1) {?><img src="./images/secret.gif" alt="비밀글" /><? }?>
		  <? if($dates[0] == date("Y")."-".date("m")."-".date("d")) {?><span style="font-size:11px;color:red;">New</span><? }?>
		  <? if($dco[0] != 0) {?><span style="font-size:11px;color:red;"><?=$dco[0]?></span><? }?>
		</td>
		<td></td>
		<td align="center"><?=$ddmz[name]?></td>
		<td></td>
		<td align="center"><?=$ddmz[date]?></td>
		<td></td>
		<td align="center"><?=$ddmz[hit]?></td>
	</tr>
<?
$cntz ++;
}
?>
</table>
<div class="boards_b">
	<div class="boards_bl">
		<a href="board.php?id=<?=$id?>" style="background:url(./images/home_boardbutton1.jpg) no-repeat left top;"></a>
	</div>
	<div class="boards_bc">
		<a href="board.php?id=<?=$id?>&amp;page=1">&lt;&lt;</a>
<?
$al = $page-5;
$ar = $page+5;

for($i=$al;$i<=$ar;$i++) {
  if($i<1){}else{
  if($i>$paging){}else{
?>
		<a href="board.php?id=<?=$id?>&amp;page=<?=$i?>" <? if($i==$page) {?>style="font-weight:bold;color:red;"<? }?>><?=$i?></a>
<?
}}}
?>
		<a href="board.php?id=<?=$id?>&amp;page=<?=$paging?>">&gt;&gt;</a>
	</div>
	<div class="boards_br">
		<a href="board_write.php?id=<?=$id?>" style="background:url(./images/home_boardbutton2.jpg) no-repeat left top;"></a>
	</div>
</div>
<?
include "foot2.php";
?>
