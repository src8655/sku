<?
// 지역선택 페이지

include "lib.php";

//전화번호 imei 없으면 종료
if(!$_GET[phone]) exit;
if(!$_GET[imei]) exit;

$qu = "select count(*) from android_member where phone='$_GET[phone]' and imei='$_GET[imei]'";
$ru = mysql_query($qu, $connect);
$du = mysql_fetch_array($ru);

//회원정보가 없으면 종료
if($du[0] == 0) exit;


//그룹별로 나누기
if(($md[ton] == "1t")||($md[ton] == "1.4t")||($md[ton] == "1t미만")||($md[car] == "라보")||($md[car] == "다마스"))
$ls = 1;
else if(($md[ton] == "2.5t")||($md[ton] == "3.5t")) $ls = 2;
else $ls = 3;




//지역별 변수 초기화
$a = 0;
$b = 0;
$c = 0;
$ds = 0;
$e = 0;
$f = 0;
$g = 0;
$h = 0;
$i = 0;
$j = 0;
$k = 0;
$l = 0;
$n = 0;
$m = 0;
$o = 0;
$p = 0;
$total = 0;

$ac = 1;


//1이면 독차/혼적
//2이면 독차
//3이면 혼적
//만 보여주기
if($_GET[dhm] == "1") {
$wherehon = "";
}else if($_GET[dhm] == "2") {
$hhoonn = "독차";
$wherehon = " and dh='$hhoonn'";
}else if($_GET[dhm] == "3") {
$hhoonn = "혼적";
$wherehon = " and dh='$hhoonn'";
}


$q = "select * from android_data where status='$ac' $wherehon";
$r = mysql_query($q, $connect);
while($d = mysql_fetch_array($r)) {
  if($d[dh] == "혼적") {
      if(($d[times]+(60*60*24))<time()) {
        $cb = 4;
        $qq = "update android_data set
              status='$cb' where no='$d[no]'";
        mysql_query($qq, $connect);
      }else{
        if($d[sang] == "서울") $a += 1;
        if($d[sang] == "경기") $b += 1;
        if($d[sang] == "인천") $c += 1;
        if($d[sang] == "충북") $ds += 1;
        if($d[sang] == "충남") $e += 1;
        if($d[sang] == "대전") $f += 1;
        if($d[sang] == "대구") $g += 1;
        if($d[sang] == "경남") $h += 1;
        if($d[sang] == "경북") $i += 1;
        if($d[sang] == "부산") $j += 1;
        if($d[sang] == "울산") $k += 1;
        if($d[sang] == "강원") $l += 1;
        if($d[sang] == "광주") $n += 1;
        if($d[sang] == "전북") $m += 1;
        if($d[sang] == "전남") $o += 1;
        if($d[sang] == "제주") $p += 1;
        $total += 1;
      }
  }else{
    if(($d[list_status] == $ls)||($d[car] == "전체")) {
      
      //24시간이 지나면 만료(4) 상태로 변경
      if(($d[times]+(60*60*24))<time()) {
        $cb = 4;
        $qq = "update android_data set
              status='$cb' where no='$d[no]'";
        mysql_query($qq, $connect);
      }else{
        
      //지역별 갯수 카운트
        if($d[sang] == "서울") $a += 1;
        if($d[sang] == "경기") $b += 1;
        if($d[sang] == "인천") $c += 1;
        if($d[sang] == "충북") $ds += 1;
        if($d[sang] == "충남") $e += 1;
        if($d[sang] == "대전") $f += 1;
        if($d[sang] == "대구") $g += 1;
        if($d[sang] == "경남") $h += 1;
        if($d[sang] == "경북") $i += 1;
        if($d[sang] == "부산") $j += 1;
        if($d[sang] == "울산") $k += 1;
        if($d[sang] == "강원") $l += 1;
        if($d[sang] == "광주") $n += 1;
        if($d[sang] == "전북") $m += 1;
        if($d[sang] == "전남") $o += 1;
        if($d[sang] == "제주") $p += 1;
        $total += 1;
      }
    }
  }
}
echo $a."-=-".$b."-=-".$c."-=-".$ds."-=-".$e."-=-".$f."-=-".$g."-=-".$h."-=-".$i."-=-".$j."-=-".$k."-=-".$l."-=-".$n."-=-".$m."-=-".$o."-=-".$p."-=-".$total."-=-";
?>