<?
//�Խñ� ����

include "lib.php";

//��ȭ��ȣ imei ������ ����
if(!$_GET[phone]) exit;
if(!$_GET[imei]) exit;

$qu = "select count(*) from android_member where phone='$_GET[phone]' and imei='$_GET[imei]'";
$ru = mysql_query($qu, $connect);
$du = mysql_fetch_array($ru);

//ȸ�������� ������ ����
if($du[0] == 0) exit;

$todays = date("Y").date("m").date("d");

$qs = "select count(*) from android_data where reader_time='$todays' and reader_number='$md[phone]' and reader_imei='$md[imei]' and status='2'";
$rs = mysql_query($qs, $connect);
$ds = mysql_fetch_array($rs);

$choicedcnt = 0;
if($ds[0] >= 2) $choicedcnt = 1;
  
$q = "select * from android_data where no='$_GET[no]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

echo $d[sang]."-=-".$d[sangmemo]."-=-".$d[sangtime]."-=-".$d[ha]."-=-".$d[hatime]."-=-".$d[objectname]."-=-".$d[car]."-=-".$d[ton]."-=-".$d[p1]."-=-".$d[money1]."-=-".$d[memo]."-=-".$d[no]."-=-".$d[status]."-=-".$d[writer_time]."-=-".$d[writer_time_t]."-=-".$d[dh]."-=-".$d[p2]."-=-".$d[money2]."-=-".$d[sangbang]."-=-".$d[habang]."-=-".$choicedcnt."-=-".$d[money2]."-=-";
?>