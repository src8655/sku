<?
//올렸던 배차 취소및 다시올리기

include "lib.php";

//전화번호 imei 없으면 종료
if(!$_GET[phone]) exit;
if(!$_GET[imei]) exit;

$qu = "select count(*) from android_member where phone='$_GET[phone]' and imei='$_GET[imei]'";
$ru = mysql_query($qu, $connect);
$du = mysql_fetch_array($ru);

//회원정보 없으면 종료
if($du[0] == 0) exit;


$qr = "select * from android_data where writer_number='$md[phone]' and writer_imei='$md[imei]' and no='$_GET[no]'";
$rr = mysql_query($qr, $connect);
$dr = mysql_fetch_array($rr);

//만료(4)상태나 수정불가완료(5) 상태면 강제종료
if(($dr[status] == 5)||($dr[status] == 4)) {
  exit;
}else{


$dig = 3;

$q = "update android_data set
      status = '$dig' where writer_number='$md[phone]' and writer_imei='$md[imei]' and no='$_GET[no]' and status!='5' and status!='4'";
mysql_query($q, $connect);





  $mq2 = "select * from android_member where phone='$dr[reader_number]' and imei='$dr[reader_imei]'";
  $mr2 = mysql_query($mq2, $connect);
  $md2 = mysql_fetch_array($mr2);
  
  
//톤스별 금액 설정
  $cmmoney = 5000;
  if(($md2[ton] == "1t")||($md2[ton] == "1.4t")||($md2[car] == "다마스")||($md2[car] == "라보"))
  			$cmmoney = 2500;
  		else if(($md2[ton] == "2.5t")||($md2[myton] == "3.5t"))
  			$cmmoney = 3000;
  		else if(($md2[ton] == "5t"))
  			$cmmoney = 4000;
  		else $cmmoney = 5000;
  if($md2[admins] == 2) $cmmoney = 0;
		
		
		
//환불해줄 금액
$chm = $md2[mymoney]+(($dr[money2]*1000)+$cmmoney);

  if(($dr[status] == 2)) {
//상태가 수정가능한 완료(2)상태일시
//금액 환불
    $q2 = "update android_member set
            mymoney='$chm' where phone='$dr[reader_number]' and imei='$dr[reader_imei]'";
    mysql_query($q2, $connect);

//거래내역에 추가
    $tomoney = (($dr[money2]*1000)+$cmmoney);
    $tomemo = "화물취소";
    $todays2 = date("Y").date("m").date("d");
    $qpays = "insert into android_pay(dates, money, memo, phone, imei, money2)
              values('$todays2','$tomoney','$tomemo','$dr[reader_number]','$dr[reader_imei]','$chm')";
    mysql_query($qpays, $connect);
    
    if($dr[money2] != 0) {
      $qe = "select * from android_member where phone='$dr[writer_number]' and imei='$dr[writer_imei]'";
      $re = mysql_query($qe, $connect);
      $de = mysql_fetch_array($re);
      
      //게시글 작성자에게도 금액환불
      $chm2 = $de[mymoney]-($dr[money2]*1000);
      $q3 = "update android_member set
              mymoney='$chm2' where phone='$de[phone]' and imei='$de[imei]'";
      mysql_query($q3, $connect);
      
      //거래내역에 추가
      $tomoneys = -($dr[money2]*1000);
      $tomemos = "알선료취소";
      $todays2s = date("Y").date("m").date("d");
      $qpayss = "insert into android_pay(dates, money, memo, phone, imei, money2)
                values('$todays2s','$tomoneys','$tomemos','$dr[writer_number]','$dr[writer_imei]','$chm2')";
      mysql_query($qpayss, $connect);
    }
    
    
    
  }
}
?>