<?
//리스트페이지

include "lib.php";

//전화번호 imei 없으면 종료
if(!$_GET[phone]) exit;
if(!$_GET[imei]) exit;

$qu = "select count(*) from android_member where phone='$_GET[phone]' and imei='$_GET[imei]'";
$ru = mysql_query($qu, $connect);
$du = mysql_fetch_array($ru);

//회원정보가 없으면 종료
if($du[0] == 0) exit;

$dde = 1;


//그룹1,2,3으로 나눔
if(($md[ton] == "1t")||($md[ton] == "1.4t")||($md[car] == "라보")||($_GET[ton] == "1t미만")||($md[car] == "다마스"))
$ls = 1;
else if(($md[ton] == "2.5t")||($md[ton] == "3.5t")) 
$ls = 2;
else 
$ls = 3;




//요청한것이 1이면 혼적과독차
//요청한것이 2이면 독차
//요청한것이 3이면 혼적
//만 보여주기
  if($_GET[dhm] == "1") {
    $wherehon = "";
  }else if($_GET[dhm] == "2") {
    $hhoonn = "독차";
    $wherehon = " and dh='$hhoonn'";
  }else if($_GET[dhm] == "3") {
  $hhoonn = "혼적";
  $wherehon = " and dh='$hhoonn'";
 }
  
  
  if($_GET[ji] != "전체") {
  $q2 = "select * from android_data where status='$dde' $wherehon";
  $r2 = mysql_query($q2, $connect);
  $eer = 0;
  
  //24시간이 지난 게시글은 만료(4)상태로 변경
  while($d2 = mysql_fetch_array($r2)) {
    if($d2[dh] == "혼적") {
      if(ereg($d2[sang],$_GET[ji])) {
          if(($d2[times]+(60*60*24))<time()) {
            
            $cb = 4;
            $qq = "update android_data set
                  status='$cb' where no='$d2[no]'";
            mysql_query($qq, $connect);
          }else{
          
            $eer += 1;
          }
        }
    }else{
      if(($d2[car] == "전체")||($d2[list_status] == $ls)) {
        
        if(ereg($d2[sang],$_GET[ji])) {
          if(($d2[times]+(60*60*24))<time()) {
            
            $cb = 4;
            $qq = "update android_data set
                  status='$cb' where no='$d2[no]'";
            mysql_query($qq, $connect);
          }else{
          
            $eer += 1;
          }
        }
      }
    }
  }
  echo $eer."-=-";
  
  $q = "select * from android_data where status='$dde' $wherehon order by no desc";
  $r = mysql_query($q, $connect);
  while($d = mysql_fetch_array($r)) {
    if($d[dh] == "혼적") {
          if(ereg($d[sang],$_GET[ji])) {
            echo $d[sang]."_=_".$d[sangmemo]."_=_".$d[sangtime]."_=_".$d[ha]."_=_".$d[hatime]."_=_".$d[objectname]."_=_".$d[car]."_=_".$d[ton]."_=_".$d[pay]."_=_".$d[money1]."_=_".$d[memo]."_=_".$d[no]."_=_".$d[writer_time_t]."_=_".$d[dh]."_=_".$d[money2]."_=_".$d[p1]."_=_".$d[sangbang]."_=_".$d[habang]."_=_".$d[money2]."_=_";
            echo "-=-";
          }
      }else{
      if(($d[car] == "전체")||($d[list_status] == $ls)) {
        if(ereg($d[sang],$_GET[ji])) {
          echo $d[sang]."_=_".$d[sangmemo]."_=_".$d[sangtime]."_=_".$d[ha]."_=_".$d[hatime]."_=_".$d[objectname]."_=_".$d[car]."_=_".$d[ton]."_=_".$d[pay]."_=_".$d[money1]."_=_".$d[memo]."_=_".$d[no]."_=_".$d[writer_time_t]."_=_".$d[dh]."_=_".$d[money2]."_=_".$d[p1]."_=_".$d[sangbang]."_=_".$d[habang]."_=_".$d[money2]."_=_";
          echo "-=-";
        }
      }else{}
    }
  }
}else{
  $q2 = "select * from android_data where status='$dde' $wherehon";
  $r2 = mysql_query($q2, $connect);
  $eer = 0;
  //24시간이 지난 게시글은 만료(4)상태로 변경
  while($d2 = mysql_fetch_array($r2)) {
    if($d2[dh] == "혼적") {
        if(($d2[times]+(60*60*24))<time()) {
          $cb = 4;
          $qq = "update android_data set
                status='$cb' where no='$d2[no]'";
          mysql_query($qq, $connect);
        }else{
          $eer += 1;
        }
    }else{
      if(($d2[car] == "전체")||($d2[list_status] == $ls)) {
        if(($d2[times]+(60*60*24))<time()) {
          $cb = 4;
          $qq = "update android_data set
                status='$cb' where no='$d2[no]'";
          mysql_query($qq, $connect);
        }else{
          $eer += 1;
        }
      }
    }
  }
  echo $eer."-=-";
  
  $q = "select * from android_data where status='$dde' $wherehon order by no desc";
  $r = mysql_query($q, $connect);
  while($d = mysql_fetch_array($r)) {
    //혼적 화물이면 모두에게 보여주고
    if($d[dh] == "혼적") {
      echo $d[sang]."_=_".$d[sangmemo]."_=_".$d[sangtime]."_=_".$d[ha]."_=_".$d[hatime]."_=_".$d[objectname]."_=_".$d[car]."_=_".$d[ton]."_=_".$d[pay]."_=_".$d[money1]."_=_".$d[memo]."_=_".$d[no]."_=_".$d[writer_time_t]."_=_".$d[dh]."_=_".$d[money2]."_=_".$d[p1]."_=_".$d[sangbang]."_=_".$d[habang]."_=_".$d[money2]."_=_";
      echo "-=-";
    }else{
      //아니면 그룹끼리만 보여주기
      if(($d[car] == "전체")||($d[list_status] == $ls)) {
          echo $d[sang]."_=_".$d[sangmemo]."_=_".$d[sangtime]."_=_".$d[ha]."_=_".$d[hatime]."_=_".$d[objectname]."_=_".$d[car]."_=_".$d[ton]."_=_".$d[pay]."_=_".$d[money1]."_=_".$d[memo]."_=_".$d[no]."_=_".$d[writer_time_t]."_=_".$d[dh]."_=_".$d[money2]."_=_".$d[p1]."_=_".$d[sangbang]."_=_".$d[habang]."_=_".$d[money2]."_=_";
          echo "-=-";
      }else{}
    }
  }
}
?>