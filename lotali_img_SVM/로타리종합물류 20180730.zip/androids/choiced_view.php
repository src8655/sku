<?
//������ ȭ�� �ڼ�������

include "lib.php";

//��ȭ��ȣ imei ������ ����
if(!$_GET[phone]) exit;
if(!$_GET[imei]) exit;

$qu = "select count(*) from android_member where phone='$_GET[phone]' and imei='$_GET[imei]'";
$ru = mysql_query($qu, $connect);
$du = mysql_fetch_array($ru);

//ȸ������ ������ ����
if($du[0] == 0) exit;
  
$q = "select * from android_data where no='$_GET[no]' and reader_number='$_GET[phone]' and reader_imei='$_GET[imei]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);


$qus = "select * from android_member where phone='$d[writer_number]' and imei='$d[writer_imei]'";
$rus = mysql_query($qus, $connect);
$dus = mysql_fetch_array($rus);

//���� ���
echo $d[sang]."-=-".$d[sangmemo]."-=-".$d[sangtime]."-=-".$d[ha]."-=-".$d[hatime]."-=-".$d[objectname]."-=-".$d[car]."-=-".$d[ton]."-=-".$d[p1]."-=-".$d[money1]."-=-".$d[memo]."-=-".$d[no]."-=-".$d[status]."-=-".$dus[name]."-=-".$dus[phone]."-=-".$d[status]."-=-".$d[writer_time]."-=-".$d[writer_time_t]."-=-".$d[reader_time]."-=-".$d[reader_time_t]."-=-".$d[p2]."-=-".$d[dh]."-=-".$d[money2]."-=-".$d[sangbang]."-=-".$d[habang]."-=-".$d[money2]."-=-";
?>