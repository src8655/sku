<?
include "lib.php";

$q = "select count(*) from android_member where phone='$_GET[phone]' and imei='$_GET[imei]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);
if($d[0] == 0) {
  echo("AA-=-");
}else{
  echo("BB-=-");
}
?>