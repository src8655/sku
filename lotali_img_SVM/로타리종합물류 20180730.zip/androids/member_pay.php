<?
include "lib.php";

?>