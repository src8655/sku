<?
// 화물가져가기페이지

include "lib.php";

//전화번호 imei 없으면 종료
if(!$_GET[phone]) exit;
if(!$_GET[imei]) exit;

$qu = "select count(*) from android_member where phone='$_GET[phone]' and imei='$_GET[imei]'";
$ru = mysql_query($qu, $connect);
$du = mysql_fetch_array($ru);

//회원정보가 없으면 종료
if($du[0] == 0) exit;
if($md[admins] == 1) exit;
if($md[cants] == 1) exit;




$todays = date("Y").date("m").date("d");

$qs = "select count(*) from android_data where reader_time='$todays' and reader_number='$md[phone]' and reader_imei='$md[imei]' and status='2'";
$rs = mysql_query($qs, $connect);
$ds = mysql_fetch_array($rs);

if($ds[0] >= 2) exit;






  
$q = "select * from android_data where no='$_GET[no]'";
$r = mysql_query($q, $connect);
$d = mysql_fetch_array($r);

//라보~1t:2500원
//2.5~3.5t:3000원
//5톤:4000원
//8톤~25톤:5000원
$cmmoney = 5000;
if(($md[ton] == "1t")||($md[ton] == "1.4t")||($md[car] == "다마스")||($md[car] == "라보"))
			$cmmoney = 2500;
		else if(($md[ton] == "2.5t")||($md[ton] == "3.5t"))
			$cmmoney = 3000;
		else if(($md[ton] == "5t"))
			$cmmoney = 4000;
		else $cmmoney = 5000;
if($md[admins] == 2) $cmmoney = 0;

//상태(status)가 대기(1)상태가 아니거나
//또는 내 금액이 알선료+톤당가격 보다 작을때
//에러표시
if(($d[status] != 1)||($md[mymoney]<(($d[money2]*1000)+$cmmoney))) {
  echo "err"."-=-";
}else{
  
  //게시글 상태 변경
  $read_times = time();
  $sdf1 = date("Y").date("m").date("d");
  $c = date("H").":".date("i");
  $sdf2 = 2;//완료상태로 변경
  $q1 = "update android_data set
         reader_number='$_GET[phone]',
         reader_imei='$_GET[imei]',
         reader_time='$sdf1',
         status='$sdf2',
         reader_time_t='$c',
         read_time='$read_times' where no='$_GET[no]' and status='1'";
  mysql_query($q1, $connect);
  
  
  
  
  //내 가상계좌 금액 변경
  $chm = $md[mymoney]-(($d[money2]*1000)+$cmmoney);
  
  $q2 = "update android_member set
          mymoney='$chm' where phone='$md[phone]' and imei='$md[imei]'";
  mysql_query($q2, $connect);
  
  //거래내역에 추가
  $tomoney = -(($d[money2]*1000)+$cmmoney);
  $tomemo = "화물선택";
  $todays2 = date("Y").date("m").date("d");
  $qpays = "insert into android_pay(dates, money, memo, phone, imei, money2)
            values('$todays2','$tomoney','$tomemo','$md[phone]','$md[imei]','$chm')";
  mysql_query($qpays, $connect);
  
  //알선료가 존재하면
  if($d[money2] != 0) {
    $qe = "select * from android_member where phone='$d[writer_number]' and imei='$d[writer_imei]'";
    $re = mysql_query($qe, $connect);
    $de = mysql_fetch_array($re);
    
    //화주에게 알선료 입금
    $chm2 = $de[mymoney]+($d[money2]*1000);
    $q3 = "update android_member set
            mymoney='$chm2' where phone='$de[phone]' and imei='$de[imei]'";
    mysql_query($q3, $connect);
    
    //거래내역에 추가
    $tomoneys = $d[money2]*1000;
    $tomemos = "알선료";
    $todays2s = date("Y").date("m").date("d");
    $qpayss = "insert into android_pay(dates, money, memo, phone, imei, money2)
              values('$todays2s','$tomoneys','$tomemos','$de[phone]','$de[imei]','$chm2')";
    mysql_query($qpayss, $connect);
  }
  
  //기사에게 화주정보 전송
  $qus = "select * from android_member where phone='$d[writer_number]' and imei='$d[writer_imei]'";
  $rus = mysql_query($qus, $connect);
  $dus = mysql_fetch_array($rus);
  echo $dus[name]."-=-".$dus[phone]."-=-";
}
?>