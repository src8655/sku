<?
$connect = mysql_connect("localhost","lsm8655","snrnsi11"); 
mysql_select_db("lsm8655", $connect);

mysql_query("set names utf8");

if(($_GET[phone] != "") && ($_GET[imei] != "")) {
  //회원정보 불러오기
  $mq = "select * from android_member where phone='$_GET[phone]' and imei='$_GET[imei]'";
  $mr = mysql_query($mq, $connect);
  $md = mysql_fetch_array($mr);
  
  
  $todaydate1 = date("Y");
  $todaydate2 = date("m");
  $todaydate = $todaydate1.$todaydate2;
  
  if($md[admins] == 2) {
    $qos = "select count(*) from android_member_pay where phone='$md[phone]' and imei='$md[imei]' and dates='$todaydate'";
    $ros = mysql_query($qos, $connect);
    $dos = mysql_fetch_array($ros);
    if($dos[0] == 0) {
      //한달결재 금액이 부족하면 err전달
      if($md[mymoney]<20000) {
        $qpays = "update android_member set
                  cants='1' where phone='$md[phone]' and imei='$md[imei]'";
        mysql_query($qpays, $connect);
        echo "err-=-";
      }else{
        //한달마다 20000원 결재
        
        $cmmoneyyy = $md[mymoney]-20000;
        $qpay = "update android_member set
                  mymoney='$cmmoneyyy',
                  cants='0' where phone='$md[phone]' and imei='$md[imei]'";
        mysql_query($qpay, $connect);
        $dtimes = time();
        $qpayin = "insert into android_member_pay(phone, imei, dates, times)
                    values('$md[phone]','$md[imei]','$todaydate','$dtimes')";
        mysql_query($qpayin, $connect);
        
        //거래내역에 추가
        $tomoneyd = -20000;
        $tomemod = "한달결제";
        $todays2d = date("Y").date("m").date("d");
        $qpaysd = "insert into android_pay(dates, money, memo, phone, imei, money2)
                  values('$todays2d','$tomoneyd','$tomemod','$md[phone]','$md[imei]','$cmmoneyyy')";
        mysql_query($qpaysd, $connect);
      }
    }
  }
  
}
?>