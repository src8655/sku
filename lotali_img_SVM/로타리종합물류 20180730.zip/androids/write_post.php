<?
//게시글 작성하기

include "lib.php";

//전화번호 imei 없으면 종료
if(!$_GET[phone]) exit;
if(!$_GET[imei]) exit;

$qu = "select count(*) from android_member where phone='$_GET[phone]' and imei='$_GET[imei]'";
$ru = mysql_query($qu, $connect);
$du = mysql_fetch_array($ru);

//회원정보가 없으면 종료
if($du[0] == 0) exit;

//알선소 회원이 아닌데 알선료를 입력시 에러
if(($md[admins] != 1)&&($_GET[p3] != "")) {
  echo "err-=-";
  exit;
  }


//톤수별로 그룹 나눔
if(($_GET[ton] == "1t")||($_GET[ton] == "1.4t")||($_GET[car] == "라보")||($_GET[ton] == "1t미만")||($_GET[car] == "다마스"))
$ls = 1;
else if(($_GET[ton] == "2.5t")||($_GET[ton] == "3.5t")) $ls = 2;
else $ls = 3;




$_GET[hwa] = str_replace("\n"," ",$_GET[hwa]);
$_GET[sangsang] = str_replace("\n"," ",$_GET[sangsang]);
$_GET[ha] = str_replace("\n"," ",$_GET[ha]);
$_GET[p1] = str_replace("\n"," ",$_GET[p1]);
$_GET[p2] = str_replace("\n"," ",$_GET[p2]);



$times = time();
$a = 1;
$b = date("Y").date("m").date("d");
$c = date("H").":".date("i");

//게시글 작성
$q = "insert into android_data(sang, sangmemo, sangtime, ha, hatime, objectname, pay, car, ton, money1, memo, writer_number, writer_imei, writer_time, status, list_status, writer_time_t, dh, p1, p2, times, money2, sangbang, habang)
      values('$_GET[ji]','$_GET[sangsang]','$_GET[sangtime]','$_GET[ha]','$_GET[hatime]','$_GET[hwa]','$_GET[pay]','$_GET[car]','$_GET[ton]','$_GET[money]','$_GET[memo]','$_GET[phone]','$_GET[imei]','$b','$a','$ls','$c','$_GET[hon]','$_GET[p1]','$_GET[p2]','$times','$_GET[p3]','$_GET[p4]','$_GET[p5]')";
mysql_query($q, $connect);
?>