<?
include "libs.php";
include "head2.php";

if(!$dlog[no]) {
	$oldl = "1";
}else{
	$oldl = $dlog[level];
}

if($oldl != 3) {


if(!$id) {
	echo("
		<script>
			window.alert('잘못된 접근입니다.')
			history.go(-1)
		</script>
	");
	exit;
}
if(!$no) {
	echo("
		<script>
			window.alert('잘못된 접근입니다.')
			history.go(-1)
		</script>
	");
	exit;
}
if(!$dlog[no]) {
if(!$passz) {
	echo("
		<script>
			window.alert('비밀번호를 입력해주세요.')
			history.go(-1)
		</script>
	");
	exit;
}}

$qcommdel = "select * from ho_board_comment where no='$no'";
$rcommdel = mysql_query($qcommdel, $connect);
$dcommdel = mysql_fetch_array($rcommdel);

if($dcommdel[password] != md5($passz)) {
	echo("
		<script>
			window.alert('비밀번호가 다릅니다.')
			history.go(-1)
		</script>
	");
	exit;
}

}

$qcommdelp = "delete from ho_board_comment where no='$no'";
mysql_query($qcommdelp, $connect);
?>
<script>
	location.href="board_view.php?no=<?=$ano?>&id=<?=$id?>";
</script>
<?
include "foot2.php";
?>
