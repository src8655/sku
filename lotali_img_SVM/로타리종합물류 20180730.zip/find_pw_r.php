<?
include "libs.php";
include "head2.php";

$qfinds = "select * from ho_board_member where user_id='$user_id' and name='$name' and email='$email' and birth='$bir'";
$rfinds = mysql_query($qfinds, $connect);
$dfinds = mysql_fetch_array($rfinds);

$amm = md5($dfinds[no].$dfinds[user_id].$dfinds[password].$dfinds[name].$dfinds[email].$dfinds[birth]);

if($codes != $amm) {
	echo("
		<script>
			window.alert('인증번호가 다릅니다.')
			history.go(-1)
		</script>
	");
	exit;
}
?>
<div id="site_map">
HOME > <span style="font-weight:bold;">아이디/비밀번호찾기</span>
</div>
<h1 id="home_com1" style="background:url(./images/home_t_find.jpg) no-repeat left top;"></h1>
<div id="home_coml1"><div id="home_coml2"></div></div>
<form action="<?=$PHP_SELF?>">
<input type="hidden" name="user_id" value="<?=$dfinds[user_id]?>" />
<input type="hidden" name="name" value="<?=$dfinds[name]?>" />
<input type="hidden" name="email" value="<?=$dfinds[email]?>" />
<input type="hidden" name="bir" value="<?=$dfinds[birth]?>" />
<input type="hidden" name="codes" value="<?=$codes?>" />
<table cellpadding="7" cellspacing="0" class="finds" style="margin:0 auto;margin-top:10px;padding:10px;width:300px;">
<col width="150" />
<col width="200" />
<? if(!$dfinds[no]) {?><tr><td>정보가 존재하지 않습니다.</td></tr><? }else{?>
<? if(!$pp_password) {?>
	<tr>
		<th>새로운비밀번호</th>
		<td><input type="password" name="pp_password" /></td>
	</tr>
	<tr>
		<th>비밀번호 확인</th>
		<td><input type="password" name="pp_password2" /></td>
	</tr>
	<tr>
		<td colspan="2" align="center"><input type="submit" value="등록하기" /></td>
	</tr>
<? }else{
if($pp_password != $pp_password2) {
	echo("
		<script>
			window.alert('비밀번호가 다릅니다.')
			history.go(-1)
		</script>
	");
	exit;
}else{
	$_REQUEST[qameer] = md5($pp_password);
	$qq = "update ho_board_member set
					password='$_REQUEST[qameer]' where user_id='$dfinds[user_id]' and name='$dfinds[name]' and email='$dfinds[email]' and no='$dfinds[no]'";
	mysql_query($qq, $connect);
	echo("
		<script>
			window.alert('변경이 완료되었습니다.')
			location.href='index.php';
		</script>
	");
}
?>

<? }}?>
</table>
</form>
<?
include "foot2.php";
?>
