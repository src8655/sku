<?
include "libs.php";
include "head2.php";

if(!$id) {
	echo("
		<script>
			window.alert('잘못된 접근입니다.')
			history.go(-1)
		</script>
	");
	exit;
}

if(!$dlog[no]) {
	$oldl = "1";
}else{
	$oldl = $dlog[level];
}
if($oldl < $dadmin[level_write]) {
	echo("
		<script>
			window.alert('권한이 없습니다.')
			history.go(-1)
		</script>
	");
	exit;
}

if(!$hiddens) {
	echo("
		<script>
			window.alert('자동등록방지를 입력해주세요.')
			history.go(-1)
		</script>
	");
	exit;
}
if($_SESSION["alpau"] != $hiddens) {
	echo("
		<script>
			window.alert('자동등록방지가 틀렸습니다.')
			history.go(-1)
		</script>
	");
	exit;
}
if(!$subject) {
	echo("
		<script>
			window.alert('제목을 입력해주세요.')
			history.go(-1)
		</script>
	");
	exit;
}
if(!$memo) {
	echo("
		<script>
			window.alert('내용을 입력해주세요.')
			history.go(-1)
		</script>
	");
	exit;
}
if(!$name) {
	echo("
		<script>
			window.alert('이름을 입력해주세요.')
			history.go(-1)
		</script>
	");
	exit;
}
if(!$passworde) {
	echo("
		<script>
			window.alert('비밀번호를 입력해주세요.')
			history.go(-1)
		</script>
	");
	exit;
}

$_REQUEST[ips] = $_SERVER[REMOTE_ADDR];
$_REQUEST[rcs] = "1";
$_REQUEST[times] = time()+300;

$ipsl = explode(".",$_SERVER[REMOTE_ADDR]);
$ipsl2 = $ipsl[0].".".$ipsl[1].".".$ipsl[2];

if($dlog[level] != 3) {

$qlimits = "select * from ho_board_limit where ip='$ipsl2' and rc='$_REQUEST[rcs]'";
$rlimits = mysql_query($qlimits, $connect);
$dlimits = mysql_fetch_array($rlimits);

if($dlimits[no]) {
if($dlimits[time]<time()) {
	$qlims = "delete from ho_board_limit where ip='$ipsl2' and rc='$_REQUEST[rcs]'";
	mysql_query($qlims, $connect);
	$qlimsr = "insert into ho_board_limit(rc,ip,time)
					values('$_REQUEST[rcs]','$ipsl2',$_REQUEST[times])";
	mysql_query($qlimsr, $connect);
}else{
	$qlimuz = "select * from ho_board_limit where ip='$ipsl2' and rc='$_REQUEST[rcs]'";
	$rlimuz = mysql_query($qlimuz, $connect);
	$dlimuz = mysql_fetch_array($rlimuz);
	$ssser = $dlimuz[count]+1;
	$qlimu = "update ho_board_limit set
						count='$ssser' where ip='$ipsl2' and rc='$_REQUEST[rcs]'";
	mysql_query($qlimu, $connect);
	if($dlimuz[count] >= 5) {
		$qbans = "insert into ho_board_ban(ip)
							values('$ipsl2')";
		mysql_query($qbans, $connect);
	}
	echo("
		<script>
			window.alert('한번 글작성후 5분동안 작성이 불가능합니다. 계속 시도시 접속 불가능합니다.')
			history.go(-1)
		</script>
	");
	exit;
}
}else{
	$qlimsr = "insert into ho_board_limit(rc,ip,time)
						values('$_REQUEST[rcs]','$ipsl2',$_REQUEST[times])";
	mysql_query($qlimsr, $connect);
}}

$_REQUEST[pas] = md5($passworde);
$_REQUEST[dates] = date("m")."/".date("d");
$date2 = date("Y-m-d h:i:s");

$qdda = "insert into ho_board_data(subject,memo,name,password,date,ip,id,secret,date2)
				values('$_REQUEST[subject]','$_REQUEST[memo]','$_REQUEST[name]','$_REQUEST[pas]','$_REQUEST[dates]','$_REQUEST[ips]','$_REQUEST[id]','$_REQUEST[secret]','$date2')";
mysql_query($qdda, $connect);
?>
<script>
	location.href="board.php?id=<?=$id?>";
</script>
<?
include "foot2.php";
?>
