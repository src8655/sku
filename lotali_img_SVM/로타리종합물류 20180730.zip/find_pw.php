<?
include "libs.php";
include "head2.php";

if(!$user_id) {
	echo("
		<script>
			window.alert('아이디를 입력해주세요')
			history.go(-1)
		</script>
	");
	exit;
}
if(!$name) {
	echo("
		<script>
			window.alert('이름을 입력해주세요')
			history.go(-1)
		</script>
	");
	exit;
}
if(!$email) {
	echo("
		<script>
			window.alert('이메일을 입력해주세요')
			history.go(-1)
		</script>
	");
	exit;
}

$bir = $birthy."-".$birthm."-".$birthd;

$qfinds = "select * from ho_board_member where user_id='$user_id' and name='$name' and email='$email' and birth='$bir'";
$rfinds = mysql_query($qfinds, $connect);
$dfinds = mysql_fetch_array($rfinds);
?>
<div id="site_map">
HOME > <span style="font-weight:bold;">아이디/비밀번호찾기</span>
</div>
<h1 id="home_com1" style="background:url(./images/home_t_find.jpg) no-repeat left top;"></h1>
<div id="home_coml1"><div id="home_coml2"></div></div>
<form action="find_pw_r.php">
<input type="hidden" name="user_id" value="<?=$dfinds[user_id]?>" />
<input type="hidden" name="name" value="<?=$dfinds[name]?>" />
<input type="hidden" name="email" value="<?=$dfinds[email]?>" />
<input type="hidden" name="bir" value="<?=$dfinds[birth]?>" />
<table cellpadding="7" cellspacing="0" class="finds" style="margin:0 auto;margin-top:10px;padding:10px;width:350px;">
<? if(!$dfinds[no]) {?><tr><td>정보가 존재하지 않습니다.</td></tr><? }else{?>
	<tr>
		<th>인증코드</th>
		<td><input type="text" name="codes" style="float:left;" /><a href="find_m.php?user_id=<?=$user_id?>&amp;name=<?=$name?>&amp;email=<?=$email?>&amp;bir=<?=$bir?>" target="_blank">인증코드 발송</a></td>
	</tr>
	<tr>
		<td colspan="2" align="center"><input type="submit" value="등록하기" /></td>
	</tr>
<? }?>
</table>
</form>
<?
include "foot2.php";
?>
