<?
include "libs.php";

$alpak = md5($myip.time().rand(0,50));
$_SESSION["alpau"] = mb_substr($alpak,2,4);

include "head2.php";

if(!$id) {
	echo("
		<script>
			window.alert('잘못된 접근입니다.')
			history.go(-1)
		</script>
	");
	exit;
}

if(!$dlog[no]) {
	$oldl = "1";
}else{
	$oldl = $dlog[level];
}
if($oldl < $dadmin[level_write]) {
	echo("
		<script>
			window.alert('권한이 없습니다.')
			history.go(-1)
		</script>
	");
	exit;
}
?>
<div class="boards_header">
	<p style="float:left;">글쓰기</p>
	<p style="float:right;text-align:right;">
<? if(!$dlog[no]) {?>
		<a href="login.php">로그인</a>
		&nbsp;
		<a href="join.php">회원가입</a>
<? }else{?>
		<span style="font-weight:bold;"><?=$dlog[name]?></span>님 환영합니다.
<? }?>
	</p>
</div>
<form name="wt_b" action="board_write_post.php" method="post">
<input type="hidden" name="id" value="<?=$id?>" />
<table cellpadding="7" cellspacing="0" class="boards">
<col width="90" />
<col width="410" />
	<tr class="boards_t">
		<th style="background:#d5e9ff;">제목</th>
		<th><input type="text" name="subject" style="width:402px;height:25px;line-height:25px;" /></th>
	</tr>
	<tr>
		<th style="background:#d5e9ff;border:none;border-bottom:1px solid #A0A0A0;">비밀글</th>
		<td style="padding:0 0 0 3px;"><input type="checkbox" name="secret" value="1" style="width:15px;height:15px;border:0px;" /> 본인과 관리자만 볼 수 있습니다.</td>
	</tr>
	<tr <? if($dlog[no]) {?>style="display:none;"<? }?>>
		<th style="background:#d5e9ff;border:none;border-bottom:1px solid #A0A0A0;">이름</th>
		<td style="padding:0 0 0 3px;"><input type="text" name="name" value="<?=$dlog[name]?>" /></td>
	</tr>
	<tr <? if($dlog[no]) {?>style="display:none;"<? }?>>
		<th style="background:#d5e9ff;border:none;border-bottom:1px solid #A0A0A0;">비밀번호</th>
		<td style="padding:0 0 0 3px;"><input type="password" name="passworde" value="<?=$dlog[password]?>" /></td>
	</tr>
</table>
<table cellpadding="7" cellspacing="0" style="width:100%;">
	<tr>
		<td align="center"><textarea name="memo" rows="100" cols="100" id="b_memo"></textarea></td>
	</tr>
</table>

<table cellpadding="7" cellspacing="0" class="boards" style="border-top:1px solid #A0A0A0;">
<col width="90" />
<col width="410" />
	<tr>
		<th style="background:#d5e9ff;border:none;border-bottom:1px solid #A0A0A0;">자동등록방지</th>
		<td style="padding:0 0 0 3px;">
			<div style="float:left;border:1px solid #bbbbbb;height:25px;padding:0 5px 0 5px;line-height:25px;">
<?
$amu = 0;
$abran = rand(1,2);
for($i=2;$i<=8;$i++) {
$alpa = rand(1,36);
if($alpa == 1) $alpar = "a";
if($alpa == 2) $alpar = "b";
if($alpa == 3) $alpar = "c";
if($alpa == 4) $alpar = "d";
if($alpa == 5) $alpar = "e";
if($alpa == 6) $alpar = "f";
if($alpa == 7) $alpar = "g";
if($alpa == 8) $alpar = "h";
if($alpa == 9) $alpar = "i";
if($alpa == 10) $alpar = "j";
if($alpa == 11) $alpar = "k";
if($alpa == 12) $alpar = "l";
if($alpa == 13) $alpar = "n";
if($alpa == 14) $alpar = "m";
if($alpa == 15) $alpar = "o";
if($alpa == 16) $alpar = "p";
if($alpa == 17) $alpar = "q";
if($alpa == 18) $alpar = "r";
if($alpa == 19) $alpar = "s";
if($alpa == 20) $alpar = "t";
if($alpa == 21) $alpar = "u";
if($alpa == 22) $alpar = "v";
if($alpa == 23) $alpar = "w";
if($alpa == 24) $alpar = "x";
if($alpa == 25) $alpar = "y";
if($alpa == 26) $alpar = "z";
if($alpa == 27) $alpar = "0";
if($alpa == 28) $alpar = "1";
if($alpa == 29) $alpar = "2";
if($alpa == 30) $alpar = "3";
if($alpa == 31) $alpar = "4";
if($alpa == 32) $alpar = "5";
if($alpa == 33) $alpar = "6";
if($alpa == 34) $alpar = "7";
if($alpa == 35) $alpar = "8";
if($alpa == 36) $alpar = "9";
?>
<?=$alpar?><? if($i%$abran==0) {?><span style="color:red;font-weight:bold;"><?=mb_substr($_SESSION["alpau"],$amu,1)?></span><? $amu++; }?>
<?
}
?>
			</div>
			<input type="text" name="hiddens" style="width:70px;float:left;margin:0 0 0 10px;" />
			<div style="float:left;height:25px;line-height:25px;margin:0 0 0 10px;">빨간 글자만 입력하세요.</div>
		</td>
	</tr>
</table>
<div class="boards_b">
	<div class="boards_bl">
		<a href="board.php?id=<?=$id?>" style="background:url(./images/home_boardbutton1.jpg) no-repeat left top;"></a>
	</div>
	<div class="boards_br">
		<input type="button" onclick="submits('<?=$_SESSION[alpau]?>');" value="&nbsp;" style="background:url(./images/home_boardbutton3.jpg) no-repeat left top;" />
	</div>
</div>
</form>

<?
include "foot2.php";
?>
