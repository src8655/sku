<?
include "libs.php";
include "head2.php";

if(!$id) {
	echo("
		<script>
			window.alert('잘못된 접근입니다.')
			history.go(-1)
		</script>
	");
	exit;
}

if(!$dlog[no]) {
	$oldl = "1";
}else{
	$oldl = $dlog[level];
}
if($oldl < $dadmin[level_write]) {
	echo("
		<script>
			window.alert('권한이 없습니다.')
			history.go(-1)
		</script>
	");
	exit;
}

$qedit = "select * from ho_board_data where no='$no' and id='$id'";
$redit = mysql_query($qedit, $connect);
$dedit = mysql_fetch_array($redit);

if(!$passworde) {
	echo("
		<script>
			window.alert('비밀번호를 입력해주세요.')
			history.go(-1)
		</script>
	");
	exit;
}

if($dedit[password] != md5($passworde)) {
	echo("
		<script>
			window.alert('비밀번호가 다릅니다.')
			history.go(-1)
		</script>
	");
	exit;
}

$qepo = "update ho_board_data set
				subject='$_REQUEST[subject]',
				name='$_REQUEST[name]',
				memo='$_REQUEST[memo]',
				secret='$_REQUEST[secret]' where id='$id' and no='$no'";
mysql_query($qepo, $connect);
?>
<script>
	location.href="board_view.php?no=<?=$no?>&id=<?=$id?>"
</script>
<?
include "foot2.php";
?>
