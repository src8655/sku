<?
include "libs.php";

$qview = "select * from ho_board_data where id='$id' and no='$no'";
$rview = mysql_query($qview, $connect);
$dview = mysql_fetch_array($rview);
$dates = explode(" ",$dview[date2]);

if(!ereg($dview[no],$boardhit)) {
$hits = $dview[hit]+1;
$qhit = "update ho_board_data set
					hit='$hits' where id='$dview[id]' and no='$dview[no]'";
mysql_query($qhit, $connect);

$temps = $boardhit."//".$dview[no];

setcookie("boardhit",$temps,time()+100000,"/");
}


$alpak = md5($myip.time().rand(0,50));
$_SESSION["alpau"] = mb_substr($alpak,2,4);

include "head2.php";


if(!$id) {
	echo("
		<script>
			window.alert('잘못된 접근입니다.')
			history.go(-1)
		</script>
	");
	exit;
}

if(!$dlog[no]) {
	$oldl = "1";
}else{
	$oldl = $dlog[level];
}
if($oldl < $dadmin[level_read]) {
	echo("
		<script>
			window.alert('권한이 없습니다.')
			history.go(-1)
		</script>
	");
	exit;
}


if($dlog[no]) {
  $passz = $dlog[password];
  }

$passzs = md5($passz);

if($dlog[level] != 3) {
if($dview[secret] == 1) {
if($passz) {
if($passzs == $dview[password]) {
  $dview[secret] = 0;
  }else{
    echo("
      <script>
        window.alert('비밀번호가 다릅니다.')
        history.go(-2)
      </script>
    ");
    exit;
    }
}}
}else{
	$dview[secret] = 0;
}
if($dview[secret] != 1) {

?>
<div class="boards_header">
	<p style="float:left;">글보기</p>
	<p style="float:right;text-align:right;">
<? if(!$dlog[no]) {?>
		<a href="login.php">로그인</a>
		&nbsp;
		<a href="join.php">회원가입</a>
<? }else{?>
		<span style="font-weight:bold;"><?=$dlog[name]?></span>님 환영합니다.
<? }?>
	</p>
</div>
<table cellpadding="7" cellspacing="0" class="boards">
<col width="100" />
<col width="380" />
<col width="100" />
<col width="120" />
	<tr class="boards_t">
		<th style="background:#d5e9ff;">제목</th>
		<th align="left" style="padding:0 0 0 10px;"><?=mb_substr($dview[subject],0,28,'euc-kr')?></th>
		<th style="background:#d5e9ff;">조회</th>
		<th align="right" style="padding:0 10px 0 0;"><?=$dview[hit]?></th>
	</tr>
	<tr>
		<th style="background:#d5e9ff;border:none;border-bottom:1px solid #A0A0A0;">이름</th>
	  <td style="padding:0 0 0 10px;font-weight:bold;"><?=$dview[name]?></td>
		<th style="background:#d5e9ff;border:none;border-bottom:1px solid #A0A0A0;">날짜</th>
	  <td align="right" style="padding:0 10px 0 0;font-weight:bold;"><?=$dates[0]?></td>
	</tr>
	<tr>
		<td colspan="4" style="padding:30px 7px 30px 7px;"><?=nl2br($dview[memo])?></td>
	</tr>
</table>
<?
if($id != "notice") {
?>
<?
$qcomm = "select * from ho_board_comment where linkno='$no' order by no asc";
$rcomm = mysql_query($qcomm, $connect);

while($dcomm = mysql_fetch_array($rcomm)) {
$ipzg = explode(".",$dcomm[ip]);
?>
<table cellpadding="7" cellspacing="0" class="comments">
<col width="100" />
<col width="400" />
	<tr>
		<th style="background:#d5e9ff;border:none;border:1px solid #A0A0A0;"><?=$dcomm[name]?>
			<span style="font-weight:normal;">
				<br /><?=$dcomm[date]?><br />
				<a <? if($dlog[no]) {?>href="board_comment_del_post.php?no=<?=$dcomm[no]?>&amp;id=<?=$id?>&amp;ano=<?=$no?>&amp;passz=<?=$dlog[password]?>"<? }else{?>href="board_comment_del.php?no=<?=$dcomm[no]?>&amp;id=<?=$id?>&amp;ano=<?=$no?>"<? }?>>[삭제]</a>
			</span>
		</th>
		<td valign="top">
			<?=nl2br($dcomm[memo])?>
		</td>
	</tr>
</table>
<?
}
?>
<form name="cm_b" action="board_comment.php">
<input type="hidden" name="linkno" value="<?=$no?>" />
<input type="hidden" name="id" value="<?=$id?>" />
<table cellpadding="7" cellspacing="0" class="comments">
<col width="120" />
<col width="200" />
<col width="120" />
<col width="80" />
<col width="80" />
	<tr style="<? if($dlog[no]) {?>display:none;<? }?>">
		<th style="background:#d5e9ff;border-left:1px solid #bbbbbb;">이름</th>
		<td style="border-top:1px solid #122942;"><input type="text" name="name" value="<?=$dlog[name]?>" /></td>
		<th style="background:#d5e9ff;">비밀번호</th>
		<td colspan="2" style="border-top:1px solid #122942;"><input type="password" name="passz" value="<?=$dlog[password]?>" /></td>
	</tr>
	<tr>
		<th style="background:#d5e9ff;border:1px solid #bbbbbb;">자동등록방지</th>
		<td colspan="4">
			<div style="float:left;border:1px solid #bbbbbb;height:22px;margin:0 0 0 10px;padding:0 5px 0 5px;line-height:22px;">
<?
$amu = 0;
$abran = rand(1,2);
for($i=2;$i<=8;$i++) {
$alpa = rand(1,36);
if($alpa == 1) $alpar = "a";
if($alpa == 2) $alpar = "b";
if($alpa == 3) $alpar = "c";
if($alpa == 4) $alpar = "d";
if($alpa == 5) $alpar = "e";
if($alpa == 6) $alpar = "f";
if($alpa == 7) $alpar = "g";
if($alpa == 8) $alpar = "h";
if($alpa == 9) $alpar = "i";
if($alpa == 10) $alpar = "j";
if($alpa == 11) $alpar = "k";
if($alpa == 12) $alpar = "l";
if($alpa == 13) $alpar = "n";
if($alpa == 14) $alpar = "m";
if($alpa == 15) $alpar = "o";
if($alpa == 16) $alpar = "p";
if($alpa == 17) $alpar = "q";
if($alpa == 18) $alpar = "r";
if($alpa == 19) $alpar = "s";
if($alpa == 20) $alpar = "t";
if($alpa == 21) $alpar = "u";
if($alpa == 22) $alpar = "v";
if($alpa == 23) $alpar = "w";
if($alpa == 24) $alpar = "x";
if($alpa == 25) $alpar = "y";
if($alpa == 26) $alpar = "z";
if($alpa == 27) $alpar = "0";
if($alpa == 28) $alpar = "1";
if($alpa == 29) $alpar = "2";
if($alpa == 30) $alpar = "3";
if($alpa == 31) $alpar = "4";
if($alpa == 32) $alpar = "5";
if($alpa == 33) $alpar = "6";
if($alpa == 34) $alpar = "7";
if($alpa == 35) $alpar = "8";
if($alpa == 36) $alpar = "9";
?>
<?=$alpar?><? if($i%$abran==0) {?><span style="color:red;font-weight:bold;"><?=mb_substr($_SESSION["alpau"],$amu,1)?></span><? $amu++; }?>
<?
}
?>
			</div>
			<input type="text" name="hiddens" style="width:70px;float:left;margin:0 0 0 10px;" />
			<div style="float:left;height:22px;line-height:22px;margin:0 0 0 10px;">빨간 글자만 입력하세요.</div>
		</td>
	</tr>
	<tr>
		<td style="border-left:none;border-right:none;" colspan="4"><textarea name="memo" rows="100" cols="100" editable="0" style="width:98%;height:40px;"></textarea></td>
		<td style="border-left:none;border-right:none;"><input type="button" onclick="submits3('<?=$_SESSION[alpau]?>');" value="등록" style="background:#d5e9ff;border:1px solid #122942;width:70px;height:45px;font-size:12px;font-weight:bold;" /></td>
	</tr>
</table>
</form>
<?
}
?>
<div class="boards_b">
	<div class="boards_bl">
		<a href="board.php?id=<?=$id?>&amp;page=<?=$page?>" style="background:url(./images/home_boardbutton1.jpg) no-repeat left top;"></a>
	</div>
	<div class="boards_br" style="width:300px;">
		<a <? if($dlog[no]) {?>href="board_del_post.php?id=<?=$dview[id]?>&amp;no=<?=$dview[no]?>&amp;passz=<?=$dlog[password]?>"<? }else{?>href="board_del.php?id=<?=$dview[id]?>&amp;no=<?=$dview[no]?>"<? }?> style="background:url(./images/home_del.jpg) no-repeat left top;float:right;margin:0 10px 0 0;"></a>
		<a href="board_edit.php?id=<?=$dview[id]?>&amp;no=<?=$dview[no]?>" style="background:url(./images/home_editb.jpg) no-repeat left top;float:right;margin:0 10px 0 0;"></a>
	</div>
</div>
<?
}else{
?>
<form action="<?=$PHP_SELF?>" method="post">
<input type="hidden" name="id" value="<?=$id?>" />
<input type="hidden" name="no" value="<?=$no?>" />
<input type="hidden" name="page" value="<?=$page?>" />
<table cellpadding="7" cellspacing="0" class="boards" style="margin:0 auto;width:300px;margin-top:50px;">
  <tr class="boards_t">
    <th colspan="2">비밀글입니다 비밀번호를 입력해주세요</th>
  </tr>
  <tr>
    <td><input type="password" name="passz" /></td>
    <td><input type="submit" value="입력" /></td>
  </tr>
</table>
</form>
<?
}
?>
<?
include "foot2.php";
?>
