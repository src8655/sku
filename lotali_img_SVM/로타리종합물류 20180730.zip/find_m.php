<?
include "libs.php";

$qfinds = "select * from ho_board_member where user_id='$user_id' and name='$name' and email='$email' and birth='$bir'";
$rfinds = mysql_query($qfinds, $connect);
$dfinds = mysql_fetch_array($rfinds);

$subject = $user_id." 인증번호 입니다";

$headers = 'From: '."로타리종합물류"."\r\n";

$memos = "인증코드 : ".md5($dfinds[no].$dfinds[user_id].$dfinds[password].$dfinds[name].$dfinds[email].$dfinds[birth]);

mail($dfinds[email],$subject,$memos,$headers);
?>
<script type="text/javascript">
	self.close();
</script>
